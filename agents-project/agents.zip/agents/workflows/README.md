# Workflow Graphs

This directory contains draft workflow graphs for the orchestration layer of the agent ecosystem.

The purpose of these graphs is not to replace the existing `.agent.md` files. It is to make control flow explicit, reviewable, and eventually machine-checkable.

In this model:

- the workflow graph defines **process**
- the agent spec defines **behavior**

That separation matters. Today, much of the orchestration logic lives inside long prose prompts. The graphs make routing, branches, gates, retries, and escalation paths visible as first-class workflow structure.

---

## What is here

### `delivery-orchestrator.dot`

An explicit graph for intake and routing:

- project readiness check
- hotfix detection
- input inspection
- delivery track resolution
- path A / B / C / D routing
- optional planning gate
- handoff verification
- post-workflow next-step recommendation
- telemetry coverage guidance
- escalation

### `pipeline-conductor.dot`

An explicit graph for the end-to-end delivery pipeline:

- input validation
- requirements gate
- full vs lean path
- domain alignment
- NFR alignment
- architecture and C4 compliance
- optional Catala path
- specs
- test generation
- implementation
- UI / E2E branch
- documentation sync
- contract drift gate
- code review
- deployment gate
- status sync
- branch / PR / merge
- optional release
- final verification

### `verification-gate.dot`

An explicit graph for readiness and completion verification:

- claim restatement
- proof-source identification
- fresh evidence inspection
- verified vs blocked vs needs-more-evidence routing
- remediation or escalation before success claims continue

### `hotfix-conductor.dot`

An explicit graph for the abbreviated hotfix path:

- stack resolution
- incident triage
- revert vs targeted-fix branch
- contract drift gate for risky schema and DTO changes
- fast review
- deploy confirmation
- smoke verification
- post-mortem tracking

### `change-request-conductor.dot`

An explicit graph for scoped post-delivery amendments:

- CR validation
- scope fence
- delta requirements
- delta specs
- optional legal delta
- contract drift gate for DTO, API, mapper, and schema changes
- implementation and review
- optional docs delta
- completion verification

### `cv-rfp-conductor.dot`

An explicit graph for candidate-specific CV response work inside the current project repo:

- request validation and mode resolution
- markdown-normalized intake package
- host-project context discovery
- won/lost corpus discovery
- candidate fit mapping
- reference optimization for slightly similar candidate-owned references
- response drafting
- red-team review
- claim evidence audit
- optional legal review
- final readiness close

### `release-manager.dot`

An explicit graph for release and rollback orchestration:

- release planning
- release notes
- pre-deployment checks
- tag and deploy confirmation
- smoke verification
- status updates
- rollback path
- completion reporting

### `janitor.dot`

An explicit graph for low-risk repository hygiene:

- scope review
- cleanup-plan drafting before edits
- safe-plan decision gate
- ordered minimal cleanup execution
- lightweight verification
- result and report write-out
- skip or block escalation path

---

## How this fits the agent specs

The workflow graphs are designed to work with the structured agent specs introduced in:

- `docs/agent-node-spec-template.md`

The three key control-layer agents already refactored toward this model are:

- `delivery-orchestrator.agent.md`
- `pipeline-conductor.agent.md`
- `verification-gate.agent.md`

And `janitor.agent.md` now follows the same graph-aligned contract for hygiene work.

The intended relationship is:

| Layer | Responsibility |
|---|---|
| `.dot` graph | Node order, branches, gates, retries, escalation paths |
| `.agent.md` spec | Inputs, preconditions, procedure, outputs, evidence rules, failure routing |
| runtime or operator | Executes the graph and invokes the correct agent at each node |

In other words:

- graph says **what happens next**
- agent spec says **what must be true before a node can claim success**

---

## Why this helps

Moving orchestration logic into graphs gives several benefits.

### 1. Control flow becomes explicit

You can review:

- where the workflow starts and exits
- where human approval is required
- which paths are optional
- what happens on failure
- where escalation occurs

### 2. Gates become visible

The current system already has strong gate logic. The graphs make it easier to see:

- which phases are goal gates
- where verification must happen
- where approval boundaries stop progress

### 3. Workflow linting becomes possible

Once a workflow is explicit, it becomes possible to check for:

- unreachable nodes
- missing escalation paths
- direct exit paths without verification
- loops without a stop condition
- missing human gates around risky transitions

### 4. Checkpoint and resume become feasible

A graph runner could later support:

- resume from last completed node
- retry only the failed stage
- preserve evidence across a long run

---

## What this does not do yet

These graphs are **design drafts**, not an active runtime.

Today they do **not**:

- drive execution automatically
- replace the `.agent.md` files
- guarantee that current tooling will parse or run them

They are intentionally written in an Attractor-like DOT style so the ecosystem can move toward graph-driven orchestration later without rethinking the workflow model from scratch.

---

## Adoption path

The recommended adoption path is incremental.

### Step 1: Use the graphs as review artifacts

Treat the graphs as the clearest source of orchestration truth for:

- routing
- stage order
- optional branches
- escalation paths

At this stage, humans still execute the workflow through the existing agent specs.

### Step 2: Keep agent specs graph-aligned

When updating an orchestration agent:

1. update the graph if control flow changes
2. update the `.agent.md` file if node behavior changes
3. keep names and stage boundaries aligned between the two

This is already the direction taken for:

- `delivery-orchestrator`
- `pipeline-conductor`
- `verification-gate`
- `hotfix-conductor`
- `change-request-conductor`
- `cv-rfp-conductor`
- `release-manager`

And the same contract/output schema is now applied in `contract_only` mode to a first downstream reviewer and validator wave:

- `gherkin-minimality-reviewer`
- `petition-translator-reviewer`
- `specs-reviewer`
- `specs-minimality-reviewer`
- `code-reviewer-strict`
- `code-minimality-reviewer`
- `c4-model-validator`
- `user-testing-flow-validator`

And now to a first worker and governance wave as well:

- `petition-translator`
- `specs-translator`
- `tdd-enforcer`
- `c4-architecture-governor`

And now to a first planning and architecture-production wave too:

- `solution-architect`
- `backlog-planner`
- `project-bootstrap`
- `component-assigner`

And now to a first review, tracking, and technical-backlog execution wave:

- `solution-architecture-reviewer`
- `component-mapping-reviewer`
- `sprint-tracker`
- `tech-debt-executor`

And now to a generic utility and meta wave:

- `doc-writer`
- `concept-model-curator`
- `idea-evaluator`
- `case-writer`
- `worker`
- `translator`
- `meta-agent`

### Step 3: Add workflow linting

Before any runtime change, lightweight validation can already be useful:

- ensure graph node names map to documented phases
- ensure all goal gates have an evidence-bearing exit path
- ensure escalation paths exist for blocking states
- ensure no completion path bypasses `verification-gate`
- ensure all nodes are reachable from start and can still reach exit
- ensure no non-exit node becomes a dead end
- ensure decision nodes actually branch
- surface uncontrolled start-to-exit paths with no goal gate or human gate
- ensure graph-aligned agent specs expose the same contract sections
- ensure output contracts use the same report fields and evidence-entry fields
- ensure minimum status vocabulary stays aligned across graph-aligned agents
- ensure graph `condition="outcome=..."` values only use supported status vocabulary
- ensure graph transitions do not reference statuses the paired agent never declares

The first lightweight linter now lives at `scripts/workflow_lint.py` and can be run with:

```bash
python scripts/workflow_lint.py --root .
```

### Step 4: Introduce a runner later

Only once graphs and specs stabilize should a runtime be considered.

That runtime could:

- traverse the graph
- invoke agents by node
- persist checkpoints
- record outcomes
- route on `success`, `blocked`, `needs-more-evidence`, or escalation outcomes

---

## Design conventions

These draft graphs currently use the following conventions.

### Node shapes

- `Mdiamond` = start
- `Msquare` = exit
- `box` = normal execution node
- `diamond` = decision node
- `hexagon` = human gate or escalation point

### Labels

Labels should match the real workflow phase or delegation step as closely as possible.

Examples:

- `Phase 0: Validate Inputs`
- `Phase 3.7: Catala Encoding`
- `Approval Boundary: Petition Drafts`
- `Delegate: pipeline-conductor`

### Goal gates

Nodes marked with `goal_gate=true` are intended as critical stages that should not be bypassed by an exit path without explicit resolution.

### Escalation

Every meaningful failure path should eventually lead to:

- remediation
- user decision
- or explicit stop

Silent fallthrough is the main anti-pattern this approach is meant to remove.

---

## How to extend

When adding a new workflow graph:

1. start with the smallest meaningful orchestrator
2. identify:
   - start
   - exit
   - mandatory gates
   - optional branches
   - escalation paths
3. keep node labels aligned with real phase names
4. avoid embedding too much execution detail in the graph; keep detailed behavior in the node spec

When adding or refactoring an agent for graph alignment:

1. use `docs/agent-node-spec-template.md`
2. declare `workflow_role` and exhaustive `graph_node_ids` coverage for every non-start/non-exit node in the same-name workflow
3. make inputs, outputs, evidence, and failure routing explicit
4. preserve the distinction between:
   - process logic in the graph
   - execution logic in the agent spec

---

## Recommended next steps

With the current control layer now graph-aligned and contract-checked, the next hardening priorities are:

1. **Extend the standard node contract beyond the control layer.**
   Apply the same exact section skeleton to the remaining niche generators, auditors, and project-specific utility agents not yet brought under the shared contract.

2. **Extend the shared output and evidence schema beyond the control layer.**
   Reuse the same report fields and evidence-entry fields in the remaining niche generators, auditors, and utility outputs so handoffs stay machine-checkable end to end.

3. **Tighten linting further.**
   Add checks for edge-condition vocabulary, status-transition consistency, and stronger graph/spec coverage guarantees.

4. **Only then consider a runtime.**
   A runner becomes much easier to introduce once graph structure, node contracts, and evidence semantics are already stable.

---

## Bottom line

These graphs are a bridge between prompt-only orchestration and a more robust workflow system.

They are useful immediately as:

- review artifacts
- design documentation
- a source of workflow truth

And they create a clean path toward a future runtime where:

- workflow control is graph-driven
- node behavior is contract-driven
- verification is enforced structurally rather than implied by prompt prose
