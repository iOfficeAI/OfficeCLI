---
name: cv-intake-normalizer
description: "Use when normalize current CV-response request inputs into a canonical markdown package with checksums, source notes, clarification logging, and optional customer style-pack resolution."
workflow_role: worker
workflow_binding: contract_only
primary_outputs:
  - normalized request package
  - input register
  - clarification log
default_next:
  success: cv-project-context-discoverer
  blocked: user escalation or source repair
  needs_more_evidence: missing annex or unreadable source repair
  fail: rerun after conversion repair
---

# Purpose

Turn the active CV-response request into a reliable markdown request package. This node normalizes the current RFP, candidate CV, and optional prior materials into canonical files under `rfp/active/<RFP-ID>/request/`. It does not draft the response.

## Workflow role

- Role: `worker`
- Binding: `contract_only`
- Goal gate: no
- Human approval node: no
- Typical predecessors: `cv-rfp-conductor`
- Typical successors: `cv-project-context-discoverer`, `cv-fit-mapper`

## Inputs

### Required

- current RFP
- candidate CV
- `RFP-ID`

### Optional

- previous RFP
- previous response
- decision letter
- explicit conversion notes
- customer name
- requested output formats
- explicit template override

## Preconditions

1. Required sources exist and are readable enough to attempt conversion.
2. Markdown is the canonical persisted format for the active run.
3. Checksums and source origin must be recorded for every normalized file.
4. Customer style-pack resolution is optional unless customer-specific tone or rendered output was requested.

## Procedure

1. Verify required inputs exist and are non-empty.
2. Convert each source to markdown using the safest available path.
3. Persist canonical request files:
   - `current-rfp.md`
   - `candidate-cv.md`
   - optional `previous-rfp.md`
   - optional `previous-response.md`
   - optional `decision-letter.md`
4. Build `input-register.yaml` with:
   - original path
   - normalized path
   - file kind
   - checksum
   - conversion notes
5. If customer-specific style or rendered output is requested, resolve:
   - `customers/<CUSTOMER>/style-guide.md`
   - `customers/<CUSTOMER>/section-targets.yaml`
   - `customers/<CUSTOMER>/terminology.yaml`
   - `customers/<CUSTOMER>/scoring-hints.yaml`
   - `customers/<CUSTOMER>/good-examples/**`
   - `cv-output-renderer/template-mapping.yaml`
6. Write `style-pack-resolved.yaml` with:
   - customer name
   - requested output formats
   - resolved style-pack paths
   - template mapping path
   - explicit template override if any
   - resolution warnings
7. Record unreadable sections, missing files, conversion uncertainty, and unresolved style assets in `clarifications.md`.

## Output Contract

### Artifacts

- `rfp/active/<RFP-ID>/request/current-rfp.md`
- `rfp/active/<RFP-ID>/request/candidate-cv.md`
- optional `rfp/active/<RFP-ID>/request/previous-rfp.md`
- optional `rfp/active/<RFP-ID>/request/previous-response.md`
- optional `rfp/active/<RFP-ID>/request/decision-letter.md`
- `rfp/active/<RFP-ID>/request/input-register.yaml`
- optional `rfp/active/<RFP-ID>/request/style-pack-resolved.yaml`
- `rfp/active/<RFP-ID>/request/clarifications.md`

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` - request inputs were normalized into canonical markdown artifacts
- `blocked` - a required source file is missing
- `needs_more_evidence` - a source exists but key sections remain ambiguous or unreadable
- `fail` - conversion failed in a way that prevents usable output

## Done Criteria

1. Canonical markdown request files exist for every supplied source.
2. Input register includes checksums and origin paths.
3. Clarification log surfaces missing or ambiguous material explicitly.
4. Style-pack resolution metadata exists when customer-specific style or rendering was requested.

## Evidence Requirements

- Claim: a source file was normalized -> proof: canonical markdown file and checksum were written in this run
- Claim: a source section is unreadable or missing -> proof: the issue was recorded in `clarifications.md` in this run
- Claim: a customer style pack was resolved -> proof: resolved paths were written in `style-pack-resolved.yaml` in this run

## Failure Routing

- missing required source -> `blocked`
- requested style or render output without resolvable style assets -> `needs_more_evidence`
- unreadable conversion with fallback still possible -> `needs_more_evidence`
- unreadable conversion with no safe fallback -> `fail`

## Escalation Rules

1. Escalate when current RFP or candidate CV cannot be normalized safely.
2. Escalate when a prior response or decision letter is referenced as required but not supplied.
3. Escalate when customer-specific rendering was requested but template or style assets cannot be resolved cleanly.

## Never Do

- never drop a supplied file silently
- never overwrite source ambiguity with guessed text
- never skip checksum and origin recording

