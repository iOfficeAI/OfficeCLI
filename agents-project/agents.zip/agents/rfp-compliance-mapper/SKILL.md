---
name: rfp-compliance-mapper
description: "Use when convert the intake package into a compliance matrix that classifies each tender requirement, response expectation, and gating gap."
workflow_role: validator
workflow_binding: contract_only
primary_outputs:
  - compliance matrix
  - gap log
default_next:
  success: rfp-strategy-shaper
  partial_success: human clarification boundary
  blocked: user escalation or source repair
  needs_more_evidence: missing capability or tender context
  fail: rerun after intake repair
---

# Purpose

Map tender requirements into a control artifact that the rest of the bid pipeline can trust. This node classifies each requirement, shows what must be answered, and exposes gaps before drafting starts.

## Workflow role

- Role: `validator`
- Binding: `contract_only`
- Goal gate: yes, for mandatory requirement readiness
- Human approval node: yes, when mandatory items cannot be answered from available material
- Typical predecessors: `rfp-intake-normalizer`
- Typical successors: `rfp-strategy-shaper`, user clarification, or escalation

## Inputs

### Required

- `rfp/<RFP-ID>/intake/rfp-intake.md`
- `rfp/<RFP-ID>/intake/requirements-register.yaml`

### Optional

- capability library
- legal or commercial review notes
- pricing guidance
- prior clarification answers

## Preconditions

1. Intake artifacts exist and are readable.
2. Requirement IDs and source references are stable.
3. Mandatory requirements must be treated as real gates, not drafting suggestions.

## Procedure

1. Verify intake artifacts exist and read them in full.
2. For each requirement, classify the type:
   - mandatory
   - scored
   - formality
   - commercial
   - legal
   - format
3. Map the intended response path for each requirement:
   - primary response section
   - expected evidence type
   - likely source owner
4. Set requirement status as one of:
   - `covered`
   - `partially_covered`
   - `gap`
   - `clarification_needed`
   - `customer_input_needed`
5. Write a gap log for every item that is not fully covered.
6. If a mandatory item is unresolved, surface it as a gate in the report summary.

## Output Contract

### Artifacts

- `rfp/<RFP-ID>/compliance/compliance-matrix.yaml`
- `rfp/<RFP-ID>/compliance/gap-log.md`

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` - all requirements were classified and no mandatory item remains unresolved
- `partial_success` - matrix is complete but non-final clarification or customer input remains
- `blocked` - a mandatory item cannot be answered safely from available material
- `needs_more_evidence` - capability, legal, or source context is too thin to classify confidently
- `fail` - mapping could not complete because the intake package was unusable

## Done Criteria

1. Every requirement ID appears in the compliance matrix.
2. Requirement type and status are explicit.
3. Mandatory gaps are surfaced as gates.
4. Gap log items are actionable and traceable.

## Evidence Requirements

- Claim: a requirement is mandatory or scored -> proof: cited tender source checked in this run
- Claim: a requirement is covered -> proof: an explicit response path and expected evidence type were defined in this run
- Claim: a gap exists -> proof: no safe answer path could be shown from the current material in this run

## Failure Routing

- missing intake artifacts -> `blocked`
- mandatory gap with no safe fallback -> `blocked`
- unclear source basis for classification -> `needs_more_evidence`
- structurally broken requirements register -> `fail`

## Escalation Rules

1. Escalate when a mandatory item lacks any credible response basis.
2. Escalate when pricing, legal, or contractual requirements require human sign-off.
3. Escalate when tender instructions imply a response commitment the organization may not want to make.

## Never Do

- never mark a requirement `covered` because it is probably standard
- never hide mandatory gaps inside generic prose
- never merge commercial and technical requirements into one answer path unless the tender explicitly does so
- never assume the evaluator will infer intent that the tender does not state

