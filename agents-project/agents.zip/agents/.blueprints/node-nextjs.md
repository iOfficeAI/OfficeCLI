---
# Required
name: "Node Next.js App"
description: "Next.js + TypeScript + PostgreSQL with eslint, prettier, vitest, and mandatory Playwright UI E2E"

# Mise toolchain — populates .mise.toml [tools] and [env]
mise:
  tools:
    node: "22"
    pnpm: "9"
  env:
    NODE_ENV: "development"

# Machine-readable project + harness defaults — these pre-fill `.factory/project.yaml`
project:
  language: "typescript"
  runtime: "node 22"
  source_directories:
    - "app/"
    - "src/"
  test_directories:
    - "tests/"
  build:
    compile: "pnpm tsc --noEmit"
    test: "pnpm vitest run"
    lint: "pnpm eslint . && pnpm prettier --check ."
  test_framework: "vitest"
  bdd:
    framework: "cucumber-js"
    runner: "pnpm cucumber-js"
    dry_run: "pnpm cucumber-js --dry-run"
    step_definitions: "features/step-definitions"
  e2e:
    framework: "playwright"
    project_root: "."
    test_dir: "e2e"
    config: "playwright.config.ts"
    install_command: "pnpm install --frozen-lockfile"
    type_check_command: "pnpm tsc --noEmit"
    test_list_command: "pnpm playwright test --list"
    runner: "pnpm playwright test"
    report_dir: "playwright-report"
  docs:
    engine: "mkdocs-material"
    config: "mkdocs.yml"
    docs_dir: "docs"
    site_dir: "site"
    build_command: "mkdocs build --strict"
    serve_command: "mkdocs serve"
    plugins:
      - "search"
      - "tags"
      - "mermaid2"

# Stack hints used for `.factory/project.yaml` `stack` section and harness routing
frameworks:
  backend:
    - "Next.js Route Handlers"
  ui:
    - "Next.js 15"
    - "React 19"
    - "Tailwind CSS"
  data:
    - "PostgreSQL"
    - "Prisma"
  integration:
    - "REST"
    - "OpenAPI"
  testing:
    - "Vitest"
    - "Playwright"
    - "ESLint"
    - "Prettier"
    - "Cucumber"
  rendering_model: "hybrid"

# C4 containers — each entry becomes a container block in workspace.dsl
containers:
  - id: webApp
    name: "Web Application"
    description: "Next.js application serving server-rendered pages, client components, and route handlers"
    technology: "Node 22 / Next.js / React"
    tag: "Web Application"
  - id: database
    name: "PostgreSQL Database"
    description: "Primary relational datastore accessed through Prisma"
    technology: "PostgreSQL 16"
    tag: "Database"
  - id: cache
    name: "Redis Cache"
    description: "Session, caching, and background coordination store"
    technology: "Redis 7"
    tag: "Database"

# C4 external systems — each becomes a softwareSystem in workspace.dsl
external_systems:
  - name: "OpenID Connect Provider"
    description: "Authentication and session identity provider"
    tag: "External System"
  - name: "Email Provider"
    description: "Transactional email delivery service"
    tag: "External System"
  - name: "Blob Storage"
    description: "Object storage for uploaded files and generated assets"
    tag: "External System"

# Additional ADR principles appended to ADR-0001
adr_principles:
  - "Keep server actions and route handlers thin; business logic belongs in domain services."
  - "Validate all external inputs with schema objects at the boundary."
  - "Prefer server components unless a real client-side interaction requires client components."
  - "Use Prisma migrations for schema evolution; never mutate production schema manually."
  - "Treat Playwright as the required browser behavior harness and keep it focused on user-critical flows."
  - "Measure Playwright by user journeys and release-critical VAL-* assertions, not line-coverage percentages."
  - "Default local TypeScript harness is eslint + prettier + vitest before heavier checks."
  - "API contracts and UI routes must remain discoverable in-repo, not only in prompts."

# Optional harness metadata for future routing / audits
harness:
  local_fast:
    - "pnpm eslint ."
    - "pnpm prettier --check ."
    - "pnpm vitest run"
  ci_required:
    - "pnpm tsc --noEmit"
    - "pnpm next build"
    - "pnpm vitest run"
    - "pnpm playwright test"
    - "mkdocs build --strict"
  coverage:
    tool: "vitest"
    command: "pnpm vitest run --coverage --coverage.reporter=text --coverage.reporter=lcov --coverage.reporter=html"
    target:
      lines: 80
      branches: 70
    reports:
      console: "text"
      xml: "coverage/lcov.info"
      html_dir: "coverage"
  architecture:
    - "workspace.dsl"
    - "policies.yaml"
  runtime:
    - "docker compose up -d postgres redis"

# Compliance flags — skips asking if set
compliance:
  gdpr: false
  rigsarkivet: false
---

## Node Next.js App Blueprint

Use this blueprint for modern TypeScript web applications where Alice wants both the app topology and the executable harness defaults encoded up front.

### What This Blueprint Optimizes For

1. Fast local feedback with `eslint`, `prettier`, and `vitest`
2. Strong browser behavior checks through Playwright
3. Clear separation between UI, route handlers, and domain services
4. PostgreSQL-backed Next.js apps with Prisma migrations
5. Hybrid rendering without losing repository legibility

### Suggested Layout

```text
app/
src/
tests/
e2e/
prisma/
```

### Suggested Next Checks After Bootstrap

- confirm whether the app is mostly server-rendered or mostly SPA-like
- confirm whether Redis is actually needed
- confirm whether Cucumber should stay or be omitted
- confirm whether authentication and storage providers are known
- classify Tier 0 to Tier 3 browser journeys and mark Tier-1 release blockers
- define which `VAL-*` assertions are release-critical and must execute at Phase 6.5
- adopt `docs/e2e-coverage-policy.md` and `docs/e2e-fitness-functions.md` as the default Playwright governance baseline
- keep coverage percentages in `harness.coverage` for code coverage tools like Vitest, not for Playwright E2E
