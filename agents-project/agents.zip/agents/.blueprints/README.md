# Blueprints

Canonical repo-local blueprints for the `project-bootstrap` agent. Files here are committed with the agent definitions so stack templates and harness defaults version together.

## How It Works

When `project-bootstrap` runs, it scans two locations for blueprints (in priority order):

1. `.blueprints/` — project-local (committed, shared with team)
2. `~/.claude/blueprints/` — personal, cross-project fallback

Each blueprint is a Markdown file with YAML frontmatter. The frontmatter carries structured values that pre-fill setup questions; the Markdown body is free-form context for humans.

## Design Rule

Good blueprints should encode both:

- topology and architectural intent
- executable stack defaults that seed the harness

In practice, a useful blueprint should usually include:

- `project.*` for build, test, lint, source/test directories, and test-framework routing
- `frameworks.*` for stack metadata and rendering model
- `containers` / `external_systems` for architecture bootstrapping

Without `project.*`, a blueprint is mostly an architecture seed, not a real stack-aware bootstrap.

## Blueprint Schema

```yaml
---
name: "Display Name"                    # Required — shown in selection menu
description: "One-line summary"         # Required — shown in selection menu

mise:                                   # Populates .mise.toml
  tools: { java: "temurin-21" }
  env: { KEY: "value" }

project:                                # Pre-fills `.factory/project.yaml`
  language: "java"
  runtime: "java 21"
  source_directories: ["src/"]
  test_directories: ["src/test/"]
  build:
    compile: "mvn -q -DskipTests test-compile"
    test: "mvn -q test"
    lint: "mvn -q spotless:check"
  test_framework: "junit"
  bdd:
    framework: "cucumber-jvm"
    runner: "mvn test -Dcucumber.filter.tags=@acceptance"
    dry_run: "mvn test -Dcucumber.execution.dry-run=true"
    step_definitions: "src/test/java"
  e2e:
    framework: "playwright"
    project_root: "e2e"
    test_dir: "tests"
    config: "playwright.config.ts"
    install_command: "npm ci"
    type_check_command: "npx tsc --noEmit"
    test_list_command: "npx playwright test --list"
    runner: "npx playwright test"
    report_dir: "playwright-report"
  docs:
    engine: "mkdocs-material"
    config: "mkdocs.yml"
    docs_dir: "docs"
    site_dir: "site"
    build_command: "mkdocs build --strict"
    serve_command: "mkdocs serve"
    plugins: ["search", "tags", "mermaid2"]

frameworks:                             # Pre-fills `.factory/project.yaml` stack section
  backend: ["Spring Boot"]
  ui: ["React"]
  data: ["PostgreSQL"]
  integration: ["REST"]
  testing: ["JUnit", "Playwright"]
  rendering_model: "SPA"

agent_workflow:                         # Optional soft repo defaults consumed by delivery agents
  review_scope: "full"                  # full | targeted
  testing_scope: "targeted"             # full | targeted
  goal_verification: true

containers:                             # Pre-fills workspace.dsl
  - id: camelCaseId
    name: "Human Name"
    description: "What it does"
    technology: "Stack"
    tag: "Service | Database | Web Application | Library"

external_systems:                       # Pre-fills workspace.dsl
  - name: "System Name"
    description: "What it does"
    tag: "External System"

adr_principles: []                      # Appended to ADR-0001

harness:                               # Optional metadata for local-fast / CI / coverage / architecture / runtime defaults
  local_fast: ["ruff check .", "pytest -q"]
  ci_required: ["pytest", "ruff check .", "mkdocs build --strict"]
  coverage:
    tool: "pytest-cov"
    command: "pytest --cov=src --cov-report=term-missing --cov-report=xml:coverage.xml --cov-report=html:htmlcov"
    target:
      lines: 85
      branches: 75
    reports:
      console: "term-missing"
      xml: "coverage.xml"
      html_dir: "htmlcov"
  architecture: ["workspace.dsl", "policies.yaml"]
  runtime: ["docker compose up -d"]

compliance:
  gdpr: true | false | unknown
  rigsarkivet: true | false | unknown
---

Free-form notes below the frontmatter.
```

Any field that is absent falls back to manual prompting. Blueprints never lock out user overrides.

## Field Guidance

| Field | Type | Required | Purpose |
|---|---|---|---|
| `name` | string | ✓ | Shown in blueprint selection menu |
| `description` | string | ✓ | One-line summary in selection menu |
| `mise.tools` | map | ✓ | Populates `[tools]` in `.mise.toml` |
| `mise.env` | map | — | Populates `[env]` in `.mise.toml` |
| `project.language` | string | — | Pre-fills the primary language in `.factory/project.yaml` |
| `project.runtime` | string | — | Pre-fills the runtime version in `.factory/project.yaml` |
| `project.source_directories` | list | — | Pre-fills source dirs so bootstrap does not have to ask |
| `project.test_directories` | list | — | Pre-fills test dirs so bootstrap does not have to ask |
| `project.build` | map | — | Pre-fills compile/test/lint commands for the stack harness |
| `project.test_framework` | string | — | Pre-fills the default test framework for routing and prompts |
| `project.bdd` | map | — | Pre-fills BDD framework, runner, and step-definition defaults |
| `project.e2e` | map | — | Pre-fills the E2E layer in `.factory/project.yaml`; required for browser UI stacks |
| `project.docs` | map | — | Declares docs engine/config/build defaults; standard is `mkdocs-material` unless explicitly overridden |
| `frameworks` | map | — | Pre-fills `.factory/project.yaml` stack section with backend/UI/data/integration/testing hints |
| `agent_workflow` | map | — | Optional soft repo defaults for delivery behavior; use for review/testing breadth and completion-verification preference, not stack facts |
| `containers` | list | — | Pre-fills workspace.dsl containers |
| `external_systems` | list | — | Pre-fills workspace.dsl external systems |
| `adr_principles` | list | — | Appended to ADR-0001 Consequences |
| `harness` | map | — | Optional metadata for local-fast / CI / coverage / architecture / runtime harness defaults |
| `harness.coverage` | map | — | Declares code-coverage tool, target thresholds, and report paths/directories; do not use this field for Playwright journey coverage |
| `compliance.gdpr` | bool | — | Skips GDPR question |
| `compliance.rigsarkivet` | bool | — | Skips Rigsarkivet question |

## Authoring Guidance

- Prefer real stack defaults over placeholders for `project.build`, `project.test_framework`, and `project.bdd`.
- Treat `project.*` plus `frameworks.*` as the blueprint's harness seed.
- Use `project.e2e` whenever the stack has browser UI or a separate live-stack acceptance layer.
- Browser UI blueprints without an explicit `project.e2e` definition are incomplete harnesses.
- For browser UI blueprints, express Playwright goals in journey, contract, runtime, and flake terms rather than line-coverage percentages.
- Use `project.docs` to make the docs tool explicit; default to `mkdocs-material` unless there is a strong reason not to.
- Use `agent_workflow` only for soft repo defaults that shape delivery behavior. Do not put stack facts, runtime commands, or CI requirements there.
- For Python blueprints, prefer `pyproject.toml` as the canonical manifest, add `uv` under `mise.tools`, and use `uv run ...` commands in `project.build` + `harness`.
- Treat `containers` and `external_systems` as the blueprint's topology seed.
- Use `harness` for extra local-fast / CI / coverage / architecture / runtime defaults that do not belong in `project.build`.
- Prefer explicit `harness.coverage` targets and report locations over vague phrases like "good coverage".
- Keep versions aligned with the reference repo; blueprint drift creates bad scaffolds.

## Available Blueprints

| File | Name | Description |
|---|---|---|
| `opendebt-stack.md` | OpenDebt | Danish public debt collection — Spring Boot microservices, GDPR-by-architecture, double-entry bookkeeping, Catala law-as-code |
| `python-fastapi.md` | Python FastAPI Service | FastAPI + PostgreSQL + Redis with uv, pyproject.toml, ruff, ty, pytest, and separate Playwright E2E when paired with a browser UI |
| `node-nextjs.md` | Node Next.js App | Next.js + TypeScript + PostgreSQL with eslint, prettier, vitest, and Playwright |
| `dotnet-webapi.md` | .NET Web API | ASP.NET Core Web API with PostgreSQL, xUnit, Playwright, and dotnet format |

## Adding a New Blueprint

1. Create a `kebab-case-name.md` file in this folder
2. Add YAML frontmatter with at least `name` and `description`
3. Fill in `project.*` and `frameworks.*` whenever you know the stack harness defaults
4. Add context in the Markdown body for human readers
5. Update the table above
