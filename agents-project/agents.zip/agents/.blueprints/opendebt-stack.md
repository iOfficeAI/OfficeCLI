---
# Required
name: "OpenDebt — Danish Public Debt Collection Platform"
description: "Spring Boot microservices with GDPR-by-architecture, double-entry bookkeeping, Catala law-as-code, and petition-driven delivery"

# Mise toolchain — populates .mise.toml [tools] and [env]
mise:
  tools:
    java: "temurin-21"
    maven: "3.9"
  env:
    MAVEN_OPTS: "-XX:+UseContainerSupport"

# Machine-readable project + harness defaults — these pre-fill `.factory/project.yaml`
project:
  language: "java"
  runtime: "java 21"
  source_directories:
    - "."
  test_directories:
    - "."
  build:
    compile: "mvn -q -DskipTests test-compile"
    test: "mvn -q test"
    lint: "mvn -q spotless:check"
  test_framework: "junit"
  bdd:
    framework: "cucumber-jvm"
    runner: "mvn test -Dcucumber.filter.tags=@acceptance"
    dry_run: "mvn test -Dcucumber.execution.dry-run=true"
    step_definitions: "src/test/java"
  docs:
    engine: "mkdocs-material"
    config: "mkdocs.yml"
    docs_dir: "docs"
    site_dir: "site"
    build_command: "mkdocs build --strict"
    serve_command: "mkdocs serve"
    plugins:
      - "search"
      - "tags"
      - "mermaid2"

# Stack hints used for `.factory/project.yaml` `stack` section and harness routing
frameworks:
  backend:
    - "Spring Boot 3.5"
    - "Flowable 7.0.1"
    - "Drools 9.x"
  ui:
    - "Thymeleaf"
    - "HTMX"
  data:
    - "PostgreSQL 16"
    - "Flyway"
    - "immudb"
  integration:
    - "OpenAPI 3.1"
    - "Keycloak 24"
    - "Smooks 2.0.0"
    - "OpenTelemetry"
    - "Resilience4j 2.4.0"
  testing:
    - "JUnit 5"
    - "Cucumber 7.18"
    - "ArchUnit 1.4.1"
    - "Playwright 1.x"
    - "JaCoCo"
    - "OWASP Dependency Check"
    - "SonarCloud"
  rendering_model: "server-rendered"

# C4 containers — each entry becomes a container block in workspace.dsl
containers:
  # --- Shared libraries ---
  - id: common
    name: "Common Library"
    description: "Shared DTOs, base entities (AuditableEntity), test fixtures, and cross-cutting utilities"
    technology: "Java 21 / Spring Boot 3.5"
    tag: "Library"

  - id: ufstBookkeepingCore
    name: "UFST Bookkeeping Core"
    description: "Shared double-entry bookkeeping domain library — posting engine, storno/reversal, interest accrual, and timeline replay. No Spring, no JPA — pure Java 21. Consumed by debt-service and payment-service. ADR-0033."
    technology: "Java 21 (no Spring, no JPA)"
    tag: "Library"

  - id: ufstRulesLib
    name: "UFST Rules Library"
    description: "Shared Drools rule evaluation library — model classes, DRL files, KieContainerFactory, and RulesService facade. Evaluated in-process by each consuming service; no standalone HTTP service. No Spring dependency — consumers wire the KieContainer @Bean themselves. ADR-0035 (supersedes ADR-0015)."
    technology: "Java 21 / Drools 9.x (no Spring)"
    tag: "Library"

  # --- GDPR PII silo ---
  - id: personRegistry
    name: "Person Registry"
    description: "GDPR PII silo — all CPR/CVR/name/address/contact data encrypted at rest (AES-256). Every other service references persons only by UUID."
    technology: "Java 21 / Spring Boot 3.5 / PostgreSQL"
    tag: "Service"

  # --- Domain services ---
  - id: debtService
    name: "Debt Service"
    description: "Core debt lifecycle management — creation, status transitions, interest calculation, and write-off"
    technology: "Java 21 / Spring Boot 3.5 / PostgreSQL"
    tag: "Service"

  - id: creditorService
    name: "Creditor Service"
    description: "Creditor master data — onboarding, configuration, and creditor-specific rules"
    technology: "Java 21 / Spring Boot 3.5 / PostgreSQL"
    tag: "Service"

  - id: caseService
    name: "Case Service"
    description: "Case and workflow management — BPMN process execution via Flowable"
    technology: "Java 21 / Spring Boot 3.5 / Flowable / PostgreSQL"
    tag: "Service"

  - id: paymentService
    name: "Payment Service"
    description: "Payment processing — double-entry bookkeeping for every financial event"
    technology: "Java 21 / Spring Boot 3.5 / PostgreSQL"
    tag: "Service"

  - id: letterService
    name: "Letter Service"
    description: "Letter and document generation for statutory correspondence"
    technology: "Java 21 / Spring Boot 3.5 / PostgreSQL"
    tag: "Service"

  - id: wageGarnishmentService
    name: "Wage Garnishment Service"
    description: "Lønindeholdelse — statutory wage garnishment processing"
    technology: "Java 21 / Spring Boot 3.5 / PostgreSQL"
    tag: "Service"

  - id: integrationGateway
    name: "Integration Gateway"
    description: "External protocol ingress — EDIFACT (CREMUL/DEBMUL), SOAP, and OCES3 mutual TLS"
    technology: "Java 21 / Spring Boot 3.5 / Spring WS / Smooks"
    tag: "Service"

  # --- BFF portals ---
  - id: creditorPortal
    name: "Creditor Portal"
    description: "BFF for fordringshavere — Thymeleaf + OIDC, no domain logic, no DB access"
    technology: "Java 21 / Spring Boot 3.5 / Thymeleaf"
    tag: "Web Application"

  - id: caseworkerPortal
    name: "Caseworker Portal"
    description: "BFF for sagsbehandlere — Thymeleaf + OIDC, no domain logic, no DB access"
    technology: "Java 21 / Spring Boot 3.5 / Thymeleaf"
    tag: "Web Application"

  - id: citizenPortal
    name: "Citizen Portal"
    description: "BFF for skyldnere — Thymeleaf + OIDC via MitID/TastSelv, no domain logic, no DB access"
    technology: "Java 21 / Spring Boot 3.5 / Thymeleaf"
    tag: "Web Application"

  # --- Datastores ---
  - id: postgresDb
    name: "PostgreSQL Database"
    description: "One schema per service, Flyway-managed migrations, AuditableEntity on all tables"
    technology: "PostgreSQL 16"
    tag: "Database"

  - id: immudbLedger
    name: "immudb Ledger"
    description: "Tamper-evident financial ledger — every journal entry is cryptographically immutable"
    technology: "immudb"
    tag: "Database"

# C4 external systems — each becomes a softwareSystem in workspace.dsl
external_systems:
  - name: "Keycloak"
    description: "Identity provider — OIDC/OAuth2 for all portals and service-to-service JWT"
    tag: "External System"

  - name: "MitID / TastSelv"
    description: "Danish national eID — citizen authentication proxied through Keycloak"
    tag: "External System"

  - name: "OCES3 Certificate Authority"
    description: "Mutual TLS certificate authority for legacy M2M ingress"
    tag: "External System"

  - name: "OpenTelemetry Collector"
    description: "OTLP/HTTP telemetry sink — routes to Tempo, Loki, and Prometheus"
    tag: "External System"

  - name: "Grafana Stack"
    description: "Dashboards (Grafana), traces (Tempo), logs (Loki), metrics (Prometheus)"
    tag: "External System"

# Additional ADR principles appended to ADR-0001
adr_principles:
  - "GDPR by architecture — all PII is isolated in the Person Registry. Every other service stores only a person_id UUID. No cross-service DB access (ADR-0007, ADR-0014)."
  - "One database schema per service. Cross-service data access is via REST only — never direct DB joins (ADR-0007)."
  - "API-first with OpenAPI 3.1 — the spec is the contract. No undocumented endpoints (ADR-0004)."
  - "Double-entry bookkeeping for all financial events. Financial state is always reconcilable from the ledger alone (ADR-0018)."
  - "Orchestration over event-driven — inter-service communication uses synchronous REST calls, not async events (ADR-0019)."
  - "Resilience4j circuit breaker + retry on all inter-service calls (ADR-0026)."
  - "Statutory codes as enums, not configuration tables. They change only when the law changes (ADR-0031)."
  - "Catala formal compliance layer is oracle-only, never in the runtime critical path (ADR-0032)."
  - "Cross-cutting financial domain logic (double-entry bookkeeping, interest accrual, storno) lives in the shared `ufst-bookkeeping-core` library — no Spring, no JPA, Java 21 only. Each consuming service provides its own JPA adapter implementing the library's port interfaces (ADR-0033)."
  - "Business rules (Drools) are evaluated in-process as a shared Maven library (`ufst-rules-lib`) — NOT as a standalone HTTP service. Each service wires the `KieContainer` as a `@Bean singleton` at startup. Rate values and domain parameters are resolved by the calling service before constructing a rule request; the library is configuration-agnostic (ADR-0035, supersedes ADR-0015)."
  - "Tamper-evident ledger via immudb for financial audit trail (ADR-0029)."
  - "Internal endpoints use /internal/ prefix, hasRole('SERVICE'), and are @Hidden from public Swagger UI."
  - "Non-root containers (UID 1000), Alpine base images, container-aware JVM memory (MaxRAMPercentage=75%)."
  - "Portals are pure BFFs — session state only, all data from downstream services via WebClient, no direct DB access."
  - "Cucumber/BDD acceptance tests run against an in-process Spring context backed by H2 (default) or `io.zonky.test:embedded-database-spring-test` (embedded PostgreSQL) — never Testcontainers. Testcontainers is reserved for integration tests that require production-equivalent behaviour (e.g. Flyway migration smoke tests, immudb connectivity)."
  - "E2E acceptance tests are written in TypeScript Playwright in `opendebt-e2e/` — a standalone Node.js project separate from the Maven build. They test portal behaviour through the browser against a running docker-compose stack. They are the only test layer that requires a live application. The `playwright-test-generator` agent generates them from Gherkin feature files. See ADR-0034."

# Optional harness metadata for future routing / audits
harness:
  local_fast:
    - "mvn -q spotless:check"
    - "mvn -q test"
  ci_required:
    - "mvn -q clean verify"
    - "mvn -q org.sonarsource.scanner.maven:sonar-maven-plugin:sonar"
    - "mkdocs build --strict"
  coverage:
    tool: "jacoco"
    command: "mvn -q clean verify"
    target:
      lines: 80
      branches: 70
    reports:
      console: "CI + SonarCloud summary"
      xml: "target/site/jacoco/jacoco.xml"
      html_dir: "target/site/jacoco"
  architecture:
    - "workspace.dsl"
    - "policies.yaml"
    - "ArchUnit"
  runtime:
    - "docker compose up -d"
    - "docker compose -f docker-compose.observability.yml up -d"

# Compliance flags — skips asking if set
compliance:
  gdpr: true
  rigsarkivet: true
---

## OpenDebt Stack Blueprint

This blueprint captures the full technology stack of **OpenDebt**, a Danish public-sector debt collection platform. Use it with `project-bootstrap` to scaffold a new project that follows the same architectural patterns.

### Usage

Tell the agent:
> "Bootstrap a new project using the OpenDebt blueprint"

The `project-bootstrap` agent reads the frontmatter above to pre-fill mise toolchain, project config, stack metadata, C4 containers, external systems, ADR principles, and compliance settings. You only need to answer questions the blueprint does not cover.

### Key Architectural Patterns

1. **GDPR by architecture** — PII isolation is structural (Person Registry), not procedural.
2. **Law as code** — Catala encodes legal rules as testable formal specifications (oracle layer).
3. **Petition-driven delivery** — petition → outcome contract → Gherkin → code. Traceable to law.
4. **Double-entry bookkeeping** — every financial event → debit + credit journal entry. Shared via `ufst-bookkeeping-core`.
5. **Statutory codes as enums** — law-mandated values compiled into the codebase.
6. **Shared domain libraries, not shared services** — cross-cutting financial logic (`ufst-bookkeeping-core`) and business rules (`ufst-rules-lib`) are in-process Maven libraries, not standalone HTTP services. This eliminates network hops, SPOFs, and diverging implementations across services. Rate changes and rule changes are versioned library releases.
7. **Agent pipeline** — specialist AI agents execute each pipeline phase with human approval gates.

### Harness Defaults Encoded In Frontmatter

This blueprint is intentionally not just a topology seed. It also encodes the default stack harness:

- Java 21 + Maven build/test/lint commands
- JUnit as the unit-test framework
- Cucumber JVM as the BDD framework
- JaCoCo coverage thresholds and report outputs
- Spring/Thymeleaf/HTMX stack hints for routing and docs
- quality tooling expectations such as Spotless, JaCoCo, OWASP, and Sonar

That means `project-bootstrap` can pre-fill more of `.factory/project.yaml` without asking repeated stack questions.

### Technology Stack Summary

| Concern | Choice |
|---|---|
| Language | Java 21 (LTS) |
| Framework | Spring Boot 3.5.x |
| Build | Maven multi-module (≥ 3.9.0) |
| Database | PostgreSQL 16, Flyway migrations |
| Auth | Keycloak 24 (OIDC/OAuth2), MitID for citizens |
| Rules | Drools 9.x — embedded in-process via `ufst-rules-lib` (ADR-0035) |
| Workflow | Flowable 7.0.1 |
| Ledger | immudb (tamper-evident) |
| Bookkeeping | `ufst-bookkeeping-core` shared library (ADR-0033) |
| Formal law | Catala (oracle only) |
| EDIFACT | Smooks 2.0.0 |
| Observability | OTel → Tempo + Loki + Prometheus + Grafana |
| Resilience | Resilience4j 2.4.0 |
| Testing (unit / BDD) | JUnit 5, Cucumber 7.18, H2 / `io.zonky.test:embedded-database-spring-test`, ArchUnit 1.4.1 |
| Testing (E2E) | Playwright 1.x (TypeScript) — `opendebt-e2e/` standalone Node.js project, runs against docker-compose stack |
| Testing (integration) | Testcontainers 1.21 (Flyway smoke tests, immudb — not Cucumber) |
| Coverage goal | JaCoCo line coverage 80%, branch coverage 70% |
| Coverage reports | `target/site/jacoco/jacoco.xml`, `target/site/jacoco/`, SonarCloud summary |
| Quality | Spotless (Google Java Format), JaCoCo, OWASP Dependency Check, SonarCloud |
| CI/CD | GitHub Actions (SHA-pinned) |

### Module Port Map

| Module | Port |
|---|---|
| person-registry | 8090 |
| debt-service | 8082 |
| creditor-service | 8092 |
| case-service | 8081 |
| payment-service | 8083 |
| letter-service | 8084 |
| creditor-portal | 8085 |
| citizen-portal | 8086 |
| caseworker-portal | 8087 |
| immudb REST | 8094 |
| immudb gRPC | 3322 |

### Bootstrap Checklist

When using this blueprint, verify:

- Maven multi-module parent with enforcer (Java 21, Maven 3.9)
- `common` module with shared base classes
- Person Registry with encryption configuration
- One PostgreSQL schema + Flyway migration set per service
- Keycloak realm export and auto-import via `KEYCLOAK_IMPORT`
- `docker-compose.yml` with all services + Keycloak + PostgreSQL
- `docker-compose.observability.yml` with OTel Collector + Tempo + Loki + Prometheus + Grafana
- immudb in docker-compose (financial ledger)
- Spotless + JaCoCo + OWASP Dependency Check configured
- GitHub Actions CI with SHA-pinned actions
- `architecture/workspace.dsl` + `architecture/policies.yaml`
- `.factory/project.yaml` with Maven + Cucumber defaults confirmed
- `architecture/adr/` with foundational ADRs (ADR-0001 through ADR-0035)
- `AGENTS.md` and `petitions/program-status.yaml`
- Non-root Dockerfiles (UID 1000, Alpine base)
- Cucumber step definitions wired to an H2 (or embedded PG) Spring test context — **no Testcontainers in the Cucumber module**
- `opendebt-e2e/` scaffold: `package.json` (`@playwright/test`), `playwright.config.ts`, `tsconfig.json`, `tests/.gitkeep` — **not a Maven module**
