---
# Required
name: "Python FastAPI Service"
description: "FastAPI + PostgreSQL + Redis with uv, pyproject.toml, ruff, ty, pytest, and separate Playwright E2E when paired with a browser UI"

# Mise toolchain — populates .mise.toml [tools] and [env]
mise:
  tools:
    python: "3.12"
    uv: "latest"
    node: "22"
  env:
    PYTHONDONTWRITEBYTECODE: "1"
    PYTHONUNBUFFERED: "1"

# Machine-readable project + harness defaults — these pre-fill `.factory/project.yaml`
project:
  language: "python"
  runtime: "python 3.12"
  source_directories:
    - "src/"
  test_directories:
    - "tests/"
  build:
    compile: "uv run python -m compileall src"
    test: "uv run pytest"
    lint: "uv run ruff check . && uv run ty check"
  test_framework: "pytest"
  bdd:
    framework: "behave"
    runner: "behave"
    dry_run: "behave --dry-run"
    step_definitions: "features/steps"
  e2e:
    framework: "playwright"
    project_root: "e2e"
    test_dir: "tests"
    config: "playwright.config.ts"
    install_command: "npm ci"
    type_check_command: "npx tsc --noEmit"
    test_list_command: "npx playwright test --list"
    runner: "npx playwright test"
    report_dir: "playwright-report"
  docs:
    engine: "mkdocs-material"
    config: "mkdocs.yml"
    docs_dir: "docs"
    site_dir: "site"
    build_command: "mkdocs build --strict"
    serve_command: "mkdocs serve"
    plugins:
      - "search"
      - "tags"
      - "mermaid2"

# Stack hints used for `.factory/project.yaml` `stack` section and harness routing
frameworks:
  backend:
    - "FastAPI"
    - "Pydantic v2"
    - "SQLAlchemy 2.x"
  ui:
    - "none"
  data:
    - "PostgreSQL"
    - "Redis"
    - "Alembic"
  integration:
    - "REST"
    - "OpenAPI 3.1"
  testing:
    - "uv"
    - "pytest"
    - "behave"
    - "Playwright"
    - "ruff"
    - "ty"
  rendering_model: "API-only"

# C4 containers — each entry becomes a container block in workspace.dsl
containers:
  - id: apiService
    name: "API Service"
    description: "FastAPI application exposing REST endpoints and OpenAPI documentation"
    technology: "Python 3.12 / FastAPI"
    tag: "Service"
  - id: worker
    name: "Background Worker"
    description: "Asynchronous worker for jobs, retries, and long-running processing"
    technology: "Python 3.12"
    tag: "Service"
  - id: database
    name: "PostgreSQL Database"
    description: "Primary relational datastore with Alembic-managed migrations"
    technology: "PostgreSQL 16"
    tag: "Database"
  - id: cache
    name: "Redis Cache"
    description: "Caching, rate limiting, and lightweight background coordination"
    technology: "Redis 7"
    tag: "Database"

# C4 external systems — each becomes a softwareSystem in workspace.dsl
external_systems:
  - name: "OpenID Connect Provider"
    description: "External identity provider for user and service authentication"
    tag: "External System"
  - name: "Email Provider"
    description: "Transactional email delivery service"
    tag: "External System"
  - name: "S3-Compatible Object Storage"
    description: "Blob/document storage for generated files and uploads"
    tag: "External System"

# Additional ADR principles appended to ADR-0001
adr_principles:
  - "Validate all inbound data at the boundary with Pydantic models or equivalent schema objects."
  - "Keep FastAPI route handlers thin; business logic lives in services, not controllers."
  - "Database access goes through repository or query services; no raw SQL in route handlers."
  - "Use Alembic for every schema change; never mutate production schema manually."
  - "Prefer async I/O for HTTP and database-bound request paths."
  - "Long-running work must move to the worker path and never block the request thread."
  - "Treat OpenAPI as a contract artifact and keep it aligned with implementation."
  - "Use `pyproject.toml` as the canonical Python project manifest and `uv` as the default dependency + command runner."
  - "Default local Python harness is `uv run ruff check .` + `uv run ty check` + `uv run pytest` before heavier checks."
  - "If this service is paired with a browser UI, required Playwright coverage lives in a separate Node-based `e2e/` project."

# Optional harness metadata for future routing / audits
harness:
  local_fast:
    - "uv run ruff check ."
    - "uv run ty check"
    - "uv run pytest -q"
  ci_required:
    - "uv sync --frozen"
    - "uv run ruff check ."
    - "uv run ty check"
    - "uv run pytest"
    - "uv run python -m compileall src"
    - "mkdocs build --strict"
  coverage:
    tool: "pytest-cov"
    command: "uv run pytest --cov=src --cov-report=term-missing --cov-report=xml:coverage.xml --cov-report=html:htmlcov"
    target:
      lines: 85
      branches: 75
    reports:
      console: "term-missing"
      xml: "coverage.xml"
      html_dir: "htmlcov"
  architecture:
    - "workspace.dsl"
    - "policies.yaml"
  runtime:
    - "docker compose up -d postgres redis"

# Compliance flags — skips asking if set
compliance:
  gdpr: false
  rigsarkivet: false
---

## Python FastAPI Service Blueprint

Use this blueprint for API-first Python services where Alice wants the stack harness encoded up front, with `pyproject.toml` + `uv` as the default Python workflow rather than ad hoc shell commands.

### What This Blueprint Optimizes For

1. Fast local feedback with `uv run ruff`, `uv run ty`, and `uv run pytest`
2. Clear API/service separation in FastAPI codebases
3. PostgreSQL-backed business services with migrations via Alembic
4. Separate browser E2E can live outside the Python app in `e2e/`; if a browser UI exists, do not omit it
5. Good default bootstrap for agent-friendly repos

### Suggested Layout

```text
src/
tests/
features/
alembic/
pyproject.toml
uv.lock
e2e/
```

### Suggested Next Checks After Bootstrap

- confirm whether the service is truly async-first
- confirm whether `behave` should stay or be removed
- confirm whether a browser UI exists; if yes, keep Playwright and do not omit it
- confirm whether GDPR or stronger compliance defaults apply
- confirm whether `uv.lock` should be committed for fully reproducible CI
