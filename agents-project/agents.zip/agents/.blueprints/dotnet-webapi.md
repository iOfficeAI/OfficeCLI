---
# Required
name: ".NET Web API"
description: "ASP.NET Core Web API with PostgreSQL, xUnit, Playwright, and dotnet format"

# Mise toolchain — populates .mise.toml [tools] and [env]
mise:
  tools:
    dotnet: "9"
    node: "22"
  env:
    DOTNET_CLI_TELEMETRY_OPTOUT: "1"

# Machine-readable project + harness defaults — these pre-fill `.factory/project.yaml`
project:
  language: "csharp"
  runtime: ".NET 9"
  source_directories:
    - "src/"
  test_directories:
    - "tests/"
  build:
    compile: "dotnet build"
    test: "dotnet test"
    lint: "dotnet format --verify-no-changes"
  test_framework: "xunit"
  bdd:
    framework: "specflow"
    runner: "dotnet test --filter TestCategory=Acceptance"
    dry_run: "dotnet test --filter TestCategory=Acceptance --list-tests"
    step_definitions: "tests/Steps"
  e2e:
    framework: "playwright"
    project_root: "e2e"
    test_dir: "tests"
    config: "playwright.config.ts"
    install_command: "npm ci"
    type_check_command: "npx tsc --noEmit"
    test_list_command: "npx playwright test --list"
    runner: "npx playwright test"
    report_dir: "playwright-report"
  docs:
    engine: "mkdocs-material"
    config: "mkdocs.yml"
    docs_dir: "docs"
    site_dir: "site"
    build_command: "mkdocs build --strict"
    serve_command: "mkdocs serve"
    plugins:
      - "search"
      - "tags"
      - "mermaid2"

# Stack hints used for `.factory/project.yaml` `stack` section and harness routing
frameworks:
  backend:
    - "ASP.NET Core 9"
    - "Entity Framework Core"
  ui:
    - "none"
  data:
    - "PostgreSQL"
    - "EF Core Migrations"
    - "Redis"
  integration:
    - "REST"
    - "OpenAPI"
    - "OpenTelemetry"
  testing:
    - "xUnit"
    - "SpecFlow"
    - "Playwright"
    - "dotnet format"
  rendering_model: "API-only"

# C4 containers — each entry becomes a container block in workspace.dsl
containers:
  - id: apiService
    name: "API Service"
    description: "ASP.NET Core application exposing REST endpoints and OpenAPI documentation"
    technology: ".NET 9 / ASP.NET Core"
    tag: "Service"
  - id: worker
    name: "Background Worker"
    description: "Hosted service for scheduled jobs and long-running processing"
    technology: ".NET 9"
    tag: "Service"
  - id: database
    name: "PostgreSQL Database"
    description: "Primary relational datastore managed through EF Core migrations"
    technology: "PostgreSQL 16"
    tag: "Database"
  - id: cache
    name: "Redis Cache"
    description: "Caching and lightweight coordination store"
    technology: "Redis 7"
    tag: "Database"

# C4 external systems — each becomes a softwareSystem in workspace.dsl
external_systems:
  - name: "OpenID Connect Provider"
    description: "Authentication and service identity provider"
    tag: "External System"
  - name: "Message Broker"
    description: "Optional broker for asynchronous integration events"
    tag: "External System"
  - name: "Email Provider"
    description: "Transactional email delivery service"
    tag: "External System"

# Additional ADR principles appended to ADR-0001
adr_principles:
  - "Keep controllers thin; business logic belongs in application services."
  - "Validate all request DTOs at the API boundary before business processing."
  - "Database access goes through EF Core repositories or query services, not controller logic."
  - "Use EF Core migrations for every schema change; never mutate production schema manually."
  - "Long-running work belongs in hosted/background services, never on the HTTP request path."
  - "Treat OpenAPI as the API contract artifact and keep it aligned with implementation."
  - "Default local .NET harness is dotnet format + dotnet test before heavier checks."
  - "If this service is paired with a browser UI, required Playwright coverage lives in a separate Node-based `e2e/` project."

# Optional harness metadata for future routing / audits
harness:
  local_fast:
    - "dotnet format --verify-no-changes"
    - "dotnet test"
  ci_required:
    - "dotnet build"
    - "dotnet test"
    - "dotnet format --verify-no-changes"
    - "npx playwright test"
    - "mkdocs build --strict"
  coverage:
    tool: "coverlet.collector"
    command: "dotnet test --collect:\"XPlat Code Coverage\""
    target:
      lines: 80
      branches: 70
    reports:
      console: "dotnet test summary"
      xml: "TestResults/**/coverage.cobertura.xml"
  architecture:
    - "workspace.dsl"
    - "policies.yaml"
  runtime:
    - "docker compose up -d postgres redis"

# Compliance flags — skips asking if set
compliance:
  gdpr: false
  rigsarkivet: false
---

## .NET Web API Blueprint

Use this blueprint for ASP.NET Core services where Alice wants the backend harness and, when applicable, the required browser harness encoded from the start.

### What This Blueprint Optimizes For

1. Straightforward API/service layering in ASP.NET Core
2. Fast local verification with `dotnet format` and `dotnet test`
3. PostgreSQL-backed services with EF Core migrations
4. Separate browser E2E isolated in `e2e/`; if a browser UI exists, do not omit it
5. Clean bootstrap input for agent-guided delivery

### Suggested Layout

```text
src/
tests/
e2e/
```

### Suggested Next Checks After Bootstrap

- confirm whether Redis and a broker are actually needed
- confirm whether SpecFlow should stay or be omitted
- confirm whether a browser UI exists; if yes, keep a separate Playwright E2E layer
- confirm whether stronger compliance defaults apply
