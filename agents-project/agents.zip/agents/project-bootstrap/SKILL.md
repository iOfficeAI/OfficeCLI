---
name: project-bootstrap
description: "Use when you need to bootstrap project infrastructure for the SDLC agent pipeline. Delegate deterministic blueprint validation, readiness scanning, and scaffold generation to scripts/bootstrap_tool.py; keep the skill focused on minimum input gathering, confirmation, and escalation."
workflow_role: worker
workflow_binding: contract_only
primary_outputs:
  - bootstrap scaffolding files
  - readiness summary
default_next:
  success: readiness recheck
  blocked: user confirmation or missing bootstrap info
  needs_more_evidence: missing project configuration details
  fail: rerun after output repair
---
# Purpose

Bootstrap missing project infrastructure so the SDLC pipeline can run without foundational config gaps. This skill owns **input collection, confirmation, and escalation**. Deterministic validation and file rendering belong to `scripts/bootstrap_tool.py`.

## Workflow role

- Role: `worker`
- Goal gate: yes, for any claim that the repo is bootstrapped or ready for downstream delivery
- Human approval node: yes, for optional module creation and for any unresolved stack ambiguity
- Typical predecessors: `delivery-orchestrator` or direct user request
- Typical successors: readiness recheck, `backlog-planner`, `pipeline-conductor`, or user clarification

## Inputs

### Required

- project root

### Optional

- blueprint path or blueprint selection
- bootstrap config file for deterministic generation
- project/system name
- language, runtime, build, test, and docs details
- optional module selection:
  - `c4_architecture_governance`
  - `documentation_scaffold`
  - `compliance_registry`

## Preconditions

1. The target repo is readable.
2. Always-on modules may be produced without extra confirmation:
   - `.mise.toml`
   - `.factory/project.yaml`
   - `.factory/context/PROJECT_CONTEXT.md`
   - `.factory/context/stack.md`
   - `.factory/context/testing.md`
   - `petitions/program-status.yaml`
3. Optional modules still require explicit confirmation before creation.
4. The script layer is the deterministic source of truth for:
   - blueprint validity
   - readiness status
   - scaffold rendering

## Procedure

1. **Validate blueprint when used**
   - If a blueprint is supplied or selected, run:
     `python scripts/bootstrap_tool.py validate-blueprint --blueprint <path>`
   - If validation fails, stop and report the concrete blueprint defects.

2. **Scan readiness first**
   - Run:
     `python scripts/bootstrap_tool.py readiness --root <repo>`
   - Use that output as the canonical readiness summary instead of re-deriving module state in prose.

3. **Resolve only the missing human inputs**
   - Gather minimum required data for always-on modules and any optional modules the user explicitly wants.
   - Do not ask for values already supplied by the blueprint or bootstrap config.
   - When repo signals and user input conflict, surface the conflict explicitly and ask for correction instead of guessing.

4. **Confirm optional scope**
   - Always-on bootstrap proceeds when required inputs are available.
   - Optional modules require explicit confirmation before generation.

5. **Generate scaffolds deterministically**
   - Materialize a bootstrap config file or structured arguments, then run:
     `python scripts/bootstrap_tool.py generate --root <repo> --config <path> [--blueprint <path>]`
   - Use `--overwrite` only when the user explicitly wants existing files replaced.

6. **Report exactly what happened**
   - Summarize:
     - files written
     - files skipped because they already existed
     - remaining gaps
     - next recommended step
   - If bootstrap succeeded, recommend a readiness recheck rather than claiming the repo is production-ready.

## Output Contract

### Artifacts

- bootstrap scaffolding files under project root
- readiness summary from `bootstrap_tool.py readiness`
- deterministic generation report from `bootstrap_tool.py generate`
- stack/context memory updates when applicable

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` — confirmed bootstrap files were produced or already present, and readiness summary is explicit
- `blocked` — required user confirmation or critical bootstrap info is missing
- `needs_more_evidence` — project details are too incomplete or contradictory to generate one or more selected modules safely
- `fail` — bootstrap could not complete because output paths, config shape, or required filesystem state were unusable

## Done Criteria

1. Always-on modules are created when missing or explicitly reported as already present.
2. Optional modules are only created after explicit confirmation.
3. Deterministic generation output is used as the source of truth for what was written or skipped.
4. Produced stubs are clearly scaffold-grade rather than production-ready.
5. Final summary states what was created, what remains missing, and the next step.

## Evidence Requirements

- Claim: blueprint is valid -> proof: `bootstrap_tool.py validate-blueprint` passed in this run
- Claim: module is missing or partial -> proof: `bootstrap_tool.py readiness` output was checked in this run
- Claim: bootstrap file was produced -> proof: `bootstrap_tool.py generate` reported the file as written in this run
- Claim: bootstrap file was preserved intentionally -> proof: `bootstrap_tool.py generate` reported the file as skipped in this run
- Claim: readiness improved -> proof: before/after readiness summaries were compared in this run

## Failure Routing

- invalid blueprint -> `fail`
- missing user confirmation for optional modules -> `blocked`
- incomplete or contradictory bootstrap config details -> `needs_more_evidence`
- unwritable output path or invalid parent structure -> `fail`
- no optional modules selected beyond always-on bootstrap -> `success`

## Escalation Rules

1. Escalate when critical bootstrap output cannot be written safely.
2. Escalate when project signals conflict so badly that deterministic defaults would be misleading.
3. Escalate when the user wants optional module output without providing minimum required information.

## Never Do

- never re-implement blueprint validation or readiness logic in prompt prose when `bootstrap_tool.py` can decide it
- never overwrite user-owned content blindly
- never create optional modules without confirmation
- never claim scaffolding is production-ready
- never invent stack facts when the repo, blueprint, or user has not supplied them
- never hide skipped or preserved files in the summary

## References

Detailed schema and scaffold conventions still live here:

- `project-bootstrap/references/blueprint-format.md`
- `project-bootstrap/references/module-definitions.md`
- `project-bootstrap/references/output-contract.md`
- `project-bootstrap/references/rules-2.md`
