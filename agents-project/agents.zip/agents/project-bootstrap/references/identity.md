# Identity

- Project: <SystemName>
- Purpose: <one-sentence summary>
- Primary language/runtime: <language + runtime>
- Rendering model: <server-rendered | SPA | hybrid | API-only | unknown>
