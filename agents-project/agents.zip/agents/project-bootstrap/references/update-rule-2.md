# Update Rule

- Keep this pack thin. Do not repeat commands already declared in `.factory/project.yaml` unless a pack-specific caveat is needed.
```

After writing `.factory/project.yaml`, `.factory/context/PROJECT_CONTEXT.md`, `.factory/context/stack.md`, + `.factory/context/testing.md`:
- Derive `PROJECT_CONTEXT.md` + the context files from `.factory/project.yaml`. On conflict, `.factory/project.yaml` wins.
- Use the context files only for repo signals, navigation hints, + non-obvious constraints that are not worth duplicating in YAML.
- Call `mempalace_diary_write` with `agent_name: "project-bootstrap"`, `entry: <stack summary derived from .factory/project.yaml>`, `topic: "project-tech-stack"` so downstream agents can resolve stack from MemPalace before falling back to `.factory/project.yaml` + repo inspection.
- If you update `.factory/context/*.md`, keep those derived files aligned with `.factory/project.yaml` in the same run.

**Language-specific defaults** (use as starting points when user provides only lang):

- **Python**: prefer `pyproject.toml` + `uv`. Defaults: `compile: "uv run python -m compileall src"`, `test: "uv run pytest"`, `lint: "uv run ruff check . && uv run ty check"`, `test_framework: pytest`, `bdd.framework: behave`, `bdd.runner: "uv run behave"`, `bdd.dry_run: "uv run behave --dry-run"`
- **Node.js**: `compile: "npm run build"`, `test: "npm test"`, `lint: "npm run lint"`, `test_framework: jest`, `bdd.framework: cucumber-js`, `bdd.runner: "npx cucumber-js"`, `bdd.dry_run: "npx cucumber-js --dry-run"`, and for browser UI projects add `e2e.framework: playwright`, `e2e.runner: "npx playwright test"`
- **Java**: `compile: "mvn compile"`, `test: "mvn test"`, `lint: "mvn checkstyle:check"`, `test_framework: junit`, `bdd.framework: cucumber-jvm`, `bdd.runner: "mvn test -Dcucumber"`, `bdd.dry_run: "mvn test -Dcucumber --dry-run"`
- **Go**: `compile: "go build ./..."`, `test: "go test ./..."`, `lint: "golangci-lint run"`, `test_framework: go test`, `bdd.framework: godog`, `bdd.runner: "godog"`, `bdd.dry_run: "godog --dry-run"`
- **.NET**: `compile: "dotnet build"`, `test: "dotnet test"`, `lint: "dotnet format --verify-no-changes"`, `test_framework: xunit`

---

### MODULE: C4 Architecture Governance

**Files produced**:
1. `architecture/workspace.dsl`
2. `architecture/policies.yaml`
3. `.factory/context/architecture.md`

#### `architecture/workspace.dsl` template

```dsl
workspace "<SystemName>" "Architecture model for <SystemName>. [STUB — expand with real containers and relationships]" {

    model {

        // --- Actors ---
        user = person "User" "Primary user of <SystemName>" "User"

        // --- Software System ---
        <systemId> = softwareSystem "<SystemName>" "<SystemName> handles [describe core responsibility here]. [STUB]" {

            // --- Containers (add one block per top-level service/application/datastore) ---
            // Example:
            // webApp = container "Web Application" "User-facing frontend" "React" "Web Browser"
            // apiService = container "API Service" "Core business logic" "Python/FastAPI" "Service"
            // database = container "Database" "Primary datastore" "PostgreSQL" "Database"

            <containerStubs>
        }

        // --- External Systems ---
        // Example:
        // emailProvider = softwareSystem "Email Provider" "Transactional email delivery" "External System"

        <externalSystemStubs>

        // --- Relationships ---
        user -> <systemId> "Uses"

        // Add cross-container relationships here:
        // webApp -> apiService "Calls" "HTTPS/REST"
        // apiService -> database "Reads/writes" "SQL"

    }

    views {

        systemContext <systemId> "SystemContext" "System context view for <SystemName>" {
            include *
            autoLayout lr
        }

        container <systemId> "Containers" "Container view for <SystemName>" {
            include *
            autoLayout lr
        }

        // Add deploymentEnvironment views here when infrastructure is defined:
        // deploymentEnvironment "<SystemName>" "Production" {
        //     include *
        //     autoLayout lr
        // }

        theme default
    }
}
```

Fill `<SystemName>`, `<systemId>` (camelCase, no spaces), `<containerStubs>`, + `<externalSystemStubs>` from collected information. If user provided "TBD", insert commented-out example block instead.

#### `architecture/policies.yaml` starter set

```yaml
# Architecture Policies for <SystemName>
# Evaluated by: c4-model-validator, c4-architecture-governor
# Severity levels: blocking (halts pipeline), warning (non-blocking), info (advisory)
# Add new policies by appending to this list. Do not remove existing ones without an ADR.

version: "1.0"
policies:

  - id: ARCH-001
    name: bounded-context-isolation
    severity: blocking
    description: >
      No direct cross-bounded-context data access. A service must not query
      a database owned by a different bounded context. Use APIs or events instead.

  - id: ARCH-002
    name: external-system-classification
    severity: blocking
    description: >
      All external systems declared in workspace.dsl must carry at least one
      classification tag: internal, external, third-party, or public.

  - id: ARCH-003
    name: trust-boundary-enforcement
    severity: blocking
    description: >
      Data crossing a zone or network boundary must route through a declared
      trust boundary element (API gateway, BFF, adapter). Direct cross-boundary
      calls without a boundary element are forbidden.

  - id: ARCH-004
    name: no-orphaned-containers
    severity: blocking
    description: >
      Every container must participate in at least one declared relationship
      (as source or target). A container with no relationships is undeclared
      architectural drift.

  - id: ARCH-005
    name: deployment-view-required
    severity: blocking
    description: >
      Every container must appear in at least one deploymentEnvironment view
      before the feature reaches the deployment gate.

  - id: ARCH-006
    name: descriptions-required
    severity: warning
    description: >
      All containers, components, and relationships must carry a non-empty
      description. Blank descriptions degrade diagram readability and downstream
      documentation quality.

  - id: ARCH-007
    name: technology-tags-required
    severity: warning
    description: >
      All containers must carry a technology tag (e.g., "Spring Boot", "React",
      "PostgreSQL", "Kafka"). Technology tags make the model actionable for
      infrastructure and security reviews.

  # --- Add project-specific policies below this line ---
  # Example:
  # - id: ARCH-008
  #   name: pii-datastore-tagging
  #   severity: blocking
  #   description: >
  #     Any datastore that persists personal data must carry the tag "pii:true"
  #     so that GDPR compliance checks can identify it automatically.
```

#### `.factory/context/architecture.md` template

```markdown
# Architecture Context — <SystemName>
<!-- [STUB — update with real content] -->
<!-- Managed by: project-bootstrap -->
<!-- Derived from: canonical architecture artifacts -->
