# Non-Obvious Test Conventions

- <important discovery rule, naming convention, auth/bootstrap requirement, or output convention>
