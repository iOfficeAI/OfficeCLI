# System Context

[Describe the system's purpose and its relationship to users and external systems here]
