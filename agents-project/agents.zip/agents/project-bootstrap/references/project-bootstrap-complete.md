# Project Bootstrap Complete

System: <SystemName>
Blueprint: <blueprint name and path, or "none — manual configuration">

### Files created
[list each file path]

### Files skipped (already existed)
[list each file path]

### Modules not set up (user skipped or not applicable)
[list]

### Next steps
1. Run `mise install` to activate the declared toolchain versions.
2. Review and update `.factory/project.yaml` with actual build commands and paths.
3. Review and update `.factory/project.yaml`, `.factory/context/PROJECT_CONTEXT.md`, and the other files under `.factory/context/` when the stack changes materially.
4. Re-index the stack in MemPalace after material stack or architecture changes.
5. Review and update `architecture/workspace.dsl` with real containers and relationships.
6. Review `architecture/policies.yaml` and add project-specific policies below ARCH-007.
7. Review `compliance/nfr-register.yaml` — remove concern sections that do not apply, update `source:` ADR references, and add project-specific NFRs.
8. Add real ADRs to `architecture/adr/` as decisions are made — one file per decision, numbered sequentially.
9. Run `delivery-orchestrator` on your first petition — the pipeline is ready.
```
