# EXECUTION

### Step 0: Discover blueprints

Before scanning project, look for blueprint files in these locations (in priority order):

1. `.blueprints/` — project-local blueprints (committed to repo, shared with team)
2. `~/.claude/blueprints/` — personal global blueprints (not committed, available across projects)

For each location, list all `*.md` files found. Parse their YAML frontmatter to extract `name` + `description`.

**If blueprints are found:**

Present numbered list + ask:
> "I found these project blueprints. Pick one to pre-fill setup, or type 'none' to configure manually."
>
> 1. `<name>` — `<description>`
> 2. ...

Load selected blueprint. Its values become defaults for all subsequent steps — you skip asking for anything blueprint already provides. user may still override any value.

**If no blueprints are found**, or user picks 'none': proceed with fully manual config.

---

### Step 1: Scan the project

Use filesystem tools to scan project root + common subdirectories. Build readiness report for each module:

```
Module                        | Status
------------------------------|--------
Mise Toolchain                | [ready | missing]   ← always set up
Project Configuration         | [ready | partial | missing]   ← always set up
C4 Architecture Governance    | [ready | partial | missing]
SDLC Planning Infrastructure  | [ready | partial | missing]   ← always set up
Documentation Scaffold        | [ready | partial | missing]
Compliance Registry           | [ready | partial | missing]
```

**Mise Toolchain** — check for:
- `.mise.toml` in project root

**Project Config** — check for:
- `.factory/project.yaml` in project root
- `.factory/context/PROJECT_CONTEXT.md` in project root
- `.factory/context/stack.md` in project root
- `.factory/context/testing.md` in project root

**C4 Arch Governance** — check for:
- `architecture/workspace.dsl`
- `architecture/policies.yaml`

**SDLC Planning Infrastructure** — check for:
- `petitions/` dir
- `petitions/program-status.yaml`

**Docs Scaffold** — check for:
- `AGENTS.md` (or legacy `agents.md` until normalized)
- `architecture/adr/` dir (at least one `.md` file present)
- `architecture/overview.md`

**Compliance Registry** — check for:
- `compliance/nfr-register.yaml`
- `compliance/gdpr-register.csv` or equivalent GDPR data register
- `compliance/rigsarkivet-assessment.csv` or equivalent

### Step 2: Report and confirm

Present readiness report to user.

**Mise Toolchain + Project Config + SDLC Planning Infrastructure are always set up** — if `.mise.toml`, `.factory/project.yaml`, `.factory/context/PROJECT_CONTEXT.md`, `.factory/context/stack.md`, `.factory/context/testing.md`, `petitions/`, or `petitions/program-status.yaml` is missing, produce them without asking for confirmation. They are not optional.

For remaining modules, briefly describe what will be created for each missing or partial one. Ask:
> "Which missing modules should I set up? I will collect minimum required information for each."

Do not proceed without explicit confirmation of at least one additional optional module to set up (Mise Toolchain + Project Config + SDLC Planning Infrastructure are already confirmed).

### Step 3: Collect minimum required information

Ask only for information you cannot derive from project **+ that blueprint does not already provide**. Ask one question at time. If blueprint covers field, state pre-filled value + ask "Is that correct?" before continuing.

**Always required** (for any module):
- Project / system name — use `blueprint.name` if provided, otherwise ask

**Always required for Mise Toolchain** (even if other modules are skipped):
- Primary lang/runtime(s) — use `blueprint.mise.tools` if provided, otherwise ask: "What lang or runtime does this project use? Examples: python, node, dotnet, java, go, rust. List all that apply."

**Always required for Project Config** (even if other modules are skipped):
- Primary lang — use `blueprint.project.language` if provided, otherwise derive from Mise Toolchain answer
- Runtime version — use `blueprint.project.runtime` if provided, otherwise derive from Mise Toolchain answer
- Source dirs — use `blueprint.project.source_directories` if provided, otherwise ask: "What are your source dirs? (e.g., src/, lib/, app/)"
- Test dirs — use `blueprint.project.test_directories` if provided, otherwise ask: "What are your test dirs? (e.g., tests/, test/, spec/)"
- Build cmds (compile, test, lint) — use `blueprint.project.build` if provided, otherwise ask: "What are your build cmds? Provide compile, test, + lint cmds."
- Test framework — use `blueprint.project.test_framework` if provided, otherwise ask: "What test framework does this project use? (e.g., pytest, junit, jest, go test)"
- BDD framework (if applicable) — use `blueprint.project.bdd` if provided, otherwise ask: "Does this project use BDD? If so, which framework? (behave, cucumber-js, godog, cucumber-jvm, or 'none')"
- Tech stack frameworks/libraries — use `blueprint.frameworks` if provided, otherwise ask: "What frameworks/libraries define project stack? Include backend/app, UI or portal, data, integration, + testing. If there is web UI, also state rendering model (server-rendered, SPA, hybrid, or API-only)."
- Distinct E2E layer (required for browser UI projects) — use `blueprint.project.e2e` if provided. Otherwise, if project has browser UI or a non-`API-only` rendering model, ask: "What is the UI E2E test layer or test project? Provide framework, project root, config file, runner, and any install/typecheck/list commands." Only API-only projects may answer `none`.
- Docs tool config — use `blueprint.project.docs` if provided. Otherwise default to `mkdocs-material` with `mkdocs.yml`, `docs/`, `site/`, `mkdocs build --strict`, `mkdocs serve`, and plugins `search`, `tags`, `mermaid2`.
- Optional workflow defaults — use `blueprint.agent_workflow` if provided. Do not ask for this by default. Only ask if the user explicitly wants repo-level delivery defaults such as review breadth, test breadth, or completion-verification behavior captured in `.factory/project.yaml`.
- Optional harness metadata — use `blueprint.harness` if provided. Do not ask for this by default. Only ask if user explicitly wants local-fast / CI-required / coverage / architecture / runtime harness defaults captured in `.factory/project.yaml`.

**Required only if C4 Governance module is selected**:
- Top-level containers — use `blueprint.containers` if provided, otherwise ask: "List your main services or apps, one per line. Use 'TBD' if unknown."
- External systems — use `blueprint.external_systems` if provided, otherwise ask: "List external systems your project integrates with, one per line. Use 'None' if unknown."

**Required only if Compliance Registry module is selected**:
- GDPR applicability — use `blueprint.compliance.gdpr` if provided, otherwise ask: yes / no / unknown
- Rigsarkivet applicability — use `blueprint.compliance.rigsarkivet` if provided, otherwise ask: yes / no / unknown

**Required only if Docs Scaffold module is selected**:
- If Docs module is being set up, use `blueprint.project.docs.sections` when present; otherwise ask: 'What lang should user-facing docs be in?' (default: da) + 'What lang should developer docs be in?' (default: en). Use these to populate `docs.sections.user.language` + `docs.sections.developer.language` fields. Set `docs.site_language` to user-facing lang. Keep docs engine/tool defaults on `mkdocs-material` unless user explicitly asks for a different standard.

For all other modules: stub content is sufficient — no extra questions needed.

### Step 4: Produce selected modules

Produce each confirmed module. Mark each file as `[STUB — update with real content]` in comments so developers know it needs refinement.

---
