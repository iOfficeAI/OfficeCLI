# Project Agent Conventions

- Primary entrypoint: `[STUB — e.g. delivery-orchestrator or project-specific conductor]`
- Petition / request location: `[STUB — e.g. petitions/]`
- Architecture source of truth: `architecture/workspace.dsl`
- Architecture policy source: `architecture/policies.yaml`
- Documentation file agents maintain collaboratively: `AGENTS.md`
- Additional project-local constraints:
  - `[STUB — add repo-specific rules agents must follow]`
  - `[STUB — add escalation paths, forbidden actions, or required review gates]`
