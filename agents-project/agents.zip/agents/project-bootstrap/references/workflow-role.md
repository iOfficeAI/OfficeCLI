# Workflow role

- Role: `worker`
- Binding: `contract_only`
- Goal gate: no
- Human approval node: yes, for optional module selection
- Typical predecessors: `delivery-orchestrator`
- Typical successors: readiness recheck, `project-bootstrap` follow-up, or user escalation
