# Inputs

### Required
- project root

### Optional
- blueprint selection
- project/system name
- language, runtime, and build details
- architecture and compliance module preferences
