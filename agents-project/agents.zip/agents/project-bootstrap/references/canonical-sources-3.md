# Canonical Sources

- `compliance/nfr-register.yaml`
- `compliance/gdpr-register.csv` (if present)
- `compliance/rigsarkivet-assessment.csv` (if present)
