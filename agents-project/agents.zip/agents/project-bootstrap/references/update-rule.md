# Update Rule

- Keep this pack thin. Do not copy the full `stack` section from `.factory/project.yaml`.
```

#### `.factory/context/testing.md` template

```markdown
# Testing Context — <SystemName>
<!-- [STUB — update with real content] -->
<!-- Managed by: project-bootstrap -->
<!-- Derived from: `.factory/project.yaml` -->
