# Decision

The following principles govern all architectural decisions for <SystemName>:

1. **Simplicity first**: Choose the minimal architecture that delivers the stated outcome. Complexity requires explicit justification traceable to a requirement.
2. **Traceability**: Every architectural element must trace to a requirement. Orphaned components — elements with no requirement justification — are defects.
3. **Explicit over implicit**: All dependencies, boundaries, and interfaces must be declared in `architecture/workspace.dsl`. Nothing is assumed.
4. **Policy as code**: Architectural constraints are expressed in `architecture/policies.yaml`. Prose documentation alone is insufficient enforcement.
5. **Living model**: `architecture/workspace.dsl` is the source of truth for system topology. Code and IaC that diverge from the declared model are architectural drift and must be resolved, not accepted.
