# BLUEPRINT FORMAT

Blueprints are Markdown files with YAML frontmatter. frontmatter carries all structured values; Markdown body is free-form ctx for humans (ignored by agent).

Store blueprints in `.blueprints/` (project-local) or `~/.claude/blueprints/` (personal global). File name becomes blueprint's identifier (e.g., `python-fastapi.md`).

### Schema

```yaml
---
# Required
name: "Python FastAPI Microservice"
description: "REST API service using FastAPI, PostgreSQL, Redis, uv, and pyproject.toml"

# Mise toolchain — populates .mise.toml [tools] and [env]
mise:
  tools:
    python: "3.12"
    uv: "latest"
    # node: "22"        # add more runtimes as needed
  env:
    PYTHONDONTWRITEBYTECODE: "1"

# Optional stack hints used for `.factory/project.yaml` `stack` section
project:
  language: "python"
  runtime: "3.12"
  source_directories: ["src/"]
  test_directories: ["tests/"]
  build:
    compile: "uv run python -m compileall src"
    test: "uv run pytest"
    lint: "uv run ruff check . && uv run ty check"
  test_framework: "pytest"
  bdd:
    framework: "behave"
    runner: "uv run behave"
    dry_run: "uv run behave --dry-run"
    step_definitions: "features/steps"
  e2e:
    framework: "playwright"
    project_root: "e2e"
    test_dir: "tests"
    config: "playwright.config.ts"
    install_command: "npm ci"
    type_check_command: "npx tsc --noEmit"
    test_list_command: "npx playwright test --list"
    runner: "npx playwright test"
    report_dir: "playwright-report"
  docs:
    engine: "mkdocs-material"
    config: "mkdocs.yml"
    docs_dir: "docs"
    site_dir: "site"
    build_command: "mkdocs build --strict"
    serve_command: "mkdocs serve"
    plugins:
      - "search"
      - "tags"
      - "mermaid2"

frameworks:
  backend:
    - "FastAPI"
  ui:
    - "React"
  data:
    - "PostgreSQL"
  testing:
    - "uv"
    - "pytest"
  rendering_model: "SPA"

# C4 containers — each entry becomes a container block in workspace.dsl
containers:
  - id: webApi
    name: "Web API"
    description: "FastAPI REST API service"
    technology: "Python/FastAPI"
    tag: "Service"
  - id: database
    name: "Database"
    description: "Primary relational datastore"
    technology: "PostgreSQL"
    tag: "Database"

# C4 external systems — each becomes a softwareSystem in workspace.dsl
external_systems:
  - name: "Email Provider"
    description: "Transactional email delivery"
    tag: "External System"

# Additional ADR principles appended to ADR-0001 (optional)
adr_principles:
  - "All database access goes through the repository pattern — no raw SQL in handlers."
  - "Async FastAPI handlers for all I/O-bound endpoints."
  - "Use `pyproject.toml` as the canonical Python project manifest and `uv` as the default dependency + command runner."

# Optional soft repo defaults for delivery behavior
agent_workflow:
  review_scope: "full"           # full | targeted
  testing_scope: "targeted"      # full | targeted
  goal_verification: true

# Optional harness metadata for future routing / audits
harness:
  local_fast:
    - "uv run ruff check ."
    - "uv run ty check"
    - "uv run pytest -q"
  ci_required:
    - "uv sync --frozen"
    - "uv run pytest"
    - "uv run ruff check ."
    - "uv run ty check"
    - "uv run python -m compileall src"
    - "mkdocs build --strict"
  coverage:
    tool: "pytest-cov"
    command: "uv run pytest --cov=src --cov-report=term-missing --cov-report=xml:coverage.xml --cov-report=html:htmlcov"
    target:
      lines: 85
      branches: 75
    reports:
      console: "term-missing"
      xml: "coverage.xml"
      html_dir: "htmlcov"
  architecture:
    - "workspace.dsl"
    - "policies.yaml"
  runtime:
    - "docker compose up -d"

# Compliance flags — skips asking if set
compliance:
  gdpr: true           # true | false | unknown
  rigsarkivet: false   # true | false | unknown
---
