# Canonical Sources

- `architecture/workspace.dsl`
- `architecture/policies.yaml`
- `architecture/adr/`
