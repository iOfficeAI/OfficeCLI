# Non-Obvious Constraints

- <important migration fact, ambiguity, or repo convention not obvious from project.yaml>
