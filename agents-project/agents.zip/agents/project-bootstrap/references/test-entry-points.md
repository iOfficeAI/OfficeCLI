# Test Entry Points

- Main test locations: <tests/, e2e/, spec/, ...>
- Distinct E2E project/root: <path or `required but not scaffolded yet` or none for API-only>
- Key fixtures/helpers: <paths or none>
- Validation/seed/bootstrap files: <paths or none>
- Coverage goal + report locations: <line/branch targets + xml/html/console outputs or none>
