# Rules

- `.factory/project.yaml` is canonical. If this file conflicts, YAML wins.
- Keep this file stable across sessions.
- Keep it short; link to packs or YAML instead of repeating full stack or command detail.
- Update it when stack, architecture, or delivery conventions change materially.
- Do not put task-specific notes here.
```

#### `.factory/context/stack.md` template

```markdown
# Stack Context — <SystemName>
<!-- [STUB — update with real content] -->
<!-- Managed by: project-bootstrap -->
<!-- Derived from: `.factory/project.yaml` -->
