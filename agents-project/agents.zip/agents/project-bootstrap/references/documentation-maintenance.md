# Documentation Maintenance

- `implementation-doc-sync` updates this file when project-specific agent conventions change.
- `docs/` pages are handled separately and should not be mirrored here.
- Keep this file short. If content is already maintained elsewhere, link to it instead of copying it.
