# Escalation Rules

1. Escalate when critical bootstrap output cannot be written safely.
2. Escalate when project signals conflict so badly that bootstrap defaults would be misleading.
3. Escalate when user wants optional module output without providing minimum required information.
