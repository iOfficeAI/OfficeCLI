# Obligations

- GDPR: <true | false | unknown>
- Rigsarkivet: <true | false | unknown>
