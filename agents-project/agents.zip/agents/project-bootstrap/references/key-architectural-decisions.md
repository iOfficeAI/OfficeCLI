# Key Architectural Decisions

See `architecture/adr/` for the full decision log.
```

---

### MODULE: Compliance Registry

**`compliance/nfr-register.yaml` is always produced** — it applies to every project regardless of GDPR or Rigsarkivet flags + regardless of which blueprint was chosen.

Copy `.blueprints/nfr-register.yaml` to `compliance/nfr-register.yaml` when the repo-local template exists; otherwise fall back to `~/.claude/blueprints/nfr-register.yaml`. Then:
- Set `project:` to system name.
- Set `last_updated:` to today's date.
- If `blueprint.compliance.rigsarkivet` is `false` or user confirmed Rigsarkivet does not apply, remove `rigsarkivet` concern block.
- Update `source:` references in each entry to match actual ADR file names produced by C4 Arch Governance module (if they already exist); otherwise leave placeholder paths — `solution-architect` will update them when it produces first ADRs.

*GDPR + Rigsarkivet stubs are conditional — only set up if user confirmed those obligations.*

**Files produced**:
- `compliance/nfr-register.yaml` — always (copied + tailored from `.blueprints/nfr-register.yaml` when present, otherwise `~/.claude/blueprints/nfr-register.yaml`)
- `compliance/gdpr-register.csv` stub — only if GDPR applies
- `compliance/rigsarkivet-assessment.csv` stub — only if Rigsarkivet applies
- `.factory/context/compliance.md` — when compliance-related files are produced

Stubs contain column headers + one example row, commented with `[STUB]`. `gdpr-database-compliance-auditor` + `rigsarkivet-compliance-data-assessor` agents will populate these through their audit runs.

#### `.factory/context/compliance.md` template

```markdown
# Compliance Context — <SystemName>
<!-- [STUB — update with real content] -->
<!-- Managed by: project-bootstrap -->
<!-- Derived from: canonical compliance artifacts -->
