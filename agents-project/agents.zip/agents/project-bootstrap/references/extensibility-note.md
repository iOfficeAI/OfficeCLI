# EXTENSIBILITY NOTE

To add new module to this agent:
1. Add detection check in Step 1 (one or more file paths that indicate module is set up).
2. Add module name to readiness report table.
3. Add new `### MODULE: <name>` section below existing modules with its files + templates.
4. No other changes are required. Existing modules are unaffected.
