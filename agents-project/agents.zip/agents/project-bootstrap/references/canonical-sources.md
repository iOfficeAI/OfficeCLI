# Canonical Sources

- Project configuration + stack: `.factory/project.yaml`
