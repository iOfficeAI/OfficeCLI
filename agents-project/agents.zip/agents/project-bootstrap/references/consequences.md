# Consequences

- Every architecture review (`solution-architecture-reviewer`) checks conformance to these principles explicitly.
- Deviations are not rejected silently — they must be documented as a new ADR and escalated for human review.
- New principles are added via ADR (new file in `architecture/adr/`), not by editing this document.
- `[STUB — add project-specific principles below this line]`
```

When producing this file, fill in `<SystemName>` + `<today_date>`. `[STUB]` marker signals where team should add system-specific principles.

#### `architecture/overview.md` stub

```markdown
# Architecture Overview — <SystemName>

**Status**: [STUB — update after running `solution-architect` for the first time]

For the machine-readable architecture model, see `architecture/workspace.dsl`.
For architecture policies, see `architecture/policies.yaml`.
For architectural principles and decisions, see `architecture/adr/`.
