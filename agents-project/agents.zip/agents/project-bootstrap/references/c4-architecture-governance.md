# C4 Architecture Governance

Architecture is governed using Structurizr DSL. Key files:

| File | Purpose |
|---|---|
| `architecture/workspace.dsl` | Canonical C4 model — updated by `solution-architect`, maintained by `implementation-doc-sync` |
| `architecture/policies.yaml` | Architecture policy set — evaluated by `c4-model-validator` and `c4-architecture-governor` |

See `architecture/adr/` for architectural decision records that govern all design choices.
```

#### `architecture/adr/0001-architecture-principles.md`

ADR files follow standard format: Title, Status, Context, Decision, Consequences. File naming convention: `NNNN-short-title-kebab-case.md`. first ADR captures foundational architectural principles for system.

```markdown
# ADR-0001: Architecture Principles

**Status**: Accepted
**Date**: <today_date>
**Deciders**: [list names or roles]
