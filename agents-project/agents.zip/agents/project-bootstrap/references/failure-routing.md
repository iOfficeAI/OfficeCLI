# Failure Routing

- missing user confirmation for optional modules -> `blocked`
- incomplete project configuration details -> `needs_more_evidence`
- unwritable output path or invalid parent structure -> `fail`
- no optional modules selected beyond always-on bootstrap -> `success`
