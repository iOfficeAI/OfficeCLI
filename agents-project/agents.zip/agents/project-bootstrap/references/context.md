# Context

Every software system requires a set of foundational principles to guide architectural decisions consistently. Without explicit principles, each decision is made in isolation and the architecture drifts over time.

This ADR establishes the binding principles for <SystemName>. All agents that produce or review architecture (`solution-architect`, `solution-architecture-reviewer`) treat these as non-negotiable constraints. A deviation from any principle requires a new ADR documenting the rationale.
