# Canonical Source

- Project configuration + stack: `.factory/project.yaml`
