# Done Criteria

1. Always-on modules are created when missing.
2. Optional modules are only created after explicit confirmation.
3. Produced files are marked as stubs where refinement is still needed.
4. Summary states what was created, what remains missing, and next step.
