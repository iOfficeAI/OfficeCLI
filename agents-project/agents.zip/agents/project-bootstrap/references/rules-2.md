# Rules

- `architecture/workspace.dsl` is the source of truth for topology.
- Update this file when containers, deployment shape, or architectural policies change materially.
```

---

### MODULE: SDLC Planning Infrastructure *(always produced — not optional)*

**Files produced**:
1. `petitions/` dir (create if absent)
2. `petitions/program-status.yaml` stub (only if absent)

#### `petitions/program-status.yaml` stub

File is canonical planning state for program. This planning scaffold is baseline for delivery-managed repos. `backlog-planner` populates it, `sprint-tracker` updates petition progress, and agents such as `contract-drift-auditor`, `concept-model-curator`, `hotfix-conductor`, and `tech-debt-executor` use `technical_backlog` for durable handoff work.

```yaml
# Program Status — <SystemName>
# Managed by: backlog-planner, sprint-tracker
# Do not edit manually unless correcting a tracking error.

program: <SystemName>
last_updated: <today_date>

# Petition delivery tracking
# status values: pending | planned | in-progress | done | blocked
petitions:
  - id: petition001
    title: "Short imperative title matching petition frontmatter"
    status: pending
    phase: 1                   # delivery phase (backlog-planner assigns)
    sprint: ~                  # sprint number once planned; null until then
    depends_on: []             # list of petition IDs that must complete first
    notes: ""                  # free-form; used for blockers or decisions

# Technical debt items for durable follow-up and agent handoff
# status values: pending | in-progress | done
# source: original trigger for the item (comment, agent, incident, or audit)
technical_backlog:
  - id: TB-001
    title: "Short description of the debt item"
    status: pending
    source: "path/to/file.py:42 AIDEV-TODO"
    source_agent: ~               # optional, e.g. contract-drift-auditor
    petition: ~                   # optional petition linkage, e.g. petition007
    category: ~                   # optional, e.g. contract-drift
    remediation_target: ~         # optional, e.g. mapper
    evidence_artifact: ~          # optional review/audit artifact path
    finding_id: ~                 # optional stable finding key for deterministic hotspot debt
    severity: ~                   # optional, e.g. blocking | warning | context
    triage_status: ~              # optional, e.g. untriaged | accepted | planned | deferred | waived
    policy_version: ~             # optional deterministic policy identifier
    notes: ""
```

---

### MODULE: Documentation Scaffold

**Files produced** (only those that are absent):
1. `AGENTS.md`
2. `architecture/adr/0001-architecture-principles.md`
3. `architecture/overview.md` stub

#### `AGENTS.md` content

Canonical file name is `AGENTS.md`. Preserve lowercase `agents.md` only in legacy repos that already use it until they are normalized. If `AGENTS.md` already exists, append C4 governance section only if it is not already present. Do not overwrite existing project-specific conventions. If absent, create a minimal file focused on project-local agent guidance rather than a duplicate catalog of standard agents.

```markdown
# Agents — <SystemName>

This file captures **project-specific conventions** that agents and humans maintain collaboratively. It is maintained by `implementation-doc-sync` when project-local agent behavior, constraints, or documentation expectations change.

Do **not** duplicate the full standard agent catalog here. Global agent definitions already live in their own agent files. This document should only record what is specific to this repository.
