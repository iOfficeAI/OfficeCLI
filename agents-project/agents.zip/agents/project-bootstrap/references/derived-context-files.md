# Derived Context Files

- Stack: `.factory/context/stack.md`
- Testing: `.factory/context/testing.md`
- Architecture: `.factory/context/architecture.md` (if present)
- Compliance: `.factory/context/compliance.md` (if present)
