# MODULE DEFINITIONS

---

### MODULE: Mise Toolchain *(always produced — not optional)*

**Files produced**:
1. `.mise.toml`

Mise is project's canonical tool version manager regardless of tech stack. Every project gets `.mise.toml` at root. This keeps reproducible toolchain versions across developer machines, CI, + agent environments.

#### `.mise.toml` template

Populate `[tools]` based on declared lang/runtime(s). Include only what project uses. Use `[env]` to set any runtime-specific env variables that mise should export.

**Python**:
```toml
[tools]
python = "3.12"
uv = "latest"

[env]
PYTHONDONTWRITEBYTECODE = "1"
```

**Node.js**:
```toml
[tools]
node = "22"
```

**.NET**:
```toml
[tools]
dotnet = "9"

[env]
DOTNET_CLI_TELEMETRY_OPTOUT = "1"
```

**Java**:
```toml
[tools]
java = "temurin-21"
```

**Go**:
```toml
[tools]
go = "1.22"
```

**Rust**:
```toml
[tools]
rust = "1.78"
```

**Polyglot example (Python + Node)**:
```toml
[tools]
python = "3.12"
uv = "latest"
node = "22"

[env]
PYTHONDONTWRITEBYTECODE = "1"
```

Select appropriate block(s) from above. If version is unknown, use latest stable (look it up or use `latest` as version string + add `# [STUB — pin to exact version]` comment). Never produce empty `[tools]` block.

---

### MODULE: Project Configuration *(always produced — not optional)*

**Files produced**:
1. `.factory/project.yaml`
2. `.factory/context/PROJECT_CONTEXT.md`
3. `.factory/context/stack.md`
4. `.factory/context/testing.md`

Project Config is canonical build, test, + stack config file for project. It provides downstream agents (tdd-enforcer, bdd-test-generator, bdd-test-coverage-auditor, pipeline-conductor, + others) with cmds, paths, + stack facts they need to compile, test, lint, + reason about tooling. Every project gets `.factory/project.yaml`. Create `.factory/` dir if it absent.

`PROJECT_CONTEXT.md` + the other files under `.factory/context/` are **derived navigation artifacts**, not second sources of truth. Keep them thin. They should point back to `.factory/project.yaml`, highlight repo signals, + record only non-obvious constraints or navigation hints that help downstream agents avoid broad exploration.

#### `.factory/project.yaml` template

```yaml
# Project Configuration — <SystemName>
# [STUB — update with real content]
# Managed by: project-bootstrap
# Used by: delivery-orchestrator, pipeline-conductor, release-manager, tdd-enforcer, bdd-test-generator, bdd-test-coverage-auditor

project:
  name: "<SystemName>"                         # [STUB — update with real content]
  language: "<primary language>"               # [STUB — update with real content]
  runtime: "<runtime version>"                 # [STUB — update with real content]
  source_directories:
    - "src/"                                   # [STUB — update with real content]
  test_directories:
    - "tests/"                                 # [STUB — update with real content]
  build:
    compile: "<compile command>"               # [STUB — update with real content]
    test: "<test command>"                     # [STUB — update with real content]
    lint: "<lint command>"                     # [STUB — update with real content]
  bdd:
    framework: "<behave|cucumber-js|godog|cucumber-jvm>"  # [STUB — update with real content]
    runner: "<bdd run command>"                # [STUB — update with real content]
    dry_run: "<bdd dry-run command>"           # [STUB — update with real content]
    step_definitions: "<path to step defs>"    # [STUB — update with real content]
  test_framework: "<pytest|junit|jest|...>"    # [STUB — update with real content]
  # Required when the project has browser UI or non-API rendering.
  e2e:
    framework: "<playwright|cypress|selenium>"   # [STUB — update with real content]
    project_root: "<path to standalone e2e project or root>"
    test_dir: "<path to e2e tests>"
    config: "<playwright.config.ts|cypress.config.ts|...>"
    install_command: "<npm ci|pnpm install --frozen-lockfile|...>"
    type_check_command: "<npx tsc --noEmit|~>"
    test_list_command: "<npx playwright test --list|~>"
    runner: "<npx playwright test|npm run e2e|...>"
    report_dir: "<playwright-report|cypress/results|...>"
  docs:
    engine: "mkdocs-material"
    config: "mkdocs.yml"
    docs_dir: "docs"
    site_dir: "site"
    build_command: "mkdocs build --strict"
    serve_command: "mkdocs serve"
    plugins:
      - "search"
      - "tags"
      - "mermaid2"
    site_language: da        # MkDocs default locale (ISO 639-1, e.g. da, en, de)
    sections:
      user:
        language: da
        label: "Brugervejledning"
        enabled: true
      developer:
        language: en
        label: "Developer Guide"
        enabled: true
      operations:
        language: en
        label: "Operations"
        enabled: true
      compliance:
        language: da
        label: "Compliance"
        enabled: false        # enable when GDPR/Rigsarkivet audits are available
stack:
  languages:
    - "<python|typescript|go|java|...>"        # [STUB — update with real content]
  runtimes:
    - "<3.12|node 22|temurin-21|...>"          # [STUB — update with real content]
  frameworks:
    backend:
      - "<FastAPI|Spring Boot|ASP.NET|Express|...>"
    ui:
      - "<React|Vue|Thymeleaf|Razor|none|...>"
    data:
      - "<PostgreSQL|Hibernate|Prisma|EF Core|none|...>"
    integration:
      - "<REST|GraphQL|Kafka|none|...>"
    testing:
      - "<pytest|Jest|Playwright|JUnit|Cucumber|...>"
  rendering:
    mode: "<server-rendered|SPA|hybrid|API-only|unknown>"
    dynamic_interaction: "<HTMX|Turbo|fetch/AJAX|React state/router|LiveView|unknown>"
  notes:
    - "<important constraints, conventions, or unknowns>"
agent_workflow:
  review_scope: "full"                         # [STUB — optional soft default: full | targeted]
  testing_scope: "full"                        # [STUB — optional soft default: full | targeted]
  goal_verification: true                      # [STUB — optional soft default; never bypasses mandatory evidence gates]
harness:
  local_fast:
    - "<fast local guard command>"             # [STUB — optional]
  ci_required:
    - "<required CI command or check>"         # [STUB — optional]
  coverage:
    tool: "<jacoco|pytest-cov|vitest|coverlet|...>"   # [STUB — optional]
    command: "<coverage command that emits reports>"  # [STUB — optional]
    target:
      lines: 80
      branches: 70
    reports:
      console: "<term-missing|text-summary|CI summary|...>"
      xml: "<coverage.xml|target/site/jacoco/jacoco.xml|...>"
      html_dir: "<htmlcov|coverage|target/site/jacoco|...>"
  architecture:
    - "<ArchUnit|workspace.dsl|policies.yaml|...>"   # [STUB — optional]
  runtime:
    - "<docker compose up|grafana stack|smoke test path|...>"  # [STUB — optional]
```

Fill values from collected information. Use blueprint defaults where available. If BDD is not applicable (user answered 'none'), omit `bdd` section entirely. If project has browser UI or a non-`API-only` rendering model, do **not** omit `e2e`; capture it explicitly and use `[STUB — update with real content]` where details are still unknown. Only API-only projects may omit `e2e` entirely. `docs` defaults to `mkdocs-material` with standard config/build/serve fields unless the blueprint or user explicitly overrides them. `agent_workflow` is optional soft repo-default metadata: write it only when the blueprint or user supplies useful review/testing/completion-verification defaults, and treat explicit user instruction in a later run as higher precedence than these defaults. `harness` is optional executable metadata: write it when the blueprint or user supplies useful local-fast / CI / coverage / architecture / runtime defaults; omit it otherwise. When coverage metadata is known, include both the target threshold(s) and where agents should read the report outputs. Fill `stack` from collected information, blueprint hints, existing manifests/config files, + `containers[].technology` where available. If user provided partial answers, fill what is known + mark unknowns with `[STUB — update with real content]`. If detail is unknown during later updates, write `unknown` rather than guessing.

#### `.factory/context/PROJECT_CONTEXT.md` template

Write a stable, thin repo-local context file used before broad repo exploration. It should orient agents quickly without repeating full config already present in `.factory/project.yaml`:

```markdown
# Project Context — <SystemName>
<!-- [STUB — update with real content] -->
<!-- Managed by: project-bootstrap -->
<!-- Derived from: `.factory/project.yaml` -->
<!-- Stable context only; task-specific notes belong in SESSION_CONTEXT.md -->
