# Status Vocabulary

- `success` — confirmed bootstrap files were produced and readiness summary is explicit
- `blocked` — required user confirmation or critical bootstrap info is missing
- `needs_more_evidence` — project details are too incomplete to produce one or more selected modules safely
- `fail` — bootstrap could not complete because output paths or required filesystem state were unusable
