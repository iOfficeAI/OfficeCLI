# System Shape

- Top-level containers/services: <list>
- External systems: <list>
- Key trust boundaries: <list or unknown>
