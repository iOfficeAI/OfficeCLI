# Notes

Any free-form context about when to use this blueprint, team conventions, or links to further documentation. Ignored by the bootstrap agent.
```

### Available fields

| Field | Type | Required | Purpose |
|---|---|---|---|
| `name` | string | ✓ | Shown in blueprint selection menu |
| `description` | string | ✓ | One-line summary in selection menu |
| `mise.tools` | map | ✓ | Populates `[tools]` in `.mise.toml` |
| `mise.env` | map | — | Populates `[env]` in `.mise.toml` |
| `project` | map | — | Pre-fills `.factory/project.yaml` language/runtime/build/test/lint/test-framework defaults |
| `project.e2e` | map | — | Pre-fills the E2E layer in `.factory/project.yaml`; required when the stack has browser UI |
| `project.docs` | map | — | Declares docs engine/config/build defaults; standard is `mkdocs-material` unless explicitly overridden |
| `frameworks` | map | — | Pre-fills `.factory/project.yaml` `stack` section with backend/UI/data/testing stack hints |
| `agent_workflow` | map | — | Optional soft repo defaults for delivery behavior such as `review_scope`, `testing_scope`, and `goal_verification` |
| `containers` | list | — | Pre-fills workspace.dsl containers |
| `external_systems` | list | — | Pre-fills workspace.dsl external systems |
| `adr_principles` | list | — | Appended to ADR-0001 Consequences |
| `harness` | map | — | Optional metadata for local-fast / CI / coverage / architecture / runtime harness defaults |
| `harness.coverage` | map | — | Declares coverage tool, gate thresholds, and report output locations for agents and CI |
| `compliance.gdpr` | bool | — | Skips GDPR question |
| `compliance.rigsarkivet` | bool | — | Skips Rigsarkivet question |

Any field that is absent falls back to manual prompting. blueprint never locks out user overrides.

### Naming convention

Use kebab-case filenames that describe project type: `python-fastapi.md`, `dotnet-webapi.md`, `node-express.md`, `java-spring-batch.md`, `go-grpc-service.md`. filename is not displayed — only `name` + `description` from frontmatter are shown to user.

---



- **Always produce `.mise.toml`, `.factory/project.yaml`, + base `.factory/context/` files** — they are non-optional bootstrap files. Never skip them.
- Never overwrite file that already exists. If file exists but is stub (contains `[STUB]` marker), ask user whether to overwrite.
- Never produce file with empty required fields — use explicit `[STUB]` markers that are easy to find + replace.
- Never set up Compliance Registry module without explicit user confirmation that it applies.
- Always confirm system name before producing any file.
- Always produce completion report listing every file path created.
