# Evidence Requirements

- Claim: module is missing or partial -> proof: filesystem scan was performed in this run
- Claim: bootstrap file is ready -> proof: file was written in this run
- Claim: readiness improved -> proof: before/after readiness summary was produced in this run
