# Procedure

1. Discover blueprints and offer prefill choice when available.
2. Scan project readiness across bootstrap modules.
3. Report missing or partial modules and collect only minimum required information.
4. Produce confirmed bootstrap scaffolding files with stub markers where appropriate.
5. Write stack/context memory and summarize what was created and what remains.
