# Output Contract

### Artifacts
- bootstrap scaffolding files under project root
- readiness summary
- stack/context memory updates when applicable

### Report Fields
- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields
- `claim`
- `proof`
- `freshness`
- `result`
