# Preconditions

1. Bootstrap target repo is readable.
2. Always-on modules may be produced without extra confirmation.
3. Optional modules require explicit user confirmation before creation.
