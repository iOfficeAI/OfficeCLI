# Repo Signals

- Primary manifests/configs: <list the files that prove this stack>
- Main app entrypoints/modules: <high-signal paths only>
- UI/service boundaries: <high-signal paths, or none>
