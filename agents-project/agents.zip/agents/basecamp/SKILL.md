---
name: basecamp
description: "Use when you need to interact with Basecamp via the Basecamp CLI. Full API coverage: projects, todos, cards, messages, files, schedule, check-ins, timeline, recordings, templates, webhooks, subscriptions, lineup, chat, gauges, assignments, notifications, and accounts. Use for ANY Basecamp question or action."
triggers:
  # Direct invocations
  - basecamp
  - /basecamp
  # Resource actions
  - basecamp todo
  - basecamp project
  - basecamp card
  - basecamp chat
  - basecamp campfire
  - basecamp message
  - basecamp file
  - basecamp document
  - basecamp schedule
  - basecamp checkin
  - basecamp check-in
  - basecamp timeline
  - basecamp template
  - basecamp webhook
  - basecamp gauge
  - basecamp assignment
  - basecamp notification
  - basecamp account
  # Common actions
  - link to basecamp
  - track in basecamp
  - post to basecamp
  - comment on basecamp
  - complete todo
  - mark done
  - create todo
  - move card
  - download file
  # Search and discovery
  - search basecamp
  - find in basecamp
  - look up basecamp
  - check basecamp
  - list basecamp
  - show basecamp
  - get from basecamp
  - fetch from basecamp
  # Questions
  - can I basecamp
  - how do I basecamp
  - what's in basecamp
  - what basecamp
  - does basecamp
  # My work
  - my todos
  - my tasks
  - my schedule
  - my basecamp
  - assigned to me
  - my assignments
  - my notifications
  - overdue todos
  - upcoming events
  - project gauge
  - project progress
  # URLs
  - 3.basecamp.com
  - basecampapi.com
  - https://3.basecamp.com/
invocable: true
argument-hint: "[action] [args...]"
---
# /basecamp - Basecamp Workflow Command

Full CLI coverage: 155 endpoints across todos, cards, messages, files, schedule, check-ins, timeline, recordings, templates, webhooks, subscriptions, lineup, chat, gauges, assignments, notifications, and accounts.

## References

This skill content is modularized into reference docs for readability.

- [Agent Invariants](references/agent-invariants.md) - extracted from SKILL body
- [Quick Reference](references/quick-reference.md) - extracted from SKILL body
- [URL Parsing](references/url-parsing.md) - extracted from SKILL body
- [Decision Trees](references/decision-trees.md) - extracted from SKILL body
- [Common Workflows](references/common-workflows.md) - extracted from SKILL body
- [Resource Reference](references/resource-reference.md) - extracted from SKILL body
- [Configuration](references/configuration.md) - extracted from SKILL body
- [Error Handling](references/error-handling.md) - extracted from SKILL body
- [Built-in jq Filtering](references/built-in-jq-filtering.md) - extracted from SKILL body
- [Exit Codes](references/exit-codes.md) - extracted from SKILL body
- [Learn More](references/learn-more.md) - extracted from SKILL body
