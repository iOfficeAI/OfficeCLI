---
name: delivery-orchestrator
description: "Use when you need to guide delivery work from current repo state to the first safe next step, showing viable routes and the recommended handoff."
workflow_role: orchestrator
workflow_binding: graph_aligned
graph_node_ids:
  - readiness_check
  - readiness_decision
  - bootstrap_gate
  - bootstrap_project
  - proceed_with_gaps
  - hotfix_detection
  - hotfix_decision
  - hotfix_gate
  - hotfix_delegate
  - inspect_inputs
  - classify_entrypoint
  - ideation_path
  - ideation_approval
  - bounded_requirements_path
  - requirements_approval
  - gherkin_path
  - planning_decision
  - backlog_planning
  - planning_gate
  - pipeline_delegate
  - handoff_verification
  - next_step_recommendation
  - escalation_gate
upstream_dependencies:
  - user request
  - petition artifacts when present
  - project infrastructure files
primary_outputs:
  - routing decision
  - readiness summary
  - next-step recommendation
  - delivery track recommendation
  - telemetry coverage status
  - handoff recommendation
default_next:
  success: downstream handoff or approval boundary
  partial_success: approval boundary or exit pending approval
  blocked: user escalation
  needs_more_evidence: proof gathering or user clarification
  retry: same routing node with clarified inputs
  fail: user escalation
---

# Purpose

Inspect current repo state, choose the correct entrypoint into the delivery process, and recommend the first safe next step. This skill owns **routing judgement, approval-boundary enforcement, readiness-risk decisions, and handoff policy**. Deterministic readiness, contract, tracking, and telemetry checks belong to the script layer.

## Workflow role

- Role: `orchestrator`
- Binding: `graph_aligned`
- Goal gate: no
- Human approval node: yes, for bootstrap acceptance, ideation or requirements approval boundaries, and any user choice to proceed with acknowledged gaps
- Typical predecessors: direct user request
- Typical successors: `project-bootstrap`, `hotfix-conductor`, `ideation`, `prompt-to-requirements`, `petition-to-gherkin`, `backlog-planner`, `pipeline-conductor`, or exit

## Inputs

### Required

- current user request

### Optional

- petition artifacts when present
- `petitions/program-status.yaml`
- `.factory/project.yaml`
- telemetry artifacts for a known petition
- repo scaffolds such as architecture and docs files

## Preconditions

1. Read enough of the current request to determine whether it is ideation, bounded intake, artifact-based continuation, or production incident.
2. Verify any file or artifact claim from fresh repository evidence in this run.
3. Do not route to downstream execution until the correct approval state is known.

## Startup recall

You may review recent delivery-orchestrator diary/search results to surface prior routing decisions or known gaps worth re-checking. Recalled context is a hint only until the canonical repo artifact is reopened in this run.

## Deterministic checks

1. **Project readiness summary**
   - Run:
     `python scripts/readiness_check.py --root <repo> --json`
   - Use the output as the canonical Phase 0 readiness summary for:
     - `petitions/program-status.yaml`
     - `architecture/workspace.dsl`
     - `architecture/policies.yaml`
     - `AGENTS.md / agents.md`
     - `architecture/adr/`
     - `domain/concept-model.yaml`
   - Baseline planning scaffold is always required. Architecture, docs, and concept-model groups become required only when the chosen route needs them.
2. **Project contract sanity**
   - When `.factory/project.yaml` exists, run:
     `python scripts/project_contract_lint.py --root <repo> --json`
   - Use it as the source of truth for browser-UI signals, workflow defaults, harness declarations, and repo/config mismatches.
3. **Tracked petition sanity**
   - When a known petition is already tracked, run:
     `python scripts/delivery_state_lint.py --root <repo> --json --petition-id <id>`
   - Use it to verify that the tracked petition state, review references, escalation references, and release metadata are not structurally broken before routing from them.
4. **Telemetry coverage**
   - When a petition ID is known, run:
     `python scripts/telemetry_tool.py lint --root <repo> --json --petition-id <id>`
   - If the artifact is missing, unreadable, or the petition ID is still unknown, report `telemetry_coverage: absent`.
   - Use telemetry only as routing guidance, never as approval proof.
5. Record script runs as evidence with the exact command and result. If a required deterministic check fails, route conservatively rather than improvising around it.

## Procedure

### 1. Readiness first

1. Run `readiness_check.py` before classifying the main path.
2. Surface missing scaffolds honestly:
   - baseline planning scaffold missing -> offer `project-bootstrap`
   - architecture or docs scaffold missing -> optional unless the chosen path explicitly requires them
   - concept model missing -> recommended but not blocking; suggest `concept-model-curator` when relevant
3. If the user confirms bootstrap, delegate to `project-bootstrap`, wait for completion, and rerun readiness.
4. If the user declines bootstrap while baseline or path-required scaffolding is missing, keep the gap explicit in the report and do not silently route to unsafe execution.

### 2. Detect hotfix fast-track

1. Check whether the request describes a production incident.
2. If it does, ask whether to use **Hotfix fast-track** or **Full pipeline**.
3. If hotfix is selected, delegate to `hotfix-conductor` and stop normal routing.

### 3. Inspect artifacts and classify intake

1. Verify explicit paths first when the user provides them.
2. Inspect available artifacts in this order:
   - `petition<ID>.md`
   - `petition<ID>-outcome-contract.md`
   - `petition<ID>.feature`
3. Classify the request into exactly one of:
   - **Path A**: ideation intake
   - **Path B**: bounded prompt-only intake
   - **Path C**: petition plus outcome contract, but no feature file
   - **Path D**: petition, outcome contract, and feature file already exist
4. When `.factory/project.yaml` exists, use `project_contract_lint.py` output to carry workflow defaults and browser-UI constraints into the handoff.
5. When `petitions/program-status.yaml` tracks the petition, use `delivery_state_lint.py` output as the trusted structural state before using it for routing.

### 4. Resolve delivery track

1. Resolve any declared `delivery_track` from petition artifacts or tracked state.
2. If none exists, recommend a provisional track from current evidence:
   - `quick` for clearly bounded, low-risk single-petition work
   - `standard` for approved petition-sized work without heavy governance signals
   - `governed` for cross-cutting, compliance-sensitive, architecture-heavy, or multi-phase work
3. If a weaker requested or declared track conflicts with current evidence, recommend the safer track and explain why.
4. Do not let `quick` skip planning or approval gates.

### 5. Resolve telemetry coverage

1. When a petition ID is known, use `telemetry_tool.py lint` to report `measured`, `partial`, or `absent`.
2. When token calibration matters and coverage is `partial` or `absent`, carry that gap into the next-step recommendation.

### 6. Decide whether planning is required

Use `backlog-planner` when one or more are true:

1. work spans multiple petitions
2. change is cross-cutting, dependency-heavy, or likely multi-sprint
3. the next implementation slice is unclear
4. `petitions/program-status.yaml` exists and should be refreshed before execution
5. the caller explicitly asks for sequencing, phase planning, sprint planning, or next-best-slice guidance
6. the resolved delivery track is `governed`

If work is single, already approved, and clearly bounded, you may skip planning, but say why.

### 7. Route to exactly one entrypoint

#### Path A: ideation intake

- Use when only a broad or ambiguous plain-language request exists.
- Delegate to `ideation`.
- Treat the resulting brief as an approval boundary.

#### Path B: bounded prompt-only intake

- Use when no petition artifacts exist, but the request is already clear enough for one bounded petition.
- Delegate to `prompt-to-requirements`.
- Treat resulting drafts as an approval boundary unless the user explicitly provides prior approval.

#### Path C: petition and outcome contract exist, but no feature file

- Verify both artifacts exist and are non-empty.
- Delegate to `petition-to-gherkin`.
- If planning is required, route through `backlog-planner` before `pipeline-conductor`.
- Otherwise hand off directly to `pipeline-conductor`.

#### Path D: petition, outcome contract, and feature file already exist

- Verify all three artifacts exist and are non-empty.
- If planning is required, route through `backlog-planner` before `pipeline-conductor`.
- Otherwise hand off directly to `pipeline-conductor`.

### 8. Approval and delegation rules

1. `ideation` is always an approval boundary.
2. `prompt-to-requirements` is always an approval boundary.
3. Never infer approval from silence.
4. Reuse existing agents; do not duplicate their work.
5. Do not write code, specs, tests, or architecture yourself.
6. Do not invent missing artifacts. Report what is missing.

## Output Contract

### Artifacts

- routing decision in the final report
- readiness summary when infrastructure is checked
- escalation entry in `petitions/program-status.yaml` when required
- post-workflow next-step recommendation in the final report

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `delivery_track`
- `track_rationale`
- `telemetry_coverage`
- `available_options`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` — the correct route and first safe next step were identified from fresh evidence
- `partial_success` — a route was identified, but an approval boundary or accepted readiness gap stops immediate execution
- `blocked` — missing baseline or path-required scaffolding, broken tracked state, or explicit blocker prevents safe routing
- `needs_more_evidence` — the request or repo evidence is too incomplete to choose a safe route confidently
- `retry` — rerun routing after targeted clarification or scaffold repair
- `fail` — core routing checks could not complete safely

## Done Criteria

1. The readiness summary came from `readiness_check.py`.
2. Any `.factory/project.yaml` routing assumptions came from `project_contract_lint.py` when that file exists.
3. Any tracked-petition routing assumption came from fresh artifact checks and `delivery_state_lint.py` when applicable.
4. The chosen route, approval state, and first required step are explicit.
5. Telemetry coverage is explicit when a petition is known.

## Evidence Requirements

- Claim: scaffold is present or missing -> proof: `readiness_check.py` output was checked in this run
- Claim: project contract supports a routing assumption -> proof: `project_contract_lint.py` output was checked in this run
- Claim: tracked petition state is structurally usable -> proof: `delivery_state_lint.py` output was checked in this run
- Claim: telemetry coverage is `measured`, `partial`, or `absent` -> proof: `telemetry_tool.py lint` output or explicit artifact absence was checked in this run
- Claim: approval boundary applies -> proof: artifact state and user approval state were checked in this run

## Failure Routing

- missing baseline planning scaffold and no user acceptance of the gap -> `blocked`
- `.factory/project.yaml` exists but fails project-contract lint for path-critical assumptions -> `needs_more_evidence`
- tracked petition state fails delivery-state lint -> `blocked`
- request is too ambiguous for safe path selection -> `needs_more_evidence`
- required routing checks cannot run because the repo state is unusable -> `fail`

## Never Do

- never re-derive readiness summary in prose when `readiness_check.py` can decide it
- never bypass ideation or requirements approval boundaries
- never let `quick` track suppress planning or approval gates
- never route from structurally broken tracked state
- never treat telemetry as approval proof
- never write code, tests, specs, or architecture from this skill
