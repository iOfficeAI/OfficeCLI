# Startup Recall

Before starting, search for prior findings in this domain.

1. Call `mempalace_diary_read` with `agent_name: "delivery-orchestrator"` and `last_n: 3`.
2. Then call `mempalace_search` with `wing` set to the current project or repo name and `limit: 5` for:
   - `query: "<topic> PATTERN"`
   - `query: "<topic> DECISION"`
3. Replace `<topic>` with the primary domain keyword from the petition or request.

Use recalled entries only to surface prior blockers, reusable routing patterns, approved evidence paths, and decisions worth re-checking in the repo.
