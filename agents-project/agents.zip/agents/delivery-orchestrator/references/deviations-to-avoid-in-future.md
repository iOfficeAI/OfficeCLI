# Deviations to Avoid in Future

- <specific anti-pattern with context>
```

Store it directly in MemPalace with `mempalace_diary_write`:

- `agent_name: "delivery-orchestrator"`
- `entry: <the diary content above>`
- `topic: "petition<ID>"`
