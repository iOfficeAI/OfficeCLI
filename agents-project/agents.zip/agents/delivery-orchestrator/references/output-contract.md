# Output Contract

### Artifacts

- routing decision in the final report
- readiness summary when infrastructure is checked
- escalation entry in `petitions/program-status.yaml` when required
- post-workflow next-step recommendation in the final report

### Report Fields

- `status` — `success | partial_success | blocked | needs_more_evidence | retry | fail`
- `summary` — chosen entrypoint and routing rationale
- `artifacts` — artifacts found or created
- `evidence_checked` — readiness, approval, and planning checks performed in this run
- `delivery_track` — `quick | standard | governed`
- `track_rationale` — why this track was chosen or why a declared track was upgraded
- `telemetry_coverage` — `measured | partial | absent`
- `available_options` — candidate next steps with `action`, `target`, `preconditions_met`, `missing_evidence`, and `rationale`
- `warnings` — residual gaps, acknowledged infra issues, or approval waits
- `escalations` — escalation ID or `none`
- `next_action` — immediate next step required
- `handoff_target` — `project-bootstrap | approval-only | backlog-planner | pipeline-conductor | hotfix-conductor | exit`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`
