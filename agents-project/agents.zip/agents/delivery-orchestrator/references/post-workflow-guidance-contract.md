# Post-Workflow Guidance Contract

Every completed run must end with:

1. one binding `next_action` and `handoff_target`
2. one explicit `delivery_track`
3. one explicit `telemetry_coverage`
4. an `available_options` list that explains what else is possible, what is blocked, and why
