# Escalation Rules

1. Escalate when baseline or path-required scaffolding is missing and the user declines bootstrap.
2. Escalate when approval state cannot be established from fresh evidence.
3. Escalate when planning reports out-of-sequence work or unresolved blockers.
4. Escalate when the request mixes ideation, hotfix, and bounded delivery signals in a way that makes safe routing ambiguous.
5. Escalate when a weaker requested `delivery_track` conflicts with current evidence and the user still wants to proceed.
