# Evidence Requirements

- Claim: route is ready -> proof: required artifacts exist and approval state is explicit
- Claim: approval boundary has been passed -> proof: caller clearly approved the relevant artifact in this run or an approved artifact exists and was verified
- Claim: downstream handoff is safe -> proof: readiness gaps, planning state, and required artifacts were checked in this run
- Claim: delivery track is appropriate -> proof: petition scope, declared track, and current repo state were checked in this run
- Claim: telemetry coverage is `measured`, `partial`, or `absent` -> proof: telemetry artifact state or explicit absence was checked in this run
- Claim: alternate route is viable -> proof: route preconditions and missing evidence were checked in this run
