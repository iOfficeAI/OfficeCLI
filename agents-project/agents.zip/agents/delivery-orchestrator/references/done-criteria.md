# Done Criteria

Do not consider the run complete until all of the following are true:

1. The chosen route is explicit.
2. Required input artifacts for that route were verified in this run.
3. Approval state is explicit when the route depends on approval.
4. Any planning decision is explicit and justified.
5. Any handoff or stop condition is reported with fresh evidence.
6. Delivery track is explicit or provisionally recommended with rationale.
7. Telemetry coverage is explicit for the current petition context, or reported as `absent` when telemetry is not yet available.
8. The binding next step is distinguished from other available options.
