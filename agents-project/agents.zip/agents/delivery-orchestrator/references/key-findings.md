# Key Findings

- PATTERN: <pattern observed, positive or negative>
- FACT: <constraint, business rule, or technical gotcha>
- DECISION: <decision made with rationale>
- DEVIATION: <anti-pattern to prevent in future>
- INVESTIGATION: <root cause of a problem resolved>
