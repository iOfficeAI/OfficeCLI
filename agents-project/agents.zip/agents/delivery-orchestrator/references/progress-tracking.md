# Progress Tracking

Track progress by updating `petitions/program-status.yaml` for the active petition when the repo uses planning-state tracking.

Phases:

1. Project readiness check
2. Hotfix detection
3. Inspect inputs
4. Decide whether planning is required
5. Resolve delivery track
6. Choose entrypoint
7. Run required delegation path
8. Resolve telemetry coverage and report next step
