# Failure Routing

- missing baseline or path-required scaffolding -> offer bootstrap, then either proceed with acknowledged gap or escalate
- production incident -> route to `hotfix-conductor` if chosen
- missing required artifacts for chosen path -> `blocked`
- unclear approval state -> `needs_more_evidence`
- planning says work is blocked or out of order -> `blocked`
- declared delivery track conflicts with observed scope -> warn and recommend safer track; escalate if the weaker path is insisted on
- recoverable readiness ambiguity -> `retry` once with explicit clarification request
- delegated step fails -> `fail` and surface exact blocker
