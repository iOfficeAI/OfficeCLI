# Escalation Registry

When the user declines bootstrap while baseline or path-required scaffolding is missing, always record the escalation in the completion report. If `petitions/program-status.yaml` exists, also write the escalation under `escalations`. If the missing baseline scaffold is `petitions/program-status.yaml` itself, the completion report is the canonical escalation surface for that run.

When `petitions/program-status.yaml` exists, write the escalation entry under `escalations`:

```yaml
escalations:
  - id: ESC-NNN
    petition: P-NNN
    phase: 0
    agent: delivery-orchestrator
    reason: "<missing scaffold> not found; user declined bootstrap"
    status: open
    resolution: ~
    created: <date>
    resolved_date: ~
```
