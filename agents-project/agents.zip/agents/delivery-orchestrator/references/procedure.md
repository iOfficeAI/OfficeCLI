# Procedure

### Phase 0: Project Readiness Check

Before inspecting petition artifacts, verify which project scaffolds are present so routing can account for real gaps without pretending every optional module is mandatory.

Check for:

- `petitions/program-status.yaml` — baseline planning state for delivery-managed repos
- `architecture/workspace.dsl` — C4 governance scaffold; required only when architecture governance or deployment drift checks are in scope
- `architecture/policies.yaml` — policy scaffold paired with `architecture/workspace.dsl`
- `AGENTS.md` (legacy `agents.md` accepted until normalized) — collaborative conventions file when docs scaffold is enabled
- `architecture/adr/` — ADR scaffold when architecture governance is enabled
- `domain/concept-model.yaml` — recommended for domain alignment

Build a readiness summary in this format:

```text
petitions/program-status.yaml  [found | MISSING]
architecture/workspace.dsl     [found | MISSING]
architecture/policies.yaml     [found | MISSING]
AGENTS.md / agents.md          [found | MISSING]
architecture/adr/              [found | MISSING]
domain/concept-model.yaml      [found | MISSING]
```

If the planning scaffold exists and any remaining gaps are route-optional, proceed to Phase 0.5 without commentary.

If any are missing:

- report missing files and downstream impact
- treat `petitions/program-status.yaml` as baseline planning scaffold and offer `project-bootstrap` when it is absent
- treat `architecture/workspace.dsl`, `architecture/policies.yaml`, `AGENTS.md`, and `architecture/adr/` as optional scaffolds unless the chosen path explicitly requires them in this run
- treat `domain/concept-model.yaml` as recommended but not blocking
- offer `project-bootstrap` for missing scaffolding except the concept model; for concept-model creation suggest `concept-model-curator`
- if the user confirms bootstrap, delegate to `project-bootstrap`, wait for completion, then re-run readiness check
- if the user declines bootstrap or confirms intentional absence, note the accepted gap in the completion report and continue only if the chosen path can run safely without it
- if the user declines bootstrap while a baseline or path-required scaffold is missing, always record the escalation in the completion report; additionally log it in `petitions/program-status.yaml` under `escalations` when that file exists

Do not silently continue past missing baseline or path-required scaffolding without surfacing it.

### Phase 0.5: Hotfix Detection

Before classifying the request into Path A, B, C, or D, check whether it describes a production incident.

Signals:

- keywords: `production`, `hotfix`, `incident`, `broken`, `urgent`, `rollback`, `system down`, `critical bug`
- urgency language: `now`, `ASAP`, `right now`

If production incident is detected:

1. Ask: `This looks like a production incident. Should I use hotfix fast-track or the full pipeline?`
2. Choices: **Hotfix fast-track** (recommended) or **Full pipeline**
3. If hotfix is selected, delegate to `hotfix-conductor` and stop normal routing.
4. If full pipeline is selected, continue with Phase 1.

### Phase 1: Inspect Inputs

1. Use repository inspection tools to verify what the caller already has.
2. Look for these artifacts first:
   - `petition<ID>.md`
   - `petition<ID>-outcome-contract.md`
   - `petition<ID>.feature`
3. If paths are provided explicitly, verify those exact files before searching more broadly.
4. Read available artifacts so you understand scope before routing.
5. If the caller provided only a plain-language idea and no petition artifacts exist, classify intake as one of:
   - `ideation-needed`
   - `bounded-prompt-only`
6. If the caller provides an approved ideation brief path, verify it exists and read the `Recommended First Petition` section before routing.
7. If `.factory/project.yaml` exists, read `agent_workflow` when present and carry any supported defaults into the downstream handoff summary.
8. If a petition artifact exists, read any declared `delivery_track` from frontmatter before recommending a route.
9. If `petitions/program-status.yaml` exists and the petition is already tracked there, read the mirrored petition entry to compare planning state against the petition artifact.

### Phase 1.5: Resolve Delivery Track

1. Resolve `delivery_track` using the precedence rules above.
2. If no explicit track exists yet, recommend a provisional track from current evidence:
   - `quick` when work is clearly bounded, single-petition, and low-risk
   - `standard` when work is approved and petition-sized but not strongly governance-heavy
   - `governed` when work is cross-cutting, compliance-sensitive, architecture-heavy, or likely multi-phase
3. If a weaker declared track conflicts with current evidence, recommend the safer track, explain why, and carry the mismatch as a warning.
4. Never let `quick` suppress backlog planning when current evidence says planning is required.

### Phase 1.7: Resolve Telemetry Coverage

1. When a petition ID is known, resolve the canonical telemetry path:
   `petitions/telemetry/petition<ID>-telemetry.yaml`.
2. If the telemetry artifact exists, read `coverage.status` and report it as `measured`, `partial`, or `absent`.
3. If the telemetry artifact does not exist yet, or the petition ID is still unknown, report `telemetry_coverage: absent`.
4. Use telemetry coverage only as operational guidance for calibration and follow-up. It is not approval proof.
5. If coverage is `absent` or `partial`, include the gap in the next-step recommendation when token calibration matters.

### Phase 2: Decide Whether Planning Is Required

Use `backlog-planner` when any of the following are true:

1. Work spans multiple petitions.
2. Change is cross-cutting, dependency-heavy, or likely multi-sprint.
3. The next implementation slice is unclear.
4. `petitions/program-status.yaml` already exists and should be refreshed before execution.
5. The caller explicitly asks for sequencing, phase planning, sprint planning, or next-best-slice guidance.
6. `delivery_track` is `governed`.

If work is single, already approved, and clearly bounded, you may skip planning, but you must say why in the completion report.

### Phase 3: Choose the Entrypoint

Choose exactly one entrypoint.

#### Path A: Ideation intake

Use when the caller has only a plain-language request, no approved petition artifacts, and the request is still too broad or ambiguous for a petition.

Route here when one or more are true:

- request describes a new project, platform, or major initiative
- multiple workstreams or subsystems are implied
- user intent is clear but the first petition slice is not
- goals, non-goals, or MVP boundary remain fuzzy

Execution:

1. Delegate to `ideation`.
2. Treat the resulting project brief as an approval boundary.
3. Stop after ideation output unless the caller explicitly states that the brief is already approved and wants to proceed.
4. If the caller later provides an approved ideation brief, route the recommended first petition slice to `prompt-to-requirements`.

#### Path B: Bounded prompt-only intake

Use when the caller has no petition artifacts, but the request is already clear enough to form one bounded petition.

Execution:

1. Delegate to `prompt-to-requirements`.
2. Treat resulting drafts as an approval boundary.
3. Stop after drafts are produced unless the caller explicitly states that requirements are approved and approved artifacts already exist.
4. If explicit approval already exists, continue to the planning decision and then to `pipeline-conductor`, carrying any resolved `agent_workflow` defaults in the handoff.
5. Do not continue to downstream execution in the same run merely because drafts were created.

#### Path C: Petition and outcome contract, but no feature file

Use when petition and outcome contract exist but the Gherkin feature file does not.

Execution:

1. Verify both artifacts exist and are non-empty.
2. Delegate to `petition-to-gherkin`.
3. Do not duplicate downstream review logic here.
4. Continue only if the feature file was created successfully.
5. If planning is required, run the planning gate before delegating to `pipeline-conductor`.
6. If planning is not required, delegate directly to `pipeline-conductor` and include any resolved `agent_workflow` defaults in the handoff.

#### Path D: Petition, outcome contract, and feature file already exist

Use when all three artifacts exist.

Execution:

1. Verify all three artifacts exist and are non-empty.
2. If planning is required, run the planning gate before delegating to `pipeline-conductor`.
3. If planning is not required, delegate directly to `pipeline-conductor` and include any resolved `agent_workflow` defaults in the handoff.

### Phase 4: Planning Gate

When planning is required and execution is otherwise allowed to proceed:

1. Delegate to `backlog-planner` before `pipeline-conductor`.
2. Ask it to refresh or update `petitions/program-status.yaml` when the repo uses planning-state tracking.
3. Use its output to confirm the next implementation slice, dependencies, and blockers.
4. If `backlog-planner` shows the requested work is blocked, out of order, or superseded, stop and report that instead of forcing execution.
5. Do not ask `backlog-planner` to implement anything.

### Phase 5: Approval and Delegation Rules

Approval rules:

1. `ideation` is always an approval boundary.
2. `prompt-to-requirements` is always an approval boundary.
3. Treat approval as explicit only when the caller clearly indicates that the ideation brief or requirements artifacts are approved and ready for the next stage.
4. Never infer approval from silence.
5. Never bypass a failed review once `pipeline-conductor` begins its review gates.

Delegation rules:

1. Reuse existing agents. Do not duplicate their responsibilities.
2. Do not rewrite pipeline logic that already exists inside `pipeline-conductor`.
3. Do not rewrite planning logic that belongs inside `backlog-planner`.
4. Do not write code, specs, tests, or architecture yourself.
5. Do not invent missing artifacts. If a required artifact is missing, report exactly what is needed.
6. Do not send project-level initiatives straight to `prompt-to-requirements` when the first petition slice is still unclear.
