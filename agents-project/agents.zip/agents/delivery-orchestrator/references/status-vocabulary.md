# Status Vocabulary

- `success` — route is verified and the next safe step is clear
- `partial_success` — an approval-boundary artifact was produced safely, but execution stops pending approval
- `blocked` — required artifact, approval, or infrastructure is missing
- `needs_more_evidence` — readiness or approval claim cannot be supported yet
- `retry` — routing can continue after one targeted clarification or bootstrap retry
- `fail` — routing could not complete because the request is inconsistent or a delegated step failed
