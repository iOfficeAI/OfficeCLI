# Preconditions

1. Read enough of the current request to determine whether it is ideation, bounded intake, artifact-based continuation, or production incident.
2. Verify any file or artifact claim from fresh repository evidence in this run.
3. Do not route to downstream execution until the correct approval state is known.
