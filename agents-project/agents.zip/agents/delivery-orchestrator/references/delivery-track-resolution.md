# Delivery Track Resolution

Use `delivery_track` as petition-local shorthand for delivery posture.

Canonical source:

1. petition frontmatter when present
2. mirrored `petitions/program-status.yaml` entry when the petition artifact is unavailable in this run

Allowed values:

- `quick` — bounded bugfix or narrow enhancement, single petition, low governance surface, candidate for lean delivery
- `standard` — default petition flow for approved bounded work
- `governed` — cross-cutting, compliance-sensitive, architecture-heavy, or otherwise governance-heavy work

Track posture seeds recommendations when no stronger override exists:

| Track | Seeded posture |
|---|---|
| `quick` | lean delivery candidate; targeted review/testing defaults may be suggested; goal verification still required |
| `standard` | default delivery posture; normal planning decision; full review/testing defaults |
| `governed` | backlog planning required; full delivery posture; full review/testing; explicit governance bias |

Precedence:

1. explicit user instruction in the current run
2. petition-local `delivery_track`
3. mirrored `petitions/program-status.yaml` value when petition artifact is unavailable
4. `.factory/project.yaml` `agent_workflow`
5. built-in default `standard`

Rules:

1. `delivery_track` seeds recommendations and defaults. It never bypasses approval, planning, review, or verification gates.
2. If current evidence shows a declared `quick` track is too weak, recommend the safer track and surface a warning.
3. If the user insists on a weaker track than current evidence supports, escalate instead of pretending the risk vanished.
4. When petition frontmatter and mirrored planning state disagree, reopened petition frontmatter wins for this run.
