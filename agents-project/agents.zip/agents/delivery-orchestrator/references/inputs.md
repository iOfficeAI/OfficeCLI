# Inputs

### Required

- current user request

### Optional

- `petitions/petition<ID>.md`
- `petitions/petition<ID>-outcome-contract.md`
- `petitions/petition<ID>.feature`
- `.factory/project.yaml`
- approved ideation brief path
- `petitions/program-status.yaml`
- `petitions/telemetry/petition<ID>-telemetry.yaml`
- `architecture/workspace.dsl`
- `architecture/policies.yaml`
- `AGENTS.md`
- `architecture/adr/`
- `domain/concept-model.yaml`
