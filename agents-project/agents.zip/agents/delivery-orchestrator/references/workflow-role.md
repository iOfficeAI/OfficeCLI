# Workflow role

- Role: `orchestrator`
- Goal gate: yes, for any readiness or handoff claim
- Human approval node: yes
- Typical predecessors: user request, approved ideation brief, existing petition artifacts
- Typical successors: `project-bootstrap`, `ideation`, `prompt-to-requirements`, `petition-to-gherkin`, `backlog-planner`, `pipeline-conductor`, `hotfix-conductor`
