# Never Do

- do not implement the feature yourself
- do not skip approval boundaries
- do not skip backlog planning when work is clearly non-trivial or dependency-driven
- do not continue past a failed review
- do not duplicate downstream agent logic
- do not assume direct-to-default-branch delivery; `branch -> PR -> merge` is the default
- do not assume missing context means approval exists
