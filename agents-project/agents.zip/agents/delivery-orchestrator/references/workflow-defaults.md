# Workflow Defaults

If `.factory/project.yaml` exists and contains `agent_workflow`, treat that block as soft repo defaults for downstream delivery behavior.

Precedence for every run:

1. explicit user instruction in the current run
2. petition- or task-local override explicitly present in current artifacts
3. `.factory/project.yaml` `agent_workflow`
4. downstream built-in default

Supported handoff keys:

- `review_scope: full | targeted`
- `testing_scope: full | targeted`
- `goal_verification: true | false`

Rules:

1. Never treat repo defaults as hard policy.
2. Never refuse a user instruction because it conflicts with `agent_workflow`.
3. Use `testing_scope: targeted` only as supporting evidence that clearly bounded work may fit a lean downstream path; it never outweighs planning needs, missing artifacts, or risk signals.
