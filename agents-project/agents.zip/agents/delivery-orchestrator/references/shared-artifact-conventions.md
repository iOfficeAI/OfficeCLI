# Shared Artifact Conventions

- All review verdicts go to `petitions/reviews/petition<ID>-<agent-name>.yaml`.
- When checking review status or passing review context downstream, read from that path.
