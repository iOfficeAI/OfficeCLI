# Git Delivery Default

For any route that will modify repository contents, default delivery path is:

`work branch -> pull request -> merge`

Rules:

1. Assume downstream conductors run on a dedicated non-default branch.
2. Treat direct changes on `main`, `master`, or the repo default branch as exception-only.
3. Only use direct-to-default-branch flow when the user explicitly requests it or repo policy explicitly requires it.
4. When reporting next action, include whether work is expected to stop at an approval boundary, continue on a branch, or proceed to PR preparation.
