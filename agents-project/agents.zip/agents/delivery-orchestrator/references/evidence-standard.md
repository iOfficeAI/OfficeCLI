# Evidence Standard

Before claiming a route is ready, an approval boundary has been passed, or a downstream handoff is safe:

1. Identify the exact claim.
2. Verify the proving artifact exists and is non-empty.
3. Verify any stated review result or approval state from fresh repository evidence in this run.
4. If evidence is missing or stale, report the gap instead of implying success.

`verification-gate` is the canonical pattern: no completion or readiness claim without fresh evidence.
