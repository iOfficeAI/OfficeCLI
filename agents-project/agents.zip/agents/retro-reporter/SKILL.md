---
name: retro-reporter
description: "Use when producing a delivery retro or operating snapshot from petition planning, review, and telemetry artifacts without mutating planning state."
workflow_role: worker
workflow_binding: contract_only
primary_outputs:
  - delivery retro summary
  - optional saved retro artifact when explicitly requested
default_next:
  success: user review or planning follow-up
  partial_success: snapshot-only retro or telemetry/history gap report
  blocked: scaffold repair or user clarification
  needs_more_evidence: missing or unreadable planning artifacts
  fail: rerun after input repair
---

# Purpose

Produce a compact delivery retro for petition-driven repos. This skill owns **history interpretation, narrative shaping, and escalation recommendations**. Deterministic current-state compilation belongs to `scripts/retro_snapshot.py`, and deterministic telemetry validation or rollup belongs to `scripts/telemetry_tool.py`.

## Workflow role

- Role: `worker`
- Binding: `contract_only`
- Goal gate: no
- Human approval node: no
- Typical predecessors: `pipeline-conductor`, `release-manager`, user retrospective request
- Typical successors: user review, `backlog-planner`, `sprint-tracker`, or governance follow-up

## Inputs

### Required

- `petitions/program-status.yaml`

### Optional

- review artifacts under `petitions/reviews/`
- telemetry artifacts under `petitions/telemetry/`
- scoped petition IDs
- git history for planning/review files when the user asks for activity or throughput
- prior retro artifact when explicitly provided for comparison

## Preconditions

1. `petitions/program-status.yaml` exists and is readable.
2. The report must distinguish current snapshot facts from any history-derived activity.
3. Time-window or throughput claims require fresh history inspection in this run.

## Deterministic checks

1. **Compile the snapshot first**
   - Run:
     `python scripts/retro_snapshot.py --root <repo> --json [--petition-id <id> ...]`
   - Treat its output as the canonical current-state snapshot for petition counts, blockers, review-failure totals, open escalations, open TB counts, and baseline telemetry coverage.
2. **Validate telemetry before using it in headline claims**
   - When telemetry artifacts exist or the user asks for token/cost reporting, run:
     `python scripts/telemetry_tool.py lint --root <repo> --json [--petition-id <id>]`
   - Then run:
     `python scripts/telemetry_tool.py rollup --root <repo> --json [--petition-id <id>]`
3. **Interpret failures conservatively**
   - `retro_snapshot.py` failure on required planning input -> `blocked` or `needs_more_evidence`
   - telemetry lint/rollup failure -> usually `partial_success`; keep the retro but report the telemetry gap explicitly unless the user's whole request was telemetry-only
4. Record each script run as evidence with the exact command and result.

## Procedure

1. Run `retro_snapshot.py` and use it as the source of truth for the current snapshot section.
2. If telemetry is present or requested, run telemetry lint and rollup before making any token or cost claim.
3. If the user asked for throughput, activity, or a time window:
   - inspect git history for `petitions/program-status.yaml` and `petitions/reviews/`
   - derive only conservative activity signals the history clearly supports
   - set `retro_basis` to `current snapshot plus history-derived activity`
4. If no trustworthy history-backed activity can be derived, keep `retro_basis` as `current snapshot only` and say so explicitly.
5. Produce the final retro with separate sections for:
   - snapshot metrics
   - review failures
   - blockers
   - knowledge gaps
   - telemetry coverage and signal
   - activity signal
6. Write `petitions/retro/retro-<YYYY-MM-DD>.md` only when the user explicitly asks for a persistent artifact.

## Output Contract

### Artifacts

- delivery retro summary in the final response
- optional `petitions/retro/retro-<YYYY-MM-DD>.md` only when explicitly requested

### Report Fields

- `status`
- `summary`
- `retro_basis`
- `artifacts`
- `evidence_checked`
- `snapshot_metrics`
- `review_failures`
- `blockers`
- `knowledge_gaps`
- `telemetry_coverage`
- `telemetry_signal`
- `activity_signal`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` — snapshot and any requested history-backed activity summary were produced from fresh evidence
- `partial_success` — the retro was produced, but telemetry or throughput claims were only partially derivable
- `blocked` — the planning scaffold is missing or unreadable
- `needs_more_evidence` — required review or history evidence is too incomplete for the requested retro
- `fail` — an explicitly requested output artifact could not be written safely

## Done Criteria

1. The report clearly states whether it is snapshot-only or history-backed.
2. Review failures, blockers, and knowledge gaps are separated rather than merged.
3. Any throughput or trend claim is backed by inspected history in this run.
4. Any token or cost claim is backed by measured telemetry rows or explicitly downgraded as a coverage gap.
5. Planning state was not mutated.

## Evidence Requirements

- Claim: current snapshot metrics exist -> proof: `retro_snapshot.py` output was checked in this run
- Claim: telemetry totals exist -> proof: `telemetry_tool.py lint` and `rollup` outputs were checked in this run
- Claim: throughput or activity exists -> proof: relevant git history was inspected in this run
- Claim: a knowledge gap exists -> proof: missing or unreadable artifact, or explicit evidence gap, was checked in this run

## Failure Routing

- missing or unreadable `petitions/program-status.yaml` -> `blocked`
- unreadable review or history evidence needed for the requested report -> `needs_more_evidence`
- telemetry is requested but not fully derivable from measured artifacts -> `partial_success`
- requested persistent retro path is unusable -> `fail`

## Escalation Rules

1. Escalate when repeated blockers or open escalations show delivery churn the current loop is not closing.
2. Escalate when review failures recur across multiple petitions or hotfixes without a clear remediation owner.
3. Escalate when the user asks for a trend or token/cost claim the repo cannot support honestly.

## Never Do

- never update `petitions/program-status.yaml`
- never create or edit review files
- never claim throughput without stating the inspected history source
- never invent historical counts from the current schema alone
- never aggregate `self_reported` or `unmeasured` telemetry rows into headline totals
- never collapse blockers, review failures, and knowledge gaps into one bucket
