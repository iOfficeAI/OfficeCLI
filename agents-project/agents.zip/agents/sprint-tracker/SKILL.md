---
name: sprint-tracker
description: "Use when reconciling petition delivery state in program-status.yaml from fresh repository evidence."
workflow_role: worker
workflow_binding: contract_only
primary_outputs:
  - updated petitions/program-status.yaml
  - sprint tracking summary
  - escalation updates when required
default_next:
  success: tracking handoff or exit
  blocked: blocker escalation or user decision
  needs_more_evidence: missing delivery proof
  fail: rerun after input or write repair
---

# Purpose

Reconcile petition delivery state in `petitions/program-status.yaml` using fresh repository evidence. This skill owns **status judgement, safe mutation, contract-drift handling, escalation writing, and reporting**. Deterministic structure and referential-integrity checks belong to `scripts/delivery_state_lint.py`.

## Workflow role

- Role: `worker`
- Binding: `contract_only`
- Goal gate: no
- Human approval node: no
- Typical predecessors: `pipeline-conductor`, user sprint update request
- Typical successors: tracking handoff, release planning, or blocker escalation

## Inputs

### Required

- `petitions/program-status.yaml`

### Optional

- scoped petition IDs
- review artifacts under `petitions/reviews/`
- validation evidence, test evidence, or outcome-contract proof
- repository files referencing petition IDs
- `technical_backlog` entries linked to contract-drift follow-up

## Preconditions

1. The current program-status file is readable.
2. Status advancement must rely on explicit evidence inspected in this run.
3. Open escalations block optimistic completion claims.
4. `released` status is owned by `release-manager`, not this skill.

## Startup recall

Before reconciling status, you may review recent Sprint Tracker diary/search results to surface prior blockers or decisions worth re-checking. Recalled context is a hint only until you reopen the canonical repo artifact in this run.

## Deterministic checks

1. **Lint current state before editing**
   - Run:
     `python scripts/delivery_state_lint.py --root <repo> --json [--petition-id <id> ...]`
   - If the current file fails lint, stop with `blocked` and report the concrete defects instead of editing a broken state blindly.
2. **Use the lint output as the structural source of truth**
   - Petition IDs, escalation IDs, TB IDs, review refs, telemetry refs, and release metadata integrity come from the script output, not from prompt prose.
3. **Lint again after mutation**
   - After any edit to `petitions/program-status.yaml`, rerun the same command.
   - Post-write lint failure is `fail`; repair the file before concluding.
4. Record each lint run as evidence with the exact command and result.

## Status transition rules

Use conservative transitions only:

| From | To | Evidence required |
| --- | --- | --- |
| `pending` | `planned` | sprint assignment or explicit planning decision exists |
| `planned` | `in-progress` | repo work has started for the petition |
| `in-progress` or legacy `done` | `implemented` | implementation and supporting test/spec evidence are explicit |
| `implemented` | `validated` | required review/validation evidence passes and no open escalation or blocking review verdict remains |
| any unreleased state | `blocked` | explicit blocker exists; record it in `notes` and escalation when required |

Additional rules:

1. Preserve `released` entries unless a separate release or rollback flow updates them.
2. Legacy `done` is allowed as input, but prefer normalizing forward to `implemented` when the evidence supports it.
3. Never regress `implemented`, `validated`, or `released` casually.

## Contract-drift handoff handling

When `technical_backlog` contains contract-drift follow-up:

1. Detect entries with `source_agent: contract-drift-auditor` or `category: contract-drift`.
2. Report them separately from petition status changes.
3. Do not regress a petition solely because a contract-drift TB item remains open unless there is also explicit blocker evidence or an open escalation.
4. Preserve these TB items as distinct follow-up work. Never delete or merge them into vague notes.

## Procedure

1. Run the delivery-state lint on the current file and stop if the structural state is broken.
2. Read the current `petitions/program-status.yaml` state for the scoped petitions.
3. Gather fresh evidence:
   - repo files and tests referencing the petition
   - review artifacts and validation proof
   - open escalations
   - contract-drift TB items
4. Apply only the status transitions the evidence supports.
5. Update `status`, `sprint`, `notes`, and `last_updated` as needed.
6. When a petition is blocked and no matching escalation exists yet, add one with the next sequential `ESC-<number>` ID.
7. Rerun `delivery_state_lint.py` on the edited file.
8. Produce a concise summary covering:
   - petitions advanced
   - petitions unchanged and why
   - blockers and escalations
   - contract-drift TB follow-ups
9. Write a concise diary entry with status changes, blockers, and contract-drift follow-up context.

## Output Contract

### Artifacts

- updated `petitions/program-status.yaml`
- sprint tracking summary
- escalation entry in `petitions/program-status.yaml` when required
- diary entry for the tracking run

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` — status reconciliation completed and the file remained lint-clean
- `blocked` — blocker evidence or broken current state prevented safe advancement
- `needs_more_evidence` — review, validation, or implementation proof is too incomplete for a safe status change
- `fail` — status update or file write could not be completed safely

## Done Criteria

1. Any changed status field is supported by explicit evidence.
2. `delivery_state_lint.py` passes after the update.
3. Blockers and contract-drift follow-ups are reported separately.
4. `last_updated` is correct when the file changed.
5. The summary explains advances, unchanged items, blockers, and open contract-drift follow-up clearly.

## Evidence Requirements

- Claim: petition status changed safely -> proof: repo evidence, review artifacts, and escalation state were checked in this run
- Claim: program-status structure is valid -> proof: `delivery_state_lint.py` passed in this run
- Claim: petition is blocked -> proof: explicit blocker or open escalation was checked in this run
- Claim: contract-drift follow-up remains separate work -> proof: linked TB items were inspected in this run

## Failure Routing

- missing or unreadable `petitions/program-status.yaml` -> `blocked`
- current file fails `delivery_state_lint.py` before edits -> `blocked`
- evidence is too incomplete to justify advancement -> `needs_more_evidence`
- edited file fails `delivery_state_lint.py` after writes -> `fail`
- output path is unwritable -> `fail`

## Escalation Rules

1. Escalate when a petition is blocked and no matching escalation exists yet.
2. Escalate when evidence conflicts and status cannot be reconciled safely.
3. Escalate when completion criteria appear met except for unresolved review or escalation debt.

## Never Do

- never mark a petition `validated` while blocking review findings or open escalations remain
- never regress `implemented`, `validated`, or `released` casually
- never delete tracked petitions, escalations, or technical-backlog entries
- never hide contract-drift TB items inside generic notes
- never treat recalled context as proof
- never skip the post-write delivery-state lint
