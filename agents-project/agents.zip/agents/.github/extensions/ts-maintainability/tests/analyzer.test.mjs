import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";

import { analyzeSourceText, analyzeTargets } from "../analyzer.mjs";

test("marks a small TypeScript function as PASS", () => {
    const result = analyzeSourceText({
        filePath: "simple.ts",
        sourceText: `
        export function add(a: number, b: number) {
            return a + b;
        }
        `,
    });

    assert.equal(result.language, "typescript");
    assert.equal(result.verdict, "PASS");
    assert.equal(result.functions.length, 1);
    assert.equal(result.functions[0].function, "add");
    assert.equal(result.functions[0].score_0_100, 100);
});

test("flags a nested Python method as FAIL", () => {
    const result = analyzeSourceText({
        filePath: "service.py",
        sourceText: `
class Service:
    def review(self, items):
        if items:
            for item in items:
                while item["active"]:
                    if item["kind"] == "a" and item["active"]:
                        return 1
        return 0
        `,
    });

    assert.equal(result.language, "python");
    assert.equal(result.functions.length, 1);
    assert.equal(result.functions[0].function, "Service.review");
    assert.equal(result.functions[0].verdict, "FAIL");
    assert.match(result.functions[0].reasons.join(" "), /nesting_depth > 3/);
});

test("analyzes Java methods and returns class-qualified names", () => {
    const result = analyzeSourceText({
        filePath: "Example.java",
        sourceText: `
class Example {
    int compute(int value) {
        if (value > 0) {
            return 1;
        } else if (value == 0) {
            return 0;
        }
        return -1;
    }
}
        `,
    });

    assert.equal(result.language, "java");
    assert.equal(result.functions.length, 1);
    assert.equal(result.functions[0].function, "Example.compute");
    assert.equal(result.functions[0].verdict, "PASS");
    assert.equal(result.functions[0].cyclomatic, 3);
});

test("walks multi-language target directories and surfaces hotspots", async () => {
    const tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), "code-maintainability-"));

    try {
        await fs.mkdir(path.join(tempRoot, "src"), { recursive: true });
        await fs.writeFile(
            path.join(tempRoot, "src", "simple.ts"),
            `
            export const ping = () => "pong";
            `,
            "utf8",
        );
        await fs.writeFile(
            path.join(tempRoot, "src", "workflow.py"),
            `
def workflow(items):
    if items:
        for item in items:
            while item["active"]:
                if item["kind"] == "a" and item["active"]:
                    return item
    return None
            `,
            "utf8",
        );
        await fs.writeFile(
            path.join(tempRoot, "src", "Review.java"),
            `
class Review {
    int review(int value) {
        if (value > 0) {
            return 1;
        }
        return 0;
    }
}
            `,
            "utf8",
        );

        const result = await analyzeTargets({
            cwd: tempRoot,
            targets: ["src"],
            maxFiles: 10,
            maxHotspots: 5,
        });

        assert.equal(result.files_analyzed, 3);
        assert.equal(result.summary.file_counts.fail, 1);
        assert.equal(result.hotspots[0].language, "python");
        assert.equal(result.hotspots[0].function, "workflow");
    } finally {
        await fs.rm(tempRoot, { recursive: true, force: true });
    }
});
