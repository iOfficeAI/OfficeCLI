import { joinSession } from "@github/copilot-sdk/extension";
import {
    analyzeTargets,
    DEFAULT_OPTIONS,
    METRIC_BUNDLE,
    SUPPORTED_EXTENSIONS,
    SUPPORTED_LANGUAGES,
} from "./analyzer.mjs";

const state = {
    cwd: process.cwd(),
};

const session = await joinSession({
    hooks: {
        onSessionStart: async (input) => {
            if (input.cwd) {
                state.cwd = input.cwd;
            }
        },
        onUserPromptSubmitted: async (input) => {
            if (input.cwd) {
                state.cwd = input.cwd;
            }
        },
    },
    tools: [
        {
            name: "code_maintainability_analyze",
            description:
                "Analyze TypeScript/JavaScript, Python, and Java files for cyclomatic complexity, executable LoC, nesting depth, score, verdicts, and refactor hints.",
            skipPermission: true,
            parameters: {
                type: "object",
                properties: {
                    targets: {
                        type: "array",
                        description:
                            "File or directory paths relative to the current working directory. Defaults to ['.'].",
                        items: { type: "string" },
                    },
                    maxFiles: {
                        type: "integer",
                        description: "Maximum number of matching source files to analyze.",
                        minimum: 1,
                        maximum: 500,
                        default: DEFAULT_OPTIONS.maxFiles,
                    },
                    maxHotspots: {
                        type: "integer",
                        description: "Maximum number of lowest-scoring functions to include in hotspots.",
                        minimum: 1,
                        maximum: 100,
                        default: DEFAULT_OPTIONS.maxHotspots,
                    },
                },
            },
            handler: createAnalyzeHandler(),
        },
        {
            name: "ts_maintainability_analyze",
            description:
                "Backward-compatible alias for code_maintainability_analyze. Prefer the generic tool name for multi-language analysis.",
            skipPermission: true,
            parameters: {
                type: "object",
                properties: {
                    targets: {
                        type: "array",
                        description:
                            "File or directory paths relative to the current working directory. Defaults to ['.'].",
                        items: { type: "string" },
                    },
                    maxFiles: {
                        type: "integer",
                        description: "Maximum number of matching source files to analyze.",
                        minimum: 1,
                        maximum: 500,
                        default: DEFAULT_OPTIONS.maxFiles,
                    },
                    maxHotspots: {
                        type: "integer",
                        description: "Maximum number of lowest-scoring functions to include in hotspots.",
                        minimum: 1,
                        maximum: 100,
                        default: DEFAULT_OPTIONS.maxHotspots,
                    },
                },
            },
            handler: createAnalyzeHandler(),
        },
    ],
});

await session.log("code_maintainability_analyze extension loaded", { ephemeral: true });

function createAnalyzeHandler() {
    return async (args, invocation) => {
        const targets = Array.isArray(args?.targets) ? args.targets : ["."];
        const maxFiles = Number.isInteger(args?.maxFiles)
            ? args.maxFiles
            : DEFAULT_OPTIONS.maxFiles;
        const maxHotspots = Number.isInteger(args?.maxHotspots)
            ? args.maxHotspots
            : DEFAULT_OPTIONS.maxHotspots;

        await session.log(
            `Analyzing maintainability for ${targets.length} target(s) from ${state.cwd}`,
            { ephemeral: true },
        );

        const result = await analyzeTargets({
            cwd: state.cwd,
            targets,
            maxFiles,
            maxHotspots,
        });

        const failed = result.summary.verdict === "FAIL" && result.files_analyzed === 0;

        return {
            resultType: failed ? "failure" : "success",
            textResultForLlm: JSON.stringify(
                {
                    ...result,
                    tool: invocation.toolName,
                    metric_bundle: METRIC_BUNDLE,
                    supported_extensions: Array.from(SUPPORTED_EXTENSIONS).sort(),
                    supported_languages: SUPPORTED_LANGUAGES,
                },
                null,
                2,
            ),
        };
    };
}
