import fs from "node:fs/promises";
import path from "node:path";
import Parser from "tree-sitter";
import Java from "tree-sitter-java";
import Python from "tree-sitter-python";
import ts from "typescript";

export const METRIC_BUNDLE = "code_cc_loc_nesting_v2";

export const DEFAULT_THRESHOLDS = {
    cyclomatic: { warn: 10, fail: 20 },
    loc: { warn: 50, fail: 100 },
    nesting: { warn: 3, fail: 4 },
};

export const DEFAULT_OPTIONS = {
    maxFiles: 50,
    maxHotspots: 10,
};

const TYPE_SCRIPT_EXTENSIONS = [
    ".ts",
    ".tsx",
    ".mts",
    ".cts",
    ".js",
    ".jsx",
    ".mjs",
    ".cjs",
];

const PYTHON_CONFIG = {
    languageId: "python",
    grammar: Python,
    functionNodeTypes: new Set(["function_definition"]),
    cyclomaticNodeTypes: new Set([
        "if_statement",
        "elif_clause",
        "for_statement",
        "while_statement",
        "except_clause",
        "conditional_expression",
    ]),
    nestingNodeTypes: new Set([
        "if_statement",
        "for_statement",
        "while_statement",
        "try_statement",
        "with_statement",
        "match_statement",
        "conditional_expression",
    ]),
    lineCommentPrefixes: ["#"],
    blockCommentDelimiters: [],
    getFunctionRoot(node) {
        return node.childForFieldName("body");
    },
    getFunctionName(node, ancestors) {
        const name = node.childForFieldName("name")?.text ?? anonymousTreeSitterName(node);
        const owner = getTreeSitterAncestorName(ancestors, new Set(["class_definition"]));
        return owner ? `${owner}.${name}` : name;
    },
    getExtraCyclomaticContribution(node) {
        if (node.type === "boolean_operator") {
            return countMatches(node.text, /\b(and|or)\b/g);
        }

        return 0;
    },
};

const JAVA_CONFIG = {
    languageId: "java",
    grammar: Java,
    functionNodeTypes: new Set(["method_declaration", "constructor_declaration"]),
    cyclomaticNodeTypes: new Set([
        "if_statement",
        "for_statement",
        "enhanced_for_statement",
        "while_statement",
        "do_statement",
        "catch_clause",
        "switch_expression",
        "switch_statement",
        "ternary_expression",
    ]),
    nestingNodeTypes: new Set([
        "if_statement",
        "for_statement",
        "enhanced_for_statement",
        "while_statement",
        "do_statement",
        "catch_clause",
        "switch_expression",
        "switch_statement",
        "try_statement",
        "ternary_expression",
    ]),
    lineCommentPrefixes: ["//"],
    blockCommentDelimiters: [{ start: "/*", end: "*/" }],
    getFunctionRoot(node) {
        return node.childForFieldName("body");
    },
    getFunctionName(node, ancestors) {
        const name = node.childForFieldName("name")?.text ?? anonymousTreeSitterName(node);
        const owner = getTreeSitterAncestorName(
            ancestors,
            new Set([
                "class_declaration",
                "interface_declaration",
                "enum_declaration",
                "record_declaration",
            ]),
        );
        return owner ? `${owner}.${name}` : name;
    },
    getExtraCyclomaticContribution(node) {
        if (node.type === "binary_expression") {
            return countMatches(node.text, /&&|\|\|/g);
        }

        return 0;
    },
};

const LANGUAGE_DEFINITIONS = [
    {
        id: "typescript",
        label: "TypeScript/JavaScript",
        extensions: TYPE_SCRIPT_EXTENSIONS,
        analyzeSourceText: analyzeTypeScriptSourceText,
    },
    {
        id: "python",
        label: "Python",
        extensions: [".py"],
        analyzeSourceText: (input) => analyzeTreeSitterSourceText(input, PYTHON_CONFIG),
    },
    {
        id: "java",
        label: "Java",
        extensions: [".java"],
        analyzeSourceText: (input) => analyzeTreeSitterSourceText(input, JAVA_CONFIG),
    },
];

const EXTENSION_TO_LANGUAGE_ID = new Map(
    LANGUAGE_DEFINITIONS.flatMap((definition) =>
        definition.extensions.map((extension) => [extension, definition.id]),
    ),
);

const LANGUAGE_BY_ID = new Map(LANGUAGE_DEFINITIONS.map((definition) => [definition.id, definition]));

export const SUPPORTED_EXTENSIONS = new Set(
    LANGUAGE_DEFINITIONS.flatMap((definition) => definition.extensions),
);

export const SUPPORTED_LANGUAGES = LANGUAGE_DEFINITIONS.map((definition) => ({
    id: definition.id,
    label: definition.label,
    extensions: [...definition.extensions],
}));

export async function analyzeTargets({
    cwd = process.cwd(),
    targets = ["."],
    maxFiles = DEFAULT_OPTIONS.maxFiles,
    maxHotspots = DEFAULT_OPTIONS.maxHotspots,
} = {}) {
    const normalizedTargets = normalizeTargets(targets);
    const discovery = await expandTargets(normalizedTargets, cwd);
    const warnings = [];

    if (discovery.missingTargets.length > 0) {
        warnings.push(
            `Missing targets: ${discovery.missingTargets
                .map((target) => JSON.stringify(target))
                .join(", ")}`,
        );
    }

    if (discovery.files.length === 0) {
        return {
            metric_bundle: METRIC_BUNDLE,
            cwd,
            analyzed_at: new Date().toISOString(),
            targets: normalizedTargets,
            files_analyzed: 0,
            warnings,
            summary: {
                verdict: "FAIL",
                file_counts: { pass: 0, warn: 0, fail: 0 },
                function_counts: { pass: 0, warn: 0, fail: 0 },
                average_score: 0,
                worst_score: 0,
            },
            files: [],
            hotspots: [],
        };
    }

    const sortedFiles = discovery.files.slice().sort((left, right) => left.localeCompare(right));
    const filesToAnalyze = sortedFiles.slice(0, maxFiles);

    if (sortedFiles.length > filesToAnalyze.length) {
        warnings.push(
            `File limit reached: analyzed ${filesToAnalyze.length} of ${sortedFiles.length} matching files.`,
        );
    }

    const fileResults = [];
    for (const filePath of filesToAnalyze) {
        fileResults.push(await analyzeFile(filePath, cwd));
    }

    return {
        metric_bundle: METRIC_BUNDLE,
        cwd,
        analyzed_at: new Date().toISOString(),
        targets: normalizedTargets,
        files_analyzed: fileResults.length,
        warnings,
        summary: summarizeResults(fileResults),
        files: fileResults,
        hotspots: buildHotspots(fileResults, maxHotspots),
    };
}

export function analyzeSourceText({
    sourceText,
    filePath = "inline.ts",
    cwd = process.cwd(),
} = {}) {
    const languageDefinition = getLanguageDefinition(filePath);
    if (!languageDefinition) {
        throw new Error(`Unsupported file extension for ${filePath}`);
    }

    return languageDefinition.analyzeSourceText({ sourceText, filePath, cwd });
}

async function analyzeFile(filePath, cwd) {
    const sourceText = await fs.readFile(filePath, "utf8");
    return analyzeSourceText({ sourceText, filePath, cwd });
}

function analyzeTypeScriptSourceText({ sourceText, filePath, cwd }) {
    const sourceFile = ts.createSourceFile(
        filePath,
        sourceText,
        ts.ScriptTarget.Latest,
        true,
        getScriptKind(filePath),
    );
    const parseErrors = formatTypeScriptParseDiagnostics(sourceFile);
    const functions = collectTypeScriptFunctions(sourceFile).map((entry) =>
        analyzeTypeScriptFunction(entry, sourceFile),
    );

    return buildFileResult({
        filePath,
        cwd,
        language: describeTypeScriptLanguage(filePath),
        parseErrors,
        functions,
    });
}

function collectTypeScriptFunctions(sourceFile) {
    const entries = [];

    function visit(node, ancestors) {
        if (isAnalyzableTypeScriptFunction(node)) {
            entries.push({ node, ancestors });
        }

        const nextAncestors = ancestors.concat(node);
        ts.forEachChild(node, (child) => visit(child, nextAncestors));
    }

    visit(sourceFile, []);
    return entries;
}

function analyzeTypeScriptFunction(entry, sourceFile) {
    const { node, ancestors } = entry;
    const start = sourceFile.getLineAndCharacterOfPosition(node.getStart(sourceFile));
    const end = sourceFile.getLineAndCharacterOfPosition(node.end);
    const metrics = {
        cyclomatic: 1,
        nesting_depth: 0,
        loc: countTypeScriptExecutableLines(
            sourceFile.text.slice(node.getStart(sourceFile), node.end),
            node.getStart(sourceFile),
            sourceFile,
        ),
    };

    const root = getTypeScriptFunctionRoot(node);
    if (root) {
        traverseTypeScriptMetrics(root, node, sourceFile, metrics, 0);
    }

    return finalizeFunctionMetrics({
        functionName: getTypeScriptFunctionName(node, ancestors, sourceFile),
        kind: ts.SyntaxKind[node.kind],
        range: toRange(start, end),
        metrics,
    });
}

function isAnalyzableTypeScriptFunction(node) {
    if (
        !ts.isFunctionDeclaration(node) &&
        !ts.isMethodDeclaration(node) &&
        !ts.isConstructorDeclaration(node) &&
        !ts.isGetAccessorDeclaration(node) &&
        !ts.isSetAccessorDeclaration(node) &&
        !ts.isFunctionExpression(node) &&
        !ts.isArrowFunction(node)
    ) {
        return false;
    }

    return Boolean(getTypeScriptFunctionRoot(node));
}

function getTypeScriptFunctionRoot(node) {
    if (node.body) {
        return node.body;
    }

    if (node.expression) {
        return node.expression;
    }

    return null;
}

function traverseTypeScriptMetrics(node, rootFunctionNode, sourceFile, metrics, depth) {
    if (node !== rootFunctionNode && isAnalyzableTypeScriptFunction(node)) {
        return;
    }

    const nestingIncrement = isTypeScriptNestingNode(node) ? 1 : 0;
    const nextDepth = depth + nestingIncrement;

    if (nestingIncrement > 0) {
        metrics.nesting_depth = Math.max(metrics.nesting_depth, nextDepth);
    }

    metrics.cyclomatic += getTypeScriptCyclomaticContribution(node);

    ts.forEachChild(node, (child) => {
        traverseTypeScriptMetrics(child, rootFunctionNode, sourceFile, metrics, nextDepth);
    });
}

function getTypeScriptCyclomaticContribution(node) {
    if (
        ts.isIfStatement(node) ||
        ts.isForStatement(node) ||
        ts.isForInStatement(node) ||
        ts.isForOfStatement(node) ||
        ts.isWhileStatement(node) ||
        ts.isDoStatement(node) ||
        ts.isCatchClause(node) ||
        ts.isConditionalExpression(node)
    ) {
        return 1;
    }

    if (ts.isCaseClause(node)) {
        return 1;
    }

    if (
        ts.isBinaryExpression(node) &&
        (node.operatorToken.kind === ts.SyntaxKind.AmpersandAmpersandToken ||
            node.operatorToken.kind === ts.SyntaxKind.BarBarToken ||
            node.operatorToken.kind === ts.SyntaxKind.QuestionQuestionToken)
    ) {
        return 1;
    }

    return 0;
}

function isTypeScriptNestingNode(node) {
    return (
        ts.isIfStatement(node) ||
        ts.isForStatement(node) ||
        ts.isForInStatement(node) ||
        ts.isForOfStatement(node) ||
        ts.isWhileStatement(node) ||
        ts.isDoStatement(node) ||
        ts.isSwitchStatement(node) ||
        ts.isCatchClause(node) ||
        ts.isTryStatement(node) ||
        ts.isConditionalExpression(node)
    );
}

function countTypeScriptExecutableLines(text, offset, sourceFile) {
    const lines = new Set();
    const scanner = ts.createScanner(
        ts.ScriptTarget.Latest,
        false,
        sourceFile.languageVariant,
        text,
    );

    while (true) {
        const token = scanner.scan();
        if (token === ts.SyntaxKind.EndOfFileToken) {
            break;
        }

        const tokenStart = offset + scanner.getTokenPos();
        const tokenEnd = offset + scanner.getTextPos();
        const start = sourceFile.getLineAndCharacterOfPosition(tokenStart).line;
        const end = sourceFile.getLineAndCharacterOfPosition(tokenEnd).line;

        for (let line = start; line <= end; line += 1) {
            lines.add(line + 1);
        }
    }

    return lines.size;
}

function getTypeScriptFunctionName(node, ancestors, sourceFile) {
    if (ts.isConstructorDeclaration(node)) {
        return `${getTypeScriptEnclosingTypeName(ancestors)}.constructor`;
    }

    if (
        ts.isMethodDeclaration(node) ||
        ts.isGetAccessorDeclaration(node) ||
        ts.isSetAccessorDeclaration(node)
    ) {
        return `${getTypeScriptEnclosingTypeName(ancestors)}.${typeScriptPropertyNameToText(
            node.name,
            sourceFile,
        )}`;
    }

    if (ts.isFunctionDeclaration(node) && node.name) {
        return node.name.text;
    }

    const parent = node.parent;

    if (ts.isVariableDeclaration(parent) && ts.isIdentifier(parent.name)) {
        return parent.name.text;
    }

    if (ts.isPropertyAssignment(parent)) {
        return typeScriptPropertyNameToText(parent.name, sourceFile);
    }

    if (ts.isBinaryExpression(parent) && ts.isIdentifier(parent.left)) {
        return parent.left.text;
    }

    if (ts.isExportAssignment(parent)) {
        return "defaultExport";
    }

    return anonymousTypeScriptName(node, sourceFile);
}

function getTypeScriptEnclosingTypeName(ancestors) {
    for (let index = ancestors.length - 1; index >= 0; index -= 1) {
        const ancestor = ancestors[index];

        if ((ts.isClassDeclaration(ancestor) || ts.isClassExpression(ancestor)) && ancestor.name) {
            return ancestor.name.text;
        }

        if ((ts.isClassDeclaration(ancestor) || ts.isClassExpression(ancestor)) && !ancestor.name) {
            return "AnonymousClass";
        }

        if ((ts.isObjectLiteralExpression(ancestor) || ts.isTypeLiteralNode(ancestor)) && ancestor.parent) {
            const owner = ancestor.parent;
            if (ts.isVariableDeclaration(owner) && ts.isIdentifier(owner.name)) {
                return owner.name.text;
            }
        }
    }

    return "anonymousScope";
}

function typeScriptPropertyNameToText(name, sourceFile) {
    if (ts.isIdentifier(name) || ts.isPrivateIdentifier(name) || ts.isStringLiteral(name)) {
        return name.text;
    }

    if (ts.isNumericLiteral(name)) {
        return name.text;
    }

    return name.getText(sourceFile);
}

function anonymousTypeScriptName(node, sourceFile) {
    return `anonymous@L${sourceFile.getLineAndCharacterOfPosition(node.getStart(sourceFile)).line + 1}`;
}

function formatTypeScriptParseDiagnostics(sourceFile) {
    return sourceFile.parseDiagnostics.map((diagnostic) => {
        const start = diagnostic.start ?? 0;
        const position = sourceFile.getLineAndCharacterOfPosition(start);
        return {
            line: position.line + 1,
            column: position.character + 1,
            message: ts.flattenDiagnosticMessageText(diagnostic.messageText, "\n"),
        };
    });
}

function getScriptKind(filePath) {
    switch (path.extname(filePath).toLowerCase()) {
        case ".ts":
            return ts.ScriptKind.TS;
        case ".tsx":
            return ts.ScriptKind.TSX;
        case ".mts":
            return ts.ScriptKind.MTS;
        case ".cts":
            return ts.ScriptKind.CTS;
        case ".jsx":
            return ts.ScriptKind.JSX;
        case ".js":
        case ".mjs":
        case ".cjs":
            return ts.ScriptKind.JS;
        default:
            return ts.ScriptKind.TS;
    }
}

function describeTypeScriptLanguage(filePath) {
    const extension = path.extname(filePath).toLowerCase();

    if (extension === ".ts" || extension === ".mts" || extension === ".cts") {
        return "typescript";
    }

    if (extension === ".tsx") {
        return "tsx";
    }

    if (extension === ".jsx") {
        return "jsx";
    }

    return "javascript";
}

function analyzeTreeSitterSourceText({ sourceText, filePath, cwd }, config) {
    const parser = new Parser();
    parser.setLanguage(config.grammar);
    const tree = parser.parse(sourceText);
    const parseErrors = collectTreeSitterParseErrors(tree.rootNode);
    const functions = collectTreeSitterFunctions(tree.rootNode, config).map((entry) =>
        analyzeTreeSitterFunction(entry, config),
    );

    return buildFileResult({
        filePath,
        cwd,
        language: config.languageId,
        parseErrors,
        functions,
    });
}

function collectTreeSitterFunctions(rootNode, config) {
    const entries = [];

    function visit(node, ancestors) {
        if (config.functionNodeTypes.has(node.type) && config.getFunctionRoot(node)) {
            entries.push({ node, ancestors });
        }

        const nextAncestors = ancestors.concat(node);
        for (const child of node.namedChildren) {
            visit(child, nextAncestors);
        }
    }

    visit(rootNode, []);
    return entries;
}

function analyzeTreeSitterFunction(entry, config) {
    const { node, ancestors } = entry;
    const metrics = {
        cyclomatic: 1,
        nesting_depth: 0,
        loc: countExecutableLinesByText(node.text, {
            lineCommentPrefixes: config.lineCommentPrefixes,
            blockCommentDelimiters: config.blockCommentDelimiters,
        }),
    };
    const root = config.getFunctionRoot(node);
    if (root) {
        traverseTreeSitterMetrics(root, node, config, metrics, 0);
    }

    return finalizeFunctionMetrics({
        functionName: config.getFunctionName(node, ancestors),
        kind: node.type,
        range: {
            start_line: node.startPosition.row + 1,
            start_column: node.startPosition.column + 1,
            end_line: node.endPosition.row + 1,
            end_column: node.endPosition.column + 1,
        },
        metrics,
    });
}

function traverseTreeSitterMetrics(node, rootFunctionNode, config, metrics, depth) {
    if (node !== rootFunctionNode && config.functionNodeTypes.has(node.type)) {
        return;
    }

    const nestingIncrement = config.nestingNodeTypes.has(node.type) ? 1 : 0;
    const nextDepth = depth + nestingIncrement;

    if (nestingIncrement > 0) {
        metrics.nesting_depth = Math.max(metrics.nesting_depth, nextDepth);
    }

    metrics.cyclomatic += getTreeSitterCyclomaticContribution(node, config);

    for (const child of node.namedChildren) {
        traverseTreeSitterMetrics(child, rootFunctionNode, config, metrics, nextDepth);
    }
}

function getTreeSitterCyclomaticContribution(node, config) {
    let total = config.cyclomaticNodeTypes.has(node.type) ? 1 : 0;
    total += config.getExtraCyclomaticContribution(node);
    return total;
}

function collectTreeSitterParseErrors(rootNode) {
    if (!rootNode.hasError) {
        return [];
    }

    const firstErrorNode = findFirstTreeSitterErrorNode(rootNode);
    if (!firstErrorNode) {
        return [{ line: 1, column: 1, message: "Parser reported syntax errors in file." }];
    }

    return [
        {
            line: firstErrorNode.startPosition.row + 1,
            column: firstErrorNode.startPosition.column + 1,
            message: "Parser reported syntax errors in file.",
        },
    ];
}

function findFirstTreeSitterErrorNode(node) {
    if (node.type === "ERROR" || node.isMissing === true) {
        return node;
    }

    for (let index = 0; index < node.childCount; index += 1) {
        const child = node.child(index);
        if (!child) {
            continue;
        }

        const match = findFirstTreeSitterErrorNode(child);
        if (match) {
            return match;
        }
    }

    return null;
}

function getTreeSitterAncestorName(ancestors, targetTypes) {
    for (let index = ancestors.length - 1; index >= 0; index -= 1) {
        const ancestor = ancestors[index];
        if (!targetTypes.has(ancestor.type)) {
            continue;
        }

        const nameNode = ancestor.childForFieldName("name");
        return nameNode?.text ?? null;
    }

    return null;
}

function anonymousTreeSitterName(node) {
    return `anonymous@L${node.startPosition.row + 1}`;
}

function buildFileResult({ filePath, cwd, language, parseErrors, functions }) {
    const averageScore =
        functions.length === 0
            ? 100
            : Math.round(
                  functions.reduce((total, item) => total + item.score_0_100, 0) / functions.length,
              );
    const worstScore =
        functions.length === 0
            ? 100
            : Math.min(...functions.map((item) => item.score_0_100));

    return {
        path: toPortablePath(path.relative(cwd, filePath) || filePath),
        language,
        verdict: aggregateVerdict([
            parseErrors.length > 0 ? "FAIL" : "PASS",
            ...functions.map((item) => item.verdict),
        ]),
        parse_errors: parseErrors,
        summary: {
            function_count: functions.length,
            average_score: averageScore,
            worst_score: worstScore,
            function_counts: countVerdicts(functions.map((item) => item.verdict)),
        },
        functions,
    };
}

function finalizeFunctionMetrics({ functionName, kind, range, metrics }) {
    const penalties = {
        cyclomatic: normalizeCyclomatic(metrics.cyclomatic),
        loc: normalizeLoc(metrics.loc),
        nesting: normalizeNesting(metrics.nesting_depth),
    };
    const risk =
        penalties.cyclomatic * 0.55 + penalties.nesting * 0.25 + penalties.loc * 0.2;

    return {
        function: functionName,
        kind,
        range,
        cyclomatic: metrics.cyclomatic,
        loc: metrics.loc,
        nesting_depth: metrics.nesting_depth,
        penalties: {
            cyclomatic: roundPenalty(penalties.cyclomatic),
            loc: roundPenalty(penalties.loc),
            nesting: roundPenalty(penalties.nesting),
        },
        risk: roundPenalty(risk),
        score_0_100: Math.round(100 * (1 - risk)),
        verdict: deriveVerdict(metrics),
        reasons: buildReasons(metrics),
        recommended_actions: buildRecommendations(metrics),
    };
}

function deriveVerdict(metrics) {
    if (
        metrics.cyclomatic > DEFAULT_THRESHOLDS.cyclomatic.fail ||
        metrics.loc > DEFAULT_THRESHOLDS.loc.fail ||
        metrics.nesting_depth >= DEFAULT_THRESHOLDS.nesting.fail
    ) {
        return "FAIL";
    }

    if (
        metrics.cyclomatic > DEFAULT_THRESHOLDS.cyclomatic.warn ||
        metrics.loc > DEFAULT_THRESHOLDS.loc.warn ||
        metrics.nesting_depth >= DEFAULT_THRESHOLDS.nesting.warn
    ) {
        return "WARN";
    }

    return "PASS";
}

function buildReasons(metrics) {
    const reasons = [];

    if (metrics.cyclomatic > DEFAULT_THRESHOLDS.cyclomatic.fail) {
        reasons.push(`cyclomatic > ${DEFAULT_THRESHOLDS.cyclomatic.fail}`);
    } else if (metrics.cyclomatic > DEFAULT_THRESHOLDS.cyclomatic.warn) {
        reasons.push(
            `cyclomatic in ${DEFAULT_THRESHOLDS.cyclomatic.warn + 1}..${DEFAULT_THRESHOLDS.cyclomatic.fail} (refactor recommended)`,
        );
    }

    if (metrics.loc > DEFAULT_THRESHOLDS.loc.fail) {
        reasons.push(`loc > ${DEFAULT_THRESHOLDS.loc.fail}`);
    } else if (metrics.loc > DEFAULT_THRESHOLDS.loc.warn) {
        reasons.push(`loc > ${DEFAULT_THRESHOLDS.loc.warn} (function too long)`);
    }

    if (metrics.nesting_depth >= DEFAULT_THRESHOLDS.nesting.fail) {
        reasons.push(`nesting_depth > ${DEFAULT_THRESHOLDS.nesting.warn}`);
    } else if (metrics.nesting_depth >= DEFAULT_THRESHOLDS.nesting.warn) {
        reasons.push(`nesting_depth at recommended maximum (${DEFAULT_THRESHOLDS.nesting.warn})`);
    }

    return reasons;
}

function buildRecommendations(metrics) {
    const recommendations = [];

    if (metrics.nesting_depth >= DEFAULT_THRESHOLDS.nesting.warn) {
        recommendations.push("Extract guard clauses or early returns to flatten nesting");
        recommendations.push("Split deeply nested branches into named helpers");
    }

    if (metrics.cyclomatic > DEFAULT_THRESHOLDS.cyclomatic.warn) {
        recommendations.push("Extract helper functions for each decision cluster");
        recommendations.push(
            "Replace nested conditionals with a dispatch table or strategy where appropriate",
        );
    }

    if (metrics.loc > DEFAULT_THRESHOLDS.loc.warn) {
        recommendations.push("Split orchestration from detailed work into smaller functions");
    }

    if (recommendations.length === 0) {
        recommendations.push("No immediate refactor required");
    }

    return Array.from(new Set(recommendations));
}

function summarizeResults(fileResults) {
    const fileVerdicts = fileResults.map((item) => item.verdict);
    const functionVerdicts = fileResults.flatMap((item) => item.functions.map((fn) => fn.verdict));
    const functionScores = fileResults.flatMap((item) => item.functions.map((fn) => fn.score_0_100));

    return {
        verdict: aggregateVerdict(fileVerdicts),
        file_counts: countVerdicts(fileVerdicts),
        function_counts: countVerdicts(functionVerdicts),
        average_score:
            functionScores.length === 0
                ? 100
                : Math.round(
                      functionScores.reduce((total, value) => total + value, 0) / functionScores.length,
                  ),
        worst_score: functionScores.length === 0 ? 100 : Math.min(...functionScores),
    };
}

function buildHotspots(fileResults, maxHotspots) {
    const hotspots = [];

    for (const fileResult of fileResults) {
        for (const fn of fileResult.functions) {
            hotspots.push({
                path: fileResult.path,
                language: fileResult.language,
                function: fn.function,
                verdict: fn.verdict,
                score_0_100: fn.score_0_100,
                risk: fn.risk,
                start_line: fn.range.start_line,
                reasons: fn.reasons,
            });
        }
    }

    return hotspots
        .sort((left, right) => {
            if (left.score_0_100 !== right.score_0_100) {
                return left.score_0_100 - right.score_0_100;
            }

            if (left.risk !== right.risk) {
                return right.risk - left.risk;
            }

            if (left.path !== right.path) {
                return left.path.localeCompare(right.path);
            }

            return left.start_line - right.start_line;
        })
        .slice(0, maxHotspots);
}

function aggregateVerdict(verdicts) {
    if (verdicts.includes("FAIL")) {
        return "FAIL";
    }

    if (verdicts.includes("WARN")) {
        return "WARN";
    }

    return "PASS";
}

function countVerdicts(verdicts) {
    return verdicts.reduce(
        (counts, verdict) => {
            const key = verdict.toLowerCase();
            counts[key] += 1;
            return counts;
        },
        { pass: 0, warn: 0, fail: 0 },
    );
}

async function expandTargets(targets, cwd) {
    const files = new Set();
    const missingTargets = [];

    for (const target of targets) {
        const resolved = path.resolve(cwd, target);
        const stats = await safeStat(resolved);

        if (!stats) {
            missingTargets.push(target);
            continue;
        }

        if (stats.isSymbolicLink()) {
            continue;
        }

        if (stats.isDirectory()) {
            for (const filePath of await walkDirectory(resolved)) {
                files.add(filePath);
            }
            continue;
        }

        if (stats.isFile() && isSupportedSourceFile(resolved)) {
            files.add(resolved);
        }
    }

    return {
        files: Array.from(files),
        missingTargets,
    };
}

async function walkDirectory(root) {
    const matches = [];
    const stack = [root];

    while (stack.length > 0) {
        const current = stack.pop();
        const entries = await fs.readdir(current, { withFileTypes: true });

        for (const entry of entries) {
            const fullPath = path.join(current, entry.name);
            const nextDirectory = getNextDirectoryToVisit(entry, fullPath);
            if (nextDirectory) {
                stack.push(nextDirectory);
                continue;
            }

            if (isSourceFileEntry(entry, fullPath)) {
                matches.push(fullPath);
            }
        }
    }

    return matches;
}

function getNextDirectoryToVisit(entry, fullPath) {
    if (entry.isSymbolicLink() || !entry.isDirectory()) {
        return null;
    }

    if (shouldSkipDirectory(entry.name)) {
        return null;
    }

    return fullPath;
}

function isSourceFileEntry(entry, fullPath) {
    return entry.isFile() && isSupportedSourceFile(fullPath);
}

function shouldSkipDirectory(name) {
    return name === ".git" || name === "node_modules" || name === "dist" || name === "coverage";
}

function isSupportedSourceFile(filePath) {
    return SUPPORTED_EXTENSIONS.has(path.extname(filePath).toLowerCase());
}

function getLanguageDefinition(filePath) {
    const languageId = EXTENSION_TO_LANGUAGE_ID.get(path.extname(filePath).toLowerCase());
    return languageId ? LANGUAGE_BY_ID.get(languageId) : null;
}

function normalizeTargets(targets) {
    if (!Array.isArray(targets) || targets.length === 0) {
        return ["."];
    }

    return Array.from(
        new Set(
            targets
                .map((target) => String(target).trim())
                .filter((target) => target.length > 0),
        ),
    );
}

async function safeStat(targetPath) {
    try {
        return await fs.lstat(targetPath);
    } catch {
        return null;
    }
}

function countExecutableLinesByText(text, { lineCommentPrefixes, blockCommentDelimiters }) {
    const lines = text.split(/\r?\n/);
    const commentState = {
        inBlockComment: false,
        activeBlockDelimiter: null,
    };

    return lines.reduce((total, line) => {
        return (
            total +
            (lineContainsExecutableCode(line, commentState, {
                lineCommentPrefixes,
                blockCommentDelimiters,
            })
                ? 1
                : 0)
        );
    }, 0);
}

function lineContainsExecutableCode(
    line,
    commentState,
    { lineCommentPrefixes, blockCommentDelimiters },
) {
    let remaining = line.trim();

    while (remaining.length > 0) {
        remaining = consumeOpenBlockComment(remaining, commentState);
        if (remaining.length === 0) {
            return false;
        }

        if (startsWithCommentPrefix(remaining, lineCommentPrefixes)) {
            return false;
        }

        const blockDelimiter = findLeadingBlockDelimiter(remaining, blockCommentDelimiters);
        if (!blockDelimiter) {
            return true;
        }

        remaining = consumeLeadingBlockDelimiter(remaining, blockDelimiter, commentState);
    }

    return false;
}

function consumeOpenBlockComment(remaining, commentState) {
    if (!commentState.inBlockComment) {
        return remaining;
    }

    const activeDelimiter = commentState.activeBlockDelimiter;
    const blockEndIndex = remaining.indexOf(activeDelimiter.end);
    if (blockEndIndex === -1) {
        return "";
    }

    commentState.inBlockComment = false;
    commentState.activeBlockDelimiter = null;
    return remaining.slice(blockEndIndex + activeDelimiter.end.length).trim();
}

function startsWithCommentPrefix(remaining, lineCommentPrefixes) {
    return lineCommentPrefixes.some((prefix) => remaining.startsWith(prefix));
}

function findLeadingBlockDelimiter(remaining, blockCommentDelimiters) {
    return blockCommentDelimiters.find((delimiter) => remaining.startsWith(delimiter.start)) ?? null;
}

function consumeLeadingBlockDelimiter(remaining, blockDelimiter, commentState) {
    const blockEndIndex = remaining.indexOf(blockDelimiter.end, blockDelimiter.start.length);
    if (blockEndIndex === -1) {
        commentState.inBlockComment = true;
        commentState.activeBlockDelimiter = blockDelimiter;
        return "";
    }

    return remaining.slice(blockEndIndex + blockDelimiter.end.length).trim();
}

function normalizeCyclomatic(value) {
    return clamp((value - DEFAULT_THRESHOLDS.cyclomatic.warn) / 10, 0, 1);
}

function normalizeLoc(value) {
    return clamp((value - DEFAULT_THRESHOLDS.loc.warn) / 50, 0, 1);
}

function normalizeNesting(value) {
    return clamp((value - DEFAULT_THRESHOLDS.nesting.warn) / 3, 0, 1);
}

function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}

function roundPenalty(value) {
    return Math.round(value * 100) / 100;
}

function countMatches(value, pattern) {
    const matches = value.match(pattern);
    return matches ? matches.length : 0;
}

function toRange(start, end) {
    return {
        start_line: start.line + 1,
        start_column: start.character + 1,
        end_line: end.line + 1,
        end_column: end.character + 1,
    };
}

function toPortablePath(value) {
    return value.split(path.sep).join("/");
}
