<!--
Behavior-shaping changes in this repo are not "docs-only".
If you change agent instructions, review gates, workflow defaults, harness logic,
or blueprint semantics, treat that as executable behavior change.
-->

## Problem Statement
<!-- What concrete problem, failure mode, drift, or operator pain does this PR solve? -->

## What Changed
<!-- 1-3 sentences on the change itself. -->

## Affected Surfaces
- [ ] Agent instructions / controller behavior
- [ ] Workflow harness / transcript tests
- [ ] Bootstrap / blueprint schema
- [ ] Janitor runner / automation
- [ ] Docs only

## Why This Belongs In Core
<!-- Explain why this belongs in the shared workflow/agents repo rather than in a single project repo. -->

## Alternatives Considered
<!-- What other approaches were considered, and why were they rejected? -->

## Evidence / Validation
- Scenario or transcript used:
- Commands run:
- Before/after behavior:

## Behavior-Shaping Change Check
- [ ] This PR changes executable agent/workflow behavior
- [ ] If yes, the changed behavior is described above with evidence
- [ ] If yes, transcript or scenario-based validation was added or updated

## Scope Check
- [ ] This PR addresses one coherent problem
- [ ] Unrelated cleanup was not bundled in

## Human Review
- [ ] A human reviewed the complete diff

## Risks / Follow-ups
<!-- Residual risk, manual follow-up, or deferred work. -->
