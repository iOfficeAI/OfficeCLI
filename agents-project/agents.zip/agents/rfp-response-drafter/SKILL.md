---
name: rfp-response-drafter
description: "Use when you need to draft the proposal response from the compliance matrix and strategy brief with requirement traceability, richer evaluator-facing detail, and a claims register."
workflow_role: worker
workflow_binding: contract_only
primary_outputs:
  - response draft
  - claims register
default_next:
  success: rfp-red-team-reviewer
  partial_success: human approval boundary
  blocked: user escalation or source repair
  needs_more_evidence: missing proof, pricing, or credential inputs
  fail: rerun after strategy or source repair
---

# Purpose

Write the proposal body in a form the review pipeline can trust. This node drafts the response, keeps it traceable to tender requirements, and captures every non-trivial claim that needs evidence. It must produce more than compliance-safe bullet shells: scored sections should explain the approach, process, work products, and decision logic clearly enough for evaluator review. It does not silently invent proof.

## Workflow role

- Role: `worker`
- Binding: `contract_only`
- Goal gate: no
- Human approval node: yes, when pricing, legal wording, or named team commitments need confirmation
- Typical predecessors: `rfp-strategy-shaper`
- Typical successors: `rfp-red-team-reviewer`, `rfp-claim-evidence-auditor`

## Inputs

### Required

- `rfp/<RFP-ID>/intake/rfp-intake.md`
- `rfp/<RFP-ID>/compliance/compliance-matrix.yaml`
- `rfp/<RFP-ID>/strategy/response-strategy.md`
- `rfp/<RFP-ID>/strategy/response-outline.yaml`

### Optional

- capability library
- `rfp/<RFP-ID>/strategy/response-visual-brief.yaml`
- `rfp/<RFP-ID>/visuals/design-profile.yaml`
- approved references and case studies
- team bios and CVs
- pricing inputs
- template or formatting constraints

## Preconditions

1. The compliance matrix exists and unresolved mandatory items are not being ignored.
2. Strategy brief and outline exist.
3. Claims without proof paths must be logged, not polished away.

## Procedure

1. Verify required inputs exist and read them in full.
2. Build the response structure from the outline and submission rules.
3. Draft each section so it maps back to requirement IDs from the compliance matrix.
4. For score-moving sections, do not stop at headline bullets. Explicitly cover, where relevant:
   - what EY will do
   - how the work will be executed
   - which work products or deliverables the client will receive
   - who participates, governs, or provides inputs
   - which dependencies, risks, or assumptions matter
5. Use tables, structured lists, and approved visual placeholders or simple exhibit specs where they improve clarity. When the strategy brief calls for a timeline, process flow, governance model, matrix, or architecture view, carry that forward into the draft instead of flattening it into generic prose.
6. Preserve enough structure for later rendering by keeping, where relevant:
   - a stable visual or exhibit identifier
   - the intended artifact type
   - the business question the visual answers
   - the core labels, actors, phases, rows, columns, or nodes the renderer must preserve
   - the approved design reference or design-profile hint the renderer must preserve
7. For every non-trivial claim, add or update a claims-register entry with:
   - claim text
   - draft location
   - required proof type
   - source path if known
   - verification status
8. Mark unknown proof or pending decisions explicitly instead of hiding them in final-sounding prose.
9. Write the draft as a versioned artifact.

## Output Contract

### Artifacts

- `rfp/<RFP-ID>/drafts/response-v<N>.md`
- `rfp/<RFP-ID>/evidence/claims-register.yaml`

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` - a traceable draft and claims register were produced
- `partial_success` - the draft is usable but one or more marked decisions still require human input
- `blocked` - a mandatory source, section, or submission rule is missing
- `needs_more_evidence` - the draft exists but too many proof-critical claims lack source paths
- `fail` - drafting failed because upstream artifacts were unusable

## Done Criteria

1. The response draft exists and follows the outline or submission structure.
2. Requirement traceability is visible.
3. Non-trivial claims are recorded in the claims register.
4. Score-moving sections contain enough substance to explain process, work products, and delivery logic.
5. Open decisions and unsupported claims are explicit.
6. Visual placeholders or exhibit instructions are present where the strategy brief called for them.
7. Draft-level visual placeholders carry enough structure to seed a later manifest or typed visual spec, including any approved design reference required for styling and validation.

## Evidence Requirements

- Claim: a section addresses a requirement -> proof: requirement IDs were mapped in this run
- Claim: a substantive statement is supported -> proof: a source path or required proof type was recorded in this run
- Claim: the draft is ready for review -> proof: draft artifact and claims register were produced in this run
- Claim: a section is rich enough for evaluator review -> proof: process, work-product, and decision-useful detail were checked against the strategy brief in this run

## Failure Routing

- missing upstream strategy or compliance artifact -> `blocked`
- too many unsupported proof-critical claims -> `needs_more_evidence`
- missing pricing, legal, or named-team input for required sections -> `partial_success`
- unusable upstream artifacts -> `fail`

## Escalation Rules

1. Escalate when the tender requires commitments the current source set cannot support.
2. Escalate when pricing, commercial language, or named resource commitments remain undecided.
3. Escalate when the draft would otherwise misrepresent capability, delivery certainty, or evidence.

## Never Do

- never invent case studies, CVs, certifications, references, metrics, or delivery commitments
- never write as if an unresolved claim were already approved
- never break traceability to tender requirements
- never let generic filler replace a concrete answer to a scored requirement
- never let a section stop at thin bullets when the source set supports clearer explanation, work products, or visuals

## Drafting Depth Expectations

For any scored or evaluator-critical section, prefer this response spine unless the tender format clearly demands something else:

1. direct answer or position,
2. approach or method,
3. concrete activities or workstreams,
4. explicit work products or deliverables,
5. dependencies, governance, or client inputs,
6. proof-bearing differentiators or evidence hooks,
7. visual placeholder when a diagram, table, matrix, or timeline would carry the point better than prose alone.

