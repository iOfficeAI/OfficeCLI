---
name: rfp-submission-packager
description: "Use when assemble the final submission package from approved response artifacts, evidence status, delivery instructions, and typed visual / rendering inputs when required."
workflow_role: orchestrator
workflow_binding: contract_only
primary_outputs:
  - submission package artifacts
  - submission manifest
default_next:
  success: rfp-conductor readiness close
  partial_success: human packaging choice boundary
  blocked: user escalation or asset repair
  needs_more_evidence: missing deliverable or packaging rule
  fail: rerun after asset or renderer repair
---

# Purpose

Package the approved proposal into the deliverable set the tender actually requires. This node assembles files, delegates rendering when needed, validates filenames and completeness, and writes a submission manifest. It does not bypass evidence or compliance gates.

## Workflow role

- Role: `orchestrator`
- Binding: `contract_only`
- Goal gate: yes, for deliverable completeness and packaging readiness
- Human approval node: yes, when packaging options or final format choices require confirmation
- Typical predecessors: `rfp-claim-evidence-auditor`
- Typical successors: `powerpoint-rfp-generator`, `rfp-conductor`

## Inputs

### Required

- latest approved response draft
- `rfp/<RFP-ID>/strategy/response-outline.yaml`
- compliance matrix
- evidence audit artifact
- submission instructions

### Optional

- PowerPoint or document template
- `rfp/<RFP-ID>/strategy/response-visual-brief.yaml`
- approved design exemplars or brand-approved proposal samples
- `powerpoint-rfp-generator/artifacts/catalog.yaml`
- annexes, pricing sheets, forms, and declarations
- output naming rules
- graphical assets

## Preconditions

1. Evidence audit does not leave submission-critical claims unresolved.
2. Submission instructions exist and are readable.
3. Every mandatory deliverable must be accounted for in the manifest.

## Procedure

1. Read the response draft, evidence audit artifact, compliance matrix, and submission instructions in full.
2. Determine the mandatory deliverable set, filenames, and format rules.
3. If PowerPoint is required, compile `rfp/<RFP-ID>/visuals/visual-manifest.yaml` from the response outline and visual / exhibit brief, and write `rfp/<RFP-ID>/visuals/design-profile.yaml` when an approved design exemplar or reusable style profile exists.
4. For each required score-moving visual, write a typed spec under `rfp/<RFP-ID>/visuals/specs/` using a supported artifact type from `powerpoint-rfp-generator/artifacts/catalog.yaml`.
5. Delegate rendering to `powerpoint-rfp-generator` once per typed visual spec so it produces deterministic `visuals/rendered/` artifacts plus JSON reports and style-validation output when a `.pptx` visual artifact is requested.
6. If the tender requires a final submission deck, assemble that deck as a separate packaging step only after all required rendered visuals exist. Do not claim that `powerpoint-rfp-generator` already assembled the full deck unless that composition step actually happened in this run.
7. Assemble remaining deliverables and copy or prepare annex artifacts only when they exist and are approved inputs.
8. Validate:
    - every mandatory file exists
    - filenames match submission rules
    - no placeholder or unresolved marker survives in final deliverables
    - typed visual specs exist for every manifest item marked `render_required: true`
    - rendered visual payloads exist for every typed spec the package claims to have rendered
    - required tables, timelines, process visuals, or key exhibits from the approved brief are either present or explicitly warned as missing
    - PowerPoint deliverables have an approved design reference or an explicit warning that style validation could not run
    - a final submission deck is only claimed when the assembled `package/<submission-name>.pptx` exists in this run
9. Write a submission manifest naming each artifact, its purpose, and residual warnings.

## Output Contract

### Artifacts

- `rfp/<RFP-ID>/visuals/visual-manifest.yaml`
- `rfp/<RFP-ID>/visuals/design-profile.yaml`
- `rfp/<RFP-ID>/visuals/specs/<NN>-<artifact-id>.yaml`
- `rfp/<RFP-ID>/visuals/rendered/<NN>-<artifact-id>.json`
- optional `rfp/<RFP-ID>/visuals/rendered/<NN>-<artifact-id>.pptx`
- optional `rfp/<RFP-ID>/visuals/rendered/<NN>-<artifact-id>.report.json`
- optional `rfp/<RFP-ID>/visuals/rendered/<NN>-<artifact-id>.style-validation.json`
- optional `rfp/<RFP-ID>/package/powerpoint-render-report.json`
- `rfp/<RFP-ID>/package/submission-manifest.yaml`
- `rfp/<RFP-ID>/package/<deliverables>`

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` - the required package was assembled and validated
- `partial_success` - part of the package is assembled, but a user choice or optional format remains open
- `blocked` - a mandatory deliverable, template, or annex is missing
- `needs_more_evidence` - submission rules or source assets are too incomplete to package safely
- `fail` - packaging failed because a renderer or required asset path was unusable

## Done Criteria

1. Submission manifest exists.
2. Every mandatory deliverable is named in the manifest.
3. Produced files exist and match the required naming and format rules.
4. Placeholder text and unresolved markers were checked explicitly.
5. Required visual or exhibit moments from the approved brief are present or explicitly warned.
6. Every required PowerPoint visual has a manifest entry, typed spec, and rendered payload before rendering is claimed.
7. PowerPoint packaging includes a design profile or an explicit warning that approved exemplar comparison was not possible.
8. A final PowerPoint deck is claimed only when the assembled deck file exists in `package/` for this run.

## Evidence Requirements

- Claim: the package is complete -> proof: submission manifest and required files were checked in this run
- Claim: a packaged file matches instructions -> proof: submission rules and output filename were checked in this run
- Claim: no unresolved placeholder remains -> proof: final deliverables were inspected in this run
- Claim: expected visuals were carried into packaging -> proof: visual brief and final deliverables were checked in this run
- Claim: expected visuals were prepared for deterministic rendering -> proof: visual manifest and typed specs were produced in this run
- Claim: rendered visuals actually exist -> proof: `visuals/rendered/` payloads and reports were checked in this run
- Claim: the deck can be style-validated against approved design intent -> proof: design profile or exemplar reference was produced in this run
- Claim: a final submission deck exists -> proof: assembled `package/<submission-name>.pptx` was produced in this run

## Failure Routing

- missing mandatory annex or template -> `blocked`
- unclear packaging instructions -> `needs_more_evidence`
- missing visual spec detail for a required PowerPoint artifact -> `needs_more_evidence`
- missing approved design reference for a style-critical PowerPoint deliverable -> `needs_more_evidence`
- missing rendered visual payload for a claimed artifact -> `fail`
- renderer or file assembly path unusable -> `fail`
- optional format undecided but core package assembled -> `partial_success`

## Escalation Rules

1. Escalate when a mandatory annex or declaration is missing.
2. Escalate when requested output formats cannot be produced safely with available templates or tools.
3. Escalate when submission rules conflict with the available artifact set.

## Never Do

- never silently drop a mandatory file because the core narrative looks good
- never package unresolved placeholders as if they were final content
- never invent annexes, declarations, or pricing sheets
- never claim a packaged file exists without verifying it in this run
- never invent a typed visual spec without enough approved narrative structure to support it
- never claim a final deck exists when only per-visual render artifacts were produced
