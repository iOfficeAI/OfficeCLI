---
name: cv-history-curator
description: "Use when you need to curate provenance-rich won/lost CV-response history from the host project's markdown corpus and extract reusable patterns, elaborated win themes, and reuse guardrails without copying source prose."
workflow_role: worker
workflow_binding: contract_only
primary_outputs:
  - won corpus index
  - lost corpus index
  - reusable historical pattern summary
  - reusable win-theme library
default_next:
  success: cv-fit-mapper
  partial_success: cv-fit-mapper with thin history
  blocked: user escalation or corpus repair
  needs_more_evidence: missing historical case files
  fail: rerun after corpus repair
---

# Purpose

Turn the host project's historical `rfp/won` and `rfp/lost` markdown cases into a reusable, provenance-aware corpus for the active run. This node extracts patterns, elaborated win themes, cautions, and evidence hooks. It does not copy historical answer text into the active draft.

## Workflow role

- Role: `worker`
- Binding: `contract_only`
- Goal gate: no
- Human approval node: no
- Typical predecessors: `cv-project-context-discoverer`, `cv-rfp-conductor`
- Typical successors: `cv-fit-mapper`, `cv-response-drafter`

## Inputs

### Required

- host project repo root
- active `RFP-ID`
- normalized current RFP

### Optional

- selected project context
- normalized previous RFP
- normalized previous response

## Preconditions

1. Historical corpus lives under `rfp/won/**` and `rfp/lost/**` in markdown form.
2. Corpus output must preserve provenance down to the case path.
3. Historical material may inform patterns, not become copy source.

## Palace Recall

Before scanning the corpus, recall prior validated patterns without treating memory as proof:

1. Call `mempalace_diary_read` with `agent_name: "cv-history-curator"` and `last_n: 3`.
2. Then call `mempalace_search` with `wing` set to the current repo name and `limit: 5` for:
   - `query: "<topic> PATTERN"`
   - `query: "<topic> DEVIATION"`
3. Use recall only to guide what to re-check in the current corpus.

## Procedure

1. Discover historical case folders under `rfp/won` and `rfp/lost`.
2. For each usable case, look for:
   - `rfp.md`
   - `cv.md`
   - `offer.md`
   - `outcome.md`
   - `notes.md`
3. Build `won-corpus-index.yaml` and `lost-corpus-index.yaml` with:
   - case id
   - available files
   - domain/topic summary
   - relevance note to the active RFP
   - provenance path
4. Extract reusable findings into `historical-patterns.md`:
   - patterns from wins
   - caution signals from losses
   - evaluator preference hints that show up repeatedly
   - evidence hooks that consistently mattered
   - copy-risk notes when a case is too close in wording to reuse safely
5. Write `historical-win-themes.md` with elaborated reusable themes, each including:
   - theme id and short label
   - why the theme appears to have mattered
   - common requirement signals the theme helps answer
   - typical evidence ingredients that made the theme credible
   - when not to use the theme
   - cited win/loss case paths
6. Keep themes abstract enough to be reused safely:
   - theme language may echo recurring evaluator concerns
   - theme language must not become copy-ready paragraph text
   - each theme must preserve provenance back to specific cases
7. If the corpus is thin, return `partial_success` rather than inventing lessons.
8. After completion, write a MemPalace diary entry with validated abstract patterns and deviations only.

## Output Contract

### Artifacts

- `rfp/active/<RFP-ID>/context/won-corpus-index.yaml`
- `rfp/active/<RFP-ID>/context/lost-corpus-index.yaml`
- `rfp/active/<RFP-ID>/context/historical-patterns.md`
- `rfp/active/<RFP-ID>/context/historical-win-themes.md`

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` - usable won/lost corpus indexes and pattern summary were produced
- `partial_success` - usable but thin historical corpus was found
- `blocked` - corpus root or case structure is contradictory enough to prevent safe use
- `needs_more_evidence` - expected historical cases or outcome files are missing
- `fail` - corpus scan failed in a way that prevents usable output

## Done Criteria

1. Won and lost indexes exist with provenance.
2. Reusable patterns and cautions are abstracted into a summary file.
3. Reusable win themes are elaborated with provenance, applicability notes, and non-use guidance.
4. Thin corpus or missing cases are surfaced explicitly.
5. MemPalace write-out, when used, contains only abstract validated lessons.

## Evidence Requirements

- Claim: a historical lesson comes from the corpus -> proof: source case path is recorded in the index in this run
- Claim: a pattern is reusable -> proof: the pattern summary cites one or more current-run corpus paths
- Claim: a loss signal matters -> proof: the loss case and its outcome/notes path were checked in this run
- Claim: a win theme is reusable -> proof: the theme cites one or more current-run win/loss paths and states why the theme mattered

## Failure Routing

- `rfp/won` and `rfp/lost` both absent -> `partial_success`
- case folders present but required files missing -> `needs_more_evidence`
- provenance cannot be preserved -> `blocked`
- corpus scan unusable -> `fail`

## Escalation Rules

1. Escalate when historical cases contain sensitive material that cannot be abstracted safely.
2. Escalate when a claimed win/loss outcome cannot be tied to an `outcome.md` or equivalent source.

## Never Do

- never copy historical response prose into the active response
- never collapse provenance away from extracted lessons
- never emit copy-ready theme paragraphs that can be pasted into the active response unchanged
- never store raw historical case text in MemPalace

