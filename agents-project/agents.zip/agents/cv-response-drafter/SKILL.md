---
name: cv-response-drafter
description: "Use when you need to draft a tailored CV response from the fit matrix, active win themes, and optimized candidate references while preserving UFST-oriented narrative depth, traceability, explicit evidence hooks, and bounded-neutral uncertainty language."
workflow_role: worker
workflow_binding: contract_only
primary_outputs:
  - CV response draft
  - claims register
default_next:
  success: cv-red-team-reviewer
  partial_success: human approval boundary
  blocked: user escalation or source repair
  needs_more_evidence: missing proof paths or unresolved fit gaps
  fail: rerun after upstream repair
---

# Purpose

Write the tailored CV response in a form the review pipeline can trust. This node drafts a traceable answer to the active RFP based on current evidence, project context, active win themes, and optimized candidate references. It does not invent proof or copy historical response text.

## Workflow role

- Role: `worker`
- Binding: `contract_only`
- Goal gate: no
- Human approval node: yes, when score-critical but weakly supported claims need explicit acceptance
- Typical predecessors: `cv-fit-mapper`, `cv-reference-optimizer`
- Typical successors: `cv-red-team-reviewer`, `cv-claim-evidence-auditor`

## Inputs

### Required

- `rfp/active/<RFP-ID>/extraction/requirements-register.yaml`
- `rfp/active/<RFP-ID>/extraction/fit-matrix.yaml`
- `rfp/active/<RFP-ID>/extraction/reference-adaptations.yaml`
- `rfp/active/<RFP-ID>/request/candidate-cv.md`

### Optional

- `rfp/active/<RFP-ID>/request/style-pack-resolved.yaml`
- `rfp/active/<RFP-ID>/context/selected-context.md`
- `rfp/active/<RFP-ID>/context/historical-patterns.md`
- `rfp/active/<RFP-ID>/extraction/active-win-themes.yaml`
- `rfp/active/<RFP-ID>/extraction/hint-ceilings.yaml`
- `rfp/active/<RFP-ID>/request/previous-response.md`
- `rfp/active/<RFP-ID>/extraction/methods-tools.md`

## Preconditions

1. Fit matrix exists and unsupported high-risk gaps are explicit.
2. Historical patterns may shape the answer, not provide copy text.
3. Every non-trivial claim must receive a claims-register entry.
4. Draft prose may be tone-softened, but unresolved evidence states must still be explicit in machine-readable artifacts.

## Procedure

1. Read the requirements register, fit matrix, reference adaptations, candidate CV, and optional context artifacts in full.
2. Draft the response structure so each major section maps back to requirement IDs.
3. For score-bearing or evaluator-sensitive requirements, avoid one-line answers unless the source material is genuinely thin. Prefer either one developed paragraph or a short lead plus support paragraph.
4. Prefer this spine where it fits:
   - direct answer
   - why the candidate is relevant for this buyer
   - concrete candidate evidence
   - methods/tools alignment
   - relevant project or domain context
   - active win-theme framing when safely supported
   - explicit evidence hook
5. Use project context, active win themes, and historical patterns to improve framing, terminology, and emphasis, but never copy their prose directly.
6. When available, use `style-pack-resolved.yaml` to apply customer-specific terminology, section depth, tone constraints, and exemplar-pattern guidance as framing only.
7. Use `reference-adaptations.yaml` as structured framing guidance only:
    - `safe_reframe` entries may shape terminology, emphasis, and section ordering
    - `requires_candidate_confirmation` entries must stay visibly provisional
    - `unsafe_substitution` entries must not be used in draft prose
8. Use `hint-ceilings.yaml` to turn weak but non-contradictory competency signals into write-up opportunities at the correct assertion ceiling.
9. Elaborate win themes so they explain why the candidate matters for the tender, not just that a theme exists.
10. Write or update a claims register for every non-trivial claim with:
    - claim text
    - claim type
    - assertion ceiling
    - draft location
    - requirement id
    - required proof type
    - source path if known
    - render payload keys if used
    - verification status
11. For each elaborated win-theme paragraph, record at least one claim entry tied to a requirement id and source path.
12. Mark unresolved claims explicitly using bounded-neutral language instead of deficit language or certainty theater.
13. Apply uncertainty language policy:
    - keep factual gaps explicit in claims/evidence artifacts
    - allow neutral bounded prose that does not invent capability
    - disallow self-sabotaging phrases such as "cannot", "lacks", or "has no experience" unless the buyer explicitly requires that wording
    - disallow optimistic wording that implies verified capability when proof is missing
14. Maintain this distinction:
    - `factual_claim`: must have proof path or explicit pending approval
    - `narrative_qualifier`: tone framing only, introduces no new facts
    - `pending_confirmation`: non-committal wording linked to a named confirmation dependency
15. Apply consultancy write-up strategy for weak but non-contradictory signals:
    - if hint signals exist, write them up instead of omitting them
    - enforce assertion ceiling from upstream artifacts
    - default ceiling is `exposure` when no explicit ceiling is provided
16. Use assertion ladder:
    - `exposure`: "har arbejdet i kontekst med ..."
    - `applied_support`: "har bidraget til ..."
    - `demonstrated_ownership`: "har haft ansvar for ..."
17. Never jump to a higher assertion level than the available evidence allows.
18. If rendering is in scope, build `render-payload.yaml` as an audited handoff artifact with:
    - scalar fields
    - loop collections
    - source claim ids
    - source artifact paths
    - assertion ceilings
    - required or optional marker status
19. Write `drafts/latest.yaml` pointing to the newest versioned draft and its companion render payload.

## Output Contract

### Artifacts

- `rfp/active/<RFP-ID>/drafts/cv-response-v<N>.md`
- `rfp/active/<RFP-ID>/drafts/latest.yaml`
- `rfp/active/<RFP-ID>/evidence/claims-register.yaml`
- optional `rfp/active/<RFP-ID>/deliverables/render-payload.yaml`

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

### Claims Register Entry Fields

- `claim`
- `claim_type`
- `assertion_ceiling`
- `draft_location`
- `requirement_id`
- `required_proof_type`
- `source_path`
- `render_payload_keys`
- `verification_status`

### Render Payload Fields

- `customer`
- `candidate`
- `template_profile`
- `scalars`
- `collections`
- `field_provenance`
- `field_assertion_ceilings`
- `required_keys`

## Status Vocabulary

- `success` - a traceable CV response draft and claims register were produced
- `partial_success` - the draft is usable but one or more claims still require explicit human approval
- `blocked` - a mandatory source or section is missing
- `needs_more_evidence` - too many proof-critical claims lack safe source paths
- `fail` - drafting failed because upstream artifacts were unusable

## Done Criteria

1. Versioned response draft exists.
2. Requirement traceability is visible.
3. Score-bearing sections are developed enough to read as evaluator-ready rather than clipped notes.
4. Claims register covers non-trivial claims.
5. Historical patterns and active win themes improved the answer without becoming copied prose.
6. Optimized references were used only as framing aids anchored in candidate-owned evidence.
7. Unsupported or weak claims are explicit in machine artifacts and bounded-neutral in prose.
8. Hint-supported competencies are written up with the correct assertion ceiling.
9. Render payload exists and is provenance-linked when rendering is in scope.

## Evidence Requirements

- Claim: a section addresses a requirement -> proof: requirement id is mapped in this run
- Claim: a non-trivial statement is supported -> proof: source path or proof type was recorded in the claims register in this run
- Claim: an elaborated win theme is safe -> proof: the paragraph maps to a requirement id plus a candidate-owned source path in this run
- Claim: historical material informed the draft safely -> proof: only abstract patterns or cited case paths were used in this run
- Claim: a rendered field is safe to materialize -> proof: payload key links back to one or more current-run claims and source paths

## Failure Routing

- missing fit matrix, reference adaptations, or candidate CV -> `blocked`
- too many unsupported proof-critical claims -> `needs_more_evidence`
- missing human confirmation for score-critical wording -> `partial_success`
- unusable upstream inputs -> `fail`

## Escalation Rules

1. Escalate when the draft would otherwise overstate the candidate profile.
2. Escalate when a key requirement can only be met by speculative or unapproved wording.

## Never Do

- never invent projects, tools, certifications, or metrics
- never copy prior won-response prose into the active response
- never treat optimizer output as replacement proof for candidate evidence
- never write unsupported claims as settled fact

