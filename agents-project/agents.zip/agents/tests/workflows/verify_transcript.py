#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Verify a workflow transcript against a scenario spec."
    )
    parser.add_argument("--scenario", required=True, help="Path to scenario JSON.")
    parser.add_argument(
        "--transcript", required=True, help="Path to transcript text or JSONL."
    )
    parser.add_argument(
        "--case-sensitive",
        action="store_true",
        help="Use case-sensitive matching.",
    )
    return parser.parse_args()


def collect_strings(value: Any) -> list[str]:
    strings: list[str] = []
    if isinstance(value, str):
        strings.append(value)
    elif isinstance(value, dict):
        for nested in value.values():
            strings.extend(collect_strings(nested))
    elif isinstance(value, list):
        for nested in value:
            strings.extend(collect_strings(nested))
    return strings


def read_transcript(path: Path) -> str:
    text = path.read_text(encoding="utf-8")
    if path.suffix != ".jsonl":
        return text

    parts: list[str] = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            parts.append(line)
            continue
        parts.extend(collect_strings(payload))
    return "\n".join(parts)


def load_scenario(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"Scenario must be a JSON object: {path}")
    return data


def normalize(text: str, case_sensitive: bool) -> str:
    return text if case_sensitive else text.lower()


def evaluate(
    scenario: dict[str, Any], transcript_text: str, case_sensitive: bool
) -> list[str]:
    failures: list[str] = []
    haystack = normalize(transcript_text, case_sensitive)

    for needle in scenario.get("must_contain", []):
        probe = normalize(str(needle), case_sensitive)
        if probe not in haystack:
            failures.append(f'missing required text: "{needle}"')

    for needle in scenario.get("must_not_contain", []):
        probe = normalize(str(needle), case_sensitive)
        if probe in haystack:
            failures.append(f'found forbidden text: "{needle}"')

    for group in scenario.get("ordered_groups", []):
        last_index = -1
        for needle in group:
            probe = normalize(str(needle), case_sensitive)
            next_index = haystack.find(probe, last_index + 1)
            if next_index == -1:
                failures.append(
                    "ordered group missing text: "
                    + " -> ".join(str(item) for item in group)
                )
                break
            last_index = next_index

    return failures


def main() -> int:
    args = parse_args()
    scenario_path = Path(args.scenario).resolve()
    transcript_path = Path(args.transcript).resolve()

    scenario = load_scenario(scenario_path)
    transcript_text = read_transcript(transcript_path)
    failures = evaluate(scenario, transcript_text, args.case_sensitive)

    print(f"Scenario: {scenario.get('name', scenario_path.stem)}")
    print(f"Transcript: {transcript_path}")

    if failures:
        print("Status: FAIL")
        for failure in failures:
            print(f"- {failure}")
        return 1

    print("Status: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
