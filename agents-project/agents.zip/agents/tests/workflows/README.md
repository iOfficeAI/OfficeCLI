# Workflow Transcript Harness

This directory is a starter harness for testing workflow behavior from real or
synthetic transcripts.

Goal:

- verify agent workflows as behavior, not just prose
- assert required phrases, gates, and ordering from transcript evidence
- keep the harness zero-dependency and cross-platform

## Files

- `verify_transcript.py` — validate one transcript against one scenario JSON
- `run_fixtures.py` — self-test runner for bundled fixture transcripts
- `scenarios/*.json` — expected workflow assertions
- `fixtures/*.jsonl` — synthetic transcripts that prove the harness works

## Run Fixture Self-Tests

```bash
python tests/workflows/run_fixtures.py
```

## Check A Real Transcript

```bash
python tests/workflows/verify_transcript.py \
  --scenario tests/workflows/scenarios/delivery-orchestrator-routing.json \
  --transcript path/to/transcript.jsonl
```

The verifier accepts plain text or `.jsonl` transcripts. For `.jsonl`, it
extracts string content from each JSON object and evaluates the joined text.

## Starter Coverage

Initial scenarios cover the highest-signal workflow claims:

- `delivery-orchestrator` should surface readiness gaps and approval boundaries
- `pipeline-conductor` should report quality-gated branch/PR/merge outcomes
- `hotfix-conductor` should include fresh verification evidence
- `change-request-conductor` should report PR-ready delta delivery with evidence

## Next Step

Replace or supplement the synthetic fixtures with transcripts from real agent
runs. Keep each scenario narrow and assert only the behavior that matters.
