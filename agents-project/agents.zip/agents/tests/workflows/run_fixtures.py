#!/usr/bin/env python3
from __future__ import annotations

import sys
from pathlib import Path

from verify_transcript import evaluate, load_scenario, read_transcript


def main() -> int:
    root = Path(__file__).resolve().parent
    scenarios_dir = root / "scenarios"
    fixtures_dir = root / "fixtures"

    scenario_paths = sorted(scenarios_dir.glob("*.json"))
    if not scenario_paths:
        print("No scenarios found.", file=sys.stderr)
        return 1

    failed = False
    for scenario_path in scenario_paths:
        fixture_path = fixtures_dir / f"{scenario_path.stem}.jsonl"
        if not fixture_path.exists():
            print(f"Missing fixture for {scenario_path.name}", file=sys.stderr)
            failed = True
            continue

        scenario = load_scenario(scenario_path)
        transcript_text = read_transcript(fixture_path)
        failures = evaluate(scenario, transcript_text, case_sensitive=False)
        if failures:
            failed = True
            print(f"FAIL {scenario_path.stem}")
            for failure in failures:
                print(f"  - {failure}")
        else:
            print(f"PASS {scenario_path.stem}")

    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
