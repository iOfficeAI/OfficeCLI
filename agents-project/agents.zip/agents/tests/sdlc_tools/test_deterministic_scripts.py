from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import yaml


REPO_ROOT = Path(__file__).resolve().parents[2]
SCRIPTS_DIR = REPO_ROOT / "scripts"


def run_cli(script_name: str, *args: str, cwd: Path | None = None) -> tuple[subprocess.CompletedProcess[str], dict]:
    command = [sys.executable, str(SCRIPTS_DIR / script_name), "--json", *args]
    result = subprocess.run(
        command,
        cwd=str(cwd or REPO_ROOT),
        capture_output=True,
        text=True,
        check=False,
    )
    payload = json.loads(result.stdout) if result.stdout.strip() else {}
    return result, payload


def write_yaml(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")


class DeterministicScriptsTest(unittest.TestCase):
    def test_bootstrap_blueprint_requires_e2e_for_browser_ui(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            blueprint = Path(temp_dir) / "ui-blueprint.md"
            blueprint.write_text(
                "\n".join(
                    [
                        "---",
                        'name: "UI Stack"',
                        'description: "Browser UI without e2e"',
                        "mise:",
                        "  tools:",
                        '    node: "22"',
                        "project:",
                        '  language: "typescript"',
                        '  runtime: "node 22"',
                        "  source_directories: ['src/']",
                        "  test_directories: ['tests/']",
                        "  build:",
                        '    compile: "npm run build"',
                        '    test: "npm test"',
                        '    lint: "npm run lint"',
                        '  test_framework: "vitest"',
                        "frameworks:",
                        "  ui: ['React']",
                        '  rendering_model: "SPA"',
                        "---",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            result, payload = run_cli(
                "bootstrap_tool.py",
                "validate-blueprint",
                "--blueprint",
                str(blueprint),
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(payload["status"], "FAIL")
            self.assertIn("project.e2e", " ".join(payload["errors"]))

    def test_bootstrap_generate_writes_required_scaffolds(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            config = {
                "system_name": "Payments Portal",
                "description": "Portal scaffold",
                "selected_modules": ["documentation_scaffold"],
                "mise": {"tools": {"node": "22"}},
                "project": {
                    "language": "typescript",
                    "runtime": "node 22",
                    "source_directories": ["src"],
                    "test_directories": ["tests"],
                    "build": {
                        "compile": "npm run build",
                        "test": "npm test",
                        "lint": "npm run lint",
                    },
                    "test_framework": "vitest",
                    "e2e": {
                        "framework": "playwright",
                        "project_root": "e2e",
                        "test_dir": "tests",
                        "config": "playwright.config.ts",
                        "install_command": "npm ci",
                        "type_check_command": "npx tsc --noEmit",
                        "test_list_command": "npx playwright test --list",
                        "runner": "npx playwright test",
                        "report_dir": "playwright-report",
                    },
                },
                "frameworks": {
                    "backend": ["Express"],
                    "ui": ["React"],
                    "testing": ["Vitest", "Playwright"],
                    "rendering_model": "SPA",
                },
            }
            config_path = root / "bootstrap-config.yaml"
            write_yaml(config_path, config)

            result, payload = run_cli(
                "bootstrap_tool.py",
                "generate",
                "--root",
                str(root),
                "--config",
                str(config_path),
            )
            self.assertEqual(result.returncode, 0, msg=result.stderr)
            self.assertEqual(payload["status"], "PASS")
            self.assertTrue((root / ".mise.toml").is_file())
            self.assertTrue((root / ".factory" / "project.yaml").is_file())
            self.assertTrue((root / ".factory" / "context" / "PROJECT_CONTEXT.md").is_file())
            self.assertTrue((root / "petitions" / "program-status.yaml").is_file())
            self.assertTrue((root / "AGENTS.md").is_file())
            generated_project = yaml.safe_load(
                (root / ".factory" / "project.yaml").read_text(encoding="utf-8")
            )
            self.assertEqual(generated_project["project"]["name"], "Payments Portal")

    def test_readiness_check_flags_missing_required_groups(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            result, payload = run_cli(
                "readiness_check.py",
                "--root",
                temp_dir,
                "--require",
                "architecture",
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(payload["items"]["petitions/program-status.yaml"], "MISSING")
            self.assertEqual(payload["items"]["architecture/workspace.dsl"], "MISSING")

    def test_project_contract_lint_detects_missing_e2e(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            (root / "src").mkdir()
            (root / "tests").mkdir()
            (root / "package.json").write_text('{"name":"demo"}\n', encoding="utf-8")
            write_yaml(
                root / ".factory" / "project.yaml",
                {
                    "project": {
                        "name": "Demo",
                        "language": "typescript",
                        "runtime": "node 22",
                        "source_directories": ["src"],
                        "test_directories": ["tests"],
                        "build": {
                            "compile": "npm run build",
                            "test": "npm test",
                            "lint": "npm run lint",
                        },
                        "test_framework": "vitest",
                        "docs": {
                            "engine": "mkdocs-material",
                            "config": "mkdocs.yml",
                            "docs_dir": "docs",
                            "site_dir": "site",
                            "build_command": "mkdocs build --strict",
                            "serve_command": "mkdocs serve",
                            "plugins": ["search"],
                        },
                    },
                    "stack": {
                        "languages": ["typescript"],
                        "runtimes": ["node 22"],
                        "frameworks": {
                            "backend": ["Express"],
                            "ui": ["React"],
                            "data": ["none"],
                            "integration": ["REST"],
                            "testing": ["Vitest"],
                        },
                        "rendering": {"mode": "SPA", "dynamic_interaction": "React Router"},
                    },
                },
            )
            result, payload = run_cli(
                "project_contract_lint.py",
                "--root",
                str(root),
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("project.e2e", " ".join(payload["errors"]))

    def test_project_contract_lint_passes_for_valid_browser_ui_project(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            (root / "src").mkdir()
            (root / "tests").mkdir()
            (root / "e2e" / "tests").mkdir(parents=True)
            (root / "playwright.config.ts").write_text("export default {};\n", encoding="utf-8")
            (root / "package.json").write_text('{"name":"demo"}\n', encoding="utf-8")
            write_yaml(
                root / ".factory" / "project.yaml",
                {
                    "project": {
                        "name": "Demo",
                        "language": "typescript",
                        "runtime": "node 22",
                        "source_directories": ["src"],
                        "test_directories": ["tests"],
                        "build": {
                            "compile": "npm run build",
                            "test": "npm test",
                            "lint": "npm run lint",
                        },
                        "test_framework": "vitest",
                        "e2e": {
                            "framework": "playwright",
                            "project_root": "e2e",
                            "test_dir": "tests",
                            "config": "playwright.config.ts",
                            "install_command": "npm ci",
                            "type_check_command": "npx tsc --noEmit",
                            "test_list_command": "npx playwright test --list",
                            "runner": "npx playwright test",
                            "report_dir": "playwright-report",
                        },
                        "docs": {
                            "engine": "mkdocs-material",
                            "config": "mkdocs.yml",
                            "docs_dir": "docs",
                            "site_dir": "site",
                            "build_command": "mkdocs build --strict",
                            "serve_command": "mkdocs serve",
                            "plugins": ["search"],
                        },
                    },
                    "stack": {
                        "languages": ["typescript"],
                        "runtimes": ["node 22"],
                        "frameworks": {
                            "backend": ["Express"],
                            "ui": ["React"],
                            "data": ["none"],
                            "integration": ["REST"],
                            "testing": ["Vitest", "Playwright"],
                        },
                        "rendering": {"mode": "SPA", "dynamic_interaction": "React Router"},
                    },
                    "agent_workflow": {
                        "review_scope": "full",
                        "testing_scope": "targeted",
                        "goal_verification": True,
                    },
                    "harness": {
                        "local_fast": ["npm test"],
                        "ci_required": ["npm test", "npm run lint"],
                        "coverage": {
                            "tool": "vitest",
                            "command": "npm run coverage",
                            "target": {"lines": 80, "branches": 70},
                            "reports": {
                                "console": "text",
                                "xml": "coverage.xml",
                                "html_dir": "coverage",
                            },
                        },
                    },
                },
            )
            result, payload = run_cli(
                "project_contract_lint.py",
                "--root",
                str(root),
            )
            self.assertEqual(result.returncode, 0, msg=result.stderr)
            self.assertTrue(payload["browser_ui"])

    def test_review_artifact_lint_validates_known_schema(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            write_yaml(
                root / "petitions" / "reviews" / "petition001-code-reviewer-strict.yaml",
                {
                    "petition_id": "petition001",
                    "agent": "code-reviewer-strict",
                    "verdict": "APPROVED",
                    "timestamp": "2026-05-18T09:00:00+00:00",
                    "quality_score": 92,
                    "keep_count": 2,
                    "discard_count": 0,
                    "escalate_count": 0,
                    "findings": [
                        {
                            "id": "PaymentService",
                            "decision": "KEEP",
                            "justification": "Directly maps to petition scope.",
                        }
                    ],
                },
            )
            result, payload = run_cli(
                "review_artifact_lint.py",
                "--root",
                str(root),
            )
            self.assertEqual(result.returncode, 0, msg=result.stderr)
            self.assertEqual(payload["status"], "PASS")

    def test_review_artifact_lint_reports_invalid_schema(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            write_yaml(
                root / "petitions" / "reviews" / "petition001-contract-drift-auditor.yaml",
                {
                    "scope": "payments",
                    "agent": "contract-drift-auditor",
                    "mode": "detect",
                    "verdict": "FAIL",
                    "layers_checked": ["api", "dto"],
                    "findings": [
                        {
                            "severity": "blocking",
                            "drift_class": "enum drift",
                            "source_layer": "api",
                            "target_layer": "dto",
                            "symbol": "PaymentStatus",
                            "description": "Mapper is missing CANCELLED.",
                        }
                    ],
                },
            )
            result, payload = run_cli(
                "review_artifact_lint.py",
                "--root",
                str(root),
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("canonical_source", " ".join(payload["errors"]))

    def test_review_artifact_lint_validates_bdd_coverage_schema(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            write_yaml(
                root / "petitions" / "reviews" / "petition001-bdd-test-coverage-auditor.yaml",
                {
                    "petition_id": "petition001",
                    "agent": "bdd-test-coverage-auditor",
                    "verdict": "APPROVED",
                    "timestamp": "2026-05-18T09:00:00+00:00",
                    "keep_count": 3,
                    "discard_count": 0,
                    "escalate_count": 0,
                    "findings": [
                        {
                            "id": "AC-1",
                            "decision": "KEEP",
                            "justification": "Mapped to acceptance criteria.",
                        }
                    ],
                    "gaps": [{"requirement": "AC-2", "severity": "major"}],
                    "overreach": [
                        {
                            "test": "feature: debug-only path",
                            "justification": "Not in petition scope.",
                        }
                    ],
                },
            )
            result, payload = run_cli(
                "review_artifact_lint.py",
                "--root",
                str(root),
            )
            self.assertEqual(result.returncode, 0, msg=result.stderr)
            self.assertEqual(payload["status"], "PASS")

    def test_review_artifact_lint_validates_hotspot_schema(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            write_yaml(
                root / "petitions" / "reviews" / "petition001-code-reviewer-strict.yaml",
                {
                    "petition_id": "petition001",
                    "agent": "code-reviewer-strict",
                    "verdict": "REJECTED",
                    "timestamp": "2026-05-18T09:00:00+00:00",
                    "quality_score": 71,
                    "keep_count": 1,
                    "discard_count": 1,
                    "escalate_count": 0,
                    "findings": [
                        {
                            "id": "DebtServiceClient",
                            "decision": "DISCARD",
                            "justification": "Introduced a blocking hotspot.",
                        }
                    ],
                    "hotspot_summary": {
                        "policy_version": "structural_hotspot_v1",
                        "baseline_ref": "HEAD~1",
                        "blocking_count": 1,
                        "warning_count": 0,
                        "context_count": 0,
                    },
                    "hotspots": [
                        {
                            "finding_id": "HS-1234567890ab",
                            "file": "src/debt_service_client.py",
                            "language": "python",
                            "severity": "blocking",
                            "verdict": "BLOCK",
                            "reason_codes": [
                                "HOTSPOT_PUBLIC_METHOD_COUNT",
                                "HOTSPOT_CONSTRUCTOR_PARAM_COUNT",
                            ],
                            "metrics": {
                                "file_loc": 220,
                                "max_complexity": 3,
                                "max_nesting": 1,
                                "public_methods": 30,
                                "constructor_params": 9,
                                "import_fanout": 1,
                                "churn_90d": 2,
                            },
                            "baseline_metrics": None,
                            "worsened_metrics": [],
                            "tb_required": True,
                            "confidence": "high",
                            "baseline_available": False,
                        }
                    ],
                },
            )
            result, payload = run_cli(
                "review_artifact_lint.py",
                "--root",
                str(root),
            )
            self.assertEqual(result.returncode, 0, msg=result.stderr)
            self.assertEqual(payload["status"], "PASS")

    def test_hotspot_guard_flags_new_large_file(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            self._init_git_repo(root)
            (root / "src").mkdir(parents=True)
            (root / "README.md").write_text("seed\n", encoding="utf-8")
            subprocess.run(["git", "add", "."], cwd=root, check=True)
            subprocess.run(["git", "commit", "-m", "seed"], cwd=root, check=True)

            lines = ["class DebtServiceClient:"]
            lines.append(
                "    def __init__(self, a, b, c, d, e, f, g, h, i):"
            )
            lines.append("        self.values = [a, b, c, d, e, f, g, h, i]")
            for index in range(30):
                lines.append(f"    def creditor_action_{index}(self):")
                lines.append(f"        return self.values[{index % 9}]")
            (root / "src" / "debt_service_client.py").write_text(
                "\n".join(lines) + "\n",
                encoding="utf-8",
            )

            result, payload = run_cli(
                "hotspot_guard.py",
                "--root",
                str(root),
                "--baseline-ref",
                "HEAD",
                "src/debt_service_client.py",
            )
            self.assertNotEqual(result.returncode, 0, msg=result.stderr)
            self.assertEqual(payload["status"], "FAIL")
            self.assertEqual(payload["hotspot_counts"]["blocking"], 1)
            hotspot = payload["hotspots"][0]
            self.assertEqual(hotspot["severity"], "blocking")
            self.assertTrue(hotspot["tb_required"])
            self.assertIn(
                "HOTSPOT_CONSTRUCTOR_PARAM_COUNT",
                hotspot["reason_codes"],
            )

    def test_hotspot_backlog_sync_creates_structural_hotspot_item(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            write_yaml(
                root / "petitions" / "program-status.yaml",
                {
                    "program": "Payments",
                    "last_updated": "2026-05-18",
                    "petitions": [
                        {"id": "petition001", "title": "Payments", "status": "implemented"}
                    ],
                    "technical_backlog": [],
                    "escalations": [],
                },
            )
            write_yaml(
                root / "petitions" / "reviews" / "petition001-code-reviewer-strict.yaml",
                {
                    "petition_id": "petition001",
                    "agent": "code-reviewer-strict",
                    "verdict": "REJECTED",
                    "timestamp": "2026-05-18T09:00:00+00:00",
                    "quality_score": 71,
                    "keep_count": 1,
                    "discard_count": 1,
                    "escalate_count": 0,
                    "findings": [
                        {
                            "id": "DebtServiceClient",
                            "decision": "DISCARD",
                            "justification": "Introduced a blocking hotspot.",
                        }
                    ],
                    "hotspot_summary": {
                        "policy_version": "structural_hotspot_v1",
                        "baseline_ref": "HEAD~1",
                        "blocking_count": 1,
                        "warning_count": 0,
                        "context_count": 0,
                    },
                    "hotspots": [
                        {
                            "finding_id": "HS-1234567890ab",
                            "file": "src/debt_service_client.py",
                            "language": "python",
                            "severity": "blocking",
                            "verdict": "BLOCK",
                            "reason_codes": [
                                "HOTSPOT_PUBLIC_METHOD_COUNT",
                                "HOTSPOT_CONSTRUCTOR_PARAM_COUNT",
                            ],
                            "metrics": {
                                "file_loc": 220,
                                "max_complexity": 3,
                                "max_nesting": 1,
                                "public_methods": 30,
                                "constructor_params": 9,
                                "import_fanout": 1,
                                "churn_90d": 2,
                            },
                            "baseline_metrics": None,
                            "worsened_metrics": [],
                            "tb_required": True,
                            "confidence": "high",
                            "baseline_available": False,
                        }
                    ],
                },
            )
            result, payload = run_cli(
                "hotspot_backlog_sync.py",
                "--root",
                str(root),
                "--petition-id",
                "petition001",
            )
            self.assertEqual(result.returncode, 0, msg=result.stderr)
            self.assertEqual(payload["status"], "PASS")
            updated = yaml.safe_load(
                (root / "petitions" / "program-status.yaml").read_text(encoding="utf-8")
            )
            backlog_item = updated["technical_backlog"][0]
            self.assertEqual(backlog_item["category"], "structural-hotspot")
            self.assertEqual(backlog_item["finding_id"], "HS-1234567890ab")
            self.assertEqual(backlog_item["triage_status"], "untriaged")
            self.assertEqual(backlog_item["petition"], "petition001")

    def test_telemetry_tool_lints_and_rolls_up_measured_totals(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            write_yaml(
                root / "petitions" / "telemetry" / "petition001-telemetry.yaml",
                {
                    "subject_type": "petition",
                    "subject_id": "petition001",
                    "title": "Payments",
                    "schema_version": "1.0",
                    "status": "active",
                    "measurement_window": {
                        "started_at": "2026-05-18T09:00:00+00:00",
                        "ended_at": "2026-05-18T09:10:00+00:00",
                    },
                    "writer": {"mode": "mixed", "notes": "external writer"},
                    "coverage": {
                        "status": "partial",
                        "last_reconciled_at": None,
                        "warnings": [],
                    },
                    "rollups": {
                        "total_runs": 2,
                        "measured_runs": 1,
                        "input_tokens": 100,
                        "output_tokens": 40,
                        "cached_input_tokens": 10,
                        "total_tokens": 140,
                        "estimated_cost_usd": 0.5,
                        "tool_calls": 2,
                        "retry_runs": 1,
                        "escalated_runs": 0,
                    },
                    "runs": [
                        {
                            "run_id": "run-1",
                            "phase": "6",
                            "phase_name": "Implementation",
                            "agent": "tdd-enforcer",
                            "agent_version": None,
                            "model": "gpt-5.4",
                            "model_version": "gpt-5.4",
                            "started_at": "2026-05-18T09:00:00+00:00",
                            "ended_at": "2026-05-18T09:03:00+00:00",
                            "input_tokens": 100,
                            "output_tokens": 40,
                            "cached_input_tokens": 10,
                            "total_tokens": 140,
                            "tool_calls": 2,
                            "estimated_cost_usd": 0.5,
                            "outcome": "retry",
                            "source": "harness_measured",
                            "measurement_uri": "provider://run-1",
                            "notes": "",
                        },
                        {
                            "run_id": "run-2",
                            "phase": "8",
                            "phase_name": "Review",
                            "agent": "code-reviewer-strict",
                            "agent_version": None,
                            "model": "gpt-5.4",
                            "model_version": "gpt-5.4",
                            "started_at": "2026-05-18T09:05:00+00:00",
                            "ended_at": "2026-05-18T09:10:00+00:00",
                            "input_tokens": 20,
                            "output_tokens": 10,
                            "cached_input_tokens": 0,
                            "total_tokens": 30,
                            "tool_calls": 1,
                            "estimated_cost_usd": 0.1,
                            "outcome": "success",
                            "source": "self_reported",
                            "measurement_uri": "",
                            "notes": "",
                        },
                    ],
                    "rework_events": [],
                },
            )
            lint_result, lint_payload = run_cli(
                "telemetry_tool.py",
                "lint",
                "--root",
                str(root),
            )
            self.assertEqual(lint_result.returncode, 0, msg=lint_result.stderr)
            self.assertEqual(lint_payload["status"], "PASS")

            rollup_result, rollup_payload = run_cli(
                "telemetry_tool.py",
                "rollup",
                "--root",
                str(root),
            )
            self.assertEqual(rollup_result.returncode, 0, msg=rollup_result.stderr)
            self.assertEqual(rollup_payload["telemetry_coverage"], "partial")
            self.assertEqual(rollup_payload["aggregate"]["input_tokens"], 100)
            self.assertEqual(rollup_payload["aggregate"]["measured_runs"], 1)

    def test_delivery_state_lint_reports_dangling_review_reference(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            write_yaml(
                root / "petitions" / "program-status.yaml",
                {
                    "program": "Payments",
                    "last_updated": "2026-05-18",
                    "petitions": [
                        {
                            "id": "petition001",
                            "title": "Payments",
                            "status": "planned",
                            "phase": 1,
                            "sprint": None,
                            "depends_on": [],
                            "notes": "",
                        }
                    ],
                    "technical_backlog": [],
                    "escalations": [],
                },
            )
            (root / "petitions" / "petition001.md").parent.mkdir(parents=True, exist_ok=True)
            (root / "petitions" / "petition001.md").write_text("# Petition\n", encoding="utf-8")
            write_yaml(
                root / "petitions" / "reviews" / "petition999-specs-reviewer.yaml",
                {
                    "petition_id": "petition999",
                    "agent": "specs-reviewer",
                    "verdict": "APPROVED",
                    "timestamp": "2026-05-18T09:00:00+00:00",
                    "keep_count": 1,
                    "discard_count": 0,
                    "escalate_count": 0,
                    "findings": [
                        {"id": "S1", "decision": "KEEP", "justification": "ok"}
                    ],
                },
            )
            result, payload = run_cli(
                "delivery_state_lint.py",
                "--root",
                str(root),
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("unknown petition `petition999`", " ".join(payload["errors"]))

    def test_validation_harness_check_requires_browser_ui_artifacts(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            write_yaml(
                root / ".factory" / "project.yaml",
                {
                    "project": {"name": "Portal"},
                    "stack": {
                        "frameworks": {
                            "backend": ["Express"],
                            "ui": ["React"],
                            "data": ["none"],
                            "integration": ["REST"],
                            "testing": ["Playwright"],
                        },
                        "rendering": {"mode": "SPA"},
                    },
                },
            )
            result, payload = run_cli(
                "validation_harness_check.py",
                "--root",
                str(root),
                "--petition-id",
                "petition001",
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertTrue(payload["browser_ui"])
            self.assertIn("validation contract", " ".join(payload["errors"]).lower())

    def test_retro_snapshot_compiles_current_state(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            write_yaml(
                root / "petitions" / "program-status.yaml",
                {
                    "program": "Payments",
                    "last_updated": "2026-05-18",
                    "petitions": [
                        {
                            "id": "petition001",
                            "title": "Payments",
                            "status": "blocked",
                            "phase": 6,
                            "notes": "Waiting for contract fix",
                        }
                    ],
                    "technical_backlog": [
                        {
                            "id": "TB-001",
                            "title": "Mapper cleanup",
                            "status": "pending",
                            "source": "review",
                            "petition": "petition001",
                        }
                    ],
                    "escalations": [
                        {
                            "id": "ESC-001",
                            "petition": "petition001",
                            "phase": 6,
                            "agent": "contract-drift-auditor",
                            "reason": "Blocking drift",
                            "status": "open",
                        }
                    ],
                },
            )
            (root / "petitions" / "petition001.md").parent.mkdir(parents=True, exist_ok=True)
            (root / "petitions" / "petition001.md").write_text("# Petition\n", encoding="utf-8")
            write_yaml(
                root / "petitions" / "reviews" / "petition001-specs-reviewer.yaml",
                {
                    "petition_id": "petition001",
                    "agent": "specs-reviewer",
                    "verdict": "REJECTED",
                    "timestamp": "2026-05-18T09:00:00+00:00",
                    "keep_count": 0,
                    "discard_count": 1,
                    "escalate_count": 0,
                    "findings": [
                        {"id": "S1", "decision": "DISCARD", "justification": "bad"}
                    ],
                },
            )
            write_yaml(
                root / "petitions" / "telemetry" / "petition001-telemetry.yaml",
                {
                    "subject_type": "petition",
                    "subject_id": "petition001",
                    "title": "Payments",
                    "schema_version": "1.0",
                    "status": "active",
                    "measurement_window": {"started_at": None, "ended_at": None},
                    "writer": {"mode": "provider_export", "notes": ""},
                    "coverage": {"status": "measured", "last_reconciled_at": None, "warnings": []},
                    "rollups": {
                        "total_runs": 1,
                        "measured_runs": 1,
                        "input_tokens": 50,
                        "output_tokens": 25,
                        "cached_input_tokens": 0,
                        "total_tokens": 75,
                        "estimated_cost_usd": 0.2,
                        "tool_calls": 1,
                        "retry_runs": 0,
                        "escalated_runs": 0,
                    },
                    "runs": [
                        {
                            "run_id": "run-1",
                            "phase": "4",
                            "phase_name": "Specs",
                            "agent": "specs-reviewer",
                            "agent_version": None,
                            "model": "gpt-5.4",
                            "model_version": "gpt-5.4",
                            "started_at": "2026-05-18T09:00:00+00:00",
                            "ended_at": "2026-05-18T09:01:00+00:00",
                            "input_tokens": 50,
                            "output_tokens": 25,
                            "cached_input_tokens": 0,
                            "total_tokens": 75,
                            "tool_calls": 1,
                            "estimated_cost_usd": 0.2,
                            "outcome": "success",
                            "source": "provider_export",
                            "measurement_uri": "provider://run-1",
                            "notes": "",
                        }
                    ],
                    "rework_events": [],
                },
            )
            result, payload = run_cli(
                "retro_snapshot.py",
                "--root",
                str(root),
            )
            self.assertEqual(result.returncode, 0, msg=result.stderr)
            self.assertEqual(payload["retro_basis"], "current snapshot only")
            self.assertEqual(payload["snapshot_metrics"]["open_escalations"], 1)
            self.assertEqual(payload["telemetry_coverage"], "measured")
            self.assertEqual(payload["review_failures"]["discard_total"], 1)

    def test_docs_impact_preflight_flags_manual_workspace_review(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            result, payload = run_cli(
                "docs_impact_preflight.py",
                "--root",
                temp_dir,
                "src/api/payment_controller.py",
            )
            self.assertEqual(result.returncode, 0, msg=result.stderr)
            self.assertTrue(payload["manual_review_required"])
            self.assertIsNone(payload["recommended_line"])
            self.assertTrue(payload["review_workspace_dsl"])

    def test_release_preflight_passes_for_clean_release_candidate(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            self._init_git_repo(root)
            write_yaml(
                root / "petitions" / "program-status.yaml",
                {
                    "program": "Payments",
                    "last_updated": "2026-05-18",
                    "petitions": [
                        {"id": "petition001", "title": "Payments", "status": "implemented"},
                        {"id": "petition002", "title": "Alerts", "status": "validated"},
                    ],
                    "technical_backlog": [
                        {
                            "id": "TB-001",
                            "title": "Refactor structural hotspot: debt_service_client.py",
                            "status": "pending",
                            "source": "src/debt_service_client.py structural-hotspot HS-1234567890ab",
                            "source_agent": "code-reviewer-strict",
                            "petition": "petition001",
                            "category": "structural-hotspot",
                            "remediation_target": "src/debt_service_client.py",
                            "evidence_artifact": "petitions/reviews/petition001-code-reviewer-strict.yaml",
                            "finding_id": "HS-1234567890ab",
                            "severity": "blocking",
                            "triage_status": "accepted",
                            "policy_version": "structural_hotspot_v1",
                            "notes": "HOTSPOT_PUBLIC_METHOD_COUNT",
                        }
                    ],
                    "escalations": [],
                },
            )
            write_yaml(
                root / ".factory" / "project.yaml",
                {
                    "project": {
                        "name": "Payments",
                        "language": "python",
                        "runtime": "3.12",
                        "source_directories": ["src"],
                        "test_directories": ["tests"],
                        "build": {
                            "compile": "python -m compileall src",
                            "test": "python -m unittest",
                            "lint": "python -m py_compile src/app.py",
                        },
                        "test_framework": "unittest",
                    }
                },
            )
            (root / "releases").mkdir()
            (root / "releases" / "release-2026-05-18-v1.2.3.md").write_text(
                "# Release notes\n", encoding="utf-8"
            )
            (root / "src").mkdir()
            (root / "tests").mkdir()
            subprocess.run(["git", "add", "."], cwd=root, check=True)
            subprocess.run(["git", "commit", "-m", "seed"], cwd=root, check=True)

            result, payload = run_cli(
                "release_preflight.py",
                "--root",
                str(root),
                "--version",
                "v1.2.3",
            )
            self.assertEqual(result.returncode, 0, msg=result.stderr)
            self.assertEqual(set(payload["selected_scope"]), {"petition001", "petition002"})

    def test_release_preflight_blocks_untriaged_blocking_hotspot_debt(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            self._init_git_repo(root)
            write_yaml(
                root / "petitions" / "program-status.yaml",
                {
                    "program": "Payments",
                    "last_updated": "2026-05-18",
                    "petitions": [
                        {"id": "petition001", "title": "Payments", "status": "implemented"},
                    ],
                    "technical_backlog": [
                        {
                            "id": "TB-001",
                            "title": "Refactor structural hotspot: debt_service_client.py",
                            "status": "pending",
                            "source": "src/debt_service_client.py structural-hotspot HS-1234567890ab",
                            "source_agent": "code-reviewer-strict",
                            "petition": "petition001",
                            "category": "structural-hotspot",
                            "remediation_target": "src/debt_service_client.py",
                            "evidence_artifact": "petitions/reviews/petition001-code-reviewer-strict.yaml",
                            "finding_id": "HS-1234567890ab",
                            "severity": "blocking",
                            "triage_status": "untriaged",
                            "policy_version": "structural_hotspot_v1",
                            "notes": "HOTSPOT_PUBLIC_METHOD_COUNT",
                        }
                    ],
                    "escalations": [],
                },
            )
            write_yaml(
                root / ".factory" / "project.yaml",
                {
                    "project": {
                        "name": "Payments",
                        "language": "python",
                        "runtime": "3.12",
                        "source_directories": ["src"],
                        "test_directories": ["tests"],
                        "build": {
                            "compile": "python -m compileall src",
                            "test": "python -m unittest",
                            "lint": "python -m py_compile src/app.py",
                        },
                        "test_framework": "unittest",
                    }
                },
            )
            (root / "releases").mkdir()
            (root / "releases" / "release-2026-05-18-v1.2.3.md").write_text(
                "# Release notes\n", encoding="utf-8"
            )
            (root / "src").mkdir()
            (root / "tests").mkdir()
            subprocess.run(["git", "add", "."], cwd=root, check=True)
            subprocess.run(["git", "commit", "-m", "seed"], cwd=root, check=True)

            result, payload = run_cli(
                "release_preflight.py",
                "--root",
                str(root),
                "--version",
                "v1.2.3",
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("untriaged", " ".join(payload["errors"]).lower())

    def test_release_preflight_blocks_dirty_tree_and_open_escalation(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            self._init_git_repo(root)
            write_yaml(
                root / "petitions" / "program-status.yaml",
                {
                    "program": "Payments",
                    "last_updated": "2026-05-18",
                    "petitions": [
                        {"id": "petition001", "title": "Payments", "status": "implemented"},
                    ],
                    "technical_backlog": [],
                    "escalations": [
                        {
                            "id": "ESC-001",
                            "petition": "petition001",
                            "phase": 10,
                            "agent": "release-manager",
                            "reason": "Smoke tests failed",
                            "status": "open",
                        }
                    ],
                },
            )
            write_yaml(
                root / ".factory" / "project.yaml",
                {
                    "project": {
                        "name": "Payments",
                        "language": "python",
                        "runtime": "3.12",
                        "source_directories": ["src"],
                        "test_directories": ["tests"],
                        "build": {
                            "compile": "python -m compileall src",
                            "test": "python -m unittest",
                            "lint": "python -m py_compile src/app.py",
                        },
                        "test_framework": "unittest",
                    }
                },
            )
            (root / "releases").mkdir()
            (root / "releases" / "release-2026-05-18-v1.2.3.md").write_text(
                "# Release notes\n", encoding="utf-8"
            )
            (root / "src").mkdir()
            (root / "tests").mkdir()
            subprocess.run(["git", "add", "."], cwd=root, check=True)
            subprocess.run(["git", "commit", "-m", "seed"], cwd=root, check=True)
            (root / "README.md").write_text("dirty\n", encoding="utf-8")

            result, payload = run_cli(
                "release_preflight.py",
                "--root",
                str(root),
                "--version",
                "v1.2.3",
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("Git working tree is not clean.", payload["errors"])
            self.assertIn("Open escalation blocks release", " ".join(payload["errors"]))

    def _init_git_repo(self, root: Path) -> None:
        subprocess.run(["git", "init", "-q"], cwd=root, check=True)
        subprocess.run(["git", "config", "user.email", "copilot@example.com"], cwd=root, check=True)
        subprocess.run(["git", "config", "user.name", "Copilot"], cwd=root, check=True)


if __name__ == "__main__":
    unittest.main()
