---
name: rfp-claim-evidence-auditor
description: "Use when you need to verify proposal claims against source evidence and block submission-critical assertions that are unsupported, contradictory, or still provisional."
workflow_role: gate
workflow_binding: contract_only
primary_outputs:
  - audited claims register
  - evidence audit artifact
default_next:
  success: rfp-submission-packager
  partial_success: internal review boundary
  blocked: user escalation or source repair
  needs_more_evidence: proof gathering
  fail: rerun after artifact repair
---

# Purpose

Turn "sounds credible" into "is evidenced." This node audits proposal claims against real source material and blocks submission-critical assertions that are unsupported or contradictory. It does not draft new proof.

## Workflow role

- Role: `gate`
- Binding: `contract_only`
- Goal gate: yes, for claim credibility and submission-critical proof readiness
- Human approval node: yes, when a business owner must approve a claim without existing artifact proof
- Typical predecessors: `rfp-response-drafter`, `rfp-red-team-reviewer`
- Typical successors: `rfp-submission-packager`, proof gathering, or escalation

## Inputs

### Required

- latest response draft
- `rfp/<RFP-ID>/evidence/claims-register.yaml`

### Optional

- approved references and case studies
- certification files
- team CVs and bios
- pricing inputs
- review artifact

## Preconditions

1. Claims register exists and points to draft locations.
2. Submission-critical claims must be treated as proof items, not editorial flourishes.
3. Missing proof must be surfaced explicitly.

## Procedure

1. Verify required inputs exist and read them in full.
2. For each claim, classify evidence status as:
   - `verified`
   - `partially_verified`
   - `unverified`
   - `contradicted`
   - `pending_human_approval`
3. Treat these as submission-critical unless explicitly downgraded:
   - named references
   - CV and staffing claims
   - certifications and accreditations
   - quantitative metrics
   - delivery commitments
   - pricing or commercial assertions
   - legal or compliance claims
4. Update the claims register with audit status and source references checked.
5. Write an evidence audit artifact with blocking findings and residual warnings.

## Output Contract

### Artifacts

- `rfp/<RFP-ID>/evidence/claims-register-audited.yaml`
- `rfp/<RFP-ID>/evidence/evidence-audit.yaml`

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` - submission-critical claims are verified or explicitly accepted with non-blocking warnings
- `partial_success` - some non-critical claims remain provisional, but internal review can continue
- `blocked` - one or more submission-critical claims are unsupported, contradicted, or awaiting approval
- `needs_more_evidence` - proof may exist but has not been provided or inspected yet
- `fail` - audit could not complete because inputs were unusable

## Done Criteria

1. Every claims-register item has an audit status.
2. Submission-critical claims are explicit.
3. Blocking evidence gaps are surfaced clearly.
4. Audited claims register and evidence audit artifact were written.

## Evidence Requirements

- Claim: a proposal assertion is verified -> proof: source artifact was inspected in this run
- Claim: a claim is contradicted -> proof: inspected source conflicts with draft language in this run
- Claim: a claim is pending approval -> proof: no artifact proof exists and a named human approval dependency was recorded in this run

## Failure Routing

- missing claims register or source proof path -> `blocked`
- proof expected but not yet supplied -> `needs_more_evidence`
- contradicted or unsupported submission-critical claim -> `blocked`
- unreadable or unusable artifacts -> `fail`

## Escalation Rules

1. Escalate when a named reference, certification, staffing claim, or legal statement is unsupported.
2. Escalate when quantitative claims cannot be traced to a real source.
3. Escalate when human approval is required for a claim that would materially affect evaluator trust.

## Never Do

- never treat reputation or confidence as proof
- never let a contradicted claim survive to packaging
- never downgrade a submission-critical claim to cosmetic just to keep moving
- never claim verification without inspecting the source artifact in this run

