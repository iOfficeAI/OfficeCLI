---
name: rfp-intake-normalizer
description: "Use when normalize raw tender documents into a structured intake package with source citations, requirement extraction, and clarification logging."
workflow_role: worker
workflow_binding: contract_only
primary_outputs:
  - normalized tender source
  - intake summary
  - requirements register
  - clarification log
default_next:
  success: rfp-compliance-mapper
  blocked: user escalation or source repair
  needs_more_evidence: missing annexes or unreadable sections
  fail: rerun after source conversion repair
---

# Purpose

Turn raw tender material into a reliable intake package. This node reads source documents, converts them into a usable text form, extracts requirement-bearing material, and records open ambiguities. It does not draft a response.

## Workflow role

- Role: `worker`
- Binding: `contract_only`
- Goal gate: no
- Human approval node: no
- Typical predecessors: `rfp-conductor`
- Typical successors: `rfp-compliance-mapper`

## Inputs

### Required

- one or more source tender documents

### Optional

- submission instructions
- Q&A addenda
- annexes, forms, and pricing sheets
- previous clarification responses

## Preconditions

1. Source files exist and are readable enough to attempt conversion.
2. Every addendum provided must be treated as part of the tender source.
3. Requirement extraction must include source references.

## Procedure

1. Verify required input files exist and are non-empty.
2. Convert source documents to markdown or plain text using the safest available conversion path.
3. Read the converted content in full, not just the first pages or a summary.
4. Extract and structure:
   - issuer and procurement context
   - requested scope and deliverables
   - evaluation criteria and weighting when stated
   - mandatory forms, annexes, and format rules
   - pricing, commercial, legal, and timeline constraints
   - deadlines, contacts, and clarification rules
5. Build a requirements register with one ID per requirement-bearing item and include source references.
6. Record any ambiguity, missing annex, contradictory instruction, or unreadable section in a clarification log.

## Output Contract

### Artifacts

- `rfp/<RFP-ID>/intake/source.md`
- `rfp/<RFP-ID>/intake/rfp-intake.md`
- `rfp/<RFP-ID>/intake/requirements-register.yaml`
- `rfp/<RFP-ID>/intake/clarifications.md`

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` - source material was normalized and requirement-bearing content was extracted
- `blocked` - a required source file, annex, or readable section is missing
- `needs_more_evidence` - source exists but key content remains ambiguous or incomplete
- `fail` - conversion or extraction failed in a way that prevents usable output

## Done Criteria

1. A normalized source file exists.
2. The intake summary covers scope, evaluation, constraints, and submission rules.
3. The requirements register includes source references.
4. Clarifications and missing pieces are explicit.

## Evidence Requirements

- Claim: a requirement exists -> proof: source citation in the converted tender text
- Claim: an evaluation rule exists -> proof: cited text from the tender source
- Claim: an ambiguity exists -> proof: contradictory, missing, or unreadable tender material identified in this run

## Failure Routing

- missing source file -> `blocked`
- missing annex referenced by the tender -> `needs_more_evidence`
- unreadable conversion with no fallback path -> `fail`
- contradictory instruction across tender documents -> `needs_more_evidence`

## Escalation Rules

1. Escalate when a referenced annex or form is missing.
2. Escalate when submission instructions conflict materially across documents.
3. Escalate when a timeline, pricing rule, or mandatory deliverable cannot be read with confidence.

## Never Do

- never skip addenda or annexes because the main tender document looked sufficient
- never invent requirement text
- never collapse multiple source instructions into one summary line without preserving distinctions
- never bury ambiguity instead of logging it

