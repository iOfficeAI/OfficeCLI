---
name: cv-output-renderer
description: "Use when you need to render audited CV payloads into customer-specific DOCX templates using placeholder and loop markers with deterministic template selection."
workflow_role: worker
workflow_binding: contract_only
primary_outputs:
  - rendered customer DOCX
  - render manifest
default_next:
  success: cv-rfp-conductor final close or package handoff
  partial_success: human approval boundary
  blocked: user escalation or template repair
  needs_more_evidence: missing render fields
  fail: rerun after source or template repair
---

# Purpose

Produce a customer-ready Word document from CV pipeline artifacts and template placeholders. This node selects the correct DOCX template from `templates/`, fills scalar and loop fields, and emits a render manifest with field coverage and unresolved markers.

## Workflow role

- Role: `worker`
- Binding: `contract_only`
- Goal gate: no
- Human approval node: yes, when unresolved markers remain in score-bearing sections
- Typical predecessors: `cv-claim-evidence-auditor`, `cv-delta-updater`, `cv-rfp-conductor`
- Typical successors: packaging handoff, `cv-rfp-conductor`

## Inputs

### Required

- template directory: `cv-output-renderer/templates/`
- `rfp/active/<RFP-ID>/deliverables/render-payload.yaml`
- `rfp/active/<RFP-ID>/request/style-pack-resolved.yaml`

### Optional

- explicit template file override
- section-level fallback policy
- mapping file: `cv-output-renderer/template-mapping.yaml`

## Template Naming Convention

Templates are discovered from `templates/` and should use:

- `[Customer Name]_<name to keep>-{{candidate_name}}.docx`

Example:

- `[UFST]_Bilag 8b - Organisering - {{candidate_name}}.docx`

Compatibility note:

- legacy typo token `{candiate_name}` may be accepted for discovery compatibility but must be surfaced as a warning in the render manifest

## Placeholder Contract

### Scalar placeholders

- `{{candidate_name}}`
- `{{title}}`
- `{{summary}}`
- any additional agreed field keys

### Loop placeholders

- start: `{{#references}}`
- end: `{{/references}}`
- inner fields: `{{project_name}}`, `{{role}}`, `{{period}}`, `{{description}}`

Nested loops are allowed only when explicitly present in template and payload.

## Preconditions

1. A matching template exists for the requested customer.
2. Render payload keys are normalized, deterministic, and already audited upstream.
3. `template-mapping.yaml` is structural only: token-to-payload bindings, loop bindings, and fallback rules.
4. Word placeholders are plain text markers, not split across runs in ways that break parser replacement.

## Procedure

1. Resolve template:
   - if explicit override exists, use it
   - otherwise use the resolved customer profile from `style-pack-resolved.yaml` plus structural bindings from `template-mapping.yaml`
   - if multiple templates match, require disambiguation rule or record the selected binding explicitly
2. Load `render-payload.yaml` as the only content source for token materialization.
3. Load structural bindings from `template-mapping.yaml`:
   - token bindings map payload keys to scalar placeholders
   - loop bindings map collection keys to block markers
   - fallback rules control optional blanks or block removal
4. Replace scalar markers from payload values only.
5. Expand loop blocks from payload collections only.
6. Remove empty optional blocks when policy allows; otherwise mark unresolved.
7. Validate output:
   - no unmatched start/end loop markers
   - unresolved marker inventory is explicit
   - required payload keys were present
   - payload checksum and template selection were recorded
8. Write rendered DOCX and `render-manifest.yaml`.

## Output Contract

### Artifacts

- `rfp/active/<RFP-ID>/deliverables/<customer>-cv-<candidate>.docx`
- `rfp/active/<RFP-ID>/deliverables/render-manifest.yaml`

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

### Manifest Fields

- `template_selected`
- `payload_path`
- `payload_checksum`
- `template_discovery_matches`
- `placeholder_counts`
- `loop_blocks_processed`
- `unresolved_markers`
- `fallbacks_applied`
- `compatibility_warnings`

## Status Vocabulary

- `success` - template selected and rendered with no critical unresolved markers
- `partial_success` - rendered output produced with non-critical unresolved markers or fallback substitutions
- `blocked` - no usable template found or template is malformed
- `needs_more_evidence` - required render fields are missing from upstream payload
- `fail` - rendering failed due to parser or document corruption issues

## Done Criteria

1. Correct customer template selected deterministically.
2. Rendered DOCX produced in active deliverables path.
3. Render content came only from audited payload values.
4. Loop sections expanded correctly.
5. Unresolved markers and compatibility quirks are documented.
6. No silent drop of missing required fields.

## Evidence Requirements

- Claim: correct customer template was selected -> proof: selected template path and discovery basis were recorded in this run
- Claim: rendered content came only from audited payload values -> proof: payload path and checksum were recorded in this run
- Claim: unresolved markers were handled safely -> proof: render manifest recorded unresolved markers or confirmed none remained in this run

## Failure Routing

- no template match for customer -> `blocked`
- multiple ambiguous matches without rule -> `blocked`
- render payload missing or malformed -> `needs_more_evidence`
- required payload field missing -> `needs_more_evidence`
- malformed loop markers -> `fail`

## Escalation Rules

1. Escalate when template naming no longer follows agreed convention.
2. Escalate when unresolved markers appear in mandatory or scored sections.
3. Escalate when compatibility fallback (`{candiate_name}`) is required repeatedly.

## Never Do

- never rewrite template narrative content beyond marker expansion
- never fabricate payload values for missing required fields
- never suppress unresolved marker warnings
- never select a template from a different customer prefix
- never derive new content directly from fit matrices, draft markdown, or candidate CV inside the renderer
