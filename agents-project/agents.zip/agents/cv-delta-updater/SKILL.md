---
name: cv-delta-updater
description: "Use when apply small, bounded CV updates (for example new references or minor factual corrections) with minimal diffs, no narrative rewrites, explicit evidence anchors, and optional render-payload refresh."
workflow_role: worker
workflow_binding: contract_only
primary_outputs:
  - updated candidate CV
  - delta log
  - optional candidate reference index update
  - optional render payload refresh
default_next:
  success: cv-fit-mapper, cv-response-drafter, or cv-output-renderer
  partial_success: human approval boundary
  blocked: user escalation or missing source repair
  needs_more_evidence: candidate clarification or proof collection
  fail: rerun after source repair
---

# Purpose

Apply tiny CV deltas safely when a full regeneration is unnecessary. This node is for narrow updates such as adding a new reference, fixing dates, correcting role wording, or inserting a newly evidenced certification. It must preserve structure and tone, avoid broad edits, and leave a traceable change log.

## Workflow role

- Role: `worker`
- Binding: `contract_only`
- Goal gate: no
- Human approval node: yes, when a requested delta changes scoring-critical claims or introduces uncertain facts
- Typical predecessors: `cv-intake-normalizer`, `cv-rfp-conductor`, direct user request
- Typical successors: `cv-fit-mapper`, `cv-response-drafter`, `cv-output-renderer`

## Inputs

### Required

- `rfp/active/<RFP-ID>/request/candidate-cv.md`
- delta request describing exactly what to change

### Optional

- `rfp/active/<RFP-ID>/extraction/candidate-reference-index.yaml`
- `rfp/active/<RFP-ID>/request/style-pack-resolved.yaml`
- source proof paths for new facts (project notes, approved reference snippets, certification proof)
- target section hints
- render requested flag

## Preconditions

1. The requested scope is narrow and explicitly bounded.
2. Updates are evidence-backed or explicitly marked as requiring confirmation.
3. No full rewrite, reframing pass, or style harmonization is requested.

## Scope Decision

Run this node only when all conditions hold:

1. Requested edits touch a limited part of the CV (typically one or two sections).
2. The user asks for small maintenance updates (for example add/update references).
3. No broad narrative repositioning is needed.

Escalate to `cv-rfp-conductor` when any condition fails.

## Procedure

1. Parse the delta request into atomic changes:
   - `add_reference`
   - `update_reference`
   - `fix_fact`
   - `remove_or_deprecate_item`
2. Validate each requested change against provided proof or confirmation status.
3. Apply edits only to targeted sections of `candidate-cv.md`:
   - keep surrounding structure unchanged
   - keep existing voice and formatting conventions
   - avoid non-requested copy edits
4. If reference entries change, update `candidate-reference-index.yaml` when present.
5. Write `cv-delta-log.yaml` with one entry per atomic change:
   - change id
   - change type
   - location
    - before summary
    - after summary
    - source proof path or confirmation flag
    - risk class (`safe`, `needs_confirmation`, `blocked`)
6. If a requested change lacks safe evidence, do not fabricate. Mark it as `needs_confirmation` or `blocked`.
7. If rendering was requested and a style pack is resolved, refresh `render-payload.yaml` for the touched sections and record unresolved required fields explicitly.
8. Keep the result patch-like: minimal, reviewable, and auditable.

## Output Contract

### Artifacts

- `rfp/active/<RFP-ID>/request/candidate-cv.md` (updated in place)
- `rfp/active/<RFP-ID>/request/cv-delta-log.yaml`
- optional `rfp/active/<RFP-ID>/extraction/candidate-reference-index.yaml` (updated when present and impacted)
- optional `rfp/active/<RFP-ID>/deliverables/render-payload.yaml`

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` - all requested safe deltas were applied with traceable logging
- `partial_success` - some deltas applied, at least one held for confirmation
- `blocked` - mandatory source artifact or section target is missing
- `needs_more_evidence` - one or more requested deltas cannot be safely evidenced yet
- `fail` - update operation failed due to unusable input artifacts

## Done Criteria

1. Candidate CV reflects only the requested bounded updates.
2. No unrelated sections were rewritten.
3. Delta log records each change with proof or confirmation status.
4. Reference index is synchronized when reference changes occurred and index existed.
5. Unsupported deltas are explicit and not silently dropped.
6. Render payload is refreshed when rendering was requested and sufficient style assets exist.

## Evidence Requirements

- Claim: a delta was applied -> proof: matching entry in `cv-delta-log.yaml` with location and before/after summary
- Claim: a new fact is safe -> proof: source path or explicit confirmation flag captured in this run
- Claim: no broad rewrite occurred -> proof: edits are confined to targeted sections in this run
- Claim: rendered output can be refreshed safely -> proof: render payload was updated only for touched sections in this run

## Failure Routing

- missing candidate CV -> `blocked`
- ambiguous or contradictory delta request -> `needs_more_evidence`
- unsupported fact requested as hard claim -> `partial_success` or `needs_more_evidence`
- malformed upstream artifacts -> `fail`

## Escalation Rules

1. Escalate when requested "small updates" imply broader candidate repositioning.
2. Escalate when requested changes materially alter qualification claims without proof.
3. Escalate when section targeting is unclear and would require speculative edits.

## Never Do

- never regenerate the whole CV for minor updates
- never rewrite unrelated sections for style
- never invent references, dates, metrics, tools, or certifications
- never hide blocked or unverified deltas

