# Failing Assertion

End every `test()` body with single throw that identifies scenario:

```typescript
throw new Error('Not implemented: <petition-ID> — "<Scenario title>"');
```

Do NOT add any Playwright actions before throw in RED phase. throw
is entire body (after step comments). This keeps test fails on the
first line of real execution, with message that points directly to work item.
