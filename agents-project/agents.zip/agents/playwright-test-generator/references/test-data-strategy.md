# Test Data Strategy

Before writing any test, establish data strategy for feature:

1. **Inspect `Given` steps** across every scenario. Extract all entities, states, +
   preconditions that require data (e.g. "registered user", "invoice in state
   DRAFT", "product catalogue with 3 items").

2. **Check for existing fixtures** at `tests/fixtures/<feature-slug>/`. Use them if
   present. Create them if absent.

3. **Choose data setup mechanism** — in priority order:
   - **API seeding** via `request.post/put` — preferred; exercises same contracts
     as app + works against any env.
   - **Fixture files** (JSON in `tests/fixtures/`) — for static reference data that
     does not vary between runs.
   - **Direct DB seed** — only if `project.yaml` explicitly defines `seed_command`;
     last resort as it couples tests to DB schema.

4. **Auth state**: If scenarios require authenticated user, produce a
   `tests/fixtures/auth/<role>.json` storage-state file (populated via Playwright's
   `browserContext.storageState()`) + apply it with `test.use({ storageState })`.
   Never hardcode credentials in test files — read from `process.env.TEST_*`.

5. **Isolation**: Every test must be fully isolated. Use `test.beforeEach` to create
   data + `test.afterEach` to delete it via API or shared cleanup helper.
   Shared mutable state between tests is forbidden.
