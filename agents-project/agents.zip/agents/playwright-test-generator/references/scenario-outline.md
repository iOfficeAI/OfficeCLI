# Scenario Outline

For `Scenario Outline:` with `Examples:` table, generate one `test()` per
example row. Interpolate placeholder values into test title:

```typescript
test('User logs in with role: admin', async ({ page }) => { ... });
test('User logs in with role: viewer', async ({ page }) => { ... });
```
