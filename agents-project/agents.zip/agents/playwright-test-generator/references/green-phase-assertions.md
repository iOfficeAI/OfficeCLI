# GREEN Phase Assertions

Every scenario must assert on **observable outcomes**, not absence of errors:

- UI state changes: `expect(locator).toHaveText(...)`, `.toBeVisible()`, `.toBeHidden()`
- Navigation: `expect(page).toHaveURL(...)`
- API side effects: follow UI action with `request.get(...)` to confirm server state
- Error paths: assert error message text, not that element exists
