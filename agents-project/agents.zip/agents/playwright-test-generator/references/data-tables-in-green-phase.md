# Data Tables in GREEN Phase

Convert Gherkin data tables into typed variables + use them in both setup + assertions:

```typescript
// Given the following products exist:
//   | name       | price |
//   | Widget A   | 9.99  |
//   | Widget B   | 14.99 |
const products = [
  { name: 'Widget A', price: 9.99 },
  { name: 'Widget B', price: 14.99 },
];
for (const p of products) {
  await createProduct(request, p);
}
```
