# Scenario → Test Block

Map each `Scenario:` + `Scenario Outline:` to individual `test()` block.
test title must match scenario title exactly.
