# Data Tables

**RED phase**: Represent Gherkin data tables as inline comments showing table structure.
Do not attempt to parse them into variables in RED phase.

**GREEN phase**: Convert data tables into typed objects or arrays + use them to
drive data setup + assertions (see GREEN PHASE RULES below).

---

# GREEN PHASE RULES

Apply these rules only when in **GREEN phase**. RED phase generation rules above apply
only to tests that have not yet been implemented.
