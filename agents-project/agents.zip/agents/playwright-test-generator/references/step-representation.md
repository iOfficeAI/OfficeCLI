# Step Representation

All Gherkin steps (Given / When / Then / And / But) become sequential line
comments inside test body, in order. Preserve full step text.
