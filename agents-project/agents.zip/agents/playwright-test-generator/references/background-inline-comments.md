# Background → Inline Comments

Do **not** use `test.beforeEach()` for background steps in initial RED phase.
Inline background steps as comments at top of every test that inherits them,
prefixed with `// [Background]`. This keeps each test fully self-contained +
makes failure messages unambiguous.
