# GREEN Phase File Structure

```
<project_root>/
├── <test_dir>/
│   ├── <feature-slug>.spec.ts          ← updated in-place from RED
│   └── helpers/
│       ├── test-data.ts                ← create/delete helpers per entity type
│       └── auth.setup.ts               ← produces auth storage-state fixtures
└── tests/fixtures/
    ├── auth/
    │   └── <role>.json                 ← Playwright storageState
    └── <feature-slug>/
        └── <entity>.json               ← static reference data
```
