# Feature → Describe Block

Map each Gherkin `Feature:` to `test.describe()` block. Add traceability
header comment above it.
