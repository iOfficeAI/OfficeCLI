# GREEN Phase Test Structure Template

```typescript
import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { createInvoice, deleteInvoice } from '../helpers/test-data';

// Apply stored auth if all scenarios in this feature require a logged-in user
test.use({ storageState: 'tests/fixtures/auth/standard-user.json' });

test.describe('<Feature title>', () => {

  // Declare scenario-scoped data handles
  let entityId: string;

  test.beforeEach(async ({ request }) => {
    // Seed: create minimum data for the scenario
    const entity = await createInvoice(request, {
      status: 'DRAFT',
      amount: 1000,
    });
    entityId = entity.id;
  });

  test.afterEach(async ({ request }) => {
    // Teardown: always clean up, even if the test failed
    await deleteInvoice(request, entityId);
  });

  test('<Scenario title>', async ({ page }) => {
    // Ref: petition-<ID>.feature
    // Data: entityId seeded in beforeEach

    await page.goto(`/invoices/${entityId}`);
    await expect(page.getByTestId('invoice-status')).toHaveText('DRAFT');

    await page.getByRole('button', { name: 'Submit' }).click();
    await expect(page.getByTestId('invoice-status')).toHaveText('SUBMITTED');

    // Accessibility: assert no WCAG violations after interaction
    const a11y = await new AxeBuilder({ page }).analyze();
    expect(a11y.violations).toEqual([]);
  });

});
```
