# Key Findings

- FACT: <constraint, business rule, or technical gotcha>
- DECISION: <decision made with rationale>
- DEVIATION: <anti-pattern to prevent in future>
- LEARNED: <anything else worth remembering>
