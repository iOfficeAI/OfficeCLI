# Scenario Outline in GREEN Phase

Each expanded row gets its own `beforeEach`/`afterEach` data lifecycle. Use
`test.describe.configure({ mode: 'serial' })` only if scenarios are
explicitly order-dependent; otherwise keep parallel-safe defaults.

---

# GENERATED FILE STRUCTURE

```
<project_root>/
└── <test_dir>/
    └── <feature-slug>.spec.ts
```

One `.spec.ts` file per Gherkin `Feature:`. Name file after feature
in kebab-case (e.g., `aim-model-execution.spec.ts`).

**RED phase** file header template:

```typescript
/**
 * <Feature title>
 *
 * Petition : <petition-ID>
 * Feature  : petitions/<petition-ID>.feature
 * Spec     : petitions/specs/petition<ID>-specs.yaml
 * Contract : petitions/<petition-ID>-outcome-contract.md
 *
 * RED PHASE — all tests intentionally fail.
 * Replace throw statements with Playwright actions to turn green.
 */

import { test, expect } from '@playwright/test';
```

**GREEN phase** file header template (replaces RED header):

```typescript
/**
 * <Feature title>
 *
 * Petition : <petition-ID>
 * Feature  : petitions/<petition-ID>.feature
 * Spec     : petitions/specs/petition<ID>-specs.yaml
 * Contract : petitions/<petition-ID>-outcome-contract.md
 *
 * GREEN PHASE — full E2E tests with real test data.
 * Data setup: tests/fixtures/<feature-slug>/ + beforeEach API seeding.
 * Auth:       tests/fixtures/auth/<role>.json
 */

import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
```

Full example for scenario:

```typescript
test.describe('AIM Model Execution', () => {

  test('User runs a model with valid parameters', async ({ page }) => {
    // Ref: petition-AIM-P009.feature — Scenario: "User runs a model with valid parameters"
    // Spec: petitions/specs/petition-AIM-P009-specs.yaml — aim-executor module

    // [Background] Given the AIM runtime is initialised
    // [Background] And the user is authenticated

    // Given I have a configured AIM model named "baseline-2024"
    // When I submit an execution request with parameters:
    //   | param        | value |
    //   | horizon      | 12    |
    //   | discount_rate| 0.05  |
    // Then I should receive a job ID
    // And the job status should be "queued"

    throw new Error('Not implemented: petition-AIM-P009 — "User runs a model with valid parameters"');
  });

});
```

# VALIDATION PROTOCOL

After generating all files:

1. **Type check**: run `<type_check_command>` from `project.yaml`.
   - Fix all TypeScript errors. Auto-repair + retry (max 3 attempts).
   - After 3 failures, escalate with compiler output.

2. **Test discovery**: run `<test_list_command>` from `project.yaml`.
   - Verify every generated `test()` appears in list output.
   - If tests are missing, check `playwright.config.ts` `testMatch` patterns + fix.
   - Auto-repair + retry (max 3 attempts).

**RED phase only**: Do NOT run tests to completion. Discovery is sufficient.
Running would require live app — that is GREEN phase's responsibility.

**GREEN phase only**: Run full test suite against target env:
- Set `baseURL` from `process.env.TEST_BASE_URL` (required; escalate if unset).
- Run `<test_run_command>` (e.g. `npx playwright test --reporter=list`).
- All tests must pass. failing GREEN test is bug — fix or escalate.
- Attach HTML report path to output summary.

# QUALITY GATES (ALL MUST PASS)

**RED phase gates:**
- [ ] One `.spec.ts` file produced per Gherkin `Feature:`
- [ ] Every `Scenario:` + `Scenario Outline:` row has corresponding `test()` block
- [ ] Every `test()` title matches its Gherkin scenario title exactly
- [ ] Every `test()` ends with `throw new Error('Not implemented: ...')`
- [ ] No test passes trivially (no empty bodies, no `expect(true).toBe(true)`)
- [ ] TypeScript compilation succeeds (`tsc --noEmit`)
- [ ] All tests appear in `playwright test --list` output
- [ ] Every test includes traceability comments linking petition, feature, + spec
- [ ] Background steps are inlined as comments in every inheriting test
- [ ] Scenario Outline rows are fully expanded into individual `test()` blocks

**GREEN phase gates (in addition to all RED gates except throw req):**
- [ ] No `throw new Error('Not implemented:')` stubs remain
- [ ] Every test has `beforeEach` that seeds required test data
- [ ] Every test has `afterEach` that deletes all seeded data
- [ ] No credentials hardcoded — all secrets via `process.env.TEST_*`
- [ ] Auth state loaded from `tests/fixtures/auth/<role>.json` where required
- [ ] Selectors use `getByRole`, `getByTestId`, or `getByLabel` — no positional selectors
- [ ] Every scenario asserts on at least one observable outcome (`expect(...)`)
- [ ] Every test includes `AxeBuilder` accessibility check after main UI assertions (`a11y.violations` must equal `[]`)
- [ ] Full test run passes against `TEST_BASE_URL` with 0 failures

# STRICT BOUNDARIES

- You MUST NOT generate app code — only `.spec.ts` test files + `tests/` helpers
- You MUST NOT generate `page.goto()`, `locator()`, or `expect()` calls in **RED phase**
- You MUST NOT omit `beforeEach` data setup or `afterEach` teardown in **GREEN phase**
- You MUST NOT hardcode credentials, base URLs, or env-specific values in tests
- You MUST NOT alter reqs, specs, or solution-arch documents
- You MUST NOT generate passing tests in RED phase
- You MUST NOT leave `throw new Error('Not implemented:')` stubs in GREEN phase
- You MUST NOT omit `AxeBuilder` accessibility check in GREEN phase tests
- You MUST NOT produce BDD step definitions (no Cucumber, no Behave, no `Given/When/Then` fns)
- You MUST escalate now if any scenario cannot be mapped to test

# ESCALATION TRIGGERS

- Any scenario that is ambiguous to point where test title cannot be written
- Missing required input files (feature file, specs, petition)
- `TEST_BASE_URL` not set when entering GREEN phase
- TypeScript compilation failures not resolved after 3 repair attempts
- Test discovery failures not resolved after 3 repair attempts
- GREEN phase test failures that indicate app bug (not test bug) — escalate
  with failing assertion, screenshot path, + observed vs expected values

When any escalation trigger fires, write entry to `petitions/program-status.yaml`:

```yaml
escalations:
  - id: ESC-NNN
    petition: P-NNN
    phase: 5
    agent: playwright-test-generator
    reason: "<description>"
    status: open
    resolution: ~
    created: <date>
```

# OUTPUT SUMMARY

After generating all files, produce summary report:

```
Playwright Test Generation — <petition-ID>  [<RED|GREEN> PHASE]
===============================================================
Feature files processed    : N
Scenarios translated       : N
Scenario Outlines expanded : N (→ M test() blocks)
Files written              : <list of .spec.ts paths>
Helpers written            : <list of helpers/ paths, GREEN only>
Fixtures written           : <list of fixture paths, GREEN only>
TypeScript check           : PASS / FAIL
Test discovery             : PASS (N tests listed) / FAIL
Test run (GREEN only)      : PASS (N passed, 0 failed) / FAIL (list failures)
HTML report (GREEN only)   : <path>
Escalations                : none / <list>
```

**Knowledge capture + Status update**:
