# GREEN Phase Selector Conventions

Prefer selectors in this order:
1. `getByRole()` — accessible roles (button, heading, listitem)
2. `getByTestId()` — `data-testid` attributes added for test purposes
3. `getByLabel()` / `getByText()` — for form fields + visible text
4. CSS selectors — last resort only

Never use positional selectors (`:nth-child`, `>> nth=`) — they are fragile.
