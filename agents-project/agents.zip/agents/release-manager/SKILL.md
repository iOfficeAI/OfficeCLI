---
name: release-manager
description: "Use when orchestrating releases from implemented or validated petitions through release notes, approvals, deployment, smoke tests, and rollback."
workflow_role: orchestrator
workflow_binding: graph_aligned
graph_node_ids:
  - identify_mode
  - plan_release
  - plan_gate
  - generate_notes
  - notes_gate
  - execute_prechecks
  - tag_release
  - deploy_gate
  - deploy_release
  - smoke_tests
  - smoke_decision
  - update_status
  - completion_report
  - rollback_start
  - rollback_gate
  - rollback_execute
  - rollback_status
  - rollback_report
  - escalation_gate
upstream_dependencies:
  - program-status
  - release scope
  - project stack and deploy method
primary_outputs:
  - release plan
  - release notes
  - released or rolled-back status updates
default_next:
  success: release completion or rollback completion
  partial_success: human gate pending notes, deploy, or rollback confirmation
  blocked: user escalation
  needs_more_evidence: proof gathering or smoke verification follow-up
  retry: rerun current release phase with targeted remediation
  fail: user escalation or rollback path
---

# Purpose

Take code from `implemented` or `validated` to a confirmed release. This skill owns **scope selection, versioning, release notes, human approvals, build/test execution, deploy orchestration, smoke verification, status mutation, and rollback**. Deterministic input-readiness checks belong to `scripts/release_preflight.py`.

## Workflow role

- Role: `orchestrator`
- Goal gate: yes, for deploy readiness, smoke verification, released status changes, and rollback completion
- Human approval node: yes, for release scope, tag creation, deploy command, and rollback command
- Typical predecessors: `pipeline-conductor` or direct user release request
- Typical successors: released status updates, escalation entry, or rollback path

## Inputs

### Required

- `petitions/program-status.yaml`
- version and target environment, or enough evidence to propose them
- project stack and deploy-method resolution

### Optional

- `releases/`
- `.factory/project.yaml`
- `.factory/services.yaml`
- `architecture/workspace.dsl`
- deploy-relevant ADRs

## Preconditions

1. Release candidates exist with status `implemented` or `validated`, or the user is explicitly asking for release planning.
2. The user is available to confirm scope and any tag, deploy, or rollback command.
3. A release note path can be resolved or created before tagging.

## Startup recall

You may review recent release-manager diary/search results to surface prior blockers, rollback notes, or release patterns worth re-checking. Recalled context is a hint only until the canonical artifact is reopened in this run.

## Deterministic preflight

1. **Run the declarative readiness gate before tagging or deploying**
   - Command:
     `python scripts/release_preflight.py --root <repo> --json --version <version> [--scope <petition-id> ...] [--release-notes <path>]`
2. **Use the script output as the source of truth for**
   - semver tag validity
   - release-notes path presence
   - clean git working tree
   - candidate status eligibility
   - open escalation blockers
   - declared build/test/lint commands in `.factory/project.yaml`
   - whether blocking structural-hotspot TB items in release scope are triaged
3. **Interpret the result conservatively**
   - non-zero preflight -> stop before tagging or deploying
   - warnings do not equal approval to skip manual review
4. **Keep the non-deterministic release work in this skill**
   - run the actual build/test/lint commands
   - choose version semantics
   - generate notes content
   - obtain human approvals
   - run deploy and rollback commands
   - perform smoke verification
5. Record the preflight run as evidence with the exact command and result.

## Operating modes

### 1. Plan release

1. Read `petitions/program-status.yaml`.
2. Identify release candidates with status `implemented` or `validated`.
3. Propose scope, blockers, and version:
   - patch for bugfix-only or TB-only scope
   - minor for compatible user-facing functionality
   - major when ADRs indicate a breaking change
   - `v0.1.0` when no prior release exists
4. Present the release plan and wait for scope confirmation when needed.

### 2. Generate release notes

1. Read the confirmed scope.
2. Summarize each petition and any completed TB item in user-facing terms.
3. Summarize deploy-relevant ADR changes since the last release when they matter.
4. Write notes to `releases/release-YYYY-MM-DD-v<version>.md` unless the user specifies another path.

### 3. Execute release

1. Confirm the approved scope and version.
2. Ensure release notes exist.
3. Run `release_preflight.py`.
4. Execute the declared build, test, and lint commands. A preflight pass is **not** a substitute for running them.
5. Create the git tag only after explicit user confirmation. Do not push the tag automatically.
6. Suggest the deploy method from repo evidence, but do not run any deploy command without explicit confirmation.
7. After deploy, run smoke verification:
   - use automated smoke or health checks when available
   - for browser UI systems, treat missing automated smoke/E2E as a blocker rather than hand-waving it away
8. If deploy and smoke verification succeed, update `petitions/program-status.yaml`:
   - set included petitions to `released`
   - set `released_in` and `released_date`
   - update the program timestamp field
9. Report the release with fresh evidence for readiness, deploy success, and smoke verification.

### 4. Rollback

1. Confirm the rollback command with the user.
2. Execute the approved rollback path.
3. Verify the prior healthy state.
4. Update affected petitions from `released` back to `validated`.
5. Report the rollback and any follow-up escalation.

## Output Contract

### Artifacts

- release plan
- release notes
- tag metadata
- deploy or rollback evidence
- updated `petitions/program-status.yaml`

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` — release or rollback completed with fresh evidence
- `partial_success` — planning or notes are ready, but a human gate is still pending
- `blocked` — preflight, approvals, or smoke prerequisites prevent safe release
- `needs_more_evidence` — deploy or smoke evidence is incomplete for the requested claim
- `retry` — rerun the current phase after targeted remediation
- `fail` — release or rollback could not complete safely

## Done Criteria

1. Release scope is explicit.
2. Release notes exist for the chosen version.
3. `release_preflight.py` passed before tagging or deploying.
4. Build, test, and lint commands were actually run before release claims were made.
5. No petition was marked `released` without deploy and smoke evidence.
6. Blocking structural-hotspot debt in release scope was triaged before release.
7. `program-status.yaml` remained internally consistent after any update.

## Evidence Requirements

- Claim: release inputs are ready -> proof: `release_preflight.py` passed in this run
- Claim: release candidate is releasable -> proof: candidate status, escalation state, and executed build/test/lint evidence were checked in this run
- Claim: deployment is healthy -> proof: deploy output and smoke verification were checked in this run
- Claim: rollback completed -> proof: rollback output and restored healthy state were checked in this run

## Failure Routing

- preflight fails -> `blocked`
- build/test/lint execution fails -> `blocked`
- user confirmation is missing for tag, deploy, or rollback -> `partial_success`
- deploy succeeds but smoke proof is incomplete -> `needs_more_evidence`
- status file cannot be updated consistently -> `fail`

## Never Do

- never treat a preflight pass as proof that release execution is safe
- never tag, push, deploy, or rollback without explicit user confirmation
- never mark a petition `released` without deploy and smoke evidence
- never auto-push release tags
- never ignore open escalations in release scope
- never ship untriaged blocking structural-hotspot debt in release scope
- never hide a failed smoke test behind optimistic status updates
