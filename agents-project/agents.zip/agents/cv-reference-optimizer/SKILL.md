---
name: cv-reference-optimizer
description: "Use when optimize slightly similar candidate-owned references against current RFP requirements through structured adaptation notes, risk classes, and explicit non-extrapolation guardrails."
workflow_role: worker
workflow_binding: contract_only
primary_outputs:
  - reference adaptation plan
default_next:
  success: cv-response-drafter
  partial_success: cv-response-drafter with warnings
  blocked: user escalation or source repair
  needs_more_evidence: proof gathering or candidate clarification
  fail: rerun after source repair
---

# Purpose

Turn "this reference is close" into a safe, traceable adaptation plan. This node looks at current requirements, candidate-owned reference anchors, active win themes, and optional prior candidate material to identify where a slightly similar reference can be reframed to fit the tender. It does not draft response prose and it does not turn historical resemblance into proof.

## Workflow role

- Role: `worker`
- Binding: `contract_only`
- Goal gate: no
- Human approval node: yes, when a useful adaptation depends on candidate confirmation rather than artifact proof
- Typical predecessors: `cv-fit-mapper`
- Typical successors: `cv-response-drafter`, `cv-red-team-reviewer`

## Inputs

### Required

- `rfp/active/<RFP-ID>/extraction/requirements-register.yaml`
- `rfp/active/<RFP-ID>/extraction/fit-matrix.yaml`
- `rfp/active/<RFP-ID>/extraction/candidate-reference-index.yaml`
- `rfp/active/<RFP-ID>/request/candidate-cv.md`

### Optional

- `rfp/active/<RFP-ID>/request/previous-response.md`
- `rfp/active/<RFP-ID>/context/selected-context.md`
- `rfp/active/<RFP-ID>/context/historical-patterns.md`
- `rfp/active/<RFP-ID>/context/historical-win-themes.md`
- `rfp/active/<RFP-ID>/extraction/active-win-themes.yaml`

## Preconditions

1. Candidate reference index exists and only candidate-owned references are eligible for adaptation.
2. Historical material may guide framing, terminology, and evaluator emphasis, but never substitute for candidate proof.
3. Output must stay structured. This node emits adaptation notes, not draft-ready paragraphs.

## Procedure

1. Read the requirements register, fit matrix, candidate reference index, candidate CV, and optional supporting artifacts in full.
2. Focus on requirements that are:
   - score-bearing and only partially supported
   - phrased differently from the candidate's existing references
   - better served by reframing an already evidenced candidate reference
3. Compare requirement-to-reference resemblance across:
   - domain or public-sector setting
   - stakeholder environment
   - delivery model and responsibilities
   - methods and tools already evidenced
   - governance, compliance, or operating model context
   - outcome type or change pattern
4. Write `reference-adaptations.yaml`. For each adaptation candidate, record:
   - requirement id
   - candidate reference id
   - why the match is close enough to use
   - safe framing angle
   - preferred terminology to mirror from the requirement
   - candidate-owned evidence anchor
   - residual gap
   - risk class: `safe_reframe`, `requires_candidate_confirmation`, or `unsafe_substitution`
   - hint signal anchor(s) when only weak evidence exists
   - assertion ceiling for draft language (`exposure`, `applied_support`, `demonstrated_ownership`)
   - draft write-up strategy for consultancy positioning without factual inflation
   - bounded uncertainty phrase for draft use when helpful
   - phrasing to avoid (`harsh_deficit_language` or `bluff_risk_language`)
   - forbidden extrapolations
   - supporting source paths
5. If a score-bearing requirement has no strong path but at least one non-contradictory hint exists, provide a bounded consultancy write-up path at the correct assertion ceiling. If no safe signal exists, state the gap explicitly in artifacts.
6. Keep adaptation guidance tight enough to be auditable and rich enough to improve a weakly matched requirement.

## Output Contract

### Artifacts

- `rfp/active/<RFP-ID>/extraction/reference-adaptations.yaml`

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` - a usable reference adaptation plan was produced
- `partial_success` - some requirements received usable adaptations but thin areas remain
- `blocked` - required candidate-owned reference inputs are missing or contradictory
- `needs_more_evidence` - score-bearing requirements lack safe candidate-owned adaptation paths
- `fail` - optimization failed because upstream artifacts were unusable

## Done Criteria

1. Reference adaptation plan exists.
2. Every adaptation stays anchored in a candidate-owned source.
3. Residual gaps and forbidden extrapolations are explicit.
4. Unsafe substitutions are surfaced rather than smuggled into drafting.
5. Bounded uncertainty phrasing hints are provided when a requirement is thin but salvageable.
6. Hint-supported opportunities include explicit assertion ceilings so drafting can be assertive without overclaiming.

## Evidence Requirements

- Claim: a reference can be adapted safely -> proof: candidate-owned source path and fit rationale were recorded in this run
- Claim: a residual gap remains -> proof: the missing evidence or candidate confirmation dependency was recorded in this run
- Claim: historical material informed the adaptation -> proof: it shaped framing only and did not replace candidate-owned proof in this run

## Failure Routing

- missing candidate reference index or candidate CV -> `blocked`
- no safe adaptation for score-bearing requirements -> `needs_more_evidence`
- useful but incomplete adaptation coverage -> `partial_success`
- unusable upstream artifacts -> `fail`

## Escalation Rules

1. Escalate when a requirement can only be matched by rewriting historical resemblance into candidate fact.
2. Escalate when a reference would need new tooling, metrics, or role claims that are not already evidenced.

## Never Do

- never adapt a reference that is not candidate-owned
- never emit draft-ready prose for the response
- never use historical wins or losses as substitute proof for the candidate
- never hide forbidden extrapolations
