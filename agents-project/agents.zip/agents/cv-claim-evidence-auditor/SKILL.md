---
name: cv-claim-evidence-auditor
description: "Use when you need to verify CV-response claims against candidate evidence, project context, optimized reference plans, and historical provenance and block unsupported credibility-critical assertions."
workflow_role: gate
workflow_binding: contract_only
primary_outputs:
  - audited claims register
  - evidence audit artifact
default_next:
  success: cv-rfp-conductor final close
  partial_success: internal approval boundary
  blocked: user escalation or source repair
  needs_more_evidence: proof gathering
  fail: rerun after artifact repair
---

# Purpose

Turn "sounds plausible" into "is evidenced." This node audits non-trivial CV-response claims against the candidate CV, project context, optimized reference plans, prior materials, and historical provenance. It does not draft new proof.

## Workflow role

- Role: `gate`
- Binding: `contract_only`
- Goal gate: yes, for credibility and response-readiness proof
- Human approval node: yes, when a claim can proceed only by explicit business acceptance rather than artifact proof
- Typical predecessors: `cv-response-drafter`, `cv-red-team-reviewer`
- Typical successors: `cv-rfp-conductor` final close or proof gathering

## Inputs

### Required

- latest response draft
- `rfp/active/<RFP-ID>/evidence/claims-register.yaml`
- `rfp/active/<RFP-ID>/request/candidate-cv.md`

### Optional

- `rfp/active/<RFP-ID>/deliverables/render-payload.yaml`
- `rfp/active/<RFP-ID>/extraction/hint-ceilings.yaml`
- selected project context
- previous response
- historical patterns
- active win themes
- reference adaptations
- explicit proof artifacts

## Preconditions

1. Claims register exists and points to draft locations.
2. Credibility-critical claims must be treated as proof items, not editorial flourishes.
3. Missing proof must be surfaced explicitly.

## Procedure

1. Verify required inputs exist and read them in full.
2. For each claim, classify claim type as:
   - `factual_claim`
   - `narrative_qualifier`
   - `pending_confirmation`
3. For each claim, classify evidence status as:
   - `verified`
   - `partially_verified`
   - `hint_supported`
   - `unverified`
   - `contradicted`
   - `pending_human_approval`
4. Apply claim-type rules:
   - `factual_claim` must be verified, partially verified, `hint_supported` within assertion ceiling, or pending approval with explicit dependency
   - `narrative_qualifier` is allowed only when it adds no new factual assertion
   - `pending_confirmation` must remain non-committal and name the missing source or approver
5. Treat these as credibility-critical unless explicitly downgraded:
   - years of experience
   - role and project participation
   - methods and tool familiarity
   - certifications and accreditations
   - metrics or outcomes
   - delivery or staffing commitments
6. If an optimized reference points to a subject, project, toolset, or outcome that is not evidenced in the candidate CV or another approved source, classify the affected claim as `contradicted` rather than "creative framing."
7. Treat elaborated win-theme paragraphs as audit items. If a substantive win-theme paragraph has no checked proof path, block it.
8. When `render-payload.yaml` exists, treat each payload field as an audit item:
   - verify it traces back to audited claims or cited source paths
   - verify loop collections do not introduce unregistered factual assertions
   - verify field wording does not exceed allowed assertion ceilings
9. Update the claims register with claim type, assertion ceiling, audit status, and checked proof paths.
10. Write an evidence audit artifact with blocking findings and residual warnings.
11. For hint-supported competency language, block only when wording exceeds the allowed assertion ceiling or conflicts with known evidence.

## Output Contract

### Artifacts

- `rfp/active/<RFP-ID>/evidence/claims-register-audited.yaml`
- `rfp/active/<RFP-ID>/evidence/evidence-audit.yaml`

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` - credibility-critical claims are verified, hint-supported within ceiling, or explicitly accepted with non-blocking warnings
- `partial_success` - non-critical claims remain provisional, but internal review can continue
- `blocked` - one or more credibility-critical claims are unsupported, contradicted, or awaiting approval
- `needs_more_evidence` - proof may exist but has not been provided or inspected yet
- `fail` - audit could not complete because inputs were unusable

## Done Criteria

1. Every claims-register item has an audit status.
2. Every claims-register item has a claim type classification.
3. Credibility-critical claims are explicit.
4. Optimized references and elaborated win themes were checked against candidate-owned evidence rather than historical resemblance alone.
5. Blocking evidence gaps are surfaced clearly.
6. Audited claims register and evidence audit artifact were written.
7. Render payload fields were checked when rendering is in scope.

## Evidence Requirements

- Claim: a response assertion is verified -> proof: source artifact was inspected in this run
- Claim: a claim is contradicted -> proof: inspected source conflicts with draft language in this run
- Claim: an optimized reference is safe -> proof: the adaptation and the cited candidate-owned source were both inspected in this run
- Claim: a claim is pending approval -> proof: no artifact proof exists and a named approval dependency was recorded in this run
- Claim: a render payload field is safe -> proof: payload value was traced to current-run claim/source links in this run

## Failure Routing

- missing claims register or core proof path -> `blocked`
- rendering requested but render payload missing -> `needs_more_evidence`
- proof expected but not yet supplied -> `needs_more_evidence`
- contradicted credibility-critical claim or assertion-above-ceiling claim -> `blocked`
- unreadable or unusable artifacts -> `fail`

## Escalation Rules

1. Escalate when experience, certification, or project-participation claims are unsupported.
2. Escalate when tool or method claims are asserted more strongly than the evidence base allows.
3. Escalate when quantitative claims cannot be traced to a real source.
4. Escalate when a win-theme section depends on historical resemblance rather than candidate-owned proof.
5. Escalate when provisional wording implies factual completion without proof.
6. Escalate when hint-supported language is repeatedly written above allowed assertion ceilings.

## Never Do

- never treat confidence or domain familiarity as proof
- never let a contradicted claim survive to final close
- never downgrade a credibility-critical claim just to keep moving
- never accept an optimized reference whose subject is not evidenced in the current candidate source set
- never claim verification without inspecting the source in this run
- never accept narrative qualifiers that sneak in new unsupported facts
- never treat hint-supported signals as proof of ownership-level capability unless ceiling and evidence allow it

