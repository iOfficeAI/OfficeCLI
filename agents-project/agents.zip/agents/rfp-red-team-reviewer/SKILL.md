---
name: rfp-red-team-reviewer
description: "Use when perform a brutal proposal review against compliance, evaluator logic, credibility, clarity, content depth, and visual strength before evidence audit and packaging."
workflow_role: reviewer
workflow_binding: contract_only
primary_outputs:
  - red-team review artifact
default_next:
  success: rfp-claim-evidence-auditor or drafting remediation
  blocked: user escalation
  needs_more_evidence: missing draft or context repair
  fail: rerun after artifact repair
---

# Purpose

Stress-test the proposal the way a hard evaluator or internal bid manager would. This node reviews the draft for compliance coverage, persuasion, clarity, credibility, competitive strength, and whether the answer is substantively developed enough to score well. It does not rewrite the proposal.

## Workflow role

- Role: `reviewer`
- Binding: `contract_only`
- Goal gate: yes, for narrative and response-quality readiness
- Human approval node: no
- Typical predecessors: `rfp-response-drafter`
- Typical successors: drafting remediation or `rfp-claim-evidence-auditor`

## Inputs

### Required

- latest response draft
- compliance matrix
- strategy brief
- claims register

### Optional

- prior red-team artifact
- packaging brief
- visual / exhibit brief
- visual manifest or typed visual specs
- evaluator or account notes

## Preconditions

1. A current draft exists.
2. Compliance matrix and strategy brief exist.
3. Review findings must cite exact sections or requirement IDs.

## Procedure

1. Read the draft, compliance matrix, strategy brief, and claims register in full.
2. Review across seven lenses:
   - compliance completeness
   - evaluator clarity
   - strategic differentiation
   - credibility and specificity
   - executive readability and structure
   - content depth and work-product specificity
   - visual / exhibit adequacy for complex sections
3. Produce a verdict:
   - `APPROVE`
   - `REVISE`
   - `BLOCK`
4. For every blocking or major finding, cite the affected requirement ID or draft location.
5. Separate cosmetic comments from score-moving issues.
6. Treat thin, generic, or text-heavy responses as score-moving issues when they leave the evaluator without enough process, work-product, or visual clarity.
7. When a visual brief, manifest, or typed visual spec exists, flag mismatches between the intended artifact and the draft narrative as real findings instead of packaging polish.

## Output Contract

### Artifacts

- `rfp/<RFP-ID>/reviews/red-team.yaml`

### Report Fields

- `status`
- `verdict`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` - review completed with an explicit verdict and cited findings
- `blocked` - review could not complete because a required artifact or decision basis was missing
- `needs_more_evidence` - the draft or context is too incomplete for a meaningful review
- `fail` - review failed because the input artifacts were unusable

## Done Criteria

1. Verdict is explicit.
2. Blocking and major findings cite exact requirement IDs or draft sections.
3. Findings distinguish must-fix issues from minor noise.
4. Thin, generic, or visually weak score-moving sections are called out explicitly when present.
5. Visual intent mismatches are called out explicitly when typed specs or manifests exist.
6. Review artifact exists in machine-readable form.

## Evidence Requirements

- Claim: a compliance gap exists -> proof: requirement and draft mismatch checked in this run
- Claim: the draft is weak or strong strategically -> proof: strategy brief and draft were compared in this run
- Claim: a claim feels vague or risky -> proof: claims register and draft language were checked in this run
- Claim: a section is too thin to score well -> proof: draft depth, work-product detail, or visual support was checked against the strategy brief in this run
- Claim: a draft drifts from approved visual intent -> proof: draft language and visual brief or spec were checked in this run

## Failure Routing

- missing draft or compliance artifact -> `blocked`
- draft too incomplete for meaningful review -> `needs_more_evidence`
- review completed with `REVISE` or `BLOCK` verdict -> `success`
- unreadable artifacts -> `fail`

## Escalation Rules

1. Escalate when the draft cannot answer a mandatory requirement without new source material.
2. Escalate when strategic positioning conflicts with approved organizational stance.
3. Escalate when the proposal appears compliant but commercially or legally unsafe.

## Never Do

- never be polite at the expense of surfacing risk
- never approve a vague answer to a scored requirement
- never hide credibility problems behind tone edits
- never rewrite the draft instead of reviewing it
- never pass a text-heavy but evaluator-thin answer just because it is formally compliant

