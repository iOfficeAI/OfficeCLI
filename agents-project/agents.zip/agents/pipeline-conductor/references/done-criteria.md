# Done Criteria

Do not consider the run complete until:

1. Required stages for the chosen mode have either passed or been explicitly skipped with justification.
2. Every stage verdict is backed by a checked artifact or fresh evidence from this run.
3. Runtime integration was audited when runtime-bearing surfaces changed, or explicitly skipped with justification.
4. PR-ready or release-ready language is supported by explicit proof.
5. Any escalations, drift findings, or unresolved ambiguities are surfaced, not buried.
6. Any token or cost claim is backed by measured telemetry rows, or explicitly downgraded as a coverage gap.
7. Delivery track and telemetry coverage are explicit in the completion report.
