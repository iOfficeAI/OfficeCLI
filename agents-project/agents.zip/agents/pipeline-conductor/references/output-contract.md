# Output Contract

### Artifacts

- stage-specific artifacts produced by delegated agents
- updates to `petitions/program-status.yaml`
- `petitions/telemetry/petition<ID>-telemetry.yaml` when present or externally updated in this run
- `petitions/completion/petition<ID>-completion-guide.md` when a long-form completion guide is produced
- `petitions/status/petition<ID>-status-report.md` when a long-form status report is produced
- `petitions/implementation/petition<ID>-implementation.md` when a long-form implementation note is produced
- escalation entries when required

### Report Fields

- `status` — `success | partial_success | blocked | needs_more_evidence | retry | fail`
- `summary` — petition scope, pipeline mode, and overall stage verdict
- `artifacts` — artifacts produced with file paths
- `evidence_checked` — quality gates, review verdicts, release proof, and other fresh checks
- `delivery_track` — resolved track and any mismatch warning
- `telemetry_coverage` — `measured | partial | absent`
- `warnings` — skipped optional branches, declared limitations, or unresolved non-blocking concerns
- `escalations` — escalation IDs or manual interventions
- `telemetry_signal` — measured coverage, run correlation, and any explicit telemetry gap
- `next_action` — immediate next step required
- `handoff_target` — next stage, `release-manager`, approval boundary, or `exit`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`
