# Evidence Standard

Before any claim that a phase passed, a branch is PR-ready, or a petition is release-ready:

1. Identify the exact claim.
2. Identify the proving command or artifact.
3. Verify it from fresh evidence in this run.
4. If proof is incomplete, stale, or ambiguous, block the claim and report the gap.

Use `verification-gate` as the canonical pattern: evidence before claims.
