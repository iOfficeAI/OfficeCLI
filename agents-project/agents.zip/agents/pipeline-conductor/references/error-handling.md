# Error Handling

- If a delegated agent fails or produces no output, report failure with details and do not skip the stage.
- If a delegated agent is unavailable, report the gap and suggest a manual alternative.
- If ambiguity is discovered mid-pipeline, halt and escalate with specific questions.
- If docs impact or planning-state sync cannot be determined, halt and report the gap explicitly.
- Maximum 2 retry attempts per stage before escalation, unless the phase definition states a narrower or explicit alternative rule.
