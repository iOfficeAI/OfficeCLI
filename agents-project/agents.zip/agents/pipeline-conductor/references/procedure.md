# Procedure

### Phase 0: Validate Inputs

1. Use repository inspection tools to verify existence and content of:
   - `petition<ID>.md`
   - `petition<ID>-outcome-contract.md`
   - `petition<ID>.feature`
2. If any are missing, stop and report exactly what is needed.
3. Read all three files to understand scope and complexity.
4. Read petition frontmatter for any declared `delivery_track`. If the petition is already tracked in `petitions/program-status.yaml`, compare the mirrored track and warn on drift.
5. Resolve the canonical telemetry path:
   `petitions/telemetry/petition<ID>-telemetry.yaml`.
6. If the telemetry artifact exists, read its current coverage state and any
   measured rows relevant to the petition.
7. If the host runtime or provider export exposes measured usage for this run,
   capture the run correlation in the completion report and require the external
   collector to write the measured row. The conductor may reference telemetry,
   but it must not author token counts itself.
8. If no measured source exists, resolve `telemetry_coverage` as:
   - `absent` when no usable telemetry artifact or rows exist yet
   - `partial` when some telemetry exists but measured coverage is incomplete
   - `measured` when the reported slice is backed by measured rows
   Carry that explicit status forward into the completion report instead of inventing token or cost totals.

### Phase 1: Requirements Review

1. Delegate to `gherkin-minimality-reviewer` to validate that the feature file contains only scenarios justified by the petition and outcome contract.
2. Delegate to `petition-translator-reviewer` to validate the feature file against the petition and outcome contract.
3. If either reviewer rejects or raises blocking issues, report specific findings and halt for user decision.
4. If both pass, proceed.

Record phase result in the completion report with verdict, artifact paths, and timestamp.

### Phase 2: Decide Pipeline Depth

Based on the change scope, choose one of two modes:

- **Full pipeline** — new feature, multi-component change, or significant new behavior
- **Lean pipeline** — single-module change, bugfix, or small enhancement

Present the recommendation to the user and proceed after confirmation.

When scope signals are mixed, `testing_scope: targeted` is supporting evidence for the lean path on clearly bounded fixes, but it never outweighs petition scope, risk, or dependency complexity.

Track influence:

- `quick` may support a lean recommendation when the inspected scope stays bounded
- `standard` leaves the normal depth decision intact
- `governed` should default to the full pipeline and planning-safe posture

### Phase 2.5: Domain Concept Alignment (full pipeline only)

Runs before architecture so `solution-architect` has domain grounding.

1. Check for `domain/concept-model.yaml`.
2. If absent, skip with note: `No domain concept model found. Proceeding without domain alignment.`
3. If present, delegate to `concept-model-curator` in alignment report mode with:
   - petition document
   - outcome contract
   - path to `domain/concept-model.yaml`
4. Pass the resulting alignment report to `solution-architect` as mandatory input for Phase 3.
5. If the report flags potential new concepts, inform the user. This is advisory and should not block the pipeline.

### Phase 2.7: NFR Alignment (full and lean pipelines)

Runs after depth is decided. Produces an NFR coverage report that `solution-architect` and `specs-translator` consume as mandatory input.

1. Check for `compliance/nfr-register.yaml`.
2. If absent, skip with note:
   `No NFR register found at compliance/nfr-register.yaml. NFR alignment skipped. Add register to enable cross-cutting NFR injection.`
3. If present, read the NFR register and petition artifacts, then match applicable NFRs:
   - always include entries with `applies_to: all` or no `applies_to`
   - include `applies_to.tags` when petition text references tagged services, portals, or components
   - include `applies_to.components` only when the petition explicitly names those component IDs
4. Produce a structured NFR Coverage Report with:
   - applicable NFRs
   - skipped NFRs
   - register gaps where severity is `must` and no automated validation is defined
5. Pass the report to:
   - `solution-architect` in the full pipeline
   - `specs-translator` in both full and lean pipelines
6. If any `must` NFR has no automated validation hook, log a warning in the completion report.

Record NFR count and gap summary in the completion report.

### Phase 3: Architecture (full pipeline only)

1. Delegate to `component-assigner` to map scenarios to components.
2. Delegate to `component-mapping-reviewer` to review assignments.
3. Delegate to `solution-architect` to produce `design/solution-architecture-<ID>.md`.
4. Require the architecture document to include a `## Structurizr DSL Block` section. If absent, reject immediately and ask for correction.
5. Delegate to `solution-architecture-reviewer`.
6. On reviewer rejection, retry once with focused feedback, then escalate to the user.
7. After reviewer acceptance, merge the Structurizr DSL block into canonical `architecture/workspace.dsl`. If the file does not exist, create it from the DSL block.
8. Delegate to `c4-model-validator` in enforce mode on the resulting DSL.
9. On validator failure, feed findings back to `solution-architect` for one targeted correction pass, then escalate if still failing.

Record phase result in the completion report with verdict, artifacts, and timestamp.

### Phase 3.5: C4 Architecture Compliance

Runs on every PR in both full and lean pipelines when code, IaC, or DSL files are being changed.

1. Delegate to `c4-architecture-governor` in PR mode.
2. Provide:
   - PR diff
   - path to `architecture/workspace.dsl`
   - path to `architecture/policies.yaml` when it exists
   - architecture document when available
3. On `PASS` or `PASS-WITH-WARNINGS`, proceed and log warnings.
4. On `FAIL`:
   - feed blocking findings back to `solution-architect`
   - do not reroute this to implementation or specs agents
   - retry once after architecture correction
   - escalate if still failing

Record phase result in the completion report with verdict, artifacts, and timestamp.

### Phase 3.7: Catala Encoding (legal-footprint petitions only)

Runs after architecture and before specs, but only when the petition has legal footprint.

1. Detect legal footprint signals such as statutory references, calculations, date rules, or priority ordering derived from law.
2. If no signal is present, skip with note: `No legal footprint detected. Catala encoding skipped.`
3. If signal is present, delegate to `catala-encoder` with:
   - petition path
   - outcome contract path
   - feature file path
   - G.A. snapshot version and date when present
4. Expect:
   - `catala/<scope>.catala_da`
   - `catala/tests/<scope>-tests.catala_da`
   - updates to `petitions/program-status.yaml`
   - CI typecheck entries
5. Evaluate `catala_encoding_summary`:
   - `typecheck: FAIL` after 3 attempts -> escalate
   - `juridisk_usikkerhed_flags > 0` -> halt and escalate
   - `typecheck: DEFERRED` -> proceed with explicit note
   - `typecheck: PASS` -> proceed
6. Pass Catala artifact paths to `specs-translator` as mandatory context.

Record phase result in the completion report with Catala files, verdict, and typecheck status.

### Phase 4: Specifications

1. Delegate to `specs-translator` to produce:
   - `petitions/specs/petition<ID>-specs.yaml`
   - `petitions/validation/<petition-ID>/validation-contract.md`
2. Include architecture and Catala artifacts as mandatory context when present.
3. Delegate to `specs-reviewer`.
4. Delegate to `specs-minimality-reviewer`.
5. On rejection, feed issues back to `specs-translator` for revision within retry budget, then escalate.

Record phase result in the completion report with verdict, artifacts, and timestamp.

### Phase 5: Test Generation

Before delegating, resolve the test stack in this order:

1. If `.factory/context/PROJECT_CONTEXT.md` exists:
   - read `.factory/context/PROJECT_CONTEXT.md` before broad repo exploration
   - read the relevant `.factory/context/*.md` files, at minimum `stack.md` and `testing.md`, and `architecture.md` when present
   - treat these files as derived hints rather than canonical config
2. Search MemPalace with:
   - `query: "project tech stack FACT"`
   - `query: "project framework DECISION"`
   - `query: "project tooling FACT"`
3. Read `.factory/project.yaml`.
4. If still inconclusive, inspect the repo for framework-specific test signals such as `playwright.config.ts` or `playwright.config.js`.

Route test generation as follows:

- browser UI detected -> `playwright-test-generator`
- non-Playwright BDD framework detected -> `bdd-test-generator`

Use resolved `testing_scope` to set breadth:

- `full` -> ask generators and auditors for broad coverage across justified user paths, contracts, edge cases, and structural tests
- `targeted` -> keep generation focused on directly affected or risk-bearing paths implied by the petition, outcome contract, runtime surfaces, and browser-critical flows; do not expand to low-risk untouched surfaces

Execution:

1. If browser UI is present, delegate to `playwright-test-generator` for browser E2E coverage.
2. If another BDD framework is also configured, additionally delegate to `bdd-test-generator`.
3. Delegate to `bdd-test-coverage-auditor`.
4. Delegate to `unit-test-minimality-reviewer`.
5. If coverage gaps exist, feed them back to the relevant generator for a targeted pass.

Record phase result in the completion report with verdict, artifacts, and timestamp.

### Phase 6: Implementation

1. Delegate to `tdd-enforcer` to implement code via strict TDD.
2. Require a red-green cycle: failing tests first, then minimal implementation.

Record phase result in the completion report with verdict, artifacts, and timestamp.

### Phase 6.5: E2E Acceptance Testing

Runs after implementation and before code review. Mandatory for browser UI projects.

1. Determine whether the project has browser UI by reading `.factory/project.yaml`.
2. Check for validation harness artifacts:
   - `.factory/library/user-testing.md` or equivalent
   - validation contract under `.factory/validation/<milestone>/` or `petitions/validation/<petition-ID>/`
3. If browser UI is present and either artifact is missing, stop and report blocker: `UI project missing mandatory E2E validation harness.`
4. If browser UI is absent and either artifact is missing, skip with note: `API-only project without live-surface validation harness.`
5. Delegate to `user-testing-flow-validator` with:
   - assertion IDs derived from the validation contract
   - app URL from `.factory/services.yaml` or project config
   - `missionDir: petitions/validation/<petition-ID>/`
   - output file path `petitions/validation/<petition-ID>/user-testing/flows/main.json`
6. Review the test report:
   - all pass -> proceed
   - any fail -> feed specific failures back to `tdd-enforcer`, retry once, then escalate
   - any blocked -> report blocker and stop
7. Record the Playwright evidence path for use in code review.

Record phase result in the completion report with verdict, assertion counts, evidence directory, and timestamp.

### Phase 7: Documentation Sync

1. Delegate to `implementation-doc-sync`.
2. Require its response to include a `Documentation impact:` line.
3. If docs impact is unclear or the agent fails to make an explicit decision, retry once with focused instructions, then escalate.

Record phase result in the completion report with verdict, artifacts, and timestamp.

### Phase 7.5: Contract Drift Gate

Runs after documentation sync and before code review when the implementation touched contract-bearing layers.

1. Inspect changed artifacts for contract-bearing signals such as:
   - OpenAPI, Swagger, GraphQL, protobuf, or other external schema files
   - DTO, request, response, serializer, adapter, or mapper code
   - persistence entities, ORM models, database schema files, or migrations
   - controller or handler payload-shape changes
2. If no such signals are present, skip this phase with note:
   `No contract-bearing layer changes detected. Contract drift audit skipped.`
3. If contract-bearing signals are present, delegate to `contract-drift-auditor`.
4. Choose mode as follows:
   - `detect` for normal implementation drift checks where you want findings and warnings before review
   - `enforce` when the diff changes externally visible contracts, persistence-visible contracts, or compatibility-critical shapes that must block PR readiness if misaligned
5. Require the audit report to name:
   - canonical source used for comparison
   - layers checked
   - any drift classes found
   - remediation target for each blocking issue
6. If unresolved drift findings remain and `petitions/program-status.yaml` exists, require `contract-drift-auditor` to register or update `technical_backlog` TB handoff items for `tech-debt-executor`.
7. On `PASS` or `PASS-WITH-WARNINGS`, proceed and record warnings explicitly for code review context, including any TB handoff IDs.
8. On `FAIL`, route findings back to `tdd-enforcer` for targeted correction once, then escalate if drift remains. If drift still remains after retry and planning-state tracking exists, require the corresponding TB handoff items to be present in `petitions/program-status.yaml`.
9. On `blocked` or `needs_more_evidence`, stop and escalate instead of guessing which layer is correct.

Record phase result in the completion report with verdict, compared layers, drift summary, and timestamp.

### Phase 7.7: Runtime Integration Gate

Runs after contract drift and before code review when the implementation touched runtime-bearing surfaces.

1. Inspect changed artifacts for runtime-bearing signals such as:
   - startup scripts, compose files, make targets, or documented run paths
   - environment defaults, service config, port bindings, or base URLs
   - frontend API client or dev-proxy wiring
   - migrations, schema bootstrap, seed, or fixture setup
   - health endpoint wiring or representative API routes
   - UI entry routes or critical feature pages
2. If no runtime-bearing signals are present, skip this phase with note:
   `No runtime-bearing surface changes detected. Runtime integration audit skipped.`
3. If such signals are present, delegate to `runtime-integration-conductor`.
4. Choose mode as follows:
   - `detect` for normal implementation runtime checks where you want findings and warnings before review
   - `enforce` when the diff changes startup path, migrations, service wiring, externally consumed base URLs or ports, or critical user flows that must boot correctly before PR readiness
5. Require the audit report to name:
   - startup path used
   - services expected and services observed
   - surfaces checked
   - any drift classes found
   - remediation target for each blocking issue
6. If unresolved runtime findings remain and `petitions/program-status.yaml` exists, require `runtime-integration-conductor` to register or update `technical_backlog` TB handoff items for `tech-debt-executor`.
7. On `PASS` or `PASS-WITH-WARNINGS`, proceed and record warnings explicitly for code review context, including any TB handoff IDs.
8. On `FAIL`, route findings back to `tdd-enforcer` for targeted correction once, then escalate if runtime drift remains. If runtime drift still remains after retry and planning-state tracking exists, require the corresponding TB handoff items to be present in `petitions/program-status.yaml`.
9. On `blocked` or `needs_more_evidence`, stop and escalate instead of guessing startup ownership, missing secrets, or environment wiring.

Record phase result in the completion report with verdict, startup path, runtime surfaces checked, and timestamp.

### Phase 8: Code Review

1. Use resolved `review_scope` when shaping reviewer breadth:
   - `full` -> changed files plus adjacent risk-bearing context
   - `targeted` -> changed files plus directly affected contract-bearing or runtime-bearing surfaces only
   - review remains mandatory in both modes
2. Delegate to `code-reviewer-strict`.
3. Require `code-reviewer-strict` to resolve the changed-file set, run `code_maintainability_analyze` on touched supported-language files (`.ts`, `.tsx`, `.mts`, `.cts`, `.js`, `.jsx`, `.mjs`, `.cjs`, `.py`, `.java`), and run `python scripts/hotspot_guard.py --root <repo> --baseline-ref <approved baseline> <changed-file>...` as part of fresh review evidence.
4. Treat new or worsened maintainability `FAIL` results on touched functions as blocking review findings.
5. Treat `hotspot_guard.py` `BLOCK` findings on touched files as blocking review findings. Touched legacy `WARN` hotspots remain debt, not automatic gate failure, but must be recorded in the review artifact for backlog sync.
6. Delegate to `code-minimality-reviewer`.
7. On issues, feed structured findings back to `tdd-enforcer` for targeted fixes within retry budget, then escalate.

Record phase result in the completion report with verdict, artifacts, maintainability evidence summary when applicable, and timestamp.

### Phase 8.5: Deployment Gate

Runs after code review passes and before marking the pipeline complete. Applies when IaC files exist in the repository.

1. Check whether the repo contains IaC files such as Terraform, Bicep, Helm, or Docker Compose.
2. If none exist, skip this phase and note it in the completion report.
3. If IaC exists, delegate to `c4-architecture-governor` in drift-detection mode.
4. On `NO-DRIFT`, proceed.
5. On `DRIFT-DETECTED`:
   - do not mark the pipeline complete
   - report drift findings explicitly
   - do not silently downgrade or skip this verdict
   - escalate to the user for resolution

Record phase result in the completion report with verdict, artifacts, and timestamp.

### Phase 9: Status Sync

1. If `petitions/program-status.yaml` exists, or the repo uses planning-state tracking, delegate to `sprint-tracker`.
2. Ask it to refresh persisted status for the petition or implementation slice that completed.
3. If status sync fails in a planning-managed repo, report blocker explicitly.
4. After `sprint-tracker` confirms the petition is `done`, no further status update is needed in this phase.

Record phase result in the completion report with verdict, artifacts, and timestamp.

### Phase 9.5: Branch / PR / Merge

Runs after status sync and before optional release.

1. If this run changed repository contents, ensure the branch name is suitable for PR delivery.
2. Prepare or update PR summary with:
   - petition ID and title
   - delivered scope
   - major artifacts changed
   - quality gate summary
3. Default outcome is a PR-ready branch.
4. Do not merge directly into the default branch without PR unless the user explicitly requests exception handling.
5. If merge is still pending, report `Ready for PR / merge` and treat release as blocked until the merge path is resolved.

Record phase result in the completion report with branch name, PR readiness, merge status, and timestamp.

### Phase 10: Release (optional)

If the user requested release, or if all petitions in the current sprint are now implemented or validated:

1. Delegate to `release-manager` in execute-release mode.
2. Pass petition IDs delivered through this run.
3. On successful deploy and smoke tests, petition status transitions to `released`.
4. On deploy or smoke failure, stop, report the failure, and note that rollback is available.

If release was not requested, skip with note:
`Release not requested. N petitions are ready for release. Run release-manager to deploy.`

Record phase result in the completion report with verdict, release version when executed, deploy status, and smoke test results.

### Phase 11: Completion Report

Assemble the final summary for the run. Do not use completion language until every readiness claim in the summary is supported by fresh evidence from this run.

If you write a long-form petition completion guide, status report, or implementation note, save it under `petitions/`, not in the repository root. Canonical paths are:

- `petitions/completion/petition<ID>-completion-guide.md`
- `petitions/status/petition<ID>-status-report.md`
- `petitions/implementation/petition<ID>-implementation.md`

Before finalizing the report:

- if resolved `goal_verification` is `true`, run an explicit final verification-gate pass for every readiness claim being made
- if resolved `goal_verification` is `false`, you may avoid a duplicate recap pass only when each readiness claim was already freshly verified in this run; never use `false` to bypass mandatory evidence checks or imply readiness from stale proof

Especially verify:

- tests pass
- review passed
- PR-ready
- release-ready or released

For each claim:

1. restate the exact claim
2. identify the proving command, artifact, or report
3. inspect the full proof source in this run
4. reject the claim as `needs_more_evidence` if proof is stale, partial, or only delegated summary language

When applicable, the proof set must also include:

- contract-drift artifact from Phase 7.5
- runtime-integration artifact from Phase 7.7

If required test, lint, build, or smoke commands were not actually run in this run, do not claim the stage, branch, or release is ready.

If telemetry is mentioned in the completion report:

- only treat rows with `source: harness_measured` or `source: provider_export`
  as measured token or cost evidence
- treat rows with `source: self_reported` or `source: unmeasured` as non-headline coverage evidence only
- require a non-empty `measurement_uri` for measured rows
- report missing or low-trust coverage explicitly when measured rows are absent
- never invent token counts from stage count, prompt length, tool-call count,
  or delegated summaries
