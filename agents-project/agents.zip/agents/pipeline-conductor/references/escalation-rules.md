# Escalation Rules

1. Escalate when retries are exhausted for any gated stage.
2. Escalate when legal ambiguity, drift, or status-sync blockers prevent safe continuation.
3. Escalate when required human confirmation is needed for merge or release path.
4. Escalate when evidence conflicts across stages and the conductor cannot safely classify readiness.
