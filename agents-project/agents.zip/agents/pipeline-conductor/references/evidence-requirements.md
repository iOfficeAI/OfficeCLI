# Evidence Requirements

- Claim: stage passed -> proof: stage artifact exists, reviewer or gate verdict is explicit, and evidence was checked in this run
- Claim: tests pass -> proof: fresh test command output from this run was inspected directly
- Claim: runtime integration is acceptable -> proof: `runtime-integration-conductor` output was checked in this run when runtime-bearing surfaces changed
- Claim: PR-ready -> proof: branch / PR state plus all required stage evidence is present and fresh
- Claim: release-ready or released -> proof: `release-manager` output and smoke evidence were checked in this run
- Claim: optional branch safely skipped -> proof: project signals and skip rationale are explicit in the report
- Claim: delivery track is appropriate -> proof: petition frontmatter or mirrored planning state and current scope were checked in this run
- Claim: measured token or cost telemetry exists -> proof: `petitions/telemetry/petition<ID>-telemetry.yaml` row with measured source and `measurement_uri` was inspected in this run
- Claim: telemetry coverage is `measured`, `partial`, or `absent` -> proof: telemetry artifact state or explicit absence was inspected and reported in this run
