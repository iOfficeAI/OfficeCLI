# Preconditions

1. Required petition artifacts exist and are non-empty.
2. The petition scope has been read before any stage recommendation is made.
3. The branch strategy and evidence rules are understood before repository-changing work begins.
