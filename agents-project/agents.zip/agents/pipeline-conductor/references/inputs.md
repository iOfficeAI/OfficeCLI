# Inputs

### Required

- `petitions/petition<ID>.md`
- `petitions/petition<ID>-outcome-contract.md`
- `petitions/petition<ID>.feature`

### Optional

- `domain/concept-model.yaml`
- `compliance/nfr-register.yaml`
- `design/solution-architecture-<ID>.md`
- `architecture/workspace.dsl`
- `architecture/policies.yaml`
- Catala artifacts from prior runs
- `.factory/project.yaml`
- `.factory/services.yaml`
- `petitions/program-status.yaml`
- petition-local `delivery_track` or mirrored planning-state track when present
- `petitions/telemetry/petition<ID>-telemetry.yaml`
- harness-measured usage export or provider usage report for this run
- `.factory/context/*.md`
