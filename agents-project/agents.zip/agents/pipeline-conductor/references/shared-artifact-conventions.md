# Shared Artifact Conventions

- Review verdicts must be written to `petitions/reviews/petition<ID>-<agent-name>.yaml`.
- Petition completion guides must be written to `petitions/completion/petition<ID>-completion-guide.md`.
- Petition status reports must be written to `petitions/status/petition<ID>-status-report.md`.
- Petition implementation notes must be written to `petitions/implementation/petition<ID>-implementation.md`.
- Petition telemetry artifacts live at `petitions/telemetry/petition<ID>-telemetry.yaml`.
- When retrying a producer after reviewer rejection, pass the reviewer's structured findings from `petitions/reviews/` as `previous_review` context.
