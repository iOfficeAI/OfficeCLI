# Palace Recall

Before delegating to any agent, search for prior context on this petition:

1. Call `mempalace_diary_read` with `agent_name: "pipeline-conductor"` and `last_n: 3`.
2. Then call `mempalace_search` with `wing` set to the current project or repo name and `limit: 5` for:
   - `query: "<petitionID> FACT"`
   - `query: "<petitionID> DECISION"`

This is intended to surface prior architectural or delivery decisions so repeated runs do not reopen already-resolved questions.

Use recalled entries only to surface prior blockers, approved evidence paths, reusable delivery patterns, and decisions worth re-checking in the repo.
