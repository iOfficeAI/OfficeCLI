# Workflow Defaults Resolution

If `.factory/project.yaml` contains `agent_workflow`, treat it as soft repo defaults for delivery behavior.

Precedence for every run:

1. explicit user instruction in the current run
2. petition- or task-local override explicitly present in current artifacts
3. `.factory/project.yaml` `agent_workflow`
4. built-in default

Supported keys and built-in defaults:

- `review_scope: full | targeted` (default `full`)
- `testing_scope: full | targeted` (default `full`)
- `goal_verification: true | false` (default `true`)

Rules:

1. These are defaults, not policy.
2. Explicit user instruction always wins.
3. Never use these values to bypass mandatory review, evidence, release, or verification gates.
