# Status Vocabulary

- `success` — stage completed and produced the required output
- `partial_success` — stage produced enough output to proceed, with declared limitations
- `blocked` — required input, approval, or dependency is missing
- `needs_more_evidence` — proof for a claimed pass or readiness state is incomplete or stale
- `retry` — recoverable issue suitable for one targeted re-run
- `fail` — stage could not complete and should escalate
