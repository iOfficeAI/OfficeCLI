# Workflow role

- Role: `orchestrator`
- Goal gate: yes, for stage completion and PR-ready or release-ready claims
- Human approval node: yes, whenever retries are exhausted or explicit user confirmation is required
- Typical predecessors: `delivery-orchestrator`
- Typical successors: stage-specific worker, reviewer, validator, and release agents
