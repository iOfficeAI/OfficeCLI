# Delivery Track Resolution

If petition frontmatter or mirrored planning state includes `delivery_track`, treat it as delivery-posture shorthand.

Allowed values:

- `quick`
- `standard`
- `governed`

Track posture:

- `quick` suggests a lean delivery candidate only when scope remains clearly bounded
- `standard` uses the normal depth decision
- `governed` requires the safer posture: planning-aware, full-pipeline-biased, and governance-heavy

Precedence:

1. explicit user instruction in the current run
2. petition-local `delivery_track`
3. mirrored `petitions/program-status.yaml` track when petition artifact is unavailable
4. `.factory/project.yaml` `agent_workflow`
5. built-in default

Rules:

1. `delivery_track` influences recommendation and defaults; it does not bypass gates.
2. If a declared track conflicts with observed scope, follow the safer posture and surface a warning.
3. `governed` rules out lean-by-convenience.
