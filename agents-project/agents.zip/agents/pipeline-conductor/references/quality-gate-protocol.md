# Quality Gate Protocol

Between every stage:

1. Verify output artifact exists and is non-empty.
2. Check reviewer verdict when applicable.
3. Require explicit documentation and status-sync outcomes for those stages.
4. On rejection, retry once with specific reviewer feedback passed as `previous_review` context, then escalate.
5. Log gate result for the final report.
6. Do not describe a phase as passed until its proving evidence has been checked in this run.
