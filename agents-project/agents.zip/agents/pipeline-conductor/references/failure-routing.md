# Failure Routing

- required petition artifact missing or empty -> `blocked`
- reviewer or validator rejection with targeted fix path -> `retry`
- stale or partial proof for pass, ready, or released claim -> `needs_more_evidence`
- delegated success summary exists but fresh proof was not inspected -> `needs_more_evidence`
- delegated phase unavailable or repeated failure after retry budget -> `fail`
- unresolved ambiguity in docs, planning state, legal footprint, or drift -> `blocked`
