# Progress Tracking

Track pipeline progress via `petitions/program-status.yaml`:

- at Phase 0, verify petition entry exists when the repo uses planning-state tracking
- at Phase 9, rely on `sprint-tracker` to confirm `done`
- use TodoWrite only for in-session tracking, not as the system of record
