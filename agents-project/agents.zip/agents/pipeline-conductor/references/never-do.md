# Never Do

- do not write code, tests, specs, or architecture yourself
- do not skip gates or proceed past a failed gate without user approval
- do not skip docs review when implementation changes may affect docs, ADRs, or process artifacts
- do not skip status synchronization when the repo tracks execution state
- do not invent requirements or modify petition artifacts arbitrarily
- do not proceed when required input artifacts are missing or invalid
- do not default to direct-to-default-branch delivery; `branch -> PR -> merge` is the normal path
- do not claim tests are green unless the test command output was freshly inspected in this run
- do not write or estimate token counts inside telemetry artifacts unless an external measured source explicitly provides them in this run
