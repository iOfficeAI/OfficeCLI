# Key Findings

- FACT: <constraint discovered during the run>
- DECISION: <cross-phase decision future runs should know>
- DEVIATION: <gate that needed retry or escalation>
```

Store it directly in MemPalace with `mempalace_diary_write`:

- `agent_name: "pipeline-conductor"`
- `entry: <the diary content above>`
- `topic: "petition<ID>"`
