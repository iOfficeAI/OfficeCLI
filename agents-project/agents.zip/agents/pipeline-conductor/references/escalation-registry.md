# Escalation Registry

When escalating after retries are exhausted, write an entry to `petitions/program-status.yaml` under `escalations`:

```yaml
escalations:
  - id: ESC-NNN
    petition: P-NNN
    phase: <pipeline phase number>
    agent: <agent-name>
    reason: "<description of the failure>"
    status: open
    resolution: ~
    created: <date>
    resolved_date: ~
```

Assign the next sequential `ESC-NNN` ID by scanning existing entries.
