# Git Delivery Default

For petition delivery that changes repository contents, default git path is:

`petition branch -> pull request -> merge`

Rules:

1. Before the first repository-changing stage, ensure work is happening on a dedicated branch such as `petition/<ID>-<slug>`.
2. If the current branch is already non-default, continue there and treat it as the PR branch.
3. Direct-to-default-branch delivery is exception-only and requires explicit user instruction or repository policy.
4. After quality gates pass, the branch should be prepared for PR. Merge is the normal completion path before release is considered complete.
