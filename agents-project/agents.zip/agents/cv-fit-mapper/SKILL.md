---
name: cv-fit-mapper
description: "Use when extract requirement, methods/tools, candidate reference anchors, and candidate-fit obligations from the active RFP and map them to evidence, project context, and active win themes."
workflow_role: worker
workflow_binding: contract_only
primary_outputs:
  - methods/tools extraction
  - requirements register
  - candidate reference index
  - active win themes
  - candidate fit matrix
  - fit gap log
default_next:
  success: cv-reference-optimizer or cv-red-team-reviewer
  partial_success: human approval boundary
  blocked: user escalation or source repair
  needs_more_evidence: missing candidate proof or unclear requirement
  fail: rerun after source repair
---

# Purpose

Turn the active RFP and candidate evidence into a structured fit view. This node extracts requirement-bearing content, methods/tools expectations, candidate-owned reference anchors, active win themes, candidate fit signals, and explicit gaps. It does not draft the final response.

## Workflow role

- Role: `worker`
- Binding: `contract_only`
- Goal gate: no
- Human approval node: yes, when a requirement appears score-critical but candidate proof is weak
- Typical predecessors: `cv-intake-normalizer`, `cv-project-context-discoverer`, `cv-history-curator`
- Typical successors: `cv-reference-optimizer`, `cv-response-drafter`, `cv-red-team-reviewer`

## Inputs

### Required

- `rfp/active/<RFP-ID>/request/current-rfp.md`
- `rfp/active/<RFP-ID>/request/candidate-cv.md`

### Optional

- `rfp/active/<RFP-ID>/request/previous-rfp.md`
- `rfp/active/<RFP-ID>/request/previous-response.md`
- `rfp/active/<RFP-ID>/request/style-pack-resolved.yaml`
- `rfp/active/<RFP-ID>/context/selected-context.md`
- `rfp/active/<RFP-ID>/context/historical-patterns.md`
- `rfp/active/<RFP-ID>/context/historical-win-themes.md`

## Preconditions

1. Current RFP and candidate CV exist and are readable.
2. Requirement IDs and evidence hooks must be explicit.
3. Unsupported requirements must be logged, not smoothed over.

## Procedure

1. Read current RFP and candidate CV in full.
2. When `style-pack-resolved.yaml` exists, use terminology and scoring guidance to sharpen requirement interpretation and hint-ceiling selection without changing the evidence standard.
3. Extract methods/tools expectations and write them as a standalone artifact.
4. Build a requirements register with:
   - requirement id
   - source citation
   - category
   - mandatory or score-bearing signal
5. Build `candidate-reference-index.yaml` from candidate-owned sources such as:
   - candidate CV projects and assignments
   - previous response sections that clearly refer to the same candidate
   - approved project context that explicitly ties the candidate to the work
6. For each candidate reference, record:
   - reference id
   - source path
   - short project/domain summary
   - stakeholder or delivery context
   - methods/tools already evidenced
   - evidence strength
   - disallowed extrapolations
7. Write `active-win-themes.yaml` by selecting which historical themes actually fit the active RFP, with:
    - theme id
    - target requirement ids
    - why the theme is relevant now
    - candidate evidence anchors needed to support it
    - misuse risks
8. Write `hint-ceilings.yaml` for weak but writeable competency areas with:
   - competency or requirement id
   - hint signal anchor
   - signal strength
   - assertion ceiling
   - ceiling rationale
   - preferred bounded phrasing
   - phrasing to avoid
9. Build a fit matrix that maps each requirement to:
    - candidate evidence
    - candidate reference ids
    - supporting project-context hint if relevant
    - relevant active win theme if relevant
    - confidence and proof status
10. Write `fit-gaps.md` for:
   - unsupported requirements
   - ambiguous wording
   - likely evaluator objections
   - thin but potentially adaptable reference matches
   - claims that require human confirmation
   - `machine_gap_statement`: explicit internal evidence gap language
   - `draft_safe_bounded_phrase`: optional neutral external phrasing that does not add facts
   - `hinted_competency_signal`: weakest non-contradictory evidence anchor that can still be written up
   - `assertion_ceiling`: `exposure`, `applied_support`, or `demonstrated_ownership`
   - `ceiling_rationale`: why the selected ceiling is the highest safe level
   - `phrasing_to_avoid`: deficit or bluffing wording to avoid in draft prose
11. If strong support is missing but a non-contradictory hint exists, classify it as hint-supported with a bounded write-up path and assertion ceiling. Only classify as hard unsupported when no safe signal exists.

## Output Contract

### Artifacts

- `rfp/active/<RFP-ID>/extraction/methods-tools.md`
- `rfp/active/<RFP-ID>/extraction/requirements-register.yaml`
- `rfp/active/<RFP-ID>/extraction/candidate-reference-index.yaml`
- `rfp/active/<RFP-ID>/extraction/active-win-themes.yaml`
- `rfp/active/<RFP-ID>/extraction/hint-ceilings.yaml`
- `rfp/active/<RFP-ID>/extraction/fit-matrix.yaml`
- `rfp/active/<RFP-ID>/extraction/fit-gaps.md`

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` - methods/tools extraction, requirements register, and fit matrix were produced
- `partial_success` - the fit view is usable but one or more score-critical gaps need human judgment
- `blocked` - required source material is missing or too contradictory to map safely
- `needs_more_evidence` - candidate proof or requirement clarity is too thin for a safe fit claim
- `fail` - extraction failed because inputs were unusable

## Done Criteria

1. Methods/tools extraction exists.
2. Requirements register includes source citations.
3. Candidate reference index captures reusable candidate-owned anchors plus extrapolation limits.
4. Active win themes are selected for the current RFP rather than assumed from stale wins.
5. Hint ceilings exist for weak but safely writeable competency signals.
6. Fit matrix maps every requirement to evidence or an explicit gap.
7. Fit gaps are surfaced clearly with explicit internal gap statements, hint signals, and assertion ceilings for safe drafting.

## Evidence Requirements

- Claim: a requirement exists -> proof: cited RFP text in the requirements register
- Claim: the candidate supports a requirement -> proof: candidate CV or other cited source path recorded in the fit matrix
- Claim: a win theme applies now -> proof: the active win theme cites the historical theme id plus current requirement ids and candidate evidence anchors
- Claim: a gap exists -> proof: missing or ambiguous evidence was recorded in `fit-gaps.md` in this run
- Claim: a hint-supported competency can be written up safely -> proof: signal anchor and assertion ceiling were recorded in `hint-ceilings.yaml` in this run

## Failure Routing

- missing current RFP or candidate CV -> `blocked`
- ambiguous score-critical requirement -> `needs_more_evidence`
- unsupported score-critical claim -> `partial_success`
- unusable input artifacts -> `fail`

## Escalation Rules

1. Escalate when a mandatory or high-weight requirement has no safe evidence path.
2. Escalate when project context or historical patterns suggest a risky mismatch with the candidate profile.

## Never Do

- never invent candidate experience or tooling familiarity
- never treat historical patterns as direct proof of candidate fit
- never turn a weakly similar candidate reference into proof without recording the actual evidence anchor and extrapolation limits
- never hide a weak fit behind generic wording or ceiling-free write-up

