# AI-First Governed Delivery: The Complete Framework

*A synthesis of Architecture in Motion (AIM), the Zero Repetition Bank (ZRB) model, and the AI-first SDLC pipeline into a single, coherent operating model.*

---

## The Proposition

Three bodies of work now exist that each address a different dimension of the same problem: how organisations build, change, and govern software in an era of AI-assisted execution.

| Component | Dimension | Core question answered |
|---|---|---|
| **AI-First SDLC** (`ai-first-sdlc-e2e.md`) | Delivery engine | How is software produced, governed, and released under AI orchestration? |
| **AIM** (`~/Documents/Github/aim`) | Architectural intelligence | What are the architectural risks of a change, and what evidence supports the decision? |
| **ZRB** (`docs/zrb.md`) | Governance substrate | How are policy, compliance, and data governance enforced without manual repetition? |

Individually, each is coherent and defensible. Together they close gaps that none of them resolves alone. The AI-First SDLC relies on ZRB's PaC/DCaC/DMaC layer but does not specify how that policy content is produced or validated. ZRB provides the enforcement pattern but does not specify how software is delivered within it. AIM provides architectural intelligence but does not yet describe how that intelligence is consumed by a delivery pipeline or how its findings are translated into governance rules.

This document proposes the integrated framework, names the integration points, and describes what each component contributes and what it requires from the others.

---

## The Three-Layer Model

```
╔══════════════════════════════════════════════════════════════════╗
║  LAYER 3 — DELIVERY ENGINE           AI-First SDLC Pipeline     ║
║                                                                  ║
║  Intent → Petition → Spec → Code → Gate → Stabilise → Release   ║
║  Architect–Padawan Cell  |  Super-user layer  |  Ops feedback    ║
╠══════════════════════════════════════════════════════════════════╣
║  LAYER 2 — ARCHITECTURAL INTELLIGENCE   AIM Platform             ║
║                                                                  ║
║  Stressor catalogue  →  L1/L2/L3 impact evidence  →  ADR draft  ║
║  Trade-off tables  |  Confidence calibration  |  Drift alerts    ║
╠══════════════════════════════════════════════════════════════════╣
║  LAYER 1 — GOVERNANCE SUBSTRATE         ZRB / EaC               ║
║                                                                  ║
║  Policy-as-Code (PaC)  |  Data-Contract-as-Code (DCaC)          ║
║  Data-Management-as-Code (DMaC)  |  Infrastructure-as-Code      ║
║  Continuous enforcement  |  Automated evidence generation        ║
╚══════════════════════════════════════════════════════════════════╝
```

**Layer 1 (ZRB) runs under everything.** It is the machine-readable substrate that the delivery engine and the intelligence layer both depend on. It converts compliance from a periodic evidencing activity into a continuously enforced and continuously observable system state.

**Layer 2 (AIM) feeds the delivery engine.** It answers the architectural question *before* a petition reaches the execution phase, and validates the evidence *after* a change is live. It turns architectural decision-making from a gatekeeper conversation into a structured, evidence-graded reasoning service.

**Layer 3 (AI-First SDLC) acts on the outputs of both.** It takes AIM's stressor analyses and ADR candidates as inputs to elicitation and specification, enforces ZRB's PaC/DCaC/DMaC at every gate, and produces the operational feedback signals that flow back into both.

---

## Integration Map

Each integration point is bilateral. Both the producing and consuming side have obligations.

### AIM → Delivery Pipeline

| AIM output | Where it enters the SDLC | What it replaces or strengthens |
|---|---|---|
| Stressor catalogue for a domain | Phase 1 — Elicitation: Senior Architect runs AIM against the concept model before writing the petition | Informal architectural instinct → structured, cited risk inventory |
| L1 impact analysis | Gate G1 — Scaffold Review: impact claims are an explicit artefact of the spec gate | Architecture trade-offs buried in ADRs → visible, evidenced claims |
| L2 proto-experiment results | Gate G2 — Code Review: L2 evidence validates implementation-level architectural claims | "We think this is safe" → "we tested this under fault injection" |
| L3 pre-production experiment results | Gate G5 — Canary: L3 evidence is a required input before full rollout of any petition with L2+ stressors | Manual pre-launch review → canary backed by chaos experiment evidence |
| ADR drafts | Phase 2 — Specification: AIM-generated ADR candidates are reviewed at G1 and committed as constraints | Architect writes ADR from scratch → AIM proposes, Architect decides |
| Drift alerts | Phase 7 — Operations: AIM drift alerts trigger new petitions or CRs | Operational surprise → structured feedback loop |
| Architectural analytics | Architect Guild dashboard: cross-petition view of stressor recurrence, mitigation coverage, ADR health | Ad hoc guild discussions → data-informed governance |

### Delivery Pipeline → AIM

| SDLC output | How AIM uses it | Benefit |
|---|---|---|
| Merged petition artefacts (spec, tests, code) | AIM Knowledge Base update: new patterns and decisions indexed for future stressor triangulation | AIM learns from real delivery outcomes |
| Operational incident signals (Phase 7) | Stressor engine ingestion: incidents become evidence for stressor prioritisation | AIM's incident taxonomy stays grounded in production reality |
| Petition concept model deltas | KB reindexing: concept model changes trigger KB hygiene review (AIM-P007 quarterly cycle) | KB does not drift from the delivered domain model |
| Gate refusals and rework events | AIM evidence registry: failed gate evidence feeds back into impact calibration | Confidence calibrator improves over actual delivery track record |

### ZRB → Delivery Pipeline

| ZRB mechanism | Where it enforces in the SDLC | Effect |
|---|---|---|
| PaC evaluation | G2 (Code Review) and G3 (Merge Approval): every PR is evaluated against the PaC store; non-conformant PRs are blocked | Compliance is structural, not manual |
| DCaC validation | G3 and every deployment: data contracts validated before any change reaches production | Data flow integrity enforced at delivery time, not audit time |
| DMaC runtime enforcement | Phase 7 — Operations: data management policies evaluated continuously against live flows | Compliance drift detected in real time, not periodically |
| Automated DPIA evidence generation | Phase 4 — Verification: compliance artefact generation is automated as part of the pipeline | 50–60 hour manual DPIA effort → automated evidence, human review of exceptions |
| Infrastructure-as-Code validation | Platform Cell: all infrastructure changes validated against PaC before provisioning | Design-reality gap eliminated by construction |

### Delivery Pipeline → ZRB

| SDLC output | How ZRB uses it | Benefit |
|---|---|---|
| New petition with legal / regulatory scope | Policy Translation Gate: petition → PaC stub generated by `policy-to-PaC` agent, reviewed by policy owner + security SME | PaC stays current with each delivery cycle |
| Architecture changes (ADRs, C4 deltas) | PaC store update: architectural invariants from ADRs become new PaC rules | Architectural governance is encoded, not documented |
| Super-user fixes (SU-NNN petitions) | DMaC re-evaluation: any super-user change touching data flows triggers DMaC re-check | Super-user scope boundary enforced by the governance substrate |
| Operational anomaly reports | ZRB's datafication layer: runtime signals feed compliance dashboards and trigger policy review cycles | Continuous improvement cycle is data-driven, not review-calendar-driven |

### AIM → ZRB

| AIM output | ZRB use | Benefit |
|---|---|---|
| L1/L2/L3 evidence for architectural claims | PaC calibration: impact evidence validates whether existing PaC rules cover the identified stressors | PaC is grounded in architectural evidence, not author instinct |
| Stressor catalogue | New PaC candidates: stressors with no existing PaC coverage become policy authoring inputs | Policy gaps surface before incidents, not after |
| ADR decisions | PaC derivation: the design choices formalised in ADRs become enforceable PaC rules through the Policy Translation Gate | Architecture decisions persist as machine-checked invariants |
| Architectural analytics | ZRB datafication layer: AIM's stressor recurrence and mitigation coverage metrics are part of the compliance data estate | The datafication pillar of ZRB is populated from evidence, not from forms |

---

## How the Three Layers Interact at Each SDLC Phase

### Phase 0 — Ideation
- ZRB: Not yet active; policy stack must exist before Phase 1 begins.
- AIM: `idea-evaluator` queries AIM stressor catalogue to challenge the brief against known architectural risks in the target domain. The brief must name which stressor classes apply.
- SDLC: `ideation` agent produces brief. G0 gate requires AIM stressor screening result attached.

### Phase 1 — Elicitation
- AIM: Senior Architect runs AIM against the concept model for the petition scope. Produces a scoped stressor shortlist with plausibility labels. L1 impact analysis begins.
- ZRB: Senior Architect identifies which PaC tiers apply (Tier A statutory, Tier B operational, Tier C guidance) and whether this petition requires a policy delta.
- SDLC: Petition is authored by the Architect. Petition *must* cite AIM stressor IDs and the applicable ZRB policy tiers. Agents cannot write the petition.

### Phase 2 — Specification (G1 gate)
- AIM: L1 impact claims for the petition's stressor set are reviewed at G1. Claims carry evidence badges. Speculative claims are labelled and require explicit architect acknowledgement.
- ZRB: `c4-model-validator` runs in warn mode. PaC delta candidates (generated by `policy-to-PaC` agent) are included in the G1 artefact pack.
- SDLC: G1 gate requires: outcome contract, Gherkin, spec, AIM L1 impact summary, PaC delta candidates, and C4 fit. No production code until all five are present.

### Phase 3 — Execution (agent swarm)
- AIM: L2 proto-experiments (fault injection, latency replay) run in parallel with implementation for petitions with medium or high stressor plausibility. L2 evidence targets are set at G1.
- ZRB: DCaC stubs are generated alongside code for any petition touching data flows. PaC stubs are drafted for new policy requirements.
- SDLC: `tdd-enforcer` / `portal-tdd-enforcer` implement against spec. Architecture governor runs in enforce mode.

### Phase 4 — Verification (G2 / G3 gates)
- AIM: L2 experiment results are evaluated. If L2 evidence changes the impact claim, the spec must be updated and G1 re-run for the affected scope. AIM generates automated DPIA evidence as a Phase 4 artefact.
- ZRB: PaC evaluation runs on every PR. DCaC validation runs before G3. Failing evaluations block merge — no exceptions without two-person override and mandatory TB item.
- SDLC: G2 requires: AIM L2 evidence summary (or documented deferral with TB item), automated review green, PaC/DCaC evaluation green. G3 requires docs, program-status update, and release notes.

### Phase 5 — Stabilisation (super-user layer)
- AIM: Super-user fixes that touch components with active L1 stressors are flagged. If a fix touches an AIM-stressor-covered component, it triggers an L1 re-check before S1 gate.
- ZRB: Super-user scope whitelist is enforced by PaC. Any super-user PR touching out-of-scope zones is auto-blocked and escalated.
- SDLC: Every SU-NNN fix is a traceable petition. No silent persistence.

### Phase 6 — UAT / Rollout (G4 / G5 / G6)
- AIM: For petitions with high-plausibility stressors, L3 canary experiment evidence is a G5 prerequisite. L3 provides chaos-validated confidence before full rollout.
- ZRB: DMaC runtime monitoring is armed before G6. Rollout without DMaC enforcement active for affected data flows is blocked.
- SDLC: Change Manager leads UAT cohort; canary auto-rollback is wired to both observability signals and AIM drift alerts.

### Phase 7 — Operations
- AIM: AIM's Integration Bus (port 8010) ingests operational signals. Drift alerts are triggered when live behaviour deviates from L1/L2 claims. Drift alerts above severity threshold emit petitions automatically.
- ZRB: DMaC evaluates data flows continuously. PaC evaluates infrastructure continuously. Compliance-drift events above threshold emit CRs.
- SDLC: `hotfix-conductor` handles P1 incidents. Retroactive full-pipeline pass is mandatory. Observability agent summarises Phase 7 into the feedback digest.

### Phase 8 — Feedback Loop
- AIM: Operational incidents ingested into stressor taxonomy. L1 calibration updated. Quarterly KB hygiene review triggered.
- ZRB: Datafication layer updated with new runtime signals. AI pillar of ZRB uses this data to surface new automation opportunities and policy gaps.
- SDLC: Every signal is filed as a petition, CR, or hotfix; or silenced with a rationale ADR; or escalated. Nothing disappears. The loop closes.

---

## What Each Component Still Needs

The integration is not complete out of the box. Three specific pieces are required to make it operational.

### 1. The Policy Translation Gate (ZRB → Pipeline bridge)

The AI-First SDLC spec calls for a `policy-to-PaC` agent. This is the bridge that makes ZRB's governance substrate self-sustaining under AI-first delivery. Without it, ZRB's PaC store grows stale whenever a new regulatory interpretation, ADR, or architecture decision should produce a new rule.

The gate works as follows: petition or ADR text with policy implications → `policy-to-PaC` agent produces a PaC stub → Policy Owner + Security SME review → PaC merged with petition or ADR.

Tier A policies (statutory, hard constraints) require formal checks. Tier B (operational) require conformance tests. Tier C (guidance) become soft guardrails in agent prompts.

### 2. AIM as a pipeline participant, not just a standalone platform

AIM currently runs as a standalone service accessed by architects. To serve the delivery pipeline, it needs two integration modes:

1. **Pre-petition mode**: Given a concept model, domain, and initial petition scope, return a scoped stressor shortlist with L1 plausibility. Consumed by Senior Architect at Phase 1.
2. **Gate artefact mode**: Given a specification and component set, return the current L1/L2 impact summary for the affected stressor IDs. Consumed by the pipeline conductor at G1 and G2.

This does not require AIM to change its architecture. It requires a defined API contract and a stable evidence artefact format that the pipeline can consume and include in gate packs.

### 3. The Evidence Continuity Contract

AIM's evidence is only useful if the delivery pipeline treats it as a tracked artefact with a lifecycle. This means:

- Stressor IDs cited in a petition persist through gates, implementation, and operations.
- L1/L2/L3 evidence for those IDs is linked to the petition and preserved in the evidence registry.
- Operational incidents are tagged with the stressor IDs they actualise.
- Gate acceptance requires the evidence level to meet the petition's stated risk threshold (defined at G1).

Without this contract, AIM evidence becomes a one-time document rather than a living chain of custody.

---

## What Remains Domain-Conditioned

Not every element of the integrated framework applies uniformly. The table below identifies which components are universal and which are tuned per domain.

| Universal | Domain-conditioned |
|---|---|
| Petition → outcome contract → Gherkin → spec flow | Catala encoding (only where statute *is* the spec) |
| AIM L1 impact screening before every petition | AIM L3 experiment evidence as G5 prerequisite (high-risk domains only) |
| PaC evaluation at G2/G3 | Specific policy engine (OPA vs Sentinel vs custom) |
| DCaC validation before every deployment | Rigsarkivet / archival compliance agents (Danish public sector) |
| Every fix is a petition | Super-user scope whitelist (depends on regulatory tolerance for citizen-developer access) |
| AIM drift alerts emit petitions | Automated DPIA evidence generation (GDPR-scoped domains; banking and public sector) |
| Architect–Padawan Cell as delivery atom | Cell size (shrinks for narrow scope; controls do not shrink) |

---

## The Integrated Framework in One Sentence

> *AI-first delivery governs itself through a machine-enforced policy substrate (ZRB), reasons about architectural risk through evidence-graded intelligence (AIM), and executes through a petition-driven, gate-constrained, human-owned delivery pipeline — where these three layers are not separate capabilities but a single operating system for software change.*

---

## Implications for EY / Consulting Practice

The practical value of the integrated framework is not that it offers more complexity. It is that it makes three independently valid claims into a single client offering:

1. **"We eliminate your compliance repetition"** — ZRB, with a concrete DPIA and IaC case.
2. **"We make your architectural decisions evidenced, not intuitive"** — AIM, with the L1/L2/L3 ladder.
3. **"We redesign your delivery model around AI, not just add tools to it"** — the AI-First SDLC operating model.

The integrated version is stronger than any one pitch because it shows that these three concerns reinforce each other rather than competing for the same budget.

A CIO who sees only the SDLC story worries about losing architectural quality as execution speeds up. AIM closes that gap. A CIO who sees only the ZRB story worries about compliance becoming a bottleneck in a faster pipeline. The SDLC's Policy Translation Gate and automated evidence generation close that gap. A CIO who sees only the AIM story worries that the evidence is only as good as the process that acts on it. The SDLC pipeline makes acting on AIM evidence structurally required, not optional.

### Minimum viable integration for a pilot

A pilot does not require all three at full depth. The minimum viable integration is:

1. Stand up one Cell with petition flow, G1–G3 gates, and PaC at minimum (ZRB Tier B level).
2. Run AIM stressor screening before the first petition is written. Attach the stressor shortlist to the petition.
3. Include the AIM L1 impact summary in the G1 artefact pack. Architect attests that the impact claims are acceptable.
4. Measure: defect leakage, architectural surprises in production, time spent on compliance evidence, Padawan progression.

That is sufficient to validate the integration hypothesis without requiring full ZRB automation, full L2/L3 evidence chains, or complete DCaC coverage.

---

## Suggested Next Step

This document is a proposal. The natural next move is to validate it as a petition against one of the active project tracks:

- **OpenDebt** already has the SDLC pipeline, PaC, and C4 model in place. The gap is AIM integration. A scoped petition to wire AIM's pre-petition stressor query into the elicitation phase would test the Phase 1 → G1 integration point in a real context.
- **AIM** has AIM-P013 (operating model), AIM-P007 (governance/safety), and AIM-P014 (fitness functions) pending. Incorporating the delivery-pipeline integration contract described above into AIM-P013 would be a natural scope extension.
- **EY client pitch**: ZRB is already positioned for banking. The integrated framework extends the pitch from "auto-compliance" to "governed AI-first delivery" — a proposition that a CIO, CISO, and CTO can each find their piece of.

---

*Related documents: `ai-first-sdlc-e2e.md` (delivery engine), `docs/zrb.md` (governance substrate), `~/Documents/Github/aim/` (architectural intelligence platform), `The-Architect-Padawan-Model-Agentic-SDLC.md` (Cell model), `docs/software-development-automation-thesis.md` (automation frontier thesis).*
