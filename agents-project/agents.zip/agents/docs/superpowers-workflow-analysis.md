# Superpowers Review For Our Workflow

## Scope

Repo reviewed:

- `C:\Users\AJ849XF\Documents\GitHub\superpowers`

Question:

- Is there anything in `superpowers` we should bring into our workflow / agents?

Method used:

- repo structure scan
- readme / contributor guidance review
- skill review
- test harness review
- hook / portability review
- compare against our current petition-driven pipeline

---

## Executive Summary

Yes. There are several things worth taking, but not the whole model.

`superpowers` is strongest where our repo is still relatively weak:

1. behavioral test harnesses for agent instructions
2. explicit anti-slop contribution and PR rigor
3. reusable verification discipline as a first-class behavior rule
4. cross-platform hook portability patterns
5. isolated branch/worktree lifecycle ergonomics

It is weaker, for our purposes, in areas where we already have a more rigorous system:

1. requirements and approval flow
2. architecture governance
3. traceability
4. compliance / NFR handling
5. release governance

So the recommendation is:

- **import selected harness ideas**
- **do not replace our pipeline model**
- **treat `superpowers` as a workflow-evals and agent-discipline source**

---

## What Looks Strong

### 1. Agent behavior is tested as behavior, not just prose

This is the strongest thing in the repo.

Evidence:

- `docs/testing.md`
- `tests/claude-code/README.md`
- `tests/claude-code/test-helpers.sh`
- `tests/skill-triggering/run-all.sh`

What they do well:

- run real headless agent sessions
- parse transcripts instead of trusting user-facing text
- verify workflow ordering and tool usage
- separate fast trigger tests from slow integration tests
- measure token usage for long-running agent flows

Why this matters for us:

Our repo has many sophisticated controller/reviewer prompts, but almost no explicit **behavioral eval harness** for those prompts. We test the *software being built* far more than we test the *agent workflows that are supposed to build it*.

What to take:

- a `tests/agents/` or `tests/workflows/` harness for our own agents
- transcript-based checks for controller behavior
- fast prompt-trigger / routing tests
- slow integration tests for selected critical flows

Most valuable candidates to test first:

- `delivery-orchestrator`
- `pipeline-conductor`
- `hotfix-conductor`
- `change-request-conductor`
- `project-bootstrap`
- `janitor`

Recommendation:

- **Strong adopt**

---

### 2. Explicit verification discipline is packaged as a reusable skill

Evidence:

- `skills/verification-before-completion/SKILL.md`

The core idea is simple but powerful:

- no completion claims without fresh verification evidence
- no trusting agent reports without independent confirmation

We already believe this philosophically, but `superpowers` turns it into an explicit reusable behavioral module with clear red flags and anti-rationalization language.

Why this matters for us:

Our controllers and reviewer flows rely on verification, but the discipline is spread across many prompts. A reusable "verification gate" skill or shared rule could reduce drift and make completion behavior more consistent across all agents.

What to take:

- shared verification doctrine for all delivery agents
- standardized "evidence before claims" language
- a reusable checklist for final responses, commit readiness, PR readiness, and release readiness

Recommendation:

- **Strong adopt**

Likely form:

- a new `verification-gate.agent.md` or reusable shared rule
- referenced by controllers, janitor, release, and review agents

---

### 3. Contribution anti-slop guardrails are unusually good

Evidence:

- `CLAUDE.md`
- `.github/PULL_REQUEST_TEMPLATE.md`

This repo is extremely explicit about:

- problem-first PRs
- duplicate PR search
- human review before submission
- one-problem-per-PR
- eval evidence for behavior-shaping changes
- rejecting fabricated justification

Why this matters for us:

Our own agent repo now contains lots of behavior-shaping content. Those are effectively executable control systems, not just docs. We should probably protect them with stronger change discipline.

What to take:

- a PR template for this repo
- a contribution rule specifically for behavior-shaping agent changes
- requirement that prompt/skill/controller changes come with evidence or at least scenario-based validation notes

Recommendation:

- **Adopt, but adapt**

We do not need their tone. We do want their rigor.

---

### 4. Cross-platform hook portability pattern is genuinely useful

Evidence:

- `docs/windows/polyglot-hooks.md`
- `hooks/session-start`
- `hooks/run-hook.cmd`

The most transferable idea:

- if hooks/scripts are part of agent workflows, Windows must be a first-class citizen
- use wrapper patterns deliberately instead of assuming bash everywhere

Why this matters for us:

- user environment here is Windows
- we already care about hooks (`doc_sync_hook.py`, janitor wrappers, repo automation)
- our workflow is increasingly shell-assisted and multi-tool

What to take:

- cross-platform hook/script design guidance for our own repo
- wrapper patterns when hooks must run under different default shells
- a small `docs/windows/automation.md` or equivalent

Recommendation:

- **Adopt selectively**

Not every hook needs a polyglot wrapper, but our automation docs should be explicitly Windows-aware.

---

### 5. Branch/worktree lifecycle ergonomics are mature

Evidence:

- `skills/using-git-worktrees/SKILL.md`
- `skills/finishing-a-development-branch/SKILL.md`

What is good:

- isolate implementation work
- verify clean baseline before work
- structured finish flow
- explicit branch integration choices

Why this matters for us:

We recently improved our controllers to default to `branch -> PR -> merge`, but the actual **operator ergonomics** are still thin. `superpowers` has concrete branch-finalization and isolation patterns we could adapt.

What to take:

- optional worktree-based execution mode for long-running tasks
- standard end-of-branch integration checklist
- explicit local-vs-PR-vs-keep-vs-discard decisions for human-controlled work

Recommendation:

- **Adopt selectively**

This is more useful for ad hoc execution agents and janitor runners than for the main petition pipeline itself.

---

## What We Already Do Better

### 1. Requirements and delivery governance

Our petition → contract → Gherkin → specs → tests → implementation → review → release pipeline is much stricter and more enterprise-ready than `superpowers`' more general plan/execution approach.

Evidence of our stronger model:

- `delivery-orchestrator.agent.md`
- `pipeline-conductor.agent.md`
- `specs-translator.agent.md`
- `release-manager.agent.md`

Recommendation:

- **Do not replace**

---

### 2. Architecture-as-code and compliance

We already have stronger architecture and compliance machinery:

- C4
- policies
- NFR register
- reviewers/governors
- Catala path for legal footprint

`superpowers` does not really compete here.

Recommendation:

- **Keep our current approach**

---

### 3. Project bootstrap and stack-aware harnessing

Our recent blueprint + harness work is more structured than anything visible in `superpowers`.

We now encode:

- build/test/lint/e2e/docs defaults
- coverage targets
- report locations
- stack hints
- harness metadata

Recommendation:

- **Keep our current direction**

---

## What Not To Import

### 1. Mandatory skill invocation model

Evidence:

- `skills/using-superpowers/SKILL.md`

This is central to their plugin architecture, but it is too rigid for our current repo model.

Why not:

- our repo already has strong controller prompts
- our environment is mixed across agent systems
- mandatory "invoke skill before anything" is more plugin-runtime logic than workflow content

Recommendation:

- **Do not import directly**

Possible adaptation:

- reuse the spirit in narrower areas, not the full mechanism

---

### 2. Their brainstorming / design gate as a universal front door

Evidence:

- `skills/brainstorming/SKILL.md`

It is good, but our petition-driven process already covers this more formally.

Recommendation:

- **Do not import as-is**

Possible adaptation:

- use it as inspiration for improving non-petition ad hoc intake only

---

### 3. Tool-specific distribution surfaces right now

Evidence:

- plugin manifests / installation docs across Claude, Cursor, Copilot, Gemini, Codex, OpenCode

This is impressive, but not the highest-value next move for us unless we explicitly want to productize this repo as a cross-platform plugin.

Recommendation:

- **Defer**

---

## Recommended Imports

### Priority 1 — Build an agent/workflow eval harness

Create a small but real test harness for our workflow agents.

Suggested scope:

1. `tests/workflows/delivery-orchestrator/`
2. `tests/workflows/pipeline-conductor/`
3. `tests/workflows/hotfix-conductor/`
4. `tests/workflows/change-request-conductor/`
5. `tests/workflows/project-bootstrap/`
6. `tests/workflows/janitor/`

Suggested test types:

- fast trigger/routing tests
- transcript-based behavior checks
- integration tests for one or two golden paths
- a small token-usage analyzer if needed

This is the single best idea to take.

---

### Priority 2 — Add a reusable verification discipline module

Create a shared verification rule/skill for:

- completion claims
- commit readiness
- PR readiness
- release readiness
- janitor baseline advancement

This should be short, direct, and reusable across controllers and reviewers.

---

### Priority 3 — Add contribution rigor for agent-behavior changes

Add:

- `.github/PULL_REQUEST_TEMPLATE.md` in this repo
- clear sections for:
  - problem statement
  - affected agents
  - scenario/eval evidence
  - whether change affects behavior-shaping content
  - human review confirmation

Also add repo guidance:

- prompt/controller/skill wording changes are not "docs-only"
- they are workflow behavior changes and should be treated as such

---

### Priority 4 — Add Windows-aware automation guidance

Document:

- how our hooks/scripts should behave on Windows
- when to use Python as portability layer
- when thin shell wrappers are enough
- how to avoid bash-only assumptions in workflow automation

This is especially relevant after janitor runner and hook growth.

---

### Priority 5 — Add optional worktree mode for long-running automation

Not mandatory for all flows, but good for:

- janitor
- long-running branch work
- multi-branch parallel execution
- risky cleanup passes

Could be a separate helper or agent, not a replacement for current branch flow.

---

## Concrete Recommendation

If we only do three things from `superpowers`, do these:

1. **Agent/workflow eval harness**
   - biggest gap in our current repo

2. **Reusable verification-before-completion rule**
   - easiest high-value discipline improvement

3. **PR/contribution rigor for behavior-shaping agent changes**
   - protects this repo from prompt/agent drift and low-evidence edits

Everything else is secondary.

---

## Suggested Next Moves

### Option A — Small

- add `verification-before-completion`-style shared rule
- add PR template for this repo

### Option B — Medium

- add small workflow eval harness for `delivery-orchestrator` and `pipeline-conductor`

### Option C — Strategic

- create full `tests/workflows/` harness for controllers + janitor
- define transcript assertions and a golden-path regression suite

---

## Bottom Line

`superpowers` is not a better replacement for our pipeline.

But it **is** a better example of:

- testing agent instructions as executable behavior
- protecting behavior-shaping changes with evidence
- packaging verification discipline explicitly
- making agent tooling portable across environments

That is exactly where we should borrow from it.
