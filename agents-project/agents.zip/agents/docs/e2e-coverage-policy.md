# Playwright E2E Coverage Policy

## Purpose

This policy defines how browser E2E coverage is measured and governed in this
petition-driven delivery model.

Use this policy for projects with a browser UI and a Playwright-based E2E layer.
It aligns Phase 5 test generation, Phase 6.5 E2E acceptance, CR delta handling,
and release or hotfix smoke verification.

Companion starter pack: `docs/e2e-fitness-functions.md`

## Core Rule

Playwright E2E coverage is measured against:

- user journeys
- Gherkin scenarios
- `VAL-*` assertions in `validation-contract.md`
- browser and role combinations that the product actually supports

Playwright E2E coverage is **not** measured by line, branch, or statement
coverage percentages.

## Why

Line-coverage targets distort E2E behavior. They encourage broad, slow, brittle
tests that optimize a number instead of protecting business-critical flows.

The purpose of Playwright in this ecosystem is to protect:

- critical user promises
- real browser behavior
- end-to-end contract validation
- release confidence

## Coverage Units

| Unit | Meaning | Gate consequence |
|---|---|---|
| Gherkin scenario | One user-visible behavior slice | Must map to Playwright when UI-bearing and in scope |
| Scenario Outline row | One concrete behavior variant | Expands to its own test obligation |
| `VAL-*` assertion | One validation-contract claim | Must be mapped to a verification method |
| Tier-1 journey | Critical release-blocking flow | Must pass before release |
| Tier-2 journey | Important but non-blocking regression path | Must run nightly or pre-release |
| Tier-3 journey | Rare, legacy, or low-frequency path | Run on schedule or before major release |

## Policy

| Policy area | Rule |
|---|---|
| Browser UI projects | Playwright E2E is mandatory when project signals require a browser UI E2E layer |
| Petition delta | `100%` of changed user-visible Gherkin scenarios must gain or update Playwright coverage |
| CR delta | No UI-bearing CR closes without Playwright coverage for the visible delta |
| Validation contract | `100%` of release-critical `VAL-*` assertions must execute in Playwright at Phase 6.5 |
| Hotfixes | Browser UI hotfixes require automated UI smoke or focused Playwright E2E before healthy claim |
| Release | No release without green Tier-1 journeys and green release-critical `VAL-*` assertions |
| Exceptions | Any intentional gap must be explicit, time-bounded, owned, and tracked as escalation or backlog item |

## Tier Model

| Tier | Scope | Typical examples | When it runs |
|---|---|---|---|
| Tier 0 | Minimum smoke | app boot, login, one core happy path | every PR affecting UI, every deploy |
| Tier 1 | Release-blocking critical journeys | submission, approval, payment, statutory calculation handoff, core case progression | PR for touched area, full pre-release |
| Tier 2 | Important regression coverage | role variations, common sad paths, major browser permutations | nightly and pre-release |
| Tier 3 | Low-frequency or legacy coverage | rare permutations, legacy browser-specific checks, long-tail setup | scheduled or change-triggered |

## Default Goals

These are the default targets unless a project ADR or project policy tightens
them.

| Goal | Default target |
|---|---|
| Changed user-visible scenarios with Playwright coverage | `100%` |
| Release-critical `VAL-*` assertions mapped and automated | `100%` |
| Tier-1 journeys covered | `100%` |
| Tier-1 journeys passing on release candidate | `100%` |
| PR smoke runtime budget | `<= 10 minutes` |
| Nightly full regression runtime budget | `<= 45 minutes` |
| Rolling suite flake rate | `< 2%` |
| Rolling per-test flake rate | `< 1%` |
| PR browser matrix | `Chromium` minimum |
| Nightly or pre-release browser matrix | all supported browsers for the product's support policy |

## Browser and Device Matrix

Set the browser matrix from real support commitments, not generic ambition.

| Level | Minimum default |
|---|---|
| PR | `Chromium` |
| Nightly | `Chromium` plus other supported browsers |
| Pre-release | full supported browser matrix |

If mobile, tablet, or kiosk variants are contractual product surfaces, they must
be represented explicitly in the matrix and tiered like browsers.

## Pass / Fail Rules

### Pass

Playwright coverage is sufficient when all are true:

1. Every changed user-visible scenario is covered by Playwright.
2. Every release-critical `VAL-*` assertion is mapped and executed.
3. Tier-1 journeys are green on the release candidate.
4. Runtime and flake budgets are within threshold.
5. Evidence from the run is stored in the expected artifact locations.

### Fail

Coverage is insufficient when any are true:

1. A changed user-visible scenario has no Playwright test.
2. A release-critical `VAL-*` assertion is unmapped or manual-only.
3. A browser UI hotfix has no automated UI smoke or focused E2E proof.
4. A Tier-1 journey is flaky, quarantined without approval, or red.
5. Runtime or flake budgets are repeatedly breached without an approved exception.

## Evidence

| Evidence | Expected location |
|---|---|
| Generated or updated Playwright specs | project `test_dir` from `.factory/project.yaml` |
| Validation contract | `petitions/validation/<petition-ID>/validation-contract.md` |
| User-testing evidence | `petitions/validation/<petition-ID>/user-testing/` |
| Coverage review verdicts | `petitions/reviews/petition<ID>-*.yaml` |
| Release or hotfix smoke proof | release or hotfix evidence from the current run |

## Governance by Phase

| Phase | Required outcome |
|---|---|
| Phase 5 test generation | Playwright tests exist for changed UI scenarios and scenario-outline rows |
| Phase 5 review | Coverage auditor findings on gaps or overreach are resolved or escalated |
| Phase 6.5 E2E acceptance | release-critical `VAL-*` assertions pass on the real UI or API surface |
| CR close | UI delta has Playwright coverage |
| Hotfix verification | browser UI hotfix has automated smoke or focused E2E evidence |
| Release | Tier-1 plus release-critical validation checks are green |

## Anti-Goals

Do not use this policy to justify:

- a line-coverage percentage target for Playwright
- broad UI test duplication of unit or integration checks
- unstable selector-heavy tests that exist only to satisfy a count
- keeping flaky tests in the release path without owner and expiry

## Review Cadence

Review thresholds and tier assignments:

- at project bootstrap
- when a new critical journey appears
- after major incidents or hotfix clusters
- at least quarterly

## Recommended Scorecard

Projects should report these measures visibly:

| Metric | Why it matters |
|---|---|
| Tier-1 coverage ratio | shows whether release-blocking journeys are protected |
| `VAL-*` automation ratio | shows contract coverage, not implementation trivia |
| PR smoke runtime | keeps developer feedback fast |
| Nightly regression runtime | shows suite scalability |
| Suite flake rate | shows whether teams can trust the suite |
| Escaped defects on covered journeys | shows whether the suite protects real outcomes |

## Default Decision

If a team asks "should we set coverage goals for Playwright E2E?", the default
answer in this ecosystem is:

- yes to journey and contract coverage goals
- yes to runtime and flake budgets
- no to line-coverage percentage goals
