# Structured Agent Node Spec Template

This template is intended for agents that participate in a larger workflow and may eventually be bound to an explicit graph-based orchestration layer. It makes node behavior more reliable by separating **control flow** from **execution behavior**.

In this model:

- the workflow graph defines **when** a node runs and **where** it can go next
- the node spec defines **what** the node must do before it can claim success

---

## Design goals

Use this template when an agent should be:

- reusable as a workflow node
- easier to audit and review
- easier to convert into a graph-driven orchestration model
- less dependent on long prose prompts with hidden branching logic

The template is especially useful for:

- orchestrators
- approval gates
- reviewers
- validators
- translators
- specialist worker agents with clear input/output contracts

---

## Recommended front matter

```yaml
---
name: <agent-name>
description: <one-sentence description>
workflow_role: orchestrator | worker | reviewer | validator | gate | reporter
workflow_binding: graph_aligned | contract_only
graph_node_ids:
  - <every non-start/non-exit node ID from workflows/<agent-name>.dot>
upstream_dependencies:
  - <node-id or artifact>
primary_outputs:
  - <artifact path or report type>
default_next:
  success: <node-id or handoff>
  partial_success: <approval boundary or next node>
  blocked: <node-id or escalation path>
  needs_more_evidence: <proof-gathering node or escalation path>
  retry: <same node or remediation node>
  fail: <escalation path>
---
```

---

## Recommended section structure

For graph-aligned agents, use these section titles exactly:

1. `# Purpose`
2. `## Workflow role`
3. `## Inputs`
4. `## Preconditions`
5. `## Procedure`
6. `## Output Contract`
7. `## Status Vocabulary`
8. `## Done Criteria`
9. `## Evidence Requirements`
10. `## Failure Routing`
11. `## Escalation Rules`
12. `## Never Do`

Additional sections are fine, but they should not replace these contract sections.

### 1. Purpose

State the job in one or two sentences.

Questions this section should answer:

- Why does this node exist?
- What outcome is it responsible for?
- What is explicitly out of scope?

### 2. Workflow role

Define how this node behaves in the larger system.

Recommended fields:

- node type: `orchestrator`, `worker`, `reviewer`, `validator`, `gate`, or `reporter`
- normal predecessors
- normal successors
- whether this node is a goal gate
- whether this node may pause for human approval

### 3. Inputs

Separate **required** from **optional** inputs.

Recommended structure:

```md
## Inputs

### Required
- `path/to/file`
- petition ID
- prior phase report

### Optional
- concept-model alignment report
- NFR coverage report
- architecture document
```

Be explicit about whether the node must:

- verify that each input exists
- read each input fully or partially
- reject execution if an input is missing

### 4. Preconditions

List what must already be true before the node starts.

Examples:

- petition artifacts are present and non-empty
- previous approval gate has passed
- branch is not the default branch
- required validation harness exists
- latest repo evidence has been checked in this run

This section should prevent silent assumptions.

### 5. Procedure

Break the node into numbered steps.

This section should contain only execution logic, not meta commentary.

Recommended pattern:

```md
## Procedure

1. Verify required inputs exist and are non-empty.
2. Read the minimum set of source artifacts needed for this decision.
3. Run delegated sub-agents or checks in the required order.
4. Record findings, outputs, and any open gaps.
5. Decide whether the node status is `success`, `blocked`, `needs-more-evidence`, `retry`, or `fail`.
```

For complex nodes, group steps into named phases.

### 6. Output contract

Define exactly what this node produces.

Recommended structure:

```md
## Output Contract

### Artifacts
- `path/to/output.md`
- `path/to/output.yaml`

### Report Fields
- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields
- `claim`
- `proof`
- `freshness`
- `result`
```

The more structured this section is, the easier it becomes to automate handoffs.

Recommended meanings:

- `summary` = one- to three-line outcome summary
- `artifacts` = explicit file paths or `none`
- `evidence_checked` = list of claims checked, proof source, freshness, and result
- `warnings` = non-blocking residual concerns
- `escalations` = escalation IDs or explicit `none`
- `next_action` = immediate next step
- `handoff_target` = next node, approval boundary, or `exit`

### 7. Status vocabulary

Use a small fixed set of outcome states. Each agent may use a subset, but should not invent new status names.

Recommended meanings:

| Status | Meaning |
|---|---|
| `success` | Node completed and produced the required output. |
| `partial_success` | Node completed sufficiently to proceed, but with declared limitations. |
| `blocked` | Node could not proceed because a prerequisite, dependency, or human input is missing. |
| `needs_more_evidence` | Node cannot make the required claim yet because proof is incomplete or stale. |
| `retry` | Node encountered a recoverable issue and should be attempted again within retry policy. |
| `fail` | Node did not complete and should route to escalation or explicit failure handling. |

### 8. Done criteria

Define what must be true before the node can claim completion.

Examples:

- required artifact exists and is non-empty
- review verdict is explicit
- evidence was gathered in the current run
- no blocking issues remain
- handoff package is complete

This is the most important section for review and verification nodes.

### 9. Evidence requirements

Make proof requirements explicit.

Recommended questions:

- What exact claim might this node make?
- What command, artifact, or report proves that claim?
- Must that evidence be fresh?
- What evidence is insufficient?

This section aligns naturally with `verification-gate`.

For handoff-friendly evidence, write each proof item in a machine-checkable shape:

- `claim`: what is being asserted
- `proof`: command, artifact, or report that proves it
- `freshness`: why the proof counts for this run
- `result`: pass, fail, partial, missing, or ambiguous

### 10. Failure routing

Describe what happens when the node does not succeed.

Recommended structure:

```md
## Failure Routing

- If required input is missing: `blocked`
- If delegated reviewer rejects: `fail`
- If evidence is stale: `needs_more_evidence`
- If issue is recoverable: `retry` once
- If retry budget is exhausted: escalate to user
```

This section should map cleanly to graph edges later.

### 11. Escalation rules

State exactly when human intervention is required.

Examples:

- approval boundary reached
- conflicting evidence
- unresolved legal ambiguity
- repeated failure after retry budget
- missing infrastructure the user must acknowledge

### 12. Never do

List forbidden shortcuts.

Examples:

- never invent missing artifacts
- never infer approval from silence
- never claim success without fresh evidence
- never change scope silently
- never bypass a failed gate

This is often more useful than adding more prose to the procedure.

---

## Copy-paste template

```md
---
name: <agent-name>
description: <one-sentence description>
workflow_role: <orchestrator|worker|reviewer|validator|gate|reporter>
workflow_binding: <graph_aligned|contract_only>
graph_node_ids:
  - <every non-start/non-exit node ID from workflows/<agent-name>.dot>
upstream_dependencies:
  - <artifact-or-node>
primary_outputs:
  - <artifact-or-report>
default_next:
  success: <node-id or handoff>
  partial_success: <approval boundary or next node>
  blocked: <node-id or escalation path>
  needs_more_evidence: <proof-gathering node or escalation path>
  retry: <same node or remediation node>
  fail: <escalation path>
---

# Purpose

<What this node is responsible for, and what it is not responsible for.>

## Workflow role

- Role: <...>
- Goal gate: <yes|no>
- Human approval node: <yes|no>
- Typical predecessors: <...>
- Typical successors: <...>

## Inputs

### Required
- `<required input>`

### Optional
- `<optional input>`

## Preconditions

1. <precondition>
2. <precondition>

## Procedure

1. <step>
2. <step>
3. <step>

## Output Contract

### Artifacts
- `<artifact path>`

### Report Fields
- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields
- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success`
- `partial_success`
- `blocked`
- `needs_more_evidence`
- `retry`
- `fail`

## Done Criteria

1. <criterion>
2. <criterion>
3. <criterion>

## Evidence Requirements

- Claim: <claim>
- Proof: <command or artifact>
- Freshness rule: <rule>

## Failure Routing

- <condition> -> `blocked`
- <condition> -> `retry`
- <condition> -> `fail`
- <condition> -> escalate

## Escalation Rules

1. <escalation trigger>
2. <escalation trigger>

## Never Do

- <forbidden shortcut>
- <forbidden shortcut>
- <forbidden shortcut>
```

---

## Suggested next step

Use this template first on:

1. `delivery-orchestrator`
2. `pipeline-conductor`
3. `verification-gate`

Those three nodes define most of the control discipline in the current system. If they become graph-aligned and structurally explicit, the rest of the agent ecosystem becomes easier to harden incrementally.
