# CV RFP Flow User Guide

This guide is for people using the CV flow, not for people changing agent internals.

The entrypoint is `cv-rfp-conductor`. It orchestrates request intake, customer style-pack resolution, host-project context discovery, won/lost corpus use, fit mapping, reference optimization, drafting, review, evidence checks, optional legality review, and optional DOCX rendering.

---

## What this flow is for

Use the CV flow when you want the agent system to produce or review a candidate-specific CV response for an RFP **inside the current project repo** without spinning up a separate app.

It is designed to:

- normalize current RFP and candidate CV into markdown
- search the current project's markdown docs for relevant context
- search `rfp/won` and `rfp/lost` for reusable historical patterns
- map candidate evidence to requirements explicitly
- elaborate reusable win themes and select which ones fit the active tender
- optimize slightly similar candidate-owned references so they fit the current requirement language safely
- draft a traceable CV response with fuller evaluator-ready prose
- red-team the answer quality
- audit proof-bearing claims
- prepare an audited render payload for downstream templating
- optionally render the output into a customer DOCX template
- optionally review tender or decision-letter legality

It is **not** designed to:

- invent candidate experience
- copy old winning prose into a new bid
- treat historical resemblance as proof for the candidate
- treat project docs or MemPalace recall as proof without re-checking
- hide fit gaps behind generic language

---

## Target repo hierarchy

The flow assumes a markdown-first hierarchy in the host project:

```text
rfp/
  won/<case-id>/
    rfp.md
    cv.md
    offer.md
    outcome.md
    notes.md
  lost/<case-id>/
    rfp.md
    cv.md
    offer.md
    outcome.md
    notes.md
  active/<RFP-ID>/
    request/
    context/
    extraction/
    drafts/
    deliverables/
    reviews/
    evidence/
    package/
```

`won` and `lost` are historical corpus inputs.

`active/<RFP-ID>` is the current run workspace.

---

## What you should provide up front

| Input | Required | Why it matters |
|---|---|---|
| Current RFP | Yes | Core requirement source |
| Candidate CV | Yes for generation/review | Core candidate evidence source |
| Host project repo | Yes | Supplies markdown context and historical corpus |
| Customer name | Optional | Resolves style pack and template profile when customer-specific output matters |
| Requested output format | Optional | Determines whether DOCX rendering is in scope |
| Template override | Optional | Forces a specific customer template when multiple match |
| Previous RFP | Optional | Helps compare reuse or drift |
| Previous response | Optional | Helps review or targeted reuse |
| Decision letter | Optional | Needed for legal-only or dispute review |
| Explicit context paths | Optional | Narrows repo search when you already know the good docs |

---

## How to start

Use `cv-rfp-conductor` as the normal entrypoint for full generate/review runs.

For small maintenance edits to the candidate CV (for example adding a new reference or correcting a minor fact), use `cv-delta-updater` instead of running the full chain. If you also need a refreshed Word output, follow it with `cv-output-renderer`.

### Minimal example

```text
@cv-rfp-conductor
Run the CV RFP flow for tender ABC-123 from the current repo.

Use:
- current RFP at rfp\incoming\ABC-123-rfp.md
- candidate CV at candidates\markus-friede-hens.md
- customer name UFST

Mode: generate
```

### Better example

```text
@cv-rfp-conductor
Run the CV RFP flow for Municipality AI Copilot tender ABC-123 from this repo.

Use:
- current RFP at rfp\incoming\ABC-123-rfp.md
- candidate CV at candidates\markus-friede-hens.md
- previous response at rfp\won\UFST-2024-07\cv.md
- decision letter at rfp\lost\Tax-2023-02\outcome.md
- explicit context paths:
  - README.md
  - docs\delivery-model.md
  - architecture\domain-overview.md
- customer name: UFST
- requested output format: docx

Mode: generate
Also run legal review if the final evidence gate passes.
```

---

## What happens at each stage

| Stage | Main agent | What it does | Main output |
|---|---|---|---|
| 0. Validate inputs | `cv-rfp-conductor` | Resolves mode, repo root, and `RFP-ID` | active run root |
| 1. Intake normalization | `cv-intake-normalizer` | Converts request files into canonical markdown, records checksums, and resolves customer style assets when requested | request package |
| 2. Project context discovery | `cv-project-context-discoverer` | Searches host-project markdown docs and selects bounded relevant context | context index and selected context |
| 3. Won/lost corpus discovery | `cv-history-curator` | Indexes historical markdown cases and extracts reusable patterns plus elaborated win themes | won/lost indexes, historical patterns, and theme library |
| 4. Fit mapping | `cv-fit-mapper` | Maps requirements to candidate evidence, candidate references, active win themes, hint ceilings, and gaps | fit matrix, candidate reference index, active win themes, hint ceilings, and gap log |
| 5. Reference optimization | `cv-reference-optimizer` | Reframes slightly similar candidate-owned references safely against current requirement wording | reference adaptations |
| 6. Response drafting | `cv-response-drafter` | Writes the candidate-specific CV response with claims tracking, ceiling-aware prose, and an audited render payload | response draft, claims register, and render payload |
| 7. Red-team review | `cv-red-team-reviewer` | Reviews specificity, evaluator fit, customer-style alignment, theme depth, and copy-risk | red-team artifact |
| 8. Claim evidence audit | `cv-claim-evidence-auditor` | Verifies non-trivial claims and render-payload fields against real sources | evidence audit |
| 9. Legal review | `cv-legality-reviewer` | Reviews tender or decision-letter legality when requested | legality artifact |
| 10. Output rendering | `cv-output-renderer` | Renders the audited payload into the selected customer template | DOCX deliverable and render manifest |
| 11. Final close | `cv-rfp-conductor` | Verifies the run's output package and next action | result manifest |

---

## MemPalace rules

The flow uses MemPalace for continuity and validated patterns, not as raw bid storage.

Allowed memory:

- abstract win/loss patterns
- validated decisions
- customer or buyer facts worth re-checking
- repeated blocker themes

Forbidden memory:

- raw RFP text
- raw CV text
- full response drafts
- full offers
- unsupported claims

If a recalled memory matters, the flow must still re-check current-run artifacts before using it as proof.

---

## What you get back

Artifacts are written under:

```text
rfp/active/<RFP-ID>/
```

Typical outputs:

- `request/input-register.yaml`
- optional `request/style-pack-resolved.yaml`
- `request/clarifications.md`
- `context/project-context-index.yaml`
- `context/selected-context.md`
- `context/won-corpus-index.yaml`
- `context/lost-corpus-index.yaml`
- `context/historical-patterns.md`
- `context/historical-win-themes.md`
- `extraction/methods-tools.md`
- `extraction/requirements-register.yaml`
- `extraction/candidate-reference-index.yaml`
- `extraction/active-win-themes.yaml`
- `extraction/hint-ceilings.yaml`
- `extraction/fit-matrix.yaml`
- `extraction/fit-gaps.md`
- `extraction/reference-adaptations.yaml`
- `drafts/cv-response-v<N>.md`
- `drafts/latest.yaml`
- `reviews/red-team.yaml`
- `evidence/claims-register.yaml`
- `evidence/claims-register-audited.yaml`
- `evidence/evidence-audit.yaml`
- optional `deliverables/render-payload.yaml`
- optional `deliverables/render-manifest.yaml`
- optional `deliverables/<customer>-cv-<candidate>.docx`
- optional `reviews/legality.yaml`
- `package/result-manifest.yaml`

---

## Status meanings

| Status | Meaning |
|---|---|
| `success` | The stage completed safely |
| `partial_success` | Useful progress exists, but a human choice or non-blocking warning remains |
| `blocked` | A prerequisite, proof item, or source is missing |
| `needs_more_evidence` | The system cannot support the claim yet with the current artifacts |
| `retry` | The issue is recoverable and should be rerun with targeted fixes |
| `fail` | The stage could not continue safely and needs escalation |

---

## Practical rules

1. Start with `cv-rfp-conductor` for full runs. Use `cv-delta-updater` only for tightly bounded small CV updates.
2. Give real paths, not vague descriptions.
3. Keep historical material in markdown under `rfp/won` and `rfp/lost`.
4. Expect the flow to stop when the candidate evidence is weak.
5. If legal review matters, provide the decision letter or the disputed source.
6. Never ask the flow to "just make it sound stronger" when the evidence base is weak.
7. Expect the flow to use historical wins for themes and framing, but to adapt only candidate-owned references into the live answer.
8. Use bounded-neutral uncertainty language in draft prose; keep hard evidence gaps explicit in machine-readable artifacts.
9. In consultancy mode, write up even weak non-contradictory competency signals, but keep wording within evidence-based assertion ceilings.
10. If you want DOCX output, supply a customer name or template override so intake can resolve the style pack cleanly.

---

## Customer style packs

When customer-specific tone and output depth matter, store style assets in:

```text
customers/<CUSTOMER>/
  style-guide.md
  section-targets.yaml
  terminology.yaml
  scoring-hints.yaml
  good-examples/
```

For template rendering, keep token mappings in:

```text
cv-output-renderer/template-mapping.yaml
```

Style packs are framing constraints, not proof sources.

They are resolved during intake and then consumed by fit mapping, drafting, review, and rendering.

`template-mapping.yaml` is structural only. It maps template markers to audited payload keys; it does not decide the prose content itself.

---

## Common failure modes

| Problem | What usually caused it |
|---|---|
| Draft sounds generic | Fit mapping was thin or project context was weak |
| Draft still feels too crisp | Active win themes or reference adaptations were thin, so the drafter had little safe material to elaborate |
| Review blocks for copy-risk | The draft leaned too hard on historical won material |
| Evidence audit blocks close | Claims register points to proof that does not exist or was not supplied |
| Context pack is thin | The repo has little usable markdown documentation |
| Legal review is inconclusive | Decision basis or tender clauses were not supplied |

---

## Simple operator checklist

- Do I have the current RFP?
- Do I have the candidate CV?
- Am I running from the correct project repo?
- Does the repo contain useful markdown docs?
- Are historical won/lost cases stored in markdown?
- Do I have enough candidate-owned references for the optimizer to work with?
- Am I willing to let the flow stop on weak evidence instead of bluffing?

If the answer to the last question is no, do not use this flow.

