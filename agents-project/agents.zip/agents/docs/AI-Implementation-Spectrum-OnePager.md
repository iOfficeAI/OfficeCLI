# AI Implementation Spectrum -- From Open-Source On-Prem to E2E Decision Platforms

**EY Confidential | March 2026**

---

## The Spectrum at a Glance

| Tier | Approach | Control | Complexity | Cost Model | Example |
|------|----------|---------|------------|------------|---------|
| **1** | On-Prem Open-Source | Full sovereignty | Medium | CapEx-heavy | EY.ai Enterprise Private |
| **2** | Managed Cloud AI Services | Shared (provider-managed) | Low-Medium | OpEx / pay-per-use | Azure OpenAI, AWS Bedrock |
| **3** | Horizontal AI/Data Platforms | Configurable | Medium-High | Platform license + OpEx | Databricks, Snowflake Cortex |
| **4** | Vertical AI Decision Platforms | Vendor-dependent | High | Enterprise license | Palantir AIP / Foundry |
| **5** | Sovereign EU Alternatives | EU-controlled | High | Enterprise license | DataWalk, Aleph Alpha |

---

## Tier 1 -- On-Premises with Open-Source Models

**EY.ai Enterprise Private** (launched May 2025): EY's own on-prem AI platform, powered by the **Dell AI Factory with NVIDIA** infrastructure and the EY.ai Agentic Framework. Designed for **regulated sectors** (financial services, government, defence) requiring full data sovereignty.

- **Infrastructure**: Dell PowerEdge servers + NVIDIA GPUs (H100/B200), runs in client data centres
- **Models**: Open-weight models such as **Mistral** (Large 3, Mixtral), **Llama 3**, **Falcon**, fine-tunable to domain tasks
- **Key advantage**: Data never leaves the client's perimeter; full IP ownership of fine-tuned models
- **Trade-off**: Requires GPU hardware investment (CapEx), internal MLOps capability, longer time-to-value

---

## Tier 2 -- Managed Cloud AI Services

Hyperscaler-hosted model APIs and AI tooling. Fastest path to production for non-sovereign workloads.

| Provider | Offering | Differentiation |
|----------|----------|-----------------|
| **Microsoft Azure** | Azure OpenAI Service, AI Foundry | Deepest enterprise integration (M365, Copilot ecosystem) |
| **AWS** | Bedrock, SageMaker | Multi-model marketplace, broadest IaaS footprint |
| **Google Cloud** | Vertex AI, Gemini | Strong multimodal, scientific AI pedigree |

---

## Tier 3 -- Horizontal AI / Data Platforms

Unified analytics + AI platforms that sit across cloud providers, combining data engineering with model serving.

- **Databricks** (Lakehouse + Mosaic AI): End-to-end MLOps, open-source Delta Lake foundation, agentic AI workflows
- **Snowflake Cortex**: Embedded LLM functions on governed data; strong for analytics-first organisations
- **Celonis** (Germany): Process mining + AI execution -- strong in operational transformation use cases

---

## Tier 4 -- E2E Surveillance & Decision Platforms (Palantir)

**Palantir** operates two core products:

| Product | Domain | Capability |
|---------|--------|------------|
| **Gotham** | Defence / Intelligence | Entity resolution, geospatial intelligence, pattern-of-life analysis, C2 integration |
| **Foundry** | Commercial / Government | Operational data fusion, digital twin, supply chain optimisation |
| **AIP** | Cross-domain | LLM-powered decision layer on top of Gotham/Foundry ontology; agentic workflows in operational context |

**Why clients choose Palantir**: Unmatched ability to fuse heterogeneous data into operational decisions at speed. Deep integration with NATO / Five Eyes classified environments.

**Key risk for EU clients**: US CLOUD Act exposure, ITAR dependencies, vendor lock-in at ontology layer.

---

## Tier 5 -- European Sovereign Alternatives to Palantir

| Vendor | HQ | Core Capability | Positioning |
|--------|----|--------------------|-------------|
| **DataWalk** | Poland (Wroclaw) | Link analysis, entity resolution, multi-source data fusion | Direct Palantir Gotham competitor for law enforcement and intelligence; dramatically lower TCO; EU data sovereignty; used by EU/NATO agencies |
| **Aleph Alpha** | Germany (Heidelberg) | Sovereign LLMs + enterprise AI platform | Backed by Schwarz Group (Lidl); runs on STACKIT sovereign cloud; GDPR-native; focus on government and critical infrastructure |
| **Atos/Eviden** | France | Sovereign Agentic Studios (launched March 2026); HPC (BullSequana); cybersecurity | Full-stack sovereign AI: from supercomputers to agentic AI orchestration; strong in EU defence and public sector |
| **SAP AI** | Germany (Walldorf) | Joule AI copilot, SAP Business AI, Sovereign Cloud | Embedded AI across ERP/S4HANA; EU Sovereign Cloud offering; dominant in enterprise process automation |
| **Helsing** | Germany (Munich) | Defence-grade AI for battlefield awareness | EU-only defence AI company; works with Bundeswehr, French MoD; real-time sensor fusion |

---

## Decision Framework for Clients

```
Data Sovereignty Required?
    |
    +-- YES --> Regulated / Defence?
    |               |
    |               +-- YES --> Tier 1 (EY.ai Enterprise Private) or Tier 5 (DataWalk / Helsing)
    |               |
    |               +-- NO  --> Tier 1 with cloud-adjacent hybrid
    |
    +-- NO  --> Operational Complexity?
                    |
                    +-- HIGH (data fusion, C2, supply chain) --> Tier 4 (Palantir) or Tier 5 (EU)
                    |
                    +-- MEDIUM (analytics + AI) --> Tier 3 (Databricks / Snowflake)
                    |
                    +-- LOW (model API consumption) --> Tier 2 (Azure / AWS / GCP)
```

---

## EY Positioning

EY can play across all tiers. The **EY.ai Enterprise Private** offering (Dell + NVIDIA) is our strongest differentiator for Tier 1, while our alliances with Microsoft, SAP, and emerging EU players position us to advise and implement across the full spectrum. For clients evaluating Palantir, EY offers independent assessment of total cost of ownership, sovereignty risk, and alternative architectures.

---

*Contact: [Partner Name] | EY Technology Consulting*
