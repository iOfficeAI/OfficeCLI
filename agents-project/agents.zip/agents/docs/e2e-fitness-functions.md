# E2E Fitness Function Starter Pack

## Purpose

Use these starter fitness functions for browser UI projects that use Playwright
in this delivery model.

This pack is intentionally small. It protects the properties that matter most:

- critical journeys keep working
- release-critical `VAL-*` assertions stay executable
- the suite stays fast enough and trustworthy enough to govern delivery

Primary source policy: `docs/e2e-coverage-policy.md`

## FF-E2E-001 - Critical Journey Release Gate

**Protected property:** Release-blocking user journeys remain executable on the
real browser surface.
**Type:** critical functional journey
**Scope:** UI
**Source:** `docs/e2e-coverage-policy.md`, `petitions/validation/<petition-ID>/validation-contract.md`, `.factory/project.yaml`

### Why it exists

Teams need a small set of flows whose failure changes release behavior
immediately. Without this, Playwright becomes broad regression noise instead of
a release gate.

### Mechanism

- **Check type:** automated
- **Implementation:** Playwright Tier-1 journey suite plus release-candidate run
- **Location:** project E2E `test_dir` from `.factory/project.yaml`
- **Trigger:** PR for touched Tier-1 area, pre-release, hotfix verification when affected

### Pass / Fail Rule

- **Pass when:** `100%` of Tier-1 journeys are covered and green on the release candidate
- **Fail when:** any Tier-1 journey is missing, red, or quarantined without explicit approval
- **Threshold / tolerance:** zero failing Tier-1 journeys

### Owner and Action

- **Owner:** delivery Cell or service owner
- **Failure action:** block release; block PR when touched area removes or breaks Tier-1 protection
- **Review cadence:** quarterly and whenever a new critical journey appears

### Evidence

- **Evidence produced:** Playwright report, CI result, user-testing evidence for touched petitions
- **Where stored:** CI artifacts, `petitions/validation/<petition-ID>/user-testing/` when applicable

### Notes

- **Trade-offs:** stronger release confidence at the cost of a slightly heavier pre-release gate
- **Retirement rule:** revise only if the journey stops being release-blocking

## FF-E2E-002 - Validation Contract Execution

**Protected property:** Release-critical `VAL-*` assertions remain mapped to
real executable checks.
**Type:** functional contract
**Scope:** UI or UI/API handoff
**Source:** `docs/e2e-coverage-policy.md`, `petitions/validation/<petition-ID>/validation-contract.md`, `README.md`

### Why it exists

This delivery model treats `validation-contract.md` as the executable acceptance
handshake. If critical `VAL-*` assertions become manual, stale, or unmapped,
Phase 6.5 loses meaning.

### Mechanism

- **Check type:** automated
- **Implementation:** `user-testing-flow-validator` plus petition-level mapping of release-critical `VAL-*`
- **Location:** `petitions/validation/<petition-ID>/validation-contract.md` and `petitions/validation/<petition-ID>/user-testing/`
- **Trigger:** Phase 6.5, pre-release, and relevant CR closure

### Pass / Fail Rule

- **Pass when:** `100%` of release-critical `VAL-*` assertions are mapped and green on the real surface
- **Fail when:** any release-critical `VAL-*` is unmapped, manual-only, stale, or red
- **Threshold / tolerance:** zero unmapped or failing release-critical `VAL-*`

### Owner and Action

- **Owner:** petition owner plus reviewer for E2E acceptance
- **Failure action:** block Phase 6.5 and block release
- **Review cadence:** every petition with browser UI impact

### Evidence

- **Evidence produced:** validator output, flow evidence, screenshots or run logs when checks fail
- **Where stored:** `petitions/validation/<petition-ID>/user-testing/` and CI artifacts

### Notes

- **Trade-offs:** requires better contract hygiene, but keeps acceptance evidence auditable
- **Retirement rule:** retire only if the UI surface itself is removed

## FF-E2E-003 - Suite Trust Budget

**Protected property:** Playwright remains fast enough and stable enough to stay
in the delivery path.
**Type:** delivery fitness function
**Scope:** UI pipeline
**Source:** `docs/e2e-coverage-policy.md`, `docs/fitness-function-template.md`

### Why it exists

An E2E suite that is slow or flaky stops being a control and becomes permission
to ignore red builds. Trust is part of the architecture.

### Mechanism

- **Check type:** automated
- **Implementation:** PR smoke runtime check, nightly regression runtime check, rolling flake analysis
- **Location:** CI workflows, Playwright reports, team dashboard
- **Trigger:** every PR run for smoke; nightly for full suite; threshold review quarterly

### Pass / Fail Rule

- **Pass when:** PR smoke runtime is `<= 10 minutes`, nightly regression runtime is `<= 45 minutes`, suite flake rate is `< 2%`, and per-test flake rate is `< 1%`
- **Fail when:** runtime or flake thresholds are exceeded repeatedly without approved exception
- **Threshold / tolerance:** thresholds above plus explicit owner and expiry for any quarantine

### Owner and Action

- **Owner:** test owner or platform owner for the UI harness
- **Failure action:** pause suite expansion, fix or quarantine offenders with owner and expiry, block promotion when Tier-1 trust falls below threshold
- **Review cadence:** weekly metric review, quarterly threshold review

### Evidence

- **Evidence produced:** CI timings, flake report, quarantine register, Playwright trend charts
- **Where stored:** CI system and project quality dashboard

### Notes

- **Trade-offs:** forces pruning and discipline instead of unconstrained suite growth
- **Retirement rule:** revise only if project support commitments or release cadence change materially
