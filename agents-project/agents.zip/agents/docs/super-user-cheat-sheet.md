# Super-User Cheat Sheet

This page is for a super-user as a domain expert, not a technician.

## What this agent is

`super-user-stabilisation-conductor` is a safe helper for small fixes after something is already built.

Use it when something is:
- unclear
- confusing
- badly worded
- in the wrong order
- a small safe UX or validation problem

## Tiny picture

```text
You spot small problem
        |
        v
Tell agent in plain words
        |
        v
Agent checks: safe small fix?
      /   \
    yes    no
    |       |
    v       v
SU file   escalate to
+ branch  Architect / CR
+ review
    |
    v
You get result
```

## What to say

Use normal words. No code needed.

Say:
1. where the problem is
2. what is wrong now
3. what you want instead
4. why it confuses users, if helpful

## Copy-paste example

```text
@super-user-stabilisation-conductor
On the hearing overview screen, the helper text about remaining days is confusing.
Users think the number is calendar days, but it is working days.
Please change the helper text so this is clear.
```

## Good for

- labels
- helper text
- validation messages
- simple form layout fixes
- localisation
- dashboard wording
- safe configuration tweaks

## Not for

- database changes
- API changes
- login or permissions
- integrations
- legal/statutory logic
- infrastructure
- secrets

If it is one of these, the agent should stop and send it to the bigger process.

## What the agent does

1. Checks whether the change is small and safe.
2. Creates a tracking item called `SU-NNN`.
3. Puts the work on a safe branch.
4. Sends it through review and checks.
5. Escalates if the change is too big or risky.

## What you get back

Usually you get a simple answer with:
- the SU number
- what the agent understood
- whether it stayed in the super-user lane
- what happened next

Typical next steps:
- PR ready
- waiting for review
- promoted to `CR-NNN`
- reverted
- rejected

## Simple rule

If you are changing what the user sees, reads, clicks, or understands, start here.

If you are changing how the system works underneath, do not start here.
