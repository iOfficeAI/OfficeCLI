From what agents can do to what humans should - a Human Work Strategy
Jennie Pettersson
Jennie Pettersson
Partner at EY, Strategy execution, AI transformation, AI Design & Experience


April 2, 2026
I've been in a lot of rooms lately where smart, well-intentioned leaders are asking the same question: "What can we automate?" And it's a reasonable question. The technology is moving fast. The pressure is real. Nobody wants to be the company that waited too long.

But that question starts from the technology and works its way toward the business. After twenty years of working in organizational and workforce transformation, I've seen this pattern before. A powerful new capability arrives, and the instinct is to deploy it everywhere before asking what it should actually serve. The companies that will get the most out of AI will be the ones starting from the other direction.

The more useful question is: "Given who we are and what our customers actually count on us for, where does human work create value that we'd be foolish to give away?" Where is it so tied to our value proposition, so central to why customers choose us over everyone else, that removing it would undermine the very advantage we compete on?

The pull of automation potential
It's easy to understand why automation-first thinking has taken hold. When you see what agentic systems can do today, and what they'll be able to do six months from now, the instinct is to deploy widely and figure out the rest later. Move fast, capture the efficiency, stay competitive.

That is most likely a trap. When every company in your space automates the same touchpoints using the same foundation models and similar agent architectures, the things you automated stop being a source of advantage. They become table stakes.

What's left that makes you you? More often than not, the answer lives in the human work you chose to keep.

You need a Human work strategy
Many organizations have, or will soon have, an AI strategy. A roadmap for where to deploy the technology. Fewer will think carefully about a Human work strategy, which is a different and more important exercise.

A Human work strategy asks you to hold three things together that rarely end up in the same room.

Your value proposition. Not your product catalog. The real reason a customer chose you over the alternative. Sometimes it's trust. Sometimes it's the feeling that someone genuinely understands their situation. Sometimes it's creative problem-solving, or speed, or the confidence that comes from knowing a human being is paying attention to their specific problem. That reason is the anchor. Everything else flows from it.

Your human capabilities. The places where your people create value that is contextual, relational, or judgment-dependent. I've stopped calling these "soft skills." There is nothing soft about them. They are often the hardest things in your organization to build, the longest to develop, and the easiest to accidentally dismantle.

And your automation boundary. A deliberate, conscious line between what you hand to agent teams and what you keep human. Not drawn by what's technically possible, but by what your particular business needs to protect.

When you hold these three together, automation decisions stop being about capability and start being about coherence. About whether the choices you're making actually match the company you say you are.

The operating model shift that follows
Taking this seriously changes how you think about your operating model.

For any given process, agent teams can most likely take over most tasks. This technology already exists. The important question is the one that requires leadership: if we remove the human here, do we strengthen or weaken the promise we make to our market?

That question is where strategy lives. And most organizations haven't thought about it yet.

It also means that the human work you choose to keep needs real investment. If you've decided that certain interactions or decisions are strategically important enough to remain human, then the way you train, support, and measure those roles should reflect that importance. Otherwise you've drawn a boundary on paper but haven't actually committed to it.

And the boundary itself should be explicit. Something you can articulate internally and externally. "We use AI here. We keep humans here. Here's why." In a world where automation is the default, it might be one of the most compelling things you can say to your market.

What would your customers say
The urgency is everywhere. The fear of falling behind, of not moving fast enough. That fear is valid. But the greater risk isn't speed. It's indiscrimination. Automating so broadly that you erode the thing that made you worth choosing, and not realizing it until your customers tell you. Usually by leaving.

I don't have a neat exercise to close with. But I do have a question that I think every leadership team should ask themselves: If your customers could see exactly which parts of their experience you've decided to hand to a machine, would they think you're doing the right thing?

The answer to that question says more about your AI strategy than your technology roadmap ever will.