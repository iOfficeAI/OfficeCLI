# Token Telemetry Model

## Purpose

Collect measured token and cost actuals first.

Do **not** start with project-level token estimates. Estimates become defensible only
after the delivery system captures trustworthy actuals across real petitions,
models, retries, and rework loops.

This document defines the first telemetry layer for that purpose.

## Canonical Artifact

Use one telemetry artifact per petition:

- `petitions/telemetry/petition<ID>-telemetry.yaml`

Keep this separate from `petitions/program-status.yaml`.

Reason:

- `program-status.yaml` is low-churn planning and execution state
- telemetry is high-churn append data
- mixing them would make planning state noisy and fragile

## First-Rollout Scope

Phase 1 covers petition-driven delivery runs only.

That is enough to start calibration for:

- token use by pipeline phase
- model mix by petition
- retry and rework pressure
- cost per successful petition

Hotfix, super-user, and cross-cutting work should adopt the same row model later,
but they are out of scope for this first rollout.

## Writer Responsibility

The telemetry artifact is **not** authored by the agent itself.

Measured token rows must be written by one of:

1. the host runtime or harness
2. a provider usage export
3. a dedicated import step that preserves provider-measured values

Agents may:

- read the telemetry artifact
- report coverage
- correlate a petition run with a telemetry path or run ID
- downgrade claims when coverage is incomplete

Agents must **not**:

- invent token counts
- estimate token counts from prompt length, phase count, or tool-call count
- treat self-reported numbers as measured telemetry

## Trust Classes

| `source` value | Meaning | Headline totals allowed |
|---|---|---|
| `harness_measured` | written directly by the host runtime or SDK usage payload | yes |
| `provider_export` | imported from provider billing or usage export | yes |
| `self_reported` | manually typed or agent-supplied number | no |
| `unmeasured` | no measured token payload exists for the row | no |

Rules:

- measured rows require a non-empty `measurement_uri`
- headline token or cost totals may use only `harness_measured` and `provider_export`
- `self_reported` and `unmeasured` rows may be used only for coverage-gap reporting

## Row Granularity

Write **one row per agent invocation**.

Do not hand-write phase totals. Derive them from invocation rows.

This avoids double-counting when:

- one phase retries
- one phase delegates to multiple agents
- the same petition re-enters the pipeline later

## Minimum Schema

Each measured row should carry at least:

- `run_id`
- `subject_type`
- `subject_id`
- `phase`
- `phase_name`
- `agent`
- `agent_version`
- `model`
- `model_version`
- `started_at`
- `ended_at`
- `input_tokens`
- `output_tokens`
- `cached_input_tokens`
- `total_tokens`
- `tool_calls`
- `estimated_cost_usd`
- `outcome`
- `source`
- `measurement_uri`

Optional but useful:

- `notes`
- `retry_of_run_id`
- `rework_cause`

## Coverage States

Use these coverage states at the artifact level:

- `absent` — no usable rows yet
- `partial` — some invocation rows exist, but measured coverage is incomplete
- `measured` — the petition has measured rows for the delivery slice being reported

Coverage is about **measurement completeness**, not whether the petition succeeded.

The artifact-level coverage state intentionally uses `absent` while row-level
`source` uses `unmeasured`. Do not reuse the same word for both scopes.

## Consumption Rules

### Pipeline Conductor

- resolves the canonical telemetry path for the petition
- reads current coverage when the artifact exists
- reports run correlation and explicit `telemetry_coverage`
- never authors token counts itself

### Retro Reporter

- reads telemetry artifacts when present
- uses only measured rows for headline token and cost totals
- reports missing or low-trust coverage explicitly
- downgrades rather than inventing totals

## Privacy and Storage Rules

Never store:

- prompt text
- model responses
- secrets
- raw provider dumps

Store only metadata and measured usage values needed for calibration and reporting.

## Template

Use `petitions/telemetry/petitionNNN-telemetry.yaml` as the starter template for a
new petition telemetry file.
