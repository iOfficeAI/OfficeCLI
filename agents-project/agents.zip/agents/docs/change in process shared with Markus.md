<!-- Slide number: 1 -->
Draft – internal usage
# Use case - DPIA
EY Technology Strategy & Transformation
2024

<!-- Slide number: 2 -->
# Delivery teams across the bank need to periodically demonstrate their continued adherence to operational, IT, data and security risk frameworks…

Context | Periodic Risk Assessments & Evidencing:

To stay on top of non-financial risks and fulfill regulatory requirements, banks have implemented an elaborate web of risk frameworks, control measures and policies.

These mechanisms are designed to manage risks including but not limited to; operational, IT, data and security risks.

To ensure compliance with these frameworks, delivery teams are required to periodically validate and evidence their adherence. This might also be triggered by events such as changes to information systems or regulatory updates.

For this purpose, teams typically carry out different assessments such as the Data Privacy Impact Assessment (DPIA/PIA), Business/Operations Impact Analysis (BIA/OIA), and Operational/Information Systems Security Baseline (OSB/ISMS).

Subsequent to these assessments, the results are reviewed and scrutinized by the bank's second line of defense. Depending on factors like risk levels and incidents, or through periodic sampling, the bank’s audit function or regulators may also participate in the review process.
Repetition use case | Data Privacy Impact Assessment (DPIA)

Under the EU General Data Protection Regulation (GDPR), it is mandatory for banks to regularly perform a Data Protection Impact Assessment (DPIA) to identify, assess, and mitigate or minimize privacy risks in data processing activities.

Depending on the Confidentiality, Integrity, and Availability (CIA) rating of the data processing system, it is best practice to perform a DPIA at least every one to three years or before a relevant change e.g. data model.

Given that the majority of delivery teams in banks manage (multiple) systems that process sensitive and/or large amounts of personal data, many teams are required to perform one or several DPI Assessments per year.

Furthermore, GDPR has been implemented on the basis of internal interpretation and / or external advice. GDPR becomes a mature legislation by rulings of Data Privacy Authorities. Some of these ruling enforce banks to re-evaluate their data policy, which trigger the requirement of an updated DPIA on top of the periodic assessment.

(NFR) Risk frameworks

![Arrow circle outline](Graphic436.jpg)

Periodic and event based evidencing

Different risk assessments

2nd and 3rd LoD scrutinization

### Notes:

<!-- Slide number: 3 -->
# …Conducting Data Privacy Impact Assessments alone is costing a large domestic bank an est. 6M per year – excluding operational waste and staff frustration
Requires multiple iterations to get right (waste), high coordination effort, takes very long to complete (2 to 3 months) leading to constant distractions and staff frustration

![Warning with solid fill](Graphic164.jpg)
THE PROCESS:
DATA PRIVACY IMPACT ASSESSMENT (DPIA):
Mandatory under GDPR, on all systems that process sensitive and/or large amounts of personal data.
Consequently almost all delivery teams need to perform DPIAs.
DPIAs are often considered very challenging to get right; ‘moving target’.

DPIA FREQUANCY AND YEARLY NUMBERS:
Frequency: every 1 to 3 years (based on CIA rating) or before relevant change.
Total number of applications: 1,500, of which 70& require a DPIA
In addition, Avg. 0.25 Audit reviews per application per year.
Total avg. number of DPIAs per year; NL: 1,050

DPIA TOTAL COST PER YEAR:

2
Avg. time spend on DPIA
45 hours* per application p.a.

Avg. time spend incl. periodic Audit sampling: 55 hours per application p.a.

Total number of applications NL 1,050 = 57,750 total hours (y FTE) spend on DPIA p.a.

DPIA total cost:
Est. € 5,8M

1
3
Delivery team / squad conducts the DPI Assessment
DPIA review with each 2nd LoD function separately
Periodic or incident driven sampling by Audit / 3rd LoD

What needs to be done:

Consult personal knowledge, conduct software code- and documentation reviews.

List all data attributes in system incl. changed and new.

Per data attribute - identify use, access rights, CRUD rights and -procedures.

Complete and fill DPIA document.

Who’s involved:

What needs to be done:

Input DPIA document often not completed first time right (‘low interest, mundane work’).

Multiple review rounds to get all data and risk evidencing complete – conducted with Compliance, IRM and Privacy functions separately.

Often management intervention/ overhead needed to get timely slots in each agenda.

Who’s involved:

What needs to be done:

Provide context and explanation to 3rd line audit services, often time consuming since they do not know the data processing landscape as well as 2nd line.

Run review workshops with both 2nd and 3rd LoD – again with each function separately. High coordination effort to get all agenda’s aligned.

Who’s involved:

4 persons per squad
2 business SMEs, 2 engineers
3 persons from 2nd  LoD  + 4 persons from delivery squad
1-2 persons from 3rd LoD + 3 persons from 2nd  LoD  + 4 persons from delivery squad

Avg. workload 8 hours per person
Avg. workload 3 hours p.p. 2nd Line and 3 hours p.p. delivery squad

Avg. workload 5 to 6 hours per person
24 hours
21 hours
40 hours
Total
workload
Total
workload
Total
workload
Throughput time
1-2 weeks
Throughput time
2-3 months
Throughput time
2-3 months

### Notes:
What's risk evidencing: process to improve you're in control, and where you are not in control show that you are going to close the gap.

3 lines of defense, evidencing in the 1st line of defence. --> You need to show the evidence to 2nd line (information risk management, compliance, privacy) > 3rd line of defense: Corporate Audit Services, Regulator

GDPR ->> Data Management Policy >> DPIA >>

4 Assessments: DPIA, Business impact analysis, Operational Security Baseline, …

You will see repetition on risk evidencing for all these / four assessments.

Example: Detailed Privacy Impact Analysis, all teams processing customer data needs to conduct a DPIA (mandatory under privacy regulations) which is pretty much any team >> DPIA is often seen as most difficult assessment bcs it is quite new, the way of evidencing is build from scratch, data management / GDPR assessments are evolving (e.g. new adjustments forced upon by the regulator) --> moving target

DPIA frequency, depends on BIA / Business impact analysis --> used to give the CIA (confidentiality, integrity, availability) rating (1 to 4 e.g. 1/1/1, 2/3/4) -> Classification of data; 1 public, to 4 passwords, Integrity; 1 everyone can alter, ! never should be altered, Availability; 1 up to 4; highest is online channel for customers. Frequency DPIA: every one to 3 years depending on CIA rating.

Per squad e.g. 3 assets / 3 applications --> 5500 applications in the bank --> 5500 /3 x 1yr, 2yr, 3yr = 2 avg DPIA p.y. per squad

Side note: build/high level view on risk management frameworks (IT risk is not the only element – Data risk not fully covered under IT risk controls) --> key to understand also to map which stakeholders to talk to.

Assumption: 30 hours for application, +12 hours of re-work and workshops, +3 hours per 2nd Line risk person
Through put time is also important factor, so most likely it takes more than 45 hours
To be visualized that it takes even more time

<!-- Slide number: 4 -->
# … with Policy-as-Code privacy limitations are defined and enforced upfront per business  unit and/or application, including for example access rights and encryption of data
CURRENT PROCESS:
Process re-design:
In current process, DPIA is derived from architectural design, implementation choices and the actual implementation. These are assumed to be factual. As it is a manual process, it has to be confirmed and audited.
In the new process, controls as requested by GDPR have to be designed  upfront organization wide and are system enforced.

Paradigm shift:
Implementation of processes are being validated upfront instead of being tested once implemented.
Processes and underlying data flows are compliant by design as Policy-as-Code and Data-Contracts-as-Code are being controlled upfront and on a continuous basis.
Reports are generated automatically. No manual interventions between reality and paper; reports are factual.

DPIA TOTAL COST PER YEAR:

2
1
3
Delivery team / squad conducts the DPI Assessment
DPIA review with each 2nd LoD function separately
Periodic or incident driven sampling by Audit / 3rd LoD
Avg. time spend on DPIA drops from 55 hours* per application p.a, including audit sampling to  4,5 hours* per

Cost and time reduction of:
~90%

DPIA cost saving :
Est. € 5,3M

24 hours
21 hours

40 hours

Total
workload
Total
workload
Total
workload
Throughput time
1-2 weeks
Throughput time
2-3 months
Throughput time
2-3 months

FUTURE PROCESS:
2
1
3
Delivery team / squad conducts the DPI Assessment
DPIA review with each 2nd LoD function separately
Periodic or incident driven sampling by Audit / 3rd LoD

What needs to be done:

Download data contracts & IAM report
Sanity check

What needs to be done:

Check for completeness
Check on consistency

What needs to be done:

Check procedure and process
Validate outcome

1 persons per squad
1 persons from 2nd line
1 persons from 3rd LoD
Avg. workload 2 hours per person
Avg. workload 2 hours p.p.

Avg. workload 2 hours per person
2 hours
2 hours
2 hours
Total
workload
Total
workload
Total
workload
Throughput time
1 day
Throughput time
1 day
Throughput time
1 day

### Notes:
What's risk evidencing: process to improve you're in control, and where you are not in control show that you are going to close the gap.

3 lines of defense, evidencing in the 1st line of defence. --> You need to show the evidence to 2nd line (information risk management, compliance, privacy) > 3rd line of defense: Corporate Audit Services, Regulator

GDPR ->> Data Management Policy >> DPIA >>

4 Assessments: DPIA, Business impact analysis, Operational Security Baseline, …

You will see repetition on risk evidencing for all these / four assessments.

Example: Detailed Privacy Impact Analysis, all teams processing customer data needs to conduct a DPIA (mandatory under privacy regulations) which is pretty much any team >> DPIA is often seen as most difficult assessment bcs it is quite new, the way of evidencing is build from scratch, data management / GDPR assessments are evolving (e.g. new adjustments forced upon by the regulator) --> moving target

DPIA frequency, depends on BIA / Business impact analysis --> used to give the CIA (confidentiality, integrity, availability) rating (1 to 4 e.g. 1/1/1, 2/3/4) -> Classification of data; 1 public, to 4 passwords, Integrity; 1 everyone can alter, ! never should be altered, Availability; 1 up to 4; highest is online channel for customers. Frequency DPIA: every one to 3 years depending on CIA rating.

Per squad e.g. 3 assets / 3 applications --> 5500 applications in the bank --> 5500 /3 x 1yr, 2yr, 3yr = 2 avg DPIA p.y. per squad

Side note: build/high level view on risk management frameworks (IT risk is not the only element – Data risk not fully covered under IT risk controls) --> key to understand also to map which stakeholders to talk to.

Assumption: 30 hours for application, +12 hours of re-work and workshops, +3 hours per 2nd Line risk person
Through put time is also important factor, so most likely it takes more than 45 hours
To be visualized that it takes even more time

<!-- Slide number: 5 -->
# Process from policy to implementation is redesigned to enable consistently implementation, automatic enforcement and reduction of workload for all parties
Policy definition
Policy interpretation
Implementation
Risk Evidencing
2nd line control (risk)
3rd line control (audit)

![Male profile outline](ContentPlaceholder10.jpg)

![List outline](Graphic122.jpg)

![List outline](Graphic125.jpg)

![Contract outline](Graphic134.jpg)

![Contract outline](Graphic151.jpg)

![List outline](Graphic213.jpg)

![Contract outline](Graphic220.jpg)

app
app

Risk Evidence
Policy
Requirements
Application
Risk Evidence
Policy
Current process
Policy owner creates paper policy based on regulation, risk appetite, market circumstances, etc.
Teams interpret policy; define requirements for application or process. Often, several policies apply. Which exactly is not always clear.
Teams implement application  within assumed relevant policies based on their interpretation.
Teams create risk evidence based on design, logs, screen prints, IAM statements, process description, etc.
Risk parties check evidence versus latest policy. Where discrepancy exists, teams need to provide more evidence and/or adjust application
Auditors check processes and do spot-checks on certain implementation.

Policy interpretation
Risk Evidencing
Policy definition
Implementation
2nd line control (risk)
3rd line control (audit)

![Male profile outline](ContentPlaceholder10.jpg)
{…}
{…}
{…}

![Male profile outline](ContentPlaceholder10.jpg)
{…}
app

app
app

Policy-as-Code
Application
ZRB process
Policy owner creates policy based on (…) and makes it available as Policy-as-Code.
Teams implement application within guardrails of the PaC.
Automated risk evidence
Risk parties check automatically generated reports in case discrepancies are identified.
Auditors check PaC process and policy enforcement.
No interpretation