# GitHub Copilot Integration Architecture for TencentDB-Agent-Memory

## Recommendation

Use a **two-layer integration**:

1. **MCP server as the primary integration surface**
2. **Optional Copilot extension later** for lifecycle automation

This keeps TencentDB-Agent-Memory reusable across hosts while making it usable with GitHub Copilot as soon as possible.

## Why this shape

TencentDB-Agent-Memory is not a Copilot-native integration. It is currently structured around:

- a host-neutral core (`TdaiCore`)
- an OpenClaw adapter
- a standalone HTTP gateway

That means the cheapest usable path is **not** to port OpenClaw hooks into Copilot first. The cheapest usable path is to place **MCP on top of the existing standalone gateway**.

## Target architecture

```mermaid
flowchart LR
    U[User] --> C[GitHub Copilot]
    C --> M[MCP Server Wrapper]
    M --> G[TDAI Gateway HTTP API]
    G --> T[TdaiCore]
    T --> S[(SQLite or Tencent Vector DB)]
    T --> F[Local Markdown / JSONL / refs]
    T --> L[LLM / Embedding Provider]
    
    C -. optional later .-> E[Copilot Extension]
    E -. automates .-> M
```

## Component responsibilities

| Component | Responsibility | Notes |
|---|---|---|
| **TencentDB-Agent-Memory Gateway** | Runs recall, capture, search, session-end, seeding | Reuse existing HTTP endpoints |
| **MCP server wrapper** | Exposes gateway capabilities as MCP tools/resources | Main integration target for Copilot |
| **GitHub Copilot** | Invokes MCP tools during agent workflows | No direct OpenClaw plugin support |
| **Optional Copilot extension** | Automates recall/capture, config UX, server lifecycle | Convenience layer, not v1 |

## V1 scope

Build the MCP server first. Treat the extension as out of scope for the first usable version.

### MCP tools

Expose these tools:

1. `memory_recall`
2. `memory_capture_turn`
3. `memory_search`
4. `conversation_search`
5. `memory_end_session`
6. `memory_health`

### Suggested tool behavior

| MCP tool | Gateway endpoint | Purpose |
|---|---|---|
| `memory_recall` | `POST /recall` | Retrieve context to inject before answering |
| `memory_capture_turn` | `POST /capture` | Persist the current user/assistant exchange |
| `memory_search` | `POST /search/memories` | Search structured long-term memory |
| `conversation_search` | `POST /search/conversations` | Search raw conversation history |
| `memory_end_session` | `POST /session/end` | Flush and close a session cleanly |
| `memory_health` | `GET /health` | Operational diagnostics |

## Data and identity model

The critical design problem is **session identity**, not transport.

### Required mapping

| Copilot concept | TDAI concept | Rule |
|---|---|---|
| chat/session/thread ID | `session_key` | Stable for the life of a Copilot conversation |
| optional message ID | `session_id` or metadata | Useful for debugging, not primary key |
| user identity | `user_id` | Optional in v1; local default acceptable |

### Recommendation

- Generate one stable `session_key` per Copilot conversation.
- Keep the mapping in the MCP server, not in the memory engine.
- Do not let the gateway invent session identity differently per call.

## Interaction flows

### Flow A: explicit memory search

Use when the agent wants to ask memory directly.

```text
Copilot -> MCP tool: memory_search(query)
MCP -> Gateway: POST /search/memories
Gateway -> TdaiCore -> store/files
Gateway -> MCP -> Copilot
```

This is the simplest and most reliable starting point.

### Flow B: recall before answer

Use when the host or agent wants contextual memory before generating a reply.

```text
Copilot turn starts
-> MCP tool memory_recall(session_key, query)
-> Gateway POST /recall
-> return compact context block
-> Copilot prepends/injects context
-> model answers
```

This can be:

- **manual** in v1: the agent explicitly calls `memory_recall`
- **automatic** later: an extension or wrapper calls it on every turn

### Flow C: capture after answer

```text
User message + assistant reply complete
-> MCP tool memory_capture_turn(...)
-> Gateway POST /capture
-> TDAI persists L0 and schedules L1/L2/L3 work
```

This is the second half of the loop. Without capture, recall quality decays quickly.

### Flow D: session shutdown

```text
Conversation ends
-> MCP tool memory_end_session(session_key)
-> Gateway POST /session/end
```

This matters for flushing and clean pipeline state.

## Recommended MCP server shape

Implement the MCP server as a **thin adapter**, not as a second memory system.

### Responsibilities

- validate tool input
- map Copilot session state to `session_key`
- call gateway endpoints
- normalize errors
- expose concise, LLM-friendly responses
- optionally expose configuration as MCP resources

### Non-responsibilities

- reimplement recall logic
- store memory itself
- bypass TdaiCore
- duplicate ranking, dedup, or persona logic

## Suggested MCP contract

### Tool: `memory_recall`

**Input**

```json
{
  "session_key": "copilot-session-123",
  "query": "What does Markus prefer for architecture sketches?"
}
```

**Output**

```json
{
  "context": "...",
  "strategy": "hybrid",
  "memory_count": 3
}
```

### Tool: `memory_capture_turn`

**Input**

```json
{
  "session_key": "copilot-session-123",
  "user_content": "Sketch architecture and save in docs",
  "assistant_content": "Created architecture sketch in docs",
  "messages": [
    {"role": "user", "content": "Sketch architecture and save in docs"},
    {"role": "assistant", "content": "Created architecture sketch in docs"}
  ]
}
```

### Tool: `memory_search`

**Input**

```json
{
  "query": "MCP wrapper for memory systems",
  "limit": 5
}
```

## Optional MCP resources

Resources are useful if you want operators to inspect state without using search tools.

Possible resources:

- `memory://health`
- `memory://persona/current`
- `memory://scenes/recent`
- `memory://sessions/<session_key>/summary`

Keep resources read-only in v1.

## Extension role later

Do **not** start with the extension unless the goal is host automation from day one.

The extension becomes useful for four things:

1. auto-run `memory_recall` before each turn
2. auto-run `memory_capture_turn` after each turn
3. manage gateway startup and configuration
4. provide a friendlier UI for status, diagnostics, and settings

### Extension architecture

```mermaid
flowchart LR
    C[GitHub Copilot] --> X[Copilot Extension]
    X --> M[MCP Server]
    M --> G[TDAI Gateway]
```

The extension should orchestrate. It should not own memory semantics.

## Deployment options

| Option | Shape | Recommendation |
|---|---|---|
| **Local sidecar** | Gateway runs on localhost, MCP server runs locally | Best default |
| **Bundled local process** | MCP server starts/stops gateway automatically | Good v2 |
| **Shared team service** | Remote gateway shared by users | Risky unless identity and tenancy are solved |

### Default

Use **local sidecar mode** first:

- simple trust boundary
- no multi-user tenancy problem
- matches current SQLite-first defaults
- easier debugging

## Security and operational constraints

### Main risks

| Risk | Why it matters | Mitigation |
|---|---|---|
| Session mix-up | Wrong memory injected into wrong conversation | Stable `session_key` mapping |
| Over-injection | Too much recalled context hurts output | Keep recall responses compact |
| Silent capture failure | Memory looks enabled but is stale | Add health/status diagnostics |
| Gateway drift | MCP contract and gateway API diverge | Keep wrapper thin and versioned |
| Multi-user leakage | Shared store exposes other users' memory | Prefer local per-user deployment |

### Guardrails

- default to local storage per user
- log recall and capture failures explicitly
- surface gateway health as an MCP tool/resource
- keep `messages` payload explicit for capture
- avoid automatic cross-session recall until session mapping is proven

## Implementation slices

### Slice 1: usable

- run TDAI gateway locally
- implement MCP wrapper for health, search, recall, capture, end-session
- manually invoke tools from Copilot

### Slice 2: comfortable

- add session-key management in MCP layer
- add compact response formatting
- add operator diagnostics and config docs

### Slice 3: seamless

- add Copilot extension
- automate recall before turn
- automate capture after turn
- optionally manage gateway lifecycle

## Minimal file layout for the integration project

```text
copilot-tdai-mcp/
  src/
    server.ts
    gateway-client.ts
    tools/
      memory-recall.ts
      memory-capture-turn.ts
      memory-search.ts
      conversation-search.ts
      memory-end-session.ts
      memory-health.ts
    session/
      session-key-store.ts
    config/
      schema.ts
  package.json
  README.md
```

## Design decisions

### Decision 1

**Use MCP as the primary integration surface.**

Reason: it is the shortest path from Copilot to the existing standalone gateway.

### Decision 2

**Keep TdaiCore behind the gateway.**

Reason: the gateway already defines a stable host-neutral boundary.

### Decision 3

**Delay the extension.**

Reason: Copilot-specific lifecycle automation is a convenience problem, not the core integration problem.

### Decision 4

**Prefer local deployment first.**

Reason: identity, privacy, and debugging stay manageable.

## Open questions for implementation

1. What stable session identifier can GitHub Copilot expose in the target host?
2. Should recall be explicit tool use only in v1, or host-automated?
3. Should the MCP server buffer failed captures and retry, or fail loudly?
4. Which LLM/embedding provider should be the default for standalone mode?
5. Is `persona.md` or scene state useful enough to expose as read-only MCP resources?

## Bottom line

The right architecture is:

**TencentDB-Agent-Memory Gateway -> MCP Server -> GitHub Copilot**

with an **optional Copilot extension later** for automation.

That gives the fastest usable integration, preserves portability, and avoids rewriting a memory engine that already has a host-neutral core.
