# The Architect–Padawan Model: Redefining Software Delivery in the Age of Agentic AI

**A Position Paper on the AI-Augmented IT Operating Model**

*EY Technology Consulting — March 2026*

---

## Executive Summary

Software development is undergoing a structural transformation driven by Generative AI. This paper argues that the commonly projected future — shrinking teams from 11 to 5–7 people — does not go far enough. The convergence of agentic AI, domain-driven design, and expanded model context windows enables a far more radical delivery model: a **Senior Architect** with deep domain and technical knowledge, supported by a **Padawan** focused on execution validation and learning, orchestrating autonomous agent swarms across the entire software development lifecycle.

This "Architect–Padawan" model is not a theoretical exercise. It reflects the operational reality emerging in organisations where senior professionals already use AI to absorb roles that were previously distributed across Business Analysts, UX designers, Solution Architects, junior developers, QA engineers, and DevOps specialists.

The term "Padawan" is deliberate. This is not a junior resource performing tasks — it is a **disciple** being trained by the Senior Architect to *become* the next Senior Architect. The Padawan role is first and foremost a talent development mechanism. Without it, the model collapses: Senior Architects are the scarcest resource in the system, the market cannot supply them at scale, and the only reliable way to produce them is through structured apprenticeship under a practising master.

However, this model addresses *delivery* — not *organisational adoption*. A separate, equally critical capability is required: **Change Management** to prepare the organisation, its governance structures, and its people for a fundamentally different way of working.

This paper consolidates and sharpens two prior works — an IT Operating Model presentation and a thought leadership paper on the Agentic SDLC — into a unified position.

---

## 1. The New Paradigm: Why AI Forces IT Operating Model Transformation

Over the next two to five years, the number one job for the CIO is to transform the IT Operating Model to target AI-enabled benefits and to manage novel risks.

Most enterprise IT organisations are on a journey from centralised, functional hierarchies towards distributed, value-creating team structures. This journey — documented extensively by DORA, the Accelerate research, and Team Topologies — has produced real gains in delivery speed, autonomy, and alignment with business outcomes.

AI does not replace this journey. It *accelerates* it — and in doing so, amplifies both its benefits and its failure modes.

### The Fragmentation Trap

Distributed operating models trade centralised control for team autonomy. When executed well, this creates alignment through shared purpose and guardrails. When executed poorly, it creates fragmentation: teams diverge in practices, tooling, and architecture, leading to:

- **IT cost escalation** as enterprise-level cost control erodes
- **Complexity growth** as cross-team visibility declines and technical choices diverge
- **Risk accumulation** as minimum standards go unenforced after centralised controls are removed
- **Coordination overhead** as prioritisation processes fail to integrate with distributed ways of working
- **Governance blur** as the ability to adopt new practices or address cross-cutting concerns is weakened

AI will significantly increase the speed of delivery. But without deliberate countermeasures, fragmentation will increase proportionally and cancel any positive effect of speed. Faster delivery without alignment is faster divergence.

---

## 2. Five Shifts Reshaping Software Development

The transformation from human-centric to agent-augmented development involves five interconnected shifts. Each one independently changes how software is built. Together, they change what a development organisation looks like.

### Shift 1: Skills — From T-Shaped to Broken Comb

Generative AI tooling expands the effective skillset of every individual. A senior developer using AI coding assistants, design tools, and requirements agents does not merely code faster — they operate across domains that previously required separate specialists. The metaphor shifts from "T-shaped" (expert in one area, collaborative across others) to "broken comb" (expert in one area, genuinely capable in several).

### Shift 2: Roles — Consolidation Through AI Augmentation

As individual capability expands, the number of distinct roles required to deliver a feature contracts. Requirements Engineer, UX Designer, Software Developer, Architect, QA Engineer, and DevOps specialist — these roles do not disappear, but their boundaries collapse. The skills persist; the role boundaries do not.

### Shift 3: SDLC — From Sequential Handoffs to Parallel Agent Orchestration

The traditional SDLC is built on sequential handoffs between specialists: Requirements → Design → Code → Test → Deploy. Each handoff is a translation point where context is lost and delay accumulates.

In the agentic SDLC, specialised AI agents work in parallel across all phases, operating on shared stateful artefacts rather than static documents. The human role shifts from executing within a phase to orchestrating across phases and validating outputs.

### Shift 4: Team Composition — From 5–11 Specialists to the Architect–Padawan Model

This is the central argument of this paper, developed in Section 3.

### Shift 5: Operating Model — Guardrails, Measurement, and Architectural Governance

Smaller teams with higher autonomy and agent-amplified output require:

- **Hard guardrails** — technical constraints enforced by platforms (API contracts, deployment policies, security scanning)
- **Soft guardrails** — agent-level instructions, architectural decision records, and coding standards embedded in agent configurations
- **Updated measurements** — metrics that detect technical debt accumulation and rework escalation before they compound
- **Stronger architectural governance** — both at the enterprise level (managing global complexity across teams and tribes) and at the team level (tech-lead-driven code-level quality)

---

## 3. The Architect–Padawan Model

### Why Current Projections Are Too Conservative

Existing analyses of the agentic SDLC — including our own prior work — project that feature delivery teams will shrink from 5–11 specialists to 3–7 people focused on oversight, validation, and complex problem-solving. This projection is too conservative because it preserves role distinctions that AI has already made redundant.

The historical separation between Business Analyst, Solution Architect, UX Lead, and Product Manager existed because **translation between business and technical domains was expensive and lossy**. You needed BAs to translate business intent into specifications, and architects to translate specifications into systems. Each translation introduced delay, distortion, and coordination cost.

Agentic AI absorbs much of this translation layer. The human who defines intent can now work across both domains simultaneously — *provided they have the domain knowledge and technical depth to do so*.

### The Model

| Capability | Role | What agents replace |
|---|---|---|
| **Business + Technical Design** | Senior Architect | BA, Solution Architect, PM, UX Lead |
| **Apprenticeship + Validation + Execution** | Padawan (disciple) | Junior Developer, QA Engineer, Technical Writer, DevOps |
| **Organisational Adoption** | Change Management (separate capability) | Nothing — agents cannot change people |

**The Senior Architect** is a domain-embedded professional who understands both the business problem and the technical system deeply enough to define intent at the level agents require. They design the system, orchestrate the agent swarms, make architectural trade-offs, and validate that agent outputs align with business goals and technical constraints. They are not a manager — they are a practitioner who happens to be the most effective unit of delivery when paired with agentic tooling.

**The Padawan** is a disciple — a person being deliberately trained by the Senior Architect to become a Senior Architect themselves. Their day-to-day work involves execution-level tasks: running validation pipelines, reviewing generated code, maintaining documentation, and managing deployments. But these tasks are the *vehicle for learning*, not the purpose of the role.

What makes the Padawan model superior to traditional apprenticeship is breadth of exposure. In a conventional team, a junior developer is siloed into writing code for one layer of one system. A Padawan reviewing agent-generated outputs across planning, design, implementation, testing, and deployment is exposed to the full SDLC every day. They see how the Architect translates business problems into technical intent, how agents elaborate that intent, and where agent outputs fail. This produces full-context professionals faster than any training programme or rotation scheme.

The Padawan pipeline is not optional. It is the **scaling mechanism** for the entire model. The market does not produce Senior Architects with the required depth of domain and technical knowledge. You must grow them — and the only reliable way to grow them is through sustained, hands-on apprenticeship under someone who is already practising at that level.

### Why Business and Technical Design Must Merge

Domain-Driven Design (DDD) already argued that the domain model *is* the technical model — that the most dangerous boundary in software development is the one between "the business people" and "the technical people." The agentic SDLC makes this structurally true.

When agents can generate code from structured requirements, the quality of the output depends entirely on the quality of the input. The architect who understands the tax regulation *and* the data model will define better agent prompts, catch more subtle errors, and make better trade-offs than a BA and a developer communicating through a specification document.

This is not an argument for full-stack developers. It is an argument for **full-context architects** — professionals whose scope is defined by the domain, not by a technical layer.

### The Scarce Resource

The bottleneck in AI transformation is not tooling, and it is not even talent in the aggregate. It is **domain-embedded architectural judgement**. Senior architects who understand both the business and the system at the depth required to orchestrate agent swarms effectively are rare. No amount of agentic tooling compensates for this gap.

This has direct implications for workforce strategy: the priority is not mass upskilling, but identifying, developing, and retaining the small number of people who can operate at this level — and building a deliberate apprenticeship pipeline (the Padawan model) to grow the next generation from within.

---

## 4. The Agentic SDLC in Practice

### How Agent Swarms Replace Handoffs

The traditional SDLC is a relay race: each phase produces an artefact that is thrown over the wall to the next phase. The agentic SDLC replaces this with a **stateful task object** — a structured, machine-readable representation of the work that evolves as agents contribute to it.

The Architect defines intent. Agent swarms elaborate, implement, and validate. The Padawan reviews and confirms. The task object serves as the single source of truth throughout.

### Architecture of Agent Swarms

The delivery model uses five swarm types, each composed of specialised agents:

**Planning Agent Swarm** — Requirements Agent, Data Model Agent, API Spec Agent, UX/Design Agent. Takes structured intent from the Architect and produces validated requirements, proposed UI components, API definitions, and schema changes. The Architect reviews and approves.

**Development Agent Swarm** — Code Agent, Testing Agent, Refactoring Agent. Reads the validated task state and generates implementation code, unit tests, integration tests, and end-to-end tests in parallel. The Padawan reviews generated outputs against the task definition.

**Validation Agent Swarm** — Build Agent, Static Analysis Agent, Security Agent, Linting Agent. Runs automatically on commits. Updates the task state with pass/fail results, security findings, and quality metrics.

**Deployment Agent Swarm** — Deployment Agent, Observability Agent. Handles rollout, monitors production metrics, and flags anomalies. The Padawan manages the deployment process; the Architect is available for escalations.

**Maintenance & Monitoring Agent Swarm** — Observability and Anomaly Agent, Incident Triage Agent, Documentation Agent, Reflection Agent. Handles ongoing operational concerns, generates documentation from the task state, and analyses completed work to identify process improvements.

**Guardrail Agents** operate continuously across all swarms, enforcing architectural standards, security policies, and coding conventions without requiring human intervention for routine compliance.

### Worked Example: Implementing a "Like" Feature

**Traditional approach (8+ people, linear handoffs):**
PM writes requirements doc → UX creates mockups → Backend engineer writes API → Frontend engineer builds UI → QA writes and runs manual tests → Security reviews → DevOps deploys → Tech writer updates docs. Each handoff introduces delay and context loss.

**Architect–Padawan approach (2 people, parallel agent swarms):**

1. **Architect** defines the goal and constraints in a structured task object: "Implement persistent per-user 'Like' for products. Heart icon. Display count. Must handle concurrent likes. Rate limit at 10/min/user."

2. **Planning Agent Swarm** elaborates: generates user stories with acceptance criteria, proposes UI component states linked to the design system, drafts the OpenAPI spec for `POST /products/{id}/like`, and proposes database migration. Architect reviews in 15 minutes — adjusts the rate limiting specification and approves.

3. **Development Agent Swarm** generates frontend component, backend endpoint, database migration, and comprehensive tests — all in parallel, all linked to the task state. Padawan reviews generated code against the acceptance criteria and API spec.

4. **Validation Agent Swarm** runs automatically: builds, tests, static analysis, security scan. Results flow into the task state. One minor security finding is flagged — the Padawan investigates and confirms it is a false positive.

5. **Deployment Agent** rolls out. Observability Agent monitors for anomalies in like-count endpoints and database write latency.

6. **Documentation Agent** updates API docs and changelog from the task state. Reflection Agent logs the cycle time and identifies that the security false positive came from an overly broad rule — suggests a guardrail refinement.

Total human effort: approximately 2–3 hours of focused work by the Architect and Padawan combined, distributed across a few review checkpoints. The agents handle the bulk of the execution.

---

## 5. Change Management: The Structural Prerequisite

The Architect–Padawan model describes a *delivery capability*. It does not, and cannot, address the organisational transformation required to adopt it. That is the domain of Change Management — and it is non-negotiable.

### Why Change Management Cannot Be Absorbed

Agents can generate communications, produce training materials, and analyse sentiment data. They cannot:

- Navigate organisational politics or entrenched power structures
- Build trust with people who fear their roles are being eliminated
- Negotiate with unions or works councils on workforce restructuring
- Facilitate the cultural shift from "I write code" to "I orchestrate agents that write code"
- Manage the grief cycle that accompanies genuine role transformation

These are fundamentally human capabilities that require empathy, political awareness, and sustained relationship-building. They sit outside the delivery model entirely.

### What Change Management Must Address

| Domain | Key Questions |
|---|---|
| **Governance, Risk & Compliance** | How do approval processes change when agents generate the artefacts? Who is accountable for agent outputs? How are audit trails maintained? |
| **Performance Management** | What does "good" look like when individual coding velocity is no longer the metric? How do we measure architectural judgement and validation quality? |
| **IT Financial Management** | How does the cost structure change when teams shrink but tooling costs increase? How do we allocate agent compute costs? |
| **Socio-Technical Architecture** | How do we design team and tribe structures when the delivery unit is 2 people, not 8? How do we maintain knowledge sharing and community? |
| **Ways of Working** | How do sprint rituals change? What replaces daily standups when agents produce async state summaries? How do code reviews work when most code is agent-generated? |
| **Workforce & Talent Management** | How do we manage the transition for people whose roles are being absorbed? How do we build the Padawan pipeline? How do we retain the Senior Architects who become the critical bottleneck? |
| **Sourcing & Third Parties** | How does outsourcing change when agent swarms replace offshore development capacity? What happens to vendor contracts structured around headcount? |

### The Organisational Interface

The Architect–Padawan model works best when the Architect is shielded from organisational overhead. This is where the change management capability must create the conditions for the model to operate:

- **Alignment mechanisms** — OKRs, architectural zones, and team-of-teams structures that keep autonomous Architect–Padawan pairs aligned without requiring constant coordination
- **Guardrail platforms** — Enterprise Architecture, security, and compliance functions that encode standards into agent configurations rather than review processes
- **Talent systems** — Career paths, compensation models, and apprenticeship programmes that recognise the Padawan as a deliberate investment in future capability, not a junior hire. The Padawan-to-Architect progression must be an explicit, resourced career track

---

## 6. Technology Enablers and Maturity Trajectory

The Architect–Padawan model depends on technology capabilities that are emerging now and will mature over the next 2–3 years.

### Current State (2025–2026)

- **GenAI tooling** is mostly intelligent wrappers around large language models; value comes from prompt engineering and API bundling, not core model innovation
- **Agent orchestration** is nascent — most tools lack native multi-agent orchestration (A2A) and multi-context prompting (MCP) support
- **Model specialisation** relies on large, general-purpose LLMs with plateauing reasoning for complex tasks
- **Context handling** is constrained — limited context windows require brittle summarisation workarounds

### Near-Term Future (2026–2028)

- **Tooling evolves toward platforms** with first-class support for agent APIs, integrations, and orchestration
- **Specialised small language models (SLMs)** trained for narrow roles (code critic, policy auditor, test generator) replace general-purpose models for routine tasks
- **Agent swarms** provide better results through task decomposition, tighter tool control, and more robust scaling
- **Context windows expand** to 100M+ tokens, enabling sustained reasoning over full systems without lossy summarisation

### Implementation Priorities

1. **Agent orchestration infrastructure** — Invest in frameworks (LangGraph, CrewAI, or equivalent) that support multi-agent collaboration over structured task states
2. **Stateful artefact standards** — Replace static documents with structured, agent-readable formats (JSON task objects, OpenAPI specs, executable acceptance criteria)
3. **Guardrail engineering** — Encode architectural standards, security policies, and compliance requirements into agent configurations and platform constraints
4. **SLM development pipelines** — Build internal capability to fine-tune small models for organisation-specific tasks
5. **Observability for agent systems** — Instrument agent workflows for monitoring, debugging, and continuous improvement

---

## 7. Risks and Mitigations

| Risk | Mitigation |
|---|---|
| **Over-reliance on single points of expertise** — The Senior Architect is a single point of failure | The Padawan pipeline is the primary mitigation. Each Senior Architect should always be training a Padawan. Knowledge is additionally captured in agent configurations, architectural decision records, and structured task histories — but these are supplements, not substitutes for apprenticeship |
| **Validation throughput bottleneck** — Agent swarms produce output faster than humans can review | Invest in automated validation (guardrail agents, test coverage, static analysis) to reduce the human review surface to genuinely ambiguous decisions |
| **Regulatory compliance gaps** — Agents produce artefacts but regulated environments require human accountability | Maintain clear accountability chains. Use agent audit logs as evidence. Adapt compliance frameworks to recognise agent-generated artefacts with human sign-off |
| **Cultural resistance** — Role consolidation triggers fear and defensiveness | Change Management capability must lead with empathy and concrete transition paths, not just efficiency arguments |
| **Technical debt acceleration** — Faster delivery may produce faster debt accumulation | Updated metrics (complexity growth rate, rework ratio, dependency health) must be embedded in guardrail agents and surfaced to the Architect |
| **Agent failure cascades** — Errors in one agent's output propagate through the swarm | Design agent workflows with validation checkpoints between phases. Require human approval at phase boundaries for high-risk changes |

---

## 8. Conclusion

The evolution of software development is not incremental. Generative AI and agent-based architectures represent a structural change in how value is delivered through code.

The commonly projected future — slightly smaller teams doing roughly the same work with AI assistance — underestimates the magnitude of this shift. The Architect–Padawan model reflects a more honest assessment: when agents absorb the translation, execution, and validation work that justified most specialist roles, the irreducible human contribution is **domain-embedded architectural judgement** and **the organisational will to change**.

The first is addressed by investing in Senior Architects who span business and technical domains, and building a structured apprenticeship pipeline — the Padawan model — that grows the next generation through hands-on practice under a master, not through courses or certifications. The second is addressed by a dedicated Change Management capability that prepares governance, talent systems, and culture for a fundamentally different operating model.

Organisations that invest in agents but skip change management will get faster fragmentation, not faster delivery. Organisations that restructure roles but lack domain-embedded architects will get well-organised mediocrity. Success requires both.

The future of the SDLC is not just faster or cheaper. It is more autonomous, more reliable, and — counterintuitively — more dependent on a small number of deeply skilled humans than ever before. Now is the time to identify those humans, build the systems around them, and prepare the organisation for what follows.

---

## References

### Technology & GenAI Systems

1. Bommasani et al. (2021) — *On the Opportunities and Risks of Foundation Models.* [arxiv.org/abs/2108.07258](https://arxiv.org/abs/2108.07258)
2. Chen et al. (2021) — *Evaluating Large Language Models Trained on Code (Codex Paper).* [arxiv.org/abs/2107.03374](https://arxiv.org/abs/2107.03374)
3. Bubeck et al. (2023) — *Sparks of Artificial General Intelligence: Early experiments with GPT-4.* [arxiv.org/abs/2303.12712](https://arxiv.org/abs/2303.12712)
4. LangChain, LangGraph, CrewAI — Agent orchestration frameworks. [docs.langchain.com](https://docs.langchain.com/), [langgraph.dev](https://www.langgraph.dev/), [docs.crewai.io](https://docs.crewai.io/)
5. Magic.dev — Long-Term Memory in LLMs, 100M+ token context. [magic.dev/blog/longterm-memory](https://magic.dev/blog/longterm-memory)

### Organisational Change, People & Process

6. Harvard Business Review (2023) — *Reinventing Roles in the Age of AI.* [hbr.org](https://hbr.org/2023/07/reinventing-roles-in-the-age-of-ai)
7. GitHub Copilot Research (2022–2024) — Developer productivity and pair programming with LLMs. [github.blog](https://github.blog/2023-06-27-the-copilot-effect-research-quantifies-productivity-gains/)
8. DORA / Accelerate — State of DevOps research on team performance and organisational capability. [dora.dev](https://dora.dev/)

### Architectural Foundations

9. Evans, Eric (2003) — *Domain-Driven Design: Tackling Complexity in the Heart of Software.* Addison-Wesley.
10. Skelton & Pais (2019) — *Team Topologies: Organizing Business and Technology Teams for Fast Flow.* IT Revolution Press.

---

*© 2026 EYGM Limited. All Rights Reserved.*
