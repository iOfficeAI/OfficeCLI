# Automation Portability

This repo runs on Windows-heavy operator environments, so workflow automation
must treat portability as a first-class design constraint.

## Default Pattern

Use:

- Python for shared runner logic
- thin Bash and PowerShell wrappers as entrypoints
- repo-local policy files for behavior
- CLI command templates for tool-specific launch integration

Avoid:

- duplicating workflow logic across `.sh` and `.ps1`
- assuming Bash is the default shell
- path handling that breaks on spaces or backslashes

## Rules

1. Put real orchestration logic in Python when the workflow is cross-platform.
2. Keep shell wrappers boring: resolve interpreter, forward args, exit with child code.
3. Quote paths aggressively in shell-facing docs and templates.
4. Prefer repo-local config and command templates over hardcoded environment assumptions.
5. Use `rtk` wrappers for shell commands in docs and examples when practical.

## Janitor Runner

`scripts/janitor.py` is the canonical pattern:

- `.janitor.yml` stores repo policy and baseline state
- runner config stores repo allowlist plus agent/PR commands
- `janitor.sh` and `janitor.ps1` only forward into the Python runner
- repo-local environment trust steps (like `mise trust -y --all`) belong in the Python runner so worktree behavior stays consistent across shells
- maintenance mode (`--cleanup-stale-janitor-worktrees`) reuses the same Python runner instead of inventing separate shell cleanup logic

## Optional Worktree Mode

Long-running or scheduled automation should prefer isolated work when it may be
surprising or disruptive to use the primary checkout.

Example:

```yaml
execution:
  use_worktree: true
  worktree_root: "~/.janitor-worktrees"
  keep_worktree: false
```

Use worktree mode when:

- automation is scheduled
- the main checkout should stay untouched
- the branch is disposable and PR-bound
- failures should not leave the primary checkout on a new branch

Use primary-checkout mode when:

- the run is fully local and supervised
- you explicitly want to inspect edits in place
- repo tooling does not tolerate worktrees

## Windows Notes

- Prefer PowerShell examples alongside Bash examples.
- Do not rely on Unix-only path assumptions.
- Use Python path handling instead of shell string surgery when possible.
- When wrappers invoke Python, propagate the child exit code exactly.
