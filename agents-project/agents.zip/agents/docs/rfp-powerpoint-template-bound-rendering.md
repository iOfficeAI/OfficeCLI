# RFP PowerPoint Rendering: Make It Truly Template-Bound

## Why this note exists

The current RFP PowerPoint path is conceptually strong upstream, but the rendering layer is still too code-driven and too weakly anchored to approved template truth.

That creates a predictable failure mode:

- strategy and drafting produce useful visual intent
- the renderer can output a slide
- but the final visual can still drift away from approved structure, capacity, and design patterns

For RFP work, that is the wrong tradeoff. The smart part should be upstream. The rendering part should be boring, constrained, and highly repeatable.

## Brutally honest assessment of the current state

The current renderer is **schema-bound** and **theme-bound**, but not yet properly **template-bound**.

Observed gaps in the current implementation:

| Area | Current state | Why it is a problem |
|---|---|---|
| Template inspection | `template_reader.py` is still a placeholder | The system cannot treat the template as a real contract |
| Slide creation | `presentation_writer.py` loads a template but creates a new blank slide and draws on it | The template influences the result less than it should |
| Layout control | Geometry is mainly driven by theme/layout math in code | Visual drift and layout creep become likely |
| Placeholder validation | `placeholder_checker.py` only checks crude markers like `TODO` and `TBD` | This is far too weak for production-quality template control |
| Variant control | Artifact types have preferred layouts, but not strong blueprint-to-variant binding | The system can still "fit" the wrong content into the wrong structure |

## Strategic position

The right architecture is:

1. **Agentic upstream**
   - decide which visuals matter
   - define artifact type
   - preserve the business meaning and structure
   - ensure evidence and narrative alignment
2. **Deterministic downstream**
   - select an approved blueprint
   - fill named slots
   - validate fit
   - fail loudly on overflow or missing structure

Short version:

> RFP intelligence should be agentic. PowerPoint rendering should be boring.

## Target operating model

The renderer should stop thinking in terms of "draw a nice slide" and start thinking in terms of:

> "Select approved blueprint X, fill slots Y, Z, and Q, and reject anything that does not fit."

That means the PowerPoint template becomes an executable contract, not a decorative input.

## Core proposals

### 1. Render into blueprint slides, not blank slides

Do not create a fresh blank slide for normal production rendering.

Instead:

- keep one hidden blueprint slide per approved artifact variant in the `.pptx` template
- duplicate the correct blueprint slide at render time
- fill the named shapes that already exist on that blueprint

This is the single biggest shift.

### 2. Introduce slot contracts

Every fillable region in a blueprint should have a stable slot ID.

Suggested naming pattern:

- `slot:title`
- `slot:subtitle`
- `slot:purpose`
- `slot:phase-1-title`
- `slot:phase-1-bullets`
- `slot:phase-2-title`
- `slot:raci-table`
- `slot:legend`
- `slot:footer-note`

Non-content shapes should also be named clearly:

- `chrome:header-bar`
- `chrome:section-divider`
- `chrome:accent-panel`
- `group:phase-1`
- `group:legend`
- `meta:blueprint-id`

### 3. Bind artifact types to approved blueprint variants

The artifact catalog should not only say "preferred layout". It should say which exact approved blueprint variants are allowed.

Examples:

- `roadmap` -> `roadmap-3-phase`, `roadmap-4-phase`, `roadmap-5-phase`
- `governance` -> `governance-3-lane`, `governance-4-lane`
- `raci_matrix` -> `raci-6x8`, `raci-8x10`

This is how you stop fake flexibility.

### 4. Add fit-preflight before rendering

Before modifying PowerPoint, the system should answer:

- Does this artifact fit blueprint `roadmap-4-phase`?
- Are there too many bullets?
- Are labels too long?
- Does the table exceed row or column limits?
- Is a different approved variant required?

If the answer is no, the system should switch to another approved variant or fail and escalate.

### 5. Prefer fill, show/hide, and swap over drawing

The renderer should prefer these actions:

- replace text in existing text boxes
- fill existing tables
- replace image placeholders
- show or hide approved groups
- duplicate predefined cards or rows only where the blueprint explicitly allows it

Drawing new shapes should be a controlled exception, not the default.

### 6. Fail on overflow instead of silently adapting

Do not let the renderer:

- silently shrink fonts
- squeeze extra bullets into a box
- create extra columns
- improvise new text boxes
- convert a visual into generic bullets because it got hard

If content does not fit the approved blueprint, the run should fail or escalate.

### 7. Strengthen validation from "style-ish" to "contractual"

Validation should check more than theme and color drift.

It should also verify:

- the chosen blueprint ID matches the artifact type
- every required slot is populated
- no required slot is empty
- no unresolved placeholders remain
- no unapproved extra text boxes or shapes were added
- the output shape count stays within the approved envelope
- all populated content stayed inside approved slot groups
- no blueprint family mismatch occurred

### 8. Fingerprint the template blueprint and the rendered slide

Each approved blueprint should have a fingerprint or version reference.

The render report should capture:

- template file used
- blueprint ID used
- blueprint fingerprint
- renderer version
- fit-preflight result
- any explicit exceptions

This turns quality disputes into traceable facts.

### 9. Move renderers toward slot payloads, not geometry authorship

Long term, renderers should output content for slots, not absolute positioning instructions.

Instead of:

- "draw chevron at X/Y with width Z"

Prefer:

- "fill blueprint `roadmap-4-phase`"
- `slot:phase-1-title = Mobilize`
- `slot:phase-1-bullets = [...]`
- `slot:phase-2-title = Implement`

This reduces rendering freedom and improves consistency.

## Concrete repo-level recommendations

### Short-term changes

1. Implement `template_reader.py` for real template metadata extraction.
2. Refactor `presentation_writer.py` so normal rendering duplicates blueprint slides instead of adding blank slides.
3. Extend `catalog.yaml` with blueprint variant bindings and capacity rules.
4. Strengthen placeholder and slot validation.

### Medium-term changes

1. Introduce explicit blueprint manifests.
2. Add fit-preflight per artifact type and variant.
3. Add no-extra-shapes and no-unapproved-text-box validation.
4. Require blueprint IDs in render reports.

### Longer-term hardening

1. Make `.pptx` template effectively mandatory for real production rendering.
2. Treat design profile as secondary to blueprint truth, not the primary layout source.
3. Reduce freeform native-shape drawing to the few artifact types where it is genuinely unavoidable.

## Suggested metadata model

The system should know, per blueprint:

| Field | Meaning |
|---|---|
| `blueprint_id` | Stable identifier such as `roadmap-4-phase` |
| `artifact_type` | Artifact family such as `roadmap` |
| `template_version` | Version of the source template |
| `slot_ids` | Required and optional named slots |
| `capacity_rules` | Max bullets, rows, columns, lines, characters |
| `allowed_overrides` | Which groups may be hidden or shown |
| `design_refs` | Approved exemplar or reference source |

## Suggested validation gates

Render should be blocked when:

- the requested artifact type has no approved blueprint
- the selected blueprint is missing required slots
- content exceeds blueprint capacity
- required slot content is empty
- a required table or group is missing
- the renderer added unapproved new content containers
- the template fingerprint does not match an approved version

## Design department cookbook: how to prepare the PowerPoint template

This section is written so it can be handed to the design team directly.

### Goal

Prepare PowerPoint templates that can be rendered safely and repeatedly by the RFP automation flow without layout drift.

### What the design team is designing

You are not designing one presentation. You are designing a **set of approved blueprint slides** that the renderer will fill with content.

Each blueprint slide should correspond to a known artifact variant, for example:

- roadmap with 3 phases
- roadmap with 4 phases
- governance with 3 swimlanes
- governance with 4 swimlanes
- RACI matrix with fixed row and column capacity
- risk and control matrix
- architecture overview

### Golden rules for template preparation

1. **One blueprint slide per approved variant**
2. **Every fillable element must have a stable shape name**
3. **Capacity must be designed intentionally, not left to chance**
4. **Optional content should use predefined groups**
5. **Do not expect the renderer to improvise layout**

### Required deliverables from design

The template handoff should include:

| Deliverable | Required | Notes |
|---|---|---|
| `.pptx` template with blueprint slides | Yes | Main source of truth |
| Blueprint inventory sheet | Yes | Lists each blueprint ID and intended use |
| Slot map | Yes | Lists shape names and slot purpose |
| Capacity rules | Yes | Max bullets, rows, columns, title length, etc. |
| Design rules | Yes | Fonts, colors, spacing, line styles, icon use |
| Approved exemplar deck or snapshots | Strongly recommended | For validation and governance |

### How to structure the template

#### A. Create hidden blueprint slides

For each approved variant:

- create one slide in the template
- keep it hidden from normal deck usage
- make it visually final, not approximate
- do not leave "designer TODO" content on it

Examples:

- `roadmap-3-phase`
- `roadmap-4-phase`
- `roadmap-5-phase`
- `governance-3-lane`
- `governance-4-lane`
- `raci-6x8`

#### B. Use the Selection Pane and rename shapes

Every fillable or controllable element must be renamed in PowerPoint's Selection Pane.

Recommended naming convention:

| Prefix | Use |
|---|---|
| `slot:` | Fillable content area |
| `group:` | Optional content group that may be shown or hidden |
| `chrome:` | Decorative or non-data element |
| `meta:` | Hidden metadata marker |

Examples:

- `slot:title`
- `slot:subtitle`
- `slot:purpose`
- `slot:phase-1-title`
- `slot:phase-1-bullets`
- `slot:phase-2-title`
- `slot:raci-table`
- `group:legend`
- `group:optional-footer`
- `chrome:header-bar`
- `meta:blueprint-id`

#### C. Add blueprint metadata

Each blueprint should carry a stable blueprint ID.

Preferred options:

1. a hidden text box named `meta:blueprint-id` containing the ID
2. a small hidden metadata block off-canvas
3. a separate machine-readable blueprint manifest distributed with the template

If possible, include:

- blueprint ID
- artifact type
- template version
- owner

### How to design slots

Each slot should be built for a known content type.

| Slot type | Recommended design approach |
|---|---|
| Title | Fixed single-line or controlled two-line area |
| Subtitle / purpose | Small fixed text box with clear max lines |
| Bullet area | Fixed bullet box with known max bullet count |
| Table | Real PowerPoint table with fixed row and column limits |
| Image | Reserved image frame with fixed crop behavior |
| Legend | Predefined grouped elements, not ad hoc mini-shapes |

### Capacity rules design must define

For each blueprint, document:

- maximum title length
- maximum subtitle or purpose lines
- maximum bullets per bullet slot
- maximum bullet line length if relevant
- maximum table rows
- maximum table columns
- whether text may wrap
- whether optional sections may be hidden

Example:

```text
Blueprint: roadmap-4-phase
- title: max 2 lines
- purpose: max 3 lines
- each phase title: max 24 characters
- each phase bullets: max 3 bullets
- each bullet: max 2 lines
- legend: optional
```

### How to handle optional content

If a visual may or may not contain something, prepare that in advance.

Good examples:

- optional legend as `group:legend`
- optional footer note as `group:footer-note`
- optional client logo area as `group:client-logo`

Bad examples:

- expecting the renderer to invent a footer when needed
- expecting the renderer to move everything because one extra note appears

### How to handle repeated structures

If the slide contains repeated content, prepare repeated placeholders.

Examples:

- `slot:phase-1-title` to `slot:phase-5-title`
- `slot:phase-1-bullets` to `slot:phase-5-bullets`
- `slot:lane-1-title` to `slot:lane-4-title`

Do not rely on dynamic layout if the structure can be fixed in the template.

### What design should avoid

Do not:

- leave unnamed shapes in blueprint areas
- rely on visual alignment that only works after manual nudging
- create blueprints that only work for one perfect text length
- hide critical capacity assumptions in someone's head
- use random grouping conventions across blueprint families
- expect the renderer to reflow the whole slide elegantly

### Suggested acceptance checklist for design handoff

Before handing the template to engineering, verify:

1. every blueprint slide has a stable blueprint ID
2. every fillable area has a slot name
3. optional groups are named and documented
4. all decorative chrome is stable and not expected to move
5. title and bullet capacity are documented
6. table limits are documented
7. blueprint variants exist for the expected size ranges
8. an approved exemplar or screenshot exists for each blueprint family

### Suggested blueprint inventory format

```text
roadmap-3-phase          -> artifact_type=roadmap
roadmap-4-phase          -> artifact_type=roadmap
roadmap-5-phase          -> artifact_type=roadmap
governance-3-lane        -> artifact_type=governance
governance-4-lane        -> artifact_type=governance
raci-6x8                 -> artifact_type=raci_matrix
risk-control-8x6         -> artifact_type=risk_control_matrix
architecture-layered     -> artifact_type=architecture_overview
```

## Practical handoff between design and engineering

The cleanest handoff model is:

1. Design delivers the `.pptx` blueprint template and blueprint inventory.
2. Engineering extracts slot metadata and capacity rules.
3. The renderer maps typed visual specs to blueprint IDs.
4. Fit-preflight selects the correct blueprint or fails.
5. Rendering fills slots only.
6. Validation confirms the output matches the blueprint contract.

## Recommended next engineering moves

If this is implemented incrementally, the best order is:

1. make `template_reader.py` real
2. introduce blueprint IDs and slot naming conventions
3. render by duplicating blueprint slides
4. add fit-preflight and capacity validation
5. tighten post-render validation to detect drift and unapproved additions

## Final position

If the team wants consistently good RFP PowerPoint output, the correct mindset is:

- upstream intelligence decides the visual
- the template decides the structure
- the renderer fills, validates, and refuses to improvise

Anything looser than that will keep producing slides that are technically generated but operationally unreliable.
