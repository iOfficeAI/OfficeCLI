# AI-First Software Delivery — Strategic Assessment and Target Operating Model

This paper brings together four inputs: the software-development automation thesis, the Architect-Padawan model, the petition-driven multi-agent delivery pipeline, and the ZRB approach to policy and compliance as code. Taken together, they point to a clear conclusion: the next wave of value in software delivery will not come from adding AI tools to the current SDLC. It will come from redesigning the operating model around AI.

The central question is therefore not whether AI can write more code. It can. The strategic question is whether organisations are prepared to redesign delivery around a new balance of human judgement, machine execution, policy control, and organisational adoption.

---

## Executive Synthesis

Five messages matter most.

1. **Execution is becoming cheaper; intent is becoming more valuable.** The bottleneck shifts upstream to requirements shaping, architectural judgement, and domain interpretation.
2. **Routine control should move into the pipeline.** Policy checks, tests, and rollout gates should absorb the repeatable path by default.
3. **Residual defects will persist.** Small intent and UX errors are best handled through a bounded super-user stabilisation layer rather than a large residual implementation workforce.
4. **The unit of delivery is changing.** Smaller Cells aligned to value streams can replace larger project-bound teams for a meaningful share of work.
5. **The harder transformation is organisational, not technical.** Change management, role redesign, and adoption readiness become more important as delivery execution becomes more automated.

---

## Part A — Strategic Assessment

The current body of thought is stronger than much of the market discussion around AI and software delivery. It already contains the outlines of a credible operating model. The task is not to discard it, but to sharpen it where it remains underspecified.

### A.1 What the current material gets right

| Element | Source | Why keep it |
|---|---|---|
| Discovery–execution boundary | Thesis §8.2, §8.4 | Empirically correct: execution layer automatable, elicitation is the durable bottleneck. Gives a defensible frontier rather than hype. |
| Legacy-as-executable-specification for brownfield | Thesis §4.3 | Converts the hardest modification problem into a well-specified greenfield one. Critical for FSV / public-sector modernisation. |
| Three human gates (Scaffold / Code / Merge) | OpenDebt + agents repo | Distributes evaluation load instead of concentrating it at UAT. Directly addresses Markus's "small errors" problem at the earliest, cheapest intervention point. |
| Catala / tier-based formal verification | Thesis §8.6.3 | Right answer for statutory domains (tax, debt, social security). Keep for FSV where law is the spec. |
| Professional accountability as pipeline *design* | Thesis §7.2, §8.6.5 | Accountability cannot be restored by moralising about AI — it must be engineered into gates, guardrails, audit trails. |
| Architect–Padawan as talent pipeline, not org chart | Padawan paper §3 | Correctly identifies domain-embedded architectural judgement as the scarce resource. Apprenticeship beats courses. |
| Five shifts (Skills / Roles / SDLC / Team / OM) | Padawan paper §2 | Clean framing for stakeholder narrative. |
| ZRB upfront enforcement (PaC, DCaC, DMaC) | ZRB deck | Turns compliance from repeated evidencing into continuous machine-checked state. Pairs perfectly with agentic pipelines. |
| Petition as discovery–execution interface | Agents repo | Makes the boundary *a concrete file*, not a slogan. Agents cannot bypass it. |

### A.2 Where the current thesis is directionally right

Four elements of the working thesis are especially strong.

1. **Agents will continue to produce small errors.** Even with strong TDD, property tests, and agentic self-review, a residual defect rate survives at the intent level because the ultimate oracle remains stakeholder interpretation.
2. **Headcount rebalancing is directionally right.** The model points to fewer pure implementers, broadly stable elicitation capacity, and greater emphasis on change management, validation, and feedback.
3. **A super-user stabilisation phase is operationally material.** It recognises that users often discover what they want by reacting to what they see, and it moves that feedback loop closer to the delivery engine.
4. **Development Cells should re-engage selectively.** Mature pipelines should absorb routine changes, while architectural and larger change requests pull scarce senior capability back into the flow.

### A.3 Where the thesis still needs sharpening

These points are best understood as design refinements, not rejections of the core argument:

| # | Gap / risk | Proposed fix |
|---|---|---|
| 1 | "**Super-users fix small errors**" blurs the accountability chain the thesis §7.2 worked hard to establish. Who owns a super-user's fix in production? What licensure, liability, audit trail? | Define super-users as a **bounded role with a defined remit**: they may fix UX copy, validation rules, configuration, and agent-prompted code suggestions within a sandboxed scope; they cannot alter architectural invariants, data contracts, policy-as-code, or integration boundaries. All super-user changes flow through the same petition / CR gate machinery — just at an accelerated cadence. |
| 2 | The model implicitly assumes super-users *have* coding tools and *can* use them safely. Most domain experts do not, and unconstrained AI-assisted editing in production-facing environments is a material governance risk. | Introduce an explicit **"Citizen Developer Guardrail Tier"**: super-users work only through pre-configured AI coding environments (Copilot Workspace / Cursor with project ruleset, or an internal equivalent) that can only read/write within whitelisted repos and against whitelisted tasks. No raw shell, no infrastructure, no secrets. Enforced via ZRB-style Policy-as-Code. |
| 3 | "More resources for user testing" is underspecified. User testing scales poorly if it's unstructured. | Adopt a **tiered feedback model**: (a) continuous telemetry (observability agent), (b) structured super-user triage, (c) cohort UAT, (d) full rollout canary. Each tier has its own closure SLA and its own re-entry rule back into the pipeline. |
| 4 | Dialectical thesis focuses on *building*; Padawan paper on *delivery capability*. Neither sufficiently addresses **operations and long-tail maintenance**. Markus's thesis is strong here but implicit. | Make Ops a first-class phase in the E2E description (Part B §5). Run-agents, anomaly-agents, SLO-agents must exist, and their outputs must be valid petitions back into the pipeline. The SDLC becomes a loop, not a pipeline. |
| 5 | Compliance-as-code assumes policy makers can produce PaC. In reality they produce prose. | Add a **Policy Translation Gate**: a `policy-to-PaC` agent that renders regulator/ADR text into PaC stubs, reviewed by policy owner + security SME. Without this, ZRB stays a slideware concept. Apply the same tier model as Catala: Tier A policies (hard constraints, legal force) → PaC with formal checks; Tier B (operational) → PaC with conformance tests; Tier C (guidance) → prompt-level soft guardrails. |
| 6 | "Same resources for requirements elicitation" is probably wrong. Elicitation *capacity* stays constant in people-count, but the **nature** of elicitation shifts: less document writing (agent-assisted), more structured challenge sessions, more domain modelling. | Re-characterise elicitation resourcing as "same *count*, different *skill mix*, deeper *domain embedment*". This is consistent with Padawan paper's "full-context architect". |
| 7 | Change management is correctly called out as non-absorbable, but remains abstract. The real gap is not technical control, but **operating-model adoption**: role transition, training, communications, stakeholder readiness, and workforce redesign. | Make this explicit. In this model, **Change Manager** means primarily **organisational change management**. Routine delivery control should be embedded in the petition/gate/PaC pipeline, while human attention shifts toward adoption readiness, rollout orchestration, and support preparedness. Then give OCM a concrete operating rhythm (Part B §6): role transition cohorts, Padawan onboarding cycles, union/works-council engagement plan, fitness-function dashboards for adoption, and a decommissioning programme for roles made redundant. This is where most AI transformations actually fail. |
| 8 | Thesis §8.6.7 warns N=1 (OpenDebt). Do not generalise the pipeline shape without acknowledging domain-specific enablers (regulated, statutory, well-documented). | In the E2E model, flag which components are *universal* vs *domain-conditioned*. Catala encoding is domain-conditioned; petition/gate structure is universal. |
| 9 | No treatment of **model supply chain and sovereignty** — which is exactly your Digital Sovereignty EY work. | Add sovereignty constraints: model provider selection, data residency, evaluator independence, exit strategy. Conscious lock-in, not zero lock-in (Fowler). |
| 10 | No treatment of **economic model**: who pays for agent compute, what the TCO curve looks like when you shrink teams, how vendor contracts change. | Add a commercial layer to the operating model (Part B §7.5). Padawan paper flags this but doesn't resolve it. |
| 11 | "Architect–Padawan" as **a pair** is a local optimum, not a stable org form at scale. Pairs are single-points-of-failure and create key-person risk. | Treat pair as the **delivery atom** but cluster atoms into a **Cell**: 1 Principal Architect, 2–3 Senior Architects, 3–6 Padawans, 1 Change Lead, 1 Product/Domain Partner, shared platform and compliance SMEs. This is defensible at scale, preserves apprenticeship, and eliminates bus-factor-of-one. |
| 12 | The models do not reconcile with **existing agile/Team Topologies** investment most enterprises have made. | Map roles onto Team Topologies: the Cell ≈ Stream-Aligned team; Platform Cell = Platform team; Compliance/PaC = Enabling team; Elicitation/Architect Guild = Complicated-Subsystem-adjacent. Preserves the organisational vocabulary CIOs already use. |
| 13 | "Super-user fix-up before UAT" risks becoming **permanent technical debt** if never escalated back. | Mandatory rule: every super-user fix **emits a petition or CR** back into the pipeline within N days; the fix is either ratified (promoted into the canonical pipeline, with tests + docs + PaC) or reverted. No silent persistence. |
| 14 | None of the documents address **evaluation and red-teaming of the pipeline itself**. The pipeline is software too; it has the same oracle problem. | Add a meta-layer: fitness functions for the pipeline (time-to-merge, defect leakage, rework ratio, human gate false-accept rate, prompt drift). Versioned agents with A/B evaluation before promotion. |

### A.4 Refined thesis

> *AI-first software delivery is best understood as a new operating model, not as a more efficient version of the current SDLC. In that model, intent remains human-led, execution is automated through a petition-driven and gate-constrained agent pipeline, routine control is embedded in policy, tests, and rollout gates, and residual small defects are absorbed through a bounded super-user stabilisation layer. Delivery capacity concentrates in Architect-Padawan Cells aligned to value streams, while freed capacity is redeployed toward deeper elicitation, organisational change management, and continuous user feedback. Compliance and infrastructure policy are engineered as code and verified continuously rather than evidenced periodically. The Cell re-engages directly where work exceeds the super-user remit or requires architectural judgement.*

This is strategically coherent, operationally actionable, and well suited to regulated environments where traceability and accountability matter as much as speed.

---

## Part B — Target Operating Model for AI-First Delivery

Part B translates the thesis into an operating model that leaders can actually mobilise. The underlying logic is simple: define intent explicitly, automate execution under policy, create structured human gates where judgement is still required, and close the loop with stabilisation, rollout, and operational feedback.

### B.0 Design principles

1. **Intent before code.** No production code is generated until a petition, outcome contract, and Gherkin/spec triple have passed a human scaffold gate.
2. **Gates, not heroics.** Quality is enforced structurally at three gates (Scaffold / Code / Merge). Agents cannot bypass gates.
3. **Compliance-by-construction.** Policy, data contracts, and data management rules exist as code and block non-conformant artefacts at the pipeline, not at audit time.
4. **Sovereignty by design.** Model providers, data residency, and evaluator independence are explicit architectural decisions (ADRs).
5. **Loop, not pipeline.** Operations and user feedback re-enter the delivery loop through structured channels (super-user remediation, CR, hotfix, feature petition).
6. **Apprenticeship is the scaling mechanism.** Every Senior Architect carries a Padawan. No Padawan → no promotion.
7. **Every fix is a petition.** Super-user fixes, hotfixes, and ad-hoc changes all emit a petition/CR. Nothing lives silently in production.
8. **Pipeline is software.** The pipeline itself has fitness functions, versioned agents, and evaluation gates.
9. **Routine delivery control is embedded.** Policy, tests, and rollout gates handle the repeatable path by default; humans focus on exceptions, elevated risk, and adoption readiness.

### B.1 Delivery lifecycle

```
 ┌───────────────────────────────────────────────────────────────────────────┐
 │  0. Ideation           1. Elicitation     2. Specification                │
 │  (human + AI probe) →  (human-led,     →  (agent-heavy, human-gated)      │
 │                         AI-augmented)                                     │
 │                                                                           │
 │  3. Execution          4. Verification    5. Stabilisation (super-user)   │
 │  (agent swarm)      →  (agents+gates)  →  (bounded, AI-assisted humans)   │
 │                                                                           │
 │  6. UAT / rollout      7. Operations      8. Feedback loop                │
 │  (cohort-gated)     →  (agent-run,     →  (emits petitions / CRs / HF)    │
 │                         human-owned)                                      │
 └───────────────────────────────────────────────────────────────────────────┘
          ▲                                                           │
          └─────────────── every change emits a petition ◀────────────┘
```

The lifecycle is intentionally designed to shift evaluation earlier, make execution more parallel, and give operational feedback a formal route back into delivery.

#### Phase 0 — Ideation

| | |
|---|---|
| Goal | Turn fuzzy initiative into an approved brief and a recommended first petition slice. |
| Human | Principal Architect + Product/Domain Partner + sponsor. |
| Agents | `ideation`, `idea-evaluator` (investment-style scoring). |
| Gate | **G0 — Brief Approval**: sponsor signs the brief; first petition slice named. |
| Artefacts | `petitions/ideation/<date>-<slug>-brief.md`, initial concept model delta, ADR candidates. |
| Safeguards | Idea-evaluator forces an INVEST / REFINE / RETHINK / SHELVE verdict before a single petition is written. |

#### Phase 1 — Elicitation (the durable human core)

| | |
|---|---|
| Goal | Produce a petition document: bounded, testable, traceable to domain and regulation. |
| Human | Senior Architect (lead), Domain SME, Padawan (observer), Policy/Legal SME if regulated. |
| Agents | `prompt-to-requirements` (structuring support only), `concept-model-curator`. |
| Method | Structured Socratic elicitation session, recorded. Architect writes the petition; agent proposes gaps and contradictions based on concept model and prior petitions. |
| Output | `petitions/P-NNN.md` (intent + scope + constraints + traceability). |
| Safeguards | Petition *must* cite domain entities from the concept model; Architect attests personally. Elicitation is **not delegated to agents**. |
| Rationale | Thesis §6.3, §8.5 — socially grounded, generative, cannot be replaced by retrieval. |

#### Phase 2 — Specification (execution handshake)

| | |
|---|---|
| Goal | Translate petition into machine-checkable artefacts. |
| Human | Senior Architect (reviewer), Padawan (reviewer + learning). |
| Agents | `petition-translator` → outcome contract; `petition-to-gherkin` → `.feature` + failing steps; `specs-translator` → entity / API / package spec; `catala-encoder` for Tier A statutory rules; `component-assigner` → maps scenarios to components; `c4-model-validator` → warn-mode architecture check. |
| **Gate G1 — Scaffold Review** | Architect + Padawan approve outcome contract, Gherkin, spec, C4 fit, PaC/DCaC impact. **No production code yet.** Cheapest rejection point. |
| Safeguards | Petition-translator-reviewer, gherkin-minimality-reviewer, specs-minimality-reviewer run before G1 is offered for human review. Minimality reviewers are mandatory — they block scope creep. |

#### Phase 3 — Execution (agent swarm)

| | |
|---|---|
| Goal | Produce working code, tests, formal rules, docs, PaC deltas. |
| Human | Padawan (day-to-day), Architect (escalations and architecture deviations). |
| Agents | `tdd-enforcer` (backend) / `portal-tdd-enforcer` (UI); `bdd-test-generator`; `playwright-test-generator`; `catala-encoder`; `doc-writer`; `tech-debt-executor` for TB items; `c4-architecture-governor` (enforce mode). |
| Parallelism | Independent services / components execute in parallel. Ambiguities are **not** resolved autonomously; agents emit `TB-*` items and stop. |
| Output | Code, unit/integration/BDD/E2E tests, Catala where applicable, doc deltas, PaC deltas, concept model updates. |

#### Phase 4 — Verification (agentic + human gate)

| | |
|---|---|
| Goal | Validate code before merge. |
| Agents | `code-reviewer-strict`, `code-minimality-reviewer`, `unit-test-minimality-reviewer`, `bdd-test-coverage-auditor`, `user-testing-flow-validator`, `gdpr-database-compliance-auditor`, `rigsarkivet-compliance-data-assessor` (or domain equivalents), `c4-architecture-governor` (PR mode), `verification-gate`. |
| **Gate G2 — Code Review** | Architect signs semantic correctness, scope, and architectural conformance. Automated review must already be green. |
| Static compliance | PaC / DCaC / DMaC evaluation runs on every PR. Failure = no merge. (ZRB principle.) |
| Formal verification | Catala files for Tier A petitions must typecheck and their test scopes must pass. |
| **Gate G3 — Merge Approval** | `doc-sync` has run; `program-status.yaml` updated; release notes drafted by `release-manager`. Architect or delegated Padawan (after N successful G3s) approves merge. |

#### Phase 5 — Stabilisation (the super-user tier — new, Markus's addition)

| | |
|---|---|
| Goal | Absorb residual small errors at the *intent* and *UX* level that survive Phases 3–4. Reach "end-to-end runs cleanly". |
| Entry condition | The owning Cell hands over only a product that is installable, starts correctly, and has passed a defined smoke test. If install/start or baseline smoke fails, the work stays with the Cell and does not enter the super-user lane. |
| Who | **Super-Users**: domain-expert early adopters trained on a constrained AI coding environment ("Citizen Developer Guardrail Tier"). Not developers. |
| Scope (hard bounded) | UX copy, validation rules, form layouts, non-statutory business rules, dashboard definitions, configuration, localisation, non-breaking agent prompt tuning. |
| **Out of scope** | Data model, API contracts, PaC, authentication, integration boundaries, statutory logic (Catala scopes), anything touching person-registry or financial ledger. Attempting these triggers a **CR escalation** to the Cell. |
| Environment | Purpose-built IDE (Copilot Workspace / Cursor with project ruleset, or internal equivalent). The IDE has: read access to whitelisted repos, write access via branch + PR only, auto-invocation of the standard agent pipeline (`petition-to-gherkin` → `tdd-enforcer` → `code-reviewer-strict` → G2/G3), no shell, no secrets, no direct infra. |
| Traceability | Every super-user change emits a lightweight `SU-NNN` petition that becomes a `CR-NNN` if adopted canonically. No silent persistence. |
| Exit criterion | **Stabilisation Exit Review** (gate S1): defect backlog below threshold, super-user CR acceptance rate > X%, no open super-user fixes touching out-of-scope zones. Only then does Phase 6 begin. |
| Safeguards | (a) Scope whitelist enforced at PR level by Policy-as-Code. (b) Weekly Architect triage of super-user branch activity. (c) Any super-user PR that `c4-architecture-governor` flags is auto-escalated to Architect. (d) All super-user activity logged in the same immutable audit trail as agents. |
| Rationale | Addresses thesis §6.3 evaluation bottleneck by distributing *early* evaluation to people who can read *and fix*. Addresses the "AI makes small mistakes forever" reality without re-staffing developers. |

#### Phase 6 — UAT / Rollout

| | |
|---|---|
| Goal | Validate with representative users beyond the super-user cohort; roll out under canary + feature-flag control. |
| Human | Change Manager (lead), Product Partner, Architect (escalation only). |
| Agents | `user-testing-flow-validator`, `release-manager`, observability agents. |
| Gates | **G4 — UAT sign-off** (cohort-based); **G5 — Production canary promotion**; **G6 — Full rollout**. |
| Safeguards | Canary metrics gate auto-rollback via observability agent; no rollout proceeds while SU-backlog is non-empty in-scope. |

#### Phase 7 — Operations

| | |
|---|---|
| Goal | Run the system; detect regressions, compliance drift, capacity issues. |
| Human | Platform Engineer (on-call), Padawan rotation (learning by operating). |
| Agents | Anomaly/triage agents, SLO agents, compliance-drift agents (PaC, DCaC), cost-anomaly agents, `hotfix-conductor` for P1 incidents. |
| Safeguards | Hotfix goes via fast-track but still defaults to branch + PR; retroactive full-pipeline pass is mandatory (TB-item). Emergency bypass requires two-person rule (Architect + Change Manager). |

#### Phase 8 — Feedback loop

| | |
|---|---|
| Goal | Convert operational and user signals into new petitions / CRs / hotfixes. |
| Agents | Reflection agent, `change-request-conductor`, observability digest agent. |
| Rule | Every signal is either *filed* (petition/CR/HF), *silenced with rationale* (ADR), or *escalated* (architect). Nothing disappears. |

### B.2 Roles and governance

#### What a Cell is, and is not

The Cell is the core organisational unit in this model. It concentrates scarce judgement, creates a durable home for apprenticeship, and allows governance, learning, and delivery rhythm to be reused across related work.

The Cell also retains accountability for technical readiness before any super-user handoff: the product must be installable, start correctly, and pass an agreed smoke test baseline. Super-users are for bounded stabilisation on a running product, not for making a broken product boot.

A **Cell** is aligned to a **value stream / domain boundary**, not necessarily to a single Jira project or funding line. One Cell may work on **multiple related projects, petitions, or work packages in parallel** if they share the same concept model, policy stack, architectural constraints, release cadence, and stakeholder set. This is efficient: the same Senior Architects, Padawans, super-user cohort, and change rhythm can serve several slices of one domain without recreating governance each time.

A Cell should **not** span multiple unrelated domains merely to keep utilisation high. If projects have different domain models, different regulatory exposure, different super-user populations, or different release authorities, the Cell becomes a bottleneck and the governance surface becomes incoherent. In that case, create a second Cell or cluster Cells under a shared Principal Architect.

Conversely, if a Cell is working on only **one small project**, headcount may be reduced, but **controls are not removed**. You may shrink the number of Padawans, share the Change Manager, and let the Principal Architect span more scope; you do **not** remove petition discipline, production gates, PaC evaluation, or the super-user traceability rule.

#### The Cell (delivery atom at scale)

| Role | Count / Cell | Core responsibility | Decisions owned |
|---|---|---|---|
| **Principal Architect** | 1 (may span 2 Cells) | Architectural integrity, sovereignty choices, PaC ownership, escalation point | ADRs, domain boundaries, vendor/model selection |
| **Senior Architect** | 2–3 | Elicitation, petition authorship, pipeline orchestration, G1–G3 sign-off | Petition scope, gate approvals, TB prioritisation |
| **Padawan** | 3–6 | Pipeline operation, code/spec/doc review, operations rotation, learning path | Routine G2/G3 after accreditation; TB triage |
| **Product / Domain Partner** | 1 | Business intent, prioritisation, user cohort liaison | Roadmap, value call |
| **Change Manager** | 1 (may span 1–2 Cells) | **Primarily organisational change management**: adoption, communications, training, workforce transition, stakeholder readiness, and UAT cohort orchestration. Works with the Architect on rollout readiness and exception handling where needed, but is not primarily a technical approval role. | UAT readiness, adoption plan, rollout cadence, support readiness |
| **Super-User Lead** | 1 (typically dotted-line from business) | Orchestrates super-user cohort, triages SU-NNN items | Phase 5 gate readiness |
| **Platform / Compliance SME** | shared across Cells | PaC, DCaC, DMaC, sovereignty controls, model-supply-chain | Guardrail rules, compliance tiering |

#### Shared / enabling functions

- **Architect Guild**: cross-Cell forum for Senior+Principal Architects; owns the petition template, agent prompts, and pipeline fitness functions.
- **Platform Cell**: runs the pipeline as a product — Gas-City-style orchestrator, model routing, secrets, observability, ZRB policy engine.
- **Policy Translation Cell**: regulatory / legal text → PaC / Catala. Tight loop with Compliance, Legal, DPO.
- **Padawan Programme Office**: manages cohort, rotation, accreditation, promotion criteria.
- **Independent Evaluator**: external or ring-fenced internal function that red-teams the pipeline itself and signs off on agent version promotions. *This is the analogue of audit 3rd line of defence — it exists to make the firm-level accountability chain (thesis §7.2) real.*

### B.3 Organisational enablers

The operating model only works if a small number of foundations are in place. Without them, AI-first delivery risks becoming a thin layer of tooling on top of the old model rather than a true redesign.

| Prerequisite | Why it matters | Concrete instantiation |
|---|---|---|
| Domain-embedded Senior Architects exist or can be identified | Padawan model has no masters otherwise | Named list, with backup; no Cell launches without one. |
| A Padawan pipeline and career track | Prevents the Senior-Architect single-point-of-failure | Formal programme, ring-fenced time for apprenticeship, promotion criteria tied to petitions/gates owned. |
| Engineering backbone | Petition store, agent runners, Git, CI, secret management, observability | Platform Cell stood up before first Cell delivery. |
| Policy-as-Code stack | ZRB principle — upfront enforcement | OPA / Rego / Kyverno / custom; PaC store versioned alongside code. |
| Concept model / domain ontology | Petitions cite it; agents use it | Living YAML curated by `concept-model-curator`; owned by Architect Guild. |
| Sovereignty policy | Model provider, data residency, exit plan | Signed by CIO/CTO; ADR; referenced in every agent deployment. |
| Legal / compliance buy-in | PaC and Catala only work if second-line accepts machine-checked evidence | Pre-agreed evidence format, joint PaC authorship, regulator briefing. |
| Works council / union engagement | Role consolidation will trigger industrial-relations risk | Early, honest, with transition packages and Padawan pathway for affected staff. |
| Commercial model | Vendor contracts structured around headcount will break | New contracts: outcome / petition-throughput / availability-based, not FTE-based. |
| Change management capability | Adoption will fail otherwise | Named Change Manager coverage for every Cell, shared across 1–2 Cells where adoption surface allows; adoption fitness functions dashboard. |

### B.4 Safeguards

The purpose of the safeguards is not to slow delivery. It is to make speed sustainable by ensuring that quality, accountability, and traceability are built into the system rather than inspected later.

1. **Three production gates + stabilisation gate + rollout gates**: G1 (Scaffold), G2 (Code), G3 (Merge), S1 (Stabilisation Exit), G4 (UAT), G5 (Canary), G6 (Full). Each has a defined human role and refusal criterion.
2. **Minimality reviewers**: separate agents whose only job is to reject scope creep in Gherkin, specs, tests, and code.
3. **Verification gate**: no success claim without fresh evidence (`verification-gate` agent pattern).
4. **Two-person rule** for any emergency bypass or super-user out-of-scope exception.
5. **Immutable audit trail** for agent + human + super-user actions (OpenDebt-style Dolt/Beads or equivalent append-only store).
6. **Pipeline fitness dashboard**: time-to-merge, defect leakage (prod defects per merged petition), rework ratio, gate false-accept rate, super-user escalation rate, compliance drift count. Reviewed monthly by Architect Guild + Independent Evaluator.
7. **Agent versioning + A/B evaluation**: no agent prompt reaches production without replay-testing against labelled historical petitions (regression suite for agents).
8. **Model-supply-chain controls**: signed model cards, evaluator independence, documented provider exit path.
9. **"Every fix is a petition" rule**: enforced by repo policy; silent drift is a blocking finding.
10. **Kill switch / manual override**: a documented procedure to run the Cell without agents for N days. Tested annually. If the Cell cannot deliver manually for a week, organisational risk is unacceptable regardless of savings.

### B.5 Resourcing implications

The model does not remove the need for capability; it changes where capability is concentrated. The broad pattern is a shift away from routine implementation and toward architecture, policy engineering, feedback absorption, and organisational adoption.

| Activity | Traditional 11-person team | AI-first Cell (same throughput) |
|---|---|---|
| Elicitation / domain | 1–2 BA | 2–3 Senior Architects (deeper, fewer, do more) |
| Architecture | 1 Solution Architect | 1 Principal Architect (spanning) |
| Implementation | 4–5 developers | 0–1 (Padawans do review, not primary authorship) |
| QA | 1–2 testers | 0 dedicated + agents + super-users |
| UX | 1 designer | Absorbed into Architect + design-system PaC |
| DevOps | 1 | Shared Platform Cell |
| Product / BA-adjacent | 1 PO | 1 Product/Domain Partner |
| *New* — Change Management | 0 | 1 per 1–2 Cells |
| *New* — Super-User Lead | 0 | 1 per business function (dotted line) |
| *New* — Padawan apprentices | 0 | 3–6 (future capacity investment) |

Net: smaller, deeper, with explicit investment in change, feedback, and talent succession. This matches your thesis *and* survives the gaps identified in §A.3.

Two clarifications matter here:

1. **Change-management demand scales with adoption surface, not with repo count.** A single technically small release can still need significant organisational change effort if it affects many user cohorts, operating procedures, unions/works councils, training materials, or service desks. Conversely, a deep technical platform change with few end users may need very little dedicated change-management capacity.
2. **A single-project Cell can be smaller than the reference shape.** If one Cell serves only one narrow project, you can reduce technical headcount (for example fewer Padawans, shared platform/compliance support, and a Change Manager shared across Cells). What must remain constant are the structural controls: petition-first work, gated verification, policy enforcement, audit trail, and super-user fixes flowing back as petitions/CRs.

### B.6 Failure modes and how the model responds

Like any operating model, this one should be judged not by whether failure modes exist, but by whether they are anticipated and addressed structurally.

| Failure mode | Where it surfaces | Catch |
|---|---|---|
| Agent produces plausibly wrong code | G2 + Phase 5 super-user usage | Strict code reviewer + super-user lived experience |
| Agent overreaches scope | Minimality reviewers before G1/G2 | Auto-block |
| Super-user creates shadow fork | Phase 5 scope rules + PaC | PR rejected; SU-NNN emitted |
| Architect becomes bottleneck | Padawan accreditation for G3 + Cell clustering | Architect signs only non-routine gates after maturity |
| Compliance drift | Continuous PaC evaluation + compliance-drift agent | Auto-ticket, pipeline blocked |
| Pipeline rot / agent prompt drift | Pipeline fitness functions + Independent Evaluator | Versioned rollback |
| Role-change resistance | Change Manager dashboard | Escalation to CIO before industrial-relations failure |
| Regulatory rejection of machine-checked evidence | Pre-agreed evidence format with 2nd/3rd line + regulator | Fallback: PaC report + human attestation |
| Vendor model lock-in (sovereignty) | Sovereignty ADR + exit drill | Annual multi-provider failover test |
| Single-point-of-failure architect | Cell clustering + Padawan pipeline | Structural, not heroic |

### B.7 What is universal and what remains domain-conditioned

Not every element of the model should be applied uniformly. Some features are broadly portable; others depend on regulatory intensity, policy maturity, and sector context.

| Universal (applies anywhere) | Domain-conditioned (tune per sector) |
|---|---|
| Petition → outcome contract → Gherkin/spec flow | Catala encoding (only where law *is* the spec) |
| G1 / G2 / G3 gates | Rigsarkivet / archival compliance agents (Danish public sector) |
| Minimality reviewers | GDPR isolation pattern (stricter in public sector / banking) |
| Architect–Padawan Cell | Super-user scope whitelist (depends on regulatory tolerance) |
| PaC / DCaC / DMaC as principle | Specific policy engines (OPA vs. Sentinel vs. custom) |
| Stabilisation super-user phase | Cohort size and fix-up SLA |
| Every-fix-is-a-petition rule | Vendor contract model |

---

## Part C — Implications for EY / FSV

For EY / FSV, the immediate opportunity is not to sell AI-enabled engineering in the abstract. It is to show a credible operating model for regulated delivery: one that improves speed and control together, aligns with sovereignty requirements, and can be piloted without enterprise-wide disruption.

1. **Start with one petition-sized use case** in a regulated domain with explicit law or policy logic. Debt, tax, VAT modernisation, and adjacent public-sector workflows are strong candidates.
2. **Stand up one Cell with named ownership** across architecture, product, change, and super-user participation. The aim is to prove the operating model, not merely the tooling.
3. **Put the control spine in place first**: petition flow, human gates, and minimum policy-as-code should exist before production code generation begins.
4. **Run the loop end to end once**, including the super-user stabilisation layer, controlled rollout, and operational feedback.
5. **Measure outcomes that matter**: defect leakage, super-user escalation rate, time-to-merge, compliance drift, adoption readiness, and Padawan progression. Do not lead with lines of code or hours saved.
6. **Scale only after repeated evidence.** One successful petition is promising; it is not yet proof of a scalable model.
7. **Make sovereignty and policy differentiation explicit.** Publishing the sovereignty ADR and policy tiering approach is where EY can create a distinctive position with CIOs, CTOs, and regulators.

---

*This paper is intended as a working operating-model view. The next step is to validate it through a small number of real petitions, measured against delivery, control, and adoption outcomes.*
