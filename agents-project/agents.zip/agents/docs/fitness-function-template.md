# Project Fitness Function Template

## Purpose

Use this template when a project needs a concrete harness for an important quality
or invariant.

Good fitness functions protect things that:

- matter a lot
- degrade silently if nobody checks them
- can be observed by test, metric, contract check, or named review gate
- should change delivery behavior when they fail

Typical examples:

- latency or throughput guardrails
- API or event contract compatibility
- browser E2E for a critical user journey
- security boundary rules
- architecture boundary rules
- calibration, provenance, or evidence integrity
- data freshness and lineage

Do **not** turn every requirement into a fitness function. Keep the set small and
decision-relevant.

## Recommended Shape

One fitness function should usually map to one protected property.

Prefer this structure:

`property -> mechanism -> threshold -> trigger -> owner -> consequence`

## Markdown Template

```markdown
## FF-<ID> - <Short name>

**Protected property:** <What important quality or invariant this protects>
**Type:** <NFR | architectural invariant | critical functional journey>
**Scope:** <service | UI | API | integration | data pipeline | docs | platform>
**Source:** <NFR register entry, ADR, policy, outcome contract, incident, etc.>

### Why it exists

<Why silent degradation matters. State business, operational, compliance, or delivery risk.>

### Mechanism

- **Check type:** <automated | manual | mixed>
- **Implementation:** <test suite, smoke check, static rule, metric alert, review gate, etc.>
- **Location:** `<file/path>` or `<system/dashboard>`
- **Trigger:** <on commit | in CI | nightly | pre-release | quarterly review | handover>

### Pass / Fail Rule

- **Pass when:** <concrete condition>
- **Fail when:** <concrete condition>
- **Threshold / tolerance:** <numeric or rule-based threshold; write "contextual" if dynamic>

### Owner and Action

- **Owner:** <role or team>
- **Failure action:** <block merge | block release | escalate | create backlog item | review manually>
- **Review cadence:** <how often threshold/mechanism is reassessed>

### Evidence

- **Evidence produced:** <report, screenshot, artifact, log, dashboard snapshot, review note>
- **Where stored:** `<path>` or `<system>`

### Notes

- **Trade-offs:** <what this may constrain or make slower>
- **Retirement rule:** <when to revise or remove this fitness function>
```

## YAML Template

Use YAML when the project wants a reusable register that agents can read.

```yaml
- id: FF-001
  name: "Contract alignment"
  protected_property: "UI, docs, and service contracts do not drift apart silently"
  type: "architectural invariant"
  scope: ["ui", "api", "docs"]
  source:
    - "compliance/nfr-register.yaml#NFR-012"
    - "architecture/adr/0012-contract-governance.md"
  rationale: >
    Silent contract drift breaks delivery, creates support churn, and erodes trust.
  mechanism:
    check_type: "automated"
    implementation: "contract smoke tests plus route checks"
    location:
      - "tests/compose_contract_smoke/"
      - ".github/workflows/test.yml"
    trigger:
      - "ci"
      - "pre-release"
  pass_rule:
    pass_when: "All required routes and payload contracts match expected shape"
    fail_when: "Required route missing, schema incompatible, or doc/runtime mismatch detected"
    threshold: "zero breaking diffs"
  owner: "Service owner"
  failure_action:
    - "block merge"
    - "block release"
  review_cadence: "each release and quarterly threshold review"
  evidence:
    produced:
      - "pytest report"
      - "CI job result"
    stored_in:
      - "CI artifacts"
  tradeoffs:
    - "Can create update cost when contracts legitimately evolve"
  retirement_rule: "Retire only if the interface is removed or replaced"
```

## Agent Drafting Flow

An agent can draft a good first version from existing repo truth.

### Best inputs

- NFR register
- ADRs
- architecture policies
- outcome contracts or validation contracts
- incident history or post-mortems
- `.factory/project.yaml`
- CI workflows
- existing unit, integration, smoke, or E2E tests
- observability dashboards or alert rules

### Drafting recipe

1. Read the NFR or control source.
2. Extract the protected property.
3. Ask: "What would silent degradation look like?"
4. Find the strongest existing mechanism already in repo.
5. Reuse that mechanism if it gives real signal.
6. Add threshold, trigger, owner, and failure action.
7. Reject draft entries that have no observable mechanism or no owner.

### Agent prompt pattern

```text
Read the NFR register, ADRs, project config, CI workflows, and current tests.
Draft 3-5 project fitness functions only.

For each one:
- map it to a specific protected property
- cite the source NFR/ADR/policy
- propose the mechanism using existing repo checks where possible
- define pass/fail rule
- define trigger, owner, evidence, and failure action

Do not create vague controls.
Do not create a giant catalog.
Prefer existing executable harnesses over new ceremony.
Flag any item that cannot yet be observed concretely.
```

## Starter Packs

Standard starter packs are a good idea if they are treated as **defaults**, not a
universal catalog.

Good rule:

- standardize the questions
- standardize the shape
- standardize common defaults
- do **not** force identical thresholds across every system

### Web UI application

Start with:

- critical user journey E2E
- UI/API contract alignment
- browser error budget or console-cleanliness check
- accessibility baseline for critical flows

### API service

Start with:

- backward compatibility or schema compatibility
- latency or response-time budget
- authn/authz boundary enforcement
- migration safety or startup health

### Event-driven or integration-heavy service

Start with:

- schema compatibility
- idempotency
- dead-letter or failure visibility
- processing lag / freshness

### Data or analytics product

Start with:

- freshness
- provenance / lineage
- null or completeness threshold
- critical transformation correctness

### AI or decision-support system

Start with:

- provenance / citation integrity
- calibration or drift visibility
- prompt / policy boundary checks
- fallback behavior when confidence is weak

## Selection Rules

Use a fitness function when all are true:

1. The property matters to architecture, trust, operability, or compliance.
2. Silent degradation is more dangerous than visible failure.
3. The project can observe it concretely.
4. A failing result should change team behavior.

Avoid:

- turning every requirement into a fitness function
- giant boilerplate catalogs
- thresholds copied from another system without local rationale
- manual reviews with no owner, cadence, or consequence
- tests that restate implementation but protect no architectural property

## Practical Recommendation

Per project, start with `3-5` active fitness functions.

Usually pick:

- `1-2` platform / architecture invariants
- `1-2` operational or NFR controls
- `0-1` critical functional journey if it protects a core business promise

If the list grows beyond that, split into:

- active fitness functions
- candidate controls
- normal tests and checks that are useful but not architecturally important
