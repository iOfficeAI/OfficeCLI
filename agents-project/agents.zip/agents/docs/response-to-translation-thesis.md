# Response to "Is Software Development Completely Automatable?"

Hey — read it properly, enjoyed it. The dialectical structure is honest, which is rare. Most people writing about this pick a side and lawyer for it. You didn't. The refined formulation at the end (execution layer automatable, discovery layer resistant) is defensible and I think basically correct.

A few things I'd push on — not because I disagree with the conclusion, but because I think there are moves available that would make it land harder, especially for anyone who actually has to make decisions about this in a real organisation.

## 1. The greenfield assumption

The entire pipeline you examine — requirements → design → code — assumes you're building something new. But the vast majority of enterprise software work is *change to existing systems*. And that's a fundamentally different automation problem.

Your task-class table (section 3.2) would look very different with an extra row: "Modify an existing 500k LOC system safely." That's not a requirements problem or a translation problem. It's an evidence problem. Can you demonstrate, structurally, that your change doesn't break something else? Can you answer "if I change X, what else is affected?" with confidence?

That question doesn't appear in requirements documents. It's not retrievable by web search. It requires structural analysis of the existing codebase — coupling topology, co-change history, consequence surfaces. LLMs are getting better at reading code, but "reading code" and "understanding the operational consequence of a change in a system you've never seen run" are very different capabilities.

This matters because the execution layer you describe as "largely automatable today" splits into two very different problems once you account for existing systems: (a) generating new code from clear specs, and (b) modifying existing systems with structural confidence. The first is approaching automation. The second is where most of the actual work happens, and it's much harder than your current framing suggests.

## 2. You identified the strongest objection and then dropped it

"No skin in the game" (section 5.3, objection 5) — you correctly call this out as having no structural equivalent in current AI systems. But then you leave it as an observation.

There's a more interesting move available: accountability doesn't have to be a property of the *agent*. It can be a property of the *system*.

If the delivery pipeline is designed so that every transition is attested, every promotion is evidence-gated, every output is traceable to its inputs and the policy it was validated against — then the system itself creates accountability structures. It doesn't matter whether a human or an AI produced the artefact. The flow enforces the same standard on both.

That reframes your objection from "AI lacks accountability, therefore it can't fully automate development" to "delivery systems need to be redesigned so that accountability is a property of flow, not of individual agents." The first is a dead end. The second is a design problem — and design problems have solutions.

## 3. Context is not the same as evidence

Your section 5 (context superiority argument) is the most interesting part of the paper, and the rebuttal is good. But it stops one step short.

The distinction you're circling is this: *knowing something* and *being able to demonstrate structural confidence in it* are fundamentally different operations.

An LLM with web search has information — vast amounts of it. But in any organisation where decisions have consequences (regulated or not), the question isn't "do you know this?" It's "can you show me *why* this is true for *this* system, at *this* moment, with *this* risk profile?"

That's not an information retrieval problem. It's an attestation problem. And it's the reason your "more context ≠ better calibration" objection is even stronger than you state it. The gap isn't just about calibration or Dunning-Kruger at scale. It's that the *type* of confidence required for consequential decisions is structurally different from pattern-matching against a large corpus.

## 4. The absorption question

Your paper asks: "Can AI produce the software?" That's the right question for the dialectic you're running. But there's a harder question hiding behind it: "Can the organisation *absorb* what AI produces?"

Your own evaluation bottleneck point (section 5.3, objection 4) almost gets there. You note that full pipeline automation doesn't eliminate human judgment — it concentrates it. But you frame this as a limitation of AI. It's actually a limitation of *organisations*.

Even if AI could perfectly automate the execution layer tomorrow, most organisations would hit a bottleneck at validation, integration, assurance, and operations. The constraint isn't code generation speed. It's the organisation's capacity to absorb machine-speed change while maintaining trust, traceability, and control.

That's not a theoretical problem. It's the actual, practical reason why "AI can write code" doesn't translate into "AI transforms software delivery." The delivery system has to be redesigned to absorb the output — and that redesign is where most of the real work (and real value) sits.

## One question back at you

You split the world into "execution layer" and "discovery layer." Clean cut, and I buy it directionally. But: is the discovery layer actually one thing?

Requirements elicitation (social, generative, Socratic) and architecture decisions (trade-off reasoning under constraints) and domain modelling (structural representation of business logic) — these have very different automation profiles. Lumping them together under "resistant to automation for deep reasons" might be too tidy. Architecture decisions, for instance, might be more automatable than you think once the constraint space is well-defined. Requirements elicitation might be *less* automatable than you think because the social trust dimension actively resists digitisation.

Would be curious whether the discovery layer decomposes into something more useful than a single category.

---

Good piece. Sharpen the greenfield blind spot and the accountability-as-system-property move, and it gets significantly harder to argue with.
