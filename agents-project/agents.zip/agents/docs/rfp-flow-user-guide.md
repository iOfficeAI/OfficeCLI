# RFP Flow User Guide

This guide is for people using the RFP flow, not for people changing the agent internals.

The entrypoint is `rfp-conductor`. It orchestrates intake, compliance, strategy, drafting, review, evidence checks, packaging, and optional PowerPoint visual generation.

---

## What this flow is for

Use the RFP flow when you want the agent system to turn tender material into a controlled proposal package without skipping the hard parts.

It is designed to:

- read and normalize tender documents
- extract and classify requirements
- block unresolved mandatory gaps before drafting
- shape a response strategy
- draft a traceable response
- red-team the answer quality
- audit proof-bearing claims
- package the final submission
- generate and validate deterministic PowerPoint visual artifacts when needed

It is **not** designed to:

- invent proof
- hide compliance gaps inside good-looking prose
- let visual polish substitute for submission readiness
- guess final packaging rules when the tender is unclear

---

## Tiny picture

```text
Tender docs + instructions
          |
          v
  rfp-conductor
          |
          v
Intake -> Compliance -> Strategy -> Draft -> Red-team -> Evidence -> Packaging
                                                            |
                                                            v
                                       Per-visual PowerPoint render + style validation
                                                            |
                                                            v
                                                  Readiness close
```

---

## What you should provide up front

| Input | Required | Why it matters |
|---|---|---|
| Tender / RFP documents | Yes | Core source material |
| Submission instructions / portal guidance | Yes | Format, naming, annex, and deadline rules |
| Desired output target | Yes | Tells the flow what to produce |
| Q&A addenda | Usually | Can change requirements materially |
| Templates (Word / PowerPoint) | If required by tender | Needed for packaging |
| Capability sources | Recommended | Gives the draft something real to say |
| Approved case studies / references / CVs / certifications | Recommended | Needed for proof-critical claims |
| Pricing / commercial guidance | If relevant | Prevents fake certainty |
| Approved design exemplars for PowerPoint | Strongly recommended | Needed if you want PowerPoint style validation to mean anything |

If you care about slide quality, provide **approved design examples**. Without them, the flow can still render PowerPoint visuals, but style validation is only against a starter design profile, not real approved design truth.

---

## How to start

Use `rfp-conductor` as the only normal entrypoint.

### Minimal example

```text
@rfp-conductor
Run the RFP flow for tender ABC-123.
Source documents are in rfp\ABC-123\source\
Submission instructions are in rfp\ABC-123\instructions\
Target deliverable: proposal package with PowerPoint visuals and, if required, an assembled deck.
```

### Better example

```text
@rfp-conductor
Run the RFP flow for Municipality AI Copilot tender ABC-123.

Use:
- tender documents in rfp\ABC-123\source\
- portal instructions in rfp\ABC-123\instructions\
- approved case studies in rfp\ABC-123\inputs\references\
- CVs in rfp\ABC-123\inputs\cvs\
- PowerPoint template in rfp\ABC-123\inputs\template\
- approved deck examples in rfp\ABC-123\inputs\design-exemplars\

Target deliverables:
- submission-ready response package
- PowerPoint visuals and, if needed, an assembled deck
- clear escalation list for anything still blocked
```

---

## What happens at each stage

| Stage | Main agent | What it does | Main output |
|---|---|---|---|
| 0. Validate inputs | `rfp-conductor` | Resolves RFP-ID, checks that the run has a safe starting point | artifact root under `rfp\<RFP-ID>\...` |
| 1. Intake normalization | `rfp-intake-normalizer` | Converts raw tender docs into usable text and extracts requirements and ambiguities | intake summary, requirements register, clarifications |
| 2. Compliance mapping | `rfp-compliance-mapper` | Classifies each requirement and exposes gaps before drafting | compliance matrix, gap log |
| 3. Strategy shaping | `rfp-strategy-shaper` | Decides how the bid should win and where visuals matter | strategy brief, outline, visual brief |
| 4. Response drafting | `rfp-response-drafter` | Writes the proposal body with requirement traceability and claims tracking | draft response, claims register |
| 5. Red-team review | `rfp-red-team-reviewer` | Reviews for evaluator logic, depth, credibility, clarity, and visual adequacy | red-team review artifact |
| 6. Claim evidence gate | `rfp-claim-evidence-auditor` | Verifies whether claims are actually supported | audited claims register, evidence audit |
| 7. Submission packaging | `rfp-submission-packager` | Assembles files, validates completeness, prepares render inputs | submission manifest, packaged deliverables |
| 8. PowerPoint generation | `powerpoint-rfp-generator` | Renders one typed visual at a time and validates the rendered slide artifact | rendered `.json`, optional `.pptx`, render report, style-validation report |
| 9. Readiness close | `rfp-conductor` | Decides whether the package is truly ready to submit | final status and next action |

---

## What the flow will block on

The flow is intentionally strict. It should stop instead of bluffing.

Expect a stop or escalation when:

- a mandatory requirement is unresolved
- a referenced annex or form is missing
- pricing, legal wording, or named commitments are not approved
- a proof-critical claim has no real source
- packaging instructions are contradictory or unclear
- a PowerPoint deliverable needs a visual standard, but no approved exemplar or design profile exists

That is not failure theater. That is the point of the flow.

---

## PowerPoint-specific path

If the tender requires PowerPoint, the flow does more than "make slides."

### What should happen

1. `rfp-strategy-shaper` defines where visuals are score-moving.
2. `rfp-response-drafter` preserves enough structure to render those visuals later.
3. `rfp-submission-packager` creates:
   - `visual-manifest.yaml`
   - `design-profile.yaml`
   - typed visual specs under `visuals\specs\`
4. `powerpoint-rfp-generator` renders each typed visual deterministically into JSON and, when requested, a single-slide `.pptx` artifact.
5. Each rendered `.pptx` visual is checked against the design profile after rendering.
6. If a final submission deck is required, `rfp-submission-packager` assembles it as a separate packaging step and only then claims the package-level `.pptx`.

### What you should provide if you want good deck quality

- an approved PowerPoint template
- approved deck examples or approved design snapshots
- any non-negotiable branding/layout rules

### What happens if you do not provide approved exemplars

The system can still render the visuals, but the style-validation result is weaker. It can catch density, layout drift, and palette issues against the supplied profile, but it cannot honestly claim "this matches approved design" unless a real approved design source exists.

---

## What you get back

The flow writes artifacts under:

```text
rfp\<RFP-ID>\
```

Typical outputs:

- `intake\source.md`
- `intake\rfp-intake.md`
- `intake\requirements-register.yaml`
- `compliance\compliance-matrix.yaml`
- `strategy\response-strategy.md`
- `strategy\response-outline.yaml`
- `strategy\response-visual-brief.yaml`
- `drafts\response-v<N>.md`
- `evidence\claims-register.yaml`
- `reviews\red-team.yaml`
- `evidence\evidence-audit.yaml`
- `package\submission-manifest.yaml`

If PowerPoint is in scope, also expect:

- `visuals\visual-manifest.yaml`
- `visuals\design-profile.yaml`
- `visuals\specs\<NN>-<artifact-id>.yaml`
- `visuals\rendered\<NN>-<artifact-id>.json`
- optional `visuals\rendered\<NN>-<artifact-id>.pptx`
- optional `visuals\rendered\<NN>-<artifact-id>.report.json`
- optional `visuals\rendered\<NN>-<artifact-id>.style-validation.json`
- `package\<submission-name>.pptx` only when a final deck was actually assembled in this run
- optional `package\powerpoint-render-report.json`

---

## Status meanings

These are the main statuses you will see from the conductor or sub-agents.

| Status | Meaning |
|---|---|
| `success` | The stage completed safely |
| `partial_success` | Useful progress exists, but a human choice or approval is still open |
| `blocked` | A prerequisite, mandatory requirement, or proof item is missing |
| `needs_more_evidence` | The system cannot support the claim yet with the current artifacts |
| `retry` | The issue is recoverable and should be rerun with targeted fixes |
| `fail` | The stage could not continue safely and needs repair or escalation |

---

## Practical rules

1. Start with `rfp-conductor`, not a downstream node.
2. Give the agent real source paths, not vague descriptions.
3. Treat addenda as part of the tender, not optional garnish.
4. Do not push the flow past a compliance or evidence gate "just to see a draft."
5. If PowerPoint quality matters, provide approved examples early.
6. Expect the red-team step to be harsh. If it is polite, it is probably useless.
7. A good-looking deck does not override a weak claim or a missing annex.

---

## Common failure modes

| Problem | What usually caused it |
|---|---|
| Draft sounds generic | Weak strategy brief, thin capability sources, or draft skipped score-moving detail |
| Compliance gate blocks drafting | Mandatory requirement unresolved or no safe answer path |
| Evidence audit blocks packaging | Claims register points to proof that does not exist or was not provided |
| Deck looks flat | Visual brief was weak, typed specs were missing, or no approved exemplars were provided |
| Final readiness is withheld | One of the upstream proofs is stale, partial, missing, or ambiguous |

---

## Simple operator checklist

- Do I have the tender documents?
- Do I have the submission instructions?
- Do I know the required deliverables?
- Do I have the proof-bearing inputs for important claims?
- If PowerPoint is required, do I have the template and approved design examples?
- Am I willing to stop when the flow finds a real blocker?

If the answer to the last question is no, do not use this flow. It is designed to stop bad submissions, not prettify them.
