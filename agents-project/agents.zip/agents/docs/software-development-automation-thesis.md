# Is Software Development Completely Automatable?
## A Dialectical Examination of the Translation Thesis

**Abstract**

A recurring argument holds that software development is, in principle, fully automatable: since all artefacts in the development pipeline are expressible in formally characterisable languages, the transitions between them fall within the reach of Turing-complete computation. This argument has motivated model-driven engineering, program synthesis, and most recently LLM-based agentic coding systems. This article reconstructs the argument, identifies a logical gap in its formal structure, and subjects it to six rounds of dialectical critique and rebuttal — arriving at a refined position that locates the automation frontier more precisely than either side of the debate typically manages.

The core conclusion — that the execution layer of development is largely automatable while the requirements-elicitation layer resists for social and generative reasons — is not new. Brooks made the essential distinction in 1986, and Jackson, Parnas, and Floyd elaborated it. What this article adds is a contemporary reassessment in light of LLM capabilities, an analysis of the brownfield legacy-as-specification strategy, a decomposition of the "discovery layer" into sub-activities with distinct automation profiles, and a worked example — OpenDebt, a 13-service debt collection platform for Danish public institutions — where a multi-agent pipeline instantiates the article's structural claims across formal statutory verification, three mandatory human gates, and petition-driven work decomposition.

**Disclosure.** This article was developed within a professional services context (EY). The conclusion that accountability can be a property of delivery systems rather than individual agents is commercially convenient for firms that deliver AI-mediated solutions. The argument is made on its merits, but the reader should note the interest.

---

## 1. The Translation Thesis

### 1.1 The Formal Argument

The argument can be stated in seven steps:

1. **Requirements** are expressed in natural language (NL) or structured NL. NL is at most recursively enumerable — it can be generated and recognised by a Turing machine.
2. **Architecture and design** are expressed in semi-formal or formal notations (UML, ADLs, pseudo-code). These are at most context-sensitive languages, a strict subset of what Turing machines can handle.
3. **Source code** is expressed in context-sensitive formal languages with well-defined semantics.
4. By the **Church–Turing thesis**, any effectively computable function is computable by a Turing machine.
5. Each transition in the pipeline — requirements → design → code — is therefore a *translation* between languages within the Turing-recognisable range.
6. Translation between Turing-recognisable languages is itself a computable function.
7. **Therefore**, the entire software development pipeline is, in principle, automatable.

This argument structure underlies **model-driven engineering** (Stahl & Völter, 2006; Czarnecki & Helsen, 2003), **program synthesis** (Gulwani et al., 2017), and much of the implicit case for LLM-based coding assistants. The pipeline it describes is already partially operational.

### 1.2 Where the Argument Is Genuinely Strong

The argument captures something real, and that should be acknowledged before critique.

**Formal specification → code is already automated.** Tools like TLA+ model checkers, Coq proof assistants, and SMT-based synthesisers translate formal specifications into verified implementations for bounded domains. Amazon Web Services uses TLA+ for critical infrastructure verification (Newcombe et al., 2015); the seL4 microkernel (Klein et al., 2009) and CompCert compiler (Leroy, 2009) demonstrate full formal verification of non-trivial systems. This is production practice, not a research curiosity.

**The translation framing is historically productive.** The structured programming movement, CASE tools, MDA (Model-Driven Architecture), and now LLM-based code generation all share the implicit assumption that development is a translation problem. Progress in each generation has been real, even if not complete. Czarnecki and Helsen's taxonomy of model transformation approaches (2003) maps an entire field built on this premise.

**Empirical velocity is accelerating.** GitHub Copilot, Cursor, Devin, and similar tools demonstrably reduce the mechanical effort of coding. On SWE-bench — a benchmark of real GitHub issues — top agentic systems now resolve 50–60% of tasks end-to-end (Jimenez et al., 2024), a figure near zero three years ago. Peng et al. (2023) found Copilot users completed tasks 55.8% faster in a controlled experiment. For well-understood problem domains with abundant prior code, automation is approaching practical sufficiency.

---

## 2. First Critique: Formal Objections

### 2.1 The Logical Gap — Language Computability Does Not Imply Mapping Computability

The most fundamental flaw in the Translation Thesis is in **step 6**: the claim that translation between Turing-recognisable languages is itself a computable function.

This does not follow. The computability of the *representation languages* says nothing about the computability of any particular *mapping* between them. The halting problem is a function from programs (a recursive language) to {halt, loop} (a finite language) — and it is not computable. More precisely: there exist uncountably many functions between any two infinite Turing-recognisable languages, and only countably many of those functions are computable. The overwhelming majority of possible mappings between such languages are not computable at all.

The Church–Turing thesis states that any *effectively computable* function is Turing-computable. It does not state that any function between Turing-recognisable languages is computable. The Translation Thesis requires the second claim, which is false.

What would be needed to rescue step 6 is a demonstration that the *specific* mapping from requirements to correct implementations is an effectively computable function. For formal specifications with well-defined semantics, this is demonstrable in bounded domains — and indeed demonstrated by the formal verification successes cited above. For natural language requirements with the properties described in §2.3, no such demonstration exists and there are reasons to believe it cannot.

The Translation Thesis, as formally stated, is invalid. What follows in this article treats it as a *practically motivated conjecture* rather than a proven theorem.

### 2.2 Computability ≠ Tractability

Even granting — for argument's sake — that the requirements-to-code mapping is computable, computability says nothing about computational complexity. Many computable functions have super-exponential solutions or terminate only asymptotically.

The search space for translating ambiguous natural language requirements into a correct, optimal implementation is astronomically large. Computability theory and complexity theory are orthogonal axes (Sipser, 2012):

> Computability: *can* it be computed?
> Complexity: *how long* will it take?

The Translation Thesis conflates the first with the second. This is a well-known conflation in software engineering argumentation — Parnas (1985) identified the same error in arguments for automated program verification.

### 2.3 The Premise Does Most of the Work — and Is False in Practice

The argument's decisive qualifier is *"if the requirements are given."* This is not a minor caveat. It is the entire problem.

In practice, requirements are never fully given. They are:

- **Incomplete**: clients know what they want only partially, and often discover the rest by seeing what they do not want (Floyd, 1984).
- **Contradictory**: different stakeholders impose mutually incompatible constraints.
- **Implicit**: domain knowledge, organisational norms, and regulatory context are assumed but not stated (Jackson, 2001).
- **Evolving**: requirements change throughout development, including in response to seeing early implementations.

The elicitation, negotiation, and disambiguation of requirements is arguably the highest-value activity in software development — and it is not a translation exercise. Brooks (1986) identified this as the "essential difficulty" of software: the specification of the conceptual construct, not its representation in code. The subsequent forty years of requirements engineering research have reinforced rather than weakened this assessment.

### 2.4 Verification Is Undecidable

Even granting that a translation is performed, there is a deeper theoretical obstacle: you cannot automatically verify that the output is correct.

The general problem of determining whether a program satisfies an arbitrary specification is undecidable — a consequence of the halting problem. **Rice's theorem** establishes a specific form of this: every non-trivial *extensional* (semantic) property of programs is undecidable. That is, there is no general algorithm that can determine, for an arbitrary program, whether the partial function it computes has a given non-trivial property.

Applied to the automation question: an automated system that generates code from requirements cannot, in general, verify its own output. It must either:

1. Operate in a sufficiently restricted domain where decidability can be recovered (bounded model checking, type systems, contracts — as demonstrated by seL4 and CompCert), or
2. Produce output whose correctness cannot be automatically guaranteed.

### 2.5 The Semantic Gap in Natural Language

The argument treats natural language as a formal object — a string-generating system with a grammar. This is technically defensible (Chomsky, 1957) but pragmatically misleading.

Natural language meaning is not a function of syntax alone. The philosophy of language offers at least four relevant dimensions:

- **Shared world models** (domain knowledge, organisational context)
- **Pragmatic implication**: Grice's Cooperative Principle (1975) establishes that speakers routinely convey meaning not contained in the literal content of their utterances — through quantity, quality, relevance, and manner. A requirement document that says "the system should be fast" conversationally implicates a specific performance expectation that varies by domain, client, and context. Formalising Gricean implicature is an open research problem.
- **Indexicality**: meaning depends on who is speaking, to whom, and when (Kaplan, 1989). "The current system" in a requirements meeting refers to something specific that the string alone does not determine.
- **Background practices**: Wittgenstein's late philosophy (*Philosophical Investigations*, 1953) argues that meaning is constituted by use within a *Lebensform* (form of life) — not by correspondence to abstract objects. The implication for software requirements is that the meaning of a specification is inseparable from the practices of the community that produces and interprets it. A specification does not have meaning independent of the organisational context in which it functions. This is not a vague philosophical gesture — it is a concrete constraint: the same document means different things in different organisations, and no amount of syntactic analysis resolves the difference.

LLMs have demonstrably learned significant pragmatic competence — handling implicature, disambiguation, and contextual reference in many cases. This narrows the semantic gap substantially for well-trodden domains. It does not close it for novel situations, because pragmatic competence learned from a training corpus generalises only to the extent that the new situation resembles the training distribution. The gap narrows but does not close.

### 2.6 Tacit Knowledge and the Frame Problem

Software development requires large amounts of *tacit knowledge* — knowledge practitioners hold but cannot fully articulate (Polanyi, 1966). Choosing an appropriate data structure, recognising when a pattern is being misapplied, knowing which edge cases matter in a given domain: none of this appears in requirements documents, because the people writing them do not know they need to state it.

This connects to the classical **Frame Problem** in AI (McCarthy & Hayes, 1969): how does a reasoning system know which aspects of the world are relevant to a given action? Requirements documents cannot enumerate everything that must be preserved or avoided.

A qualification is necessary here. The Frame Problem as originally formulated applies to *logical* AI systems that represent world states explicitly and must enumerate what does and does not change. Neural/statistical approaches — including LLMs — largely sidestep the Frame Problem by learning context-dependent relevance from data rather than enumerating frame axioms (Dreyfus, 1992, made this argument about connectionism). The tacit knowledge objection therefore applies with full force to *symbolic* automation approaches and with reduced (but not zero) force to LLM-based approaches. What LLMs lack is not the ability to learn implicit patterns — they do this well — but the ability to recognise when a situation falls *outside* learned patterns, which connects to the calibration problem addressed in §6.

---

## 3. Second Round: The Practical Rebuttal

The formal critique above is correct but arguably beside the point. The more interesting question is not whether automation is formally provable but whether it works in practice. This is the shift Brooks (1986) anticipated: from proving that no silver bullet *can* exist to observing what each successive bronze bullet actually achieves.

### 3.1 The Composed Pipeline

Consider a pipeline of specialised agents:

```
Requirements (human-stated)
  → [Design LLM]          → Architecture
  → [Implementation LLM]  → Code
  → [Test LLM]            → Test suite + fixes
  → [Review LLM]          → Validated artefact
```

This is not a thought experiment. It is roughly what Devin, SWE-agent, and agentic Cursor implement today. For well-scoped problems in known domains with clear requirements, such pipelines already produce working software with minimal human intervention. Formal objections about decidability are real in theory; they are less decisive in a system that produces output that is *good enough, often enough*, in practice — just as the undecidability of the halting problem does not prevent practical program analysis. Section §8.6 presents a concrete instance of this pipeline operating across 13 microservices in a regulated public-sector domain.

### 3.2 Empirical Quality by Task Class

| Task class | Automation quality | Empirical basis |
|---|---|---|
| Boilerplate and scaffolding | High | SWE-bench task resolution; Copilot productivity studies (Peng et al., 2023) |
| Algorithm implementation (known) | High | Competitive programming benchmarks (AlphaCode; Li et al., 2022) |
| API integration | Medium | Practitioner reports; dependent on documentation quality |
| Domain modelling | Low | Requires tacit domain knowledge not present in training data |
| Requirements elicitation | Minimal | Social/cognitive process; no benchmark exists |
| Architecture decisions | Low | Trade-off reasoning; constraint spaces rarely explicit |
| Novel system design | Very low | No prior art to translate from; limited benchmark coverage |
| Modification of existing systems (direct) | Low | Requires consequence surface analysis, implicit invariant detection, coupling topology |
| Rebuild from existing system as specification | Medium–high | Executable spec enables automated equivalence testing; limited by bug compatibility and unowned interface surface |

The automation quality ratings above are informed judgments, not measurements — no comprehensive benchmark exists that spans all task classes. What evidence does exist is consistent with the pattern: automation quality degrades precisely as the task moves away from "translation of well-specified artefacts" toward "generation of the specification itself."

---

## 4. Third Round: The Brownfield Problem — and Its Resolution

### 4.1 The Objection: Most Work Is Change, Not Construction

The practical rebuttal above implicitly assumes greenfield development — constructing a new system from clear requirements. But the majority of enterprise software effort is **modification of existing systems**: adding features, fixing defects, migrating infrastructure, adapting to regulatory change.

This is a structurally different automation problem. Modifying an existing large system safely requires more than reading code: it demands consequence surface analysis (which parts of the system are affected by this change?), coupling topology reasoning (what implicit dependencies does this module carry?), and the identification of behavioural invariants that no one has written down. None of these appear in requirements documents; none are retrievable by web search. "Reading code" and "understanding the operational consequence of a change in a system you have never seen run" are different capabilities.

### 4.2 The Counter-Argument: The Existing System Is the Specification

On examination, the brownfield objection understates the informational richness available when an existing system is present. The full artefact stack — source code, test suites, observability data (logs, metrics, traces), deployment configurations, post-mortems, API contracts, and version control history — constitutes a specification of unusual precision.

| Specification type | Ambiguity | Completeness | Executability |
|---|---|---|---|
| Natural language requirements | High | Low | None |
| Formal specification | Low | Medium | Partial |
| Existing running system | Very low | Very high (for observed behaviour) | Complete |

The existing system does not describe what someone *intended* to build. It describes, exactly and verifiably, what was built and what it does. Compared with the ambiguous, incomplete, and evolving requirements that the First Round identifies as the central weakness of the Translation Thesis, this is a far stronger specification foundation.

A critical qualification: "very high completeness" applies to the system's behaviour on inputs it has actually processed. The system's specification in the full sense includes its behaviour on *all possible* inputs — including edge cases, failure modes, race conditions, and adversarial inputs that production may never have exercised. Observability gives a sample, not the population. The gap between observed and possible behaviour is the residual specification risk.

### 4.3 The Rewrite Resolution

This observation suggests a resolution: rather than *modifying* the legacy system — which demands understanding its coupling topology, implicit invariants, and accumulated technical debt — use it as an executable specification to **rebuild the system entirely**.

```
Legacy system (running)
  → [Behavioural capture]    → Input/output corpus + traces
  → [AI implementation]      → New, clean implementation
  → [Equivalence testing]    → Parallel shadow comparison
  → [Cutover]                → Decommission legacy
```

This is a **big-bang rewrite** with an automated implementation step — not to be confused with the strangler fig pattern, which replaces systems incrementally, one module or route at a time, and carries a different risk profile. The big-bang rewrite approach has structural advantages:

- **Specification is executable and frozen**: the legacy generates ground-truth outputs against which the replacement is verified automatically. Behavioural equivalence testing is decidable for bounded input domains — but bounding the input domain is itself a specification decision that requires human judgment about what "equivalent" means in practice.
- **Speed mitigates the moving-target failure mode**: traditional rewrites fail partly because the legacy keeps changing during the rewrite. AI-compressed timelines weaken this failure mode. However, the deeper reasons rewrites fail — discovering unknown requirements, making incorrect design decisions, encountering unpredicted integration problems — are not eliminated by speed; they are compressed into a shorter period with less time to recover.
- **Design is unconstrained**: the replacement is built for changeability, without inheriting the coupling structure that makes the legacy hard to modify.
- **The discovery layer compresses**: the central question shifts from *"what should we build?"* to *"which behaviours do we want to preserve, and which do we want to change?"* — a more focused and tractable problem than open-ended requirements elicitation.

### 4.4 Surviving Objections

Four objections survive the rewrite resolution:

**Bug compatibility.** The legacy encodes not only correct behaviour but defects that downstream consumers have accommodated with implicit workarounds. Faithful replication preserves defects alongside features. Selective replication — correcting defects while preserving correct behaviour — requires distinguishing intentional from accidental behaviour, which requires organisational knowledge the artefact stack does not contain.

**Unowned interface surface.** The legacy system's full specification includes how upstream providers interact with it and what downstream consumers expect from it. Implicit contracts — response timing, error format conventions, partial-failure semantics — may not be observable from the system's own artefacts. They surface as production incidents rather than test failures.

**The replication-redesign tension.** The approach is cleanest when the goal is pure behavioural equivalence. The moment the intent shifts to *improving* behaviour — correcting known deficiencies, simplifying domain models — organisational knowledge re-enters. Understanding what to improve requires understanding why things are as they are, which is the semantic layer the artefact stack does not capture.

**AI-generated technical debt.** LLM-generated code tends toward local coherence but can develop emergent complexity at scale. Without the organisational learning embedded in the legacy's architecture, the replacement may accumulate different technical debt through different failure modes — possibly faster.

### 4.5 Net Assessment

The brownfield objection, properly examined, does not undermine the execution layer automation claim — it strengthens it for an important use case. Treating the legacy system as an executable specification and building an AI-generated replacement converts the hardest brownfield problem into a well-specified greenfield problem. The discovery layer does not disappear; it compresses to a focused organisational decision about which behaviours to preserve and which to change — a significantly more tractable problem than the open-ended requirements elicitation the Translation Thesis presupposed.

---

## 5. Fourth Round: Dissolving the Test Oracle Objection

A specific objection holds that LLM-generated tests are unreliable because they test the LLM's own interpretation of requirements rather than ground truth. This is true — but on reflection, the objection is not specific to LLMs.

A human developer writing tests does exactly the same thing: interprets requirements and asserts against that interpretation. The oracle is always ultimately **stakeholder acceptance** — and that applies identically to human-produced and AI-produced test suites. The practical feedback loop is symmetric:

```
Human team:   Build → Test → Demo to stakeholder → Refine
AI pipeline:  Build → Test → Demo to stakeholder → Refine
```

The acceptance step is human in both cases. The rest is iteration. The test oracle objection, honestly examined, is a general condition of software development — not a distinguishing weakness of AI. It is handled, in both cases, by acceptance testing and iteration.

This symmetry significantly strengthens the practical automation argument. What remains are differences of degree, not of kind:

| Dimension | Human | LLM pipeline | Gap direction |
|---|---|---|---|
| Calibrated uncertainty | Knows when to ask | May proceed when wrong | Real, narrowing |
| Implicit requirement detection | "This smells wrong" | Misses unstated invariants | Real, domain-dependent |
| Novel domain reasoning | First principles | Anchored to training data | Real |
| Requirement elicitation | Conversational, iterative | Increasingly capable | Narrowing fast |

---

## 6. Fifth Round: The Context Superiority Argument and Its Limits

### 6.1 The Argument

A further challenge sharpens the practical case for automation. An LLM equipped with web search and tool access (MCP servers, code repositories, documentation indices) has access to vastly more contextual information than any human developer: the entire indexed web, real-time documentation, live codebases, API specifications, regulatory texts, and domain knowledge repositories. If the remaining human advantages are "calibrated uncertainty" and "tacit domain knowledge," do they not dissolve when the LLM's informational context exceeds any human's by orders of magnitude?

### 6.2 Where It Holds

For factual domain knowledge, the argument is largely correct. An LLM with web search knows more about FHIR standards, tax regulation, or distributed systems patterns than any individual developer. The "training distribution" objection weakens considerably when the model can retrieve current information at inference time. The "tacit knowledge" objection weakens for knowledge that *can* be articulated and *has been* published somewhere — which is most technical knowledge.

### 6.3 The Strongest Remaining Objections

Five objections survive the context superiority argument:

**1. More Context ≠ Better Calibration**

Having access to more information is not the same as knowing what to weight, ignore, or distrust. The web contains precedent, not prescription. For a genuinely novel business problem, web search returns superficially similar cases that an LLM may overgeneralise from. A human expert knows when a situation is *meaningfully different* from prior art. An LLM with vast context may be more confidently wrong, not less. Information volume and epistemic calibration are orthogonal — a system can have access to everything ever written about distributed databases and still make a poor architectural decision for a specific novel use case, because the decision requires weighting contradictory precedents against a constraint set that has no exact prior match.

**2. Requirements Are Social, Not Informational**

This is the sharpest objection, and it survives the context argument entirely. Requirements do not pre-exist in documents waiting to be retrieved — they emerge from trust relationships (Floyd, 1984; Goguen, 1994). A stakeholder tells a trusted architect things they would never write down:

- *"The CEO's deadline is politically motivated, not technically grounded"*
- *"We want to replace vendor X, but cannot say so publicly yet"*
- *"The real constraint is the CFO's risk appetite, not the technology"*

None of this is on the web. None of it appears in an MCP-connected document store. It surfaces in conversation, over time, within a relationship built on accountability and mutual understanding. Web search accesses the *known and indexed world* — not the organisational subtext that determines what actually gets built and why.

**3. Requirement Elicitation Is Generative, Not Retrieval**

The best architects and business analysts do not extract pre-existing requirements — they use Socratic dialogue to help clients *discover* what they want. The client does not know the answer before the conversation; the conversation *creates* it. This is fundamentally different from information retrieval.

Current LLMs optimise for coherent, plausible output — which is the wrong objective for elicitation. The goal of requirement elicitation is to surface incoherence, challenge assumptions, and make the client uncomfortable enough to think clearly. Structural bias toward agreement and plausibility is a liability, not an asset, at this stage. This is an observation about current fine-tuning objectives, not necessarily a permanent architectural limitation — but see §8.5 for further analysis.

**4. The Evaluation Bottleneck Is Concentrated, Not Eliminated**

Full pipeline automation does not remove the need for human judgment — it displaces it entirely to acceptance testing. And that evaluation step becomes *harder*, because the human evaluator must assess a complete, coherent-looking system rather than catching errors as they accumulate incrementally. The cognitive load on the accepting human increases. The expertise requirement does not disappear; it concentrates at the single point where it is hardest to exercise.

**5. No Skin in the Game**

A human developer who ships broken software bears consequences — professional, financial, reputational. This incentive structure shapes the care taken at every step: flagging uncertainty, pushing back on bad requirements, resisting the production of plausible-looking nonsense under time pressure. An AI pipeline has no accountability and therefore no structural incentive toward epistemic caution. This is not merely a social nicety — it is a behavioural mechanism that current AI systems do not replicate.

---

## 7. Sixth Round: Two Objections Examined Further

Two of the surviving objections from the Fifth Round, on closer examination, do not hold as independent claims.

### 7.1 Attestation and Undecidability

An objection related to the context superiority argument holds that possessing information is not the same as being able to demonstrate warranted confidence in it — that consequential decisions require *attestation*, not pattern-matching against a corpus.

This objection belongs to the same family as the verification undecidability result from §2.4: neither humans nor AI can formally prove the correctness of non-trivial software in the general case. Both manage this through institutional mechanisms — testing, review, certification, acceptance — that produce warranted confidence without formal proof.

However, the attestation problem is not simply Rice's theorem in organisational language. It includes dimensions that undecidability results do not touch: temporal validity (was this true when we checked?), jurisdictional scope (which regulatory framework applies?), and organisational trust dynamics (will the auditor accept this evidence?). These are real constraints, but they are governance and institutional design challenges — not new mathematical barriers. They apply equally to human-produced and AI-produced artefacts, and are handled through the same institutional machinery in both cases.

The attestation objection does not survive as an independent argument against AI-automated development specifically. It is a general condition of software delivery.

### 7.2 Skin in the Game — The Professional Accountability Resolution

The Fifth Round identified "no skin in the game" as a surviving objection: AI systems bear no personal consequences for shipping broken software, removing a structural incentive toward epistemic caution.

This objection does not survive the professional accountability model. When a firm delivers an AI-mediated software solution, the accountability chain is:

```
Client ← [contract, liability, reputation] ← Delivering firm ← [pipeline design] ← AI
```

The delivering firm carries professional indemnity exposure, reputational risk, contractual liability, and in regulated industries, regulatory consequences. This is genuine skin in the game — accountability mediated through professional structures rather than individual agents.

Two qualifications are necessary.

**The structural engineering analogy has limits.** Professional engineering has mandatory licensure, codes of practice with legal force, independent inspection regimes, personal liability for licensed professionals, and statutory obligations to refuse unsafe work. Software delivery — whether human or AI-mediated — has few of these institutional safeguards. The analogy shows that professional accountability *can* be structured to create adequate incentives; it does not show that the software industry *has* done so. This is an institutional maturity gap, not a fundamental barrier.

**Granularity of accountability.** Firm-level accountability creates strong incentive to design a robust pipeline — validation gates, human review at critical transitions, confidence-gated promotion between stages. It does not automatically replicate the moment-by-moment epistemic caution that individual professional risk generates: the willingness to flag uncertainty, push back on bad requirements, and resist producing plausible-looking output under deadline pressure. This caution must be explicitly engineered into the pipeline rather than arising from individual incentives. Whether this can be done effectively is an open engineering question — §8.6.5 presents one attempt in a regulated domain.

---

## 8. Synthesis

### 8.1 What the Dialectic Establishes

The successive rounds of argument and rebuttal establish the following:

| Objection | Verdict |
|---|---|
| Translation Thesis is formally invalid (step 6) | Valid — language computability does not imply mapping computability; the thesis is treated as a practical conjecture, not a theorem |
| Computability doesn't imply tractability | Valid but partly mitigated by empirical progress |
| Requirements are never fully given | Valid and fundamental (Brooks, 1986; Jackson, 2001) |
| Verification is undecidable | Valid in theory; handled pragmatically by acceptance testing. Attestation concerns belong to the same family but include governance dimensions beyond pure undecidability |
| Semantic gap in natural language | Partially mitigated by LLM pragmatic competence; residual for novel situations |
| Tacit knowledge / Frame Problem | Partially mitigated by learned context relevance in neural approaches; survives for organisational knowledge |
| Brownfield modification | Substantially resolved by legacy-as-specification rewrite; residual gap between observed and possible behaviour; surviving objections on bug compatibility and unowned interface surface |
| Test oracle objection | Dissolved — symmetric between humans and AI |
| Calibration under novel conditions | Survives — information volume and epistemic calibration are orthogonal |
| Requirements as social product | Survives — not an information problem |
| Generative vs. retrieval elicitation | Survives — structurally distinct from translation |
| Evaluation bottleneck concentration | Survives — displaces rather than eliminates human expertise |
| Accountability and skin in the game | Largely dissolved by professional accountability structures; residual engineering challenge of replicating granular epistemic caution |

### 8.2 A Refined Formulation

The original thesis was: *software development is completely automatable because all its artefacts are within the Turing-computable range.*

The defensible, refined formulation is:

> *The execution layer of software development — translating well-specified requirements into working code, tests, and deployable artefacts — is largely automatable today for well-understood domains and will extend to broader domains as LLM capability increases. This applies to greenfield construction and to brownfield legacy replacement where the existing system serves as an executable specification. The discovery layer is not uniformly resistant. Requirements elicitation — the generative and socially grounded core of discovery — remains deeply resistant to automation for reasons not dissolved by increased capability or context access. Domain modelling and architecture decisions admit increasing AI assistance once elicitation has succeeded and the constraint space is explicit.*

**Falsifiability conditions:** This formulation would be weakened by evidence that: (a) LLM-based systems consistently succeed at requirements elicitation in novel domains without human Socratic guidance; (b) the legacy-as-specification rewrite strategy fails systematically in practice despite adequate behavioural capture; or (c) execution-layer automation plateaus significantly below current trajectory. It would be strengthened by: (d) evidence that elicitation requires social trust even when all relevant information is technically available to the AI; or (e) evidence that the observational-vs-full-behaviour gap causes systematic rewrite failures.

### 8.3 The Shifting Human Role

The consequence is not that human developers become irrelevant. It is that their role shifts:

| From | To |
|---|---|
| Writing code | Specifying intent precisely |
| Debugging implementations | Evaluating AI-generated systems |
| Translating requirements into design | Eliciting and generating requirements |
| Implementing known patterns | Handling genuinely novel problems |
| Being accountable for code | Being accountable for specifications and pipeline design |

This shift is significant. Specifying intent precisely enough for an AI pipeline to act on it correctly is harder than it sounds — arguably harder than writing the code directly for complex novel problems (Jackson, 2001). The compression of human cognitive effort into the discovery layer does not represent the elimination of expertise; it represents its intensification.

### 8.4 Decomposing the Discovery Layer

The refined formulation treats the discovery layer as internally differentiated. Three activities have meaningfully different automation profiles:

| Discovery activity | Automation profile | Limiting factor |
|---|---|---|
| Requirements elicitation | Very low | Social and generative; trust relationships surface what documents cannot |
| Domain modelling | Low–medium | Formalisable once domain knowledge is surfaced; translation-adjacent |
| Architecture decisions | Low–medium | Trade-off reasoning; tractable *after* constraint space is explicit |

**Requirements elicitation** is the most resistant — and for reasons qualitatively distinct from the other two. The process is socially grounded: stakeholders disclose strategically sensitive information within relationships of accountability and trust. Political motivations, vendor replacement intentions, budget constraints that cannot be stated publicly — none of this is recoverable from documents, because it was never intended to be written down. Social trust actively resists digitisation.

**Domain modelling** is considerably more tractable. Translating surfaced domain knowledge into a structural representation — entities, relationships, constraints, invariants — is closer to a translation problem once elicitation has succeeded. LLMs with access to domain expertise, regulatory frameworks, and existing modelling patterns are increasingly capable here. The MDE literature (Czarnecki & Helsen, 2003; Stahl & Völter, 2006) has long demonstrated that model-to-model and model-to-code transformations are automatable when the source model is well-defined.

**Architecture decisions** are more automatable than the original formulation suggests. Given well-defined functional requirements, quality attributes, and constraints, the trade-off space can be explored systematically. The bottleneck is not the reasoning — it is ensuring the constraint space is correctly specified, which returns to the elicitation problem. This is consistent with the observation that architecture is hard not because the reasoning is hard, but because the inputs to the reasoning are incomplete (Bass, Clements & Kazman, 2012).

The practical implication: human expertise concentrates most intensely at the elicitation point. Domain modelling and architectural reasoning admit increasing AI assistance as elicitation quality improves. The discovery layer has an internal structure, and the frontier of automation runs through it rather than uniformly behind it. Section §8.6.2 maps this decomposition onto a concrete pipeline where each discovery activity is assigned to a distinct agent (or to a human gate) based on its automation profile.

### 8.5 The Question of AI-Augmented Elicitation

A question the preceding analysis must confront: is requirements elicitation *necessarily* resistant to AI involvement, or is this an observation about current systems that may not hold?

The argument for resistance rests on two pillars: (1) elicitation requires social trust, which emerges from relationships of accountability between persons, and (2) elicitation is generative — it creates requirements through Socratic challenge, not retrieval.

Pillar (1) appears durable. There is no clear mechanism by which an AI system earns the kind of trust that causes a CFO to disclose their actual risk appetite or a CIO to reveal that a deadline is politically motivated. Trust of this kind is grounded in mutual accountability between agents who bear consequences — and the professional accountability resolution in §7.2 applies to the delivering *firm*, not to the AI system conducting the elicitation.

Pillar (2) is more vulnerable. An AI system explicitly designed for adversarial questioning — trained to probe, challenge, surface contradictions, and resist agreement — is architecturally feasible and partially exists today. The claim that "LLMs optimise for plausibility" is a statement about current RLHF fine-tuning practices, not a fundamental constraint on the technology. A system fine-tuned to maximise the quality of elicited requirements — measured by downstream specification completeness and consistency — would have a very different behavioural profile from a general-purpose assistant.

The honest assessment: AI-augmented elicitation is plausible and likely to become increasingly effective as a support tool. AI-*replaced* elicitation — where the AI conducts the full social and generative process independently — remains implausible for the class of requirements that are socially embedded and politically sensitive. The distinction matters, and the paper's analysis applies to the second case.

### 8.6 Worked Example: The OpenDebt Pipeline

The preceding analysis has been abstract by design. This section grounds it in a concrete system — **OpenDebt**, an open-source debt collection platform for Danish public institutions — where a multi-agent AI pipeline has been deployed across the full project lifecycle. The system replaces legacy infrastructure (EFI/DMI) and must comply with Danish public-sector architecture principles (*Fællesoffentlige Digitaliseringsarkitektur*), GDPR, and statutory debt-collection rules codified in the *Gældsinddrivelsesloven* (GA). It comprises 13 microservices (9 backend, 3 server-rendered portals, 1 shared library), 33 architecture decision records, 140 petitions (the unit of work), and 10 formal statutory rule encodings in Catala.

The pipeline is orchestrated by **Gas City** (Gas Town, 2024) — a multi-agent controller that manages agent lifecycles, work distribution, and formula execution. Work items are tracked in **Beads** (a local issue tracker backed by **Dolt**, a version-controlled SQL database), enabling audit, rollback, and federated contribution via the **Wasteland** protocol.

The example is instructive not because it proves the thesis — a single system cannot do that — but because it instantiates every major structural claim of this article in a regulated production context.

#### 8.6.1 The Pipeline as Composed Translation (cf. §3.1)

The generic composed pipeline from §3.1 becomes concrete:

```
Petition (human-authored requirement)
  → [petition-translator]      → Outcome contract
  → [petition-to-gherkin]      → Gherkin .feature file + failing step stubs  ─┐
  → [specs-translator]         → Implementation specification                 ─┤ (parallel)
  → HUMAN GATE 1: Scaffold review                                             ─┘
  → [tdd-enforcer]             → Production code (red → green → refactor)
  → [code-reviewer]            → Validated code
  → [catala-encoder]           → Formal statutory rule (Tier A only)
  → HUMAN GATE 2: Code review
  → [doc-sync]                 → Updated documentation + program-status.yaml
  → HUMAN GATE 3: Merge approval
```

Each arrow is a discrete agent with a single responsibility, a dedicated prompt template, and an explicit work queue (Beads query). The pipeline is defined declaratively in two **formula** files — `mol-petition-scaffold` (Phase 1: documentation and test scaffolding, no production code) and `mol-petition-implement` (Phase 2: TDD implementation through merge). The Gas City controller instantiates formulas as molecules of linked beads, routes work to agents based on assignment, and manages agent scaling.

Eight city-scoped agents handle cross-cutting concerns (translation, review, Catala encoding, documentation). Two rig-scoped agent types are stamped per service: `tdd-enforcer` (for 9 backend services) and `portal-tdd-enforcer` (for 3 Thymeleaf + HTMX portals). The portal variant carries a distinct prompt with architecture-specific guidance — server-side rendering patterns, HTMX fragment endpoints, accessibility constraints (WCAG 2.1 AA), and the SKAT design system — demonstrating that the execution layer can be specialised by technology stack while sharing the same formula structure.

This architecture is a direct realisation of the §3.1 observation that "well-scoped problems in known domains with clear requirements" are automatable. The key qualification — "clear requirements" — is enforced structurally: no agent touches production code until Human Gate 1 has approved the scaffold. The pipeline does not attempt to automate requirements; it automates what comes after them.

#### 8.6.2 The Petition Model as Discovery–Execution Boundary (cf. §8.4)

The decomposition of the discovery layer proposed in §8.4 maps directly onto the petition lifecycle:

| Discovery activity | OpenDebt implementation | Automation level |
|---|---|---|
| Requirements elicitation | **Human-authored petition** — a structured markdown document written by domain experts after stakeholder dialogue. 50 of 140 petitions remain unstarted, awaiting elicitation. | None — fully human |
| Domain modelling | **AI-assisted concept model** — a machine-readable YAML *begrebsmodel* (concept model) maintained by a `concept-model-curator` agent, mapping Danish legal terms to English implementation identifiers. Human-curated, agent-maintained. | Low–medium |
| Architecture decisions | **ADRs** — 33 architecture decision records, human-authored but prompted by agent-discovered conflicts. When a `tdd-enforcer` encounters an architectural ambiguity, it creates a technical backlog item rather than making an autonomous decision. | Low–medium |
| Outcome contract | **petition-translator agent** — translates petition prose into testable acceptance criteria. | High |
| Gherkin scenarios | **petition-to-gherkin agent** — generates `.feature` files and failing step stubs from the outcome contract. 60 feature files exist across the project. | High |
| Implementation spec | **specs-translator agent** — produces entity schemas, API contracts, GDPR notes, package structure. | High |

The boundary between "discovery" and "execution" is not a theoretical construct in this system — it is a configuration file. The petition document *is* the interface. Everything above it is human; everything below it is agent-mediated with human gates.

The 50 unstarted petitions are not blocked by agent capability. They are blocked by the absence of human elicitation — precisely the bottleneck §8.4 predicts.

#### 8.6.3 Formal Verification in a Statutory Domain (cf. §2.1, §2.4)

The paper's §2.1 notes that "formal specification → code is already automated" for bounded domains. OpenDebt implements this via **Catala** (Merigoux et al., 2021) — a domain-specific language designed to encode statutory rules with direct traceability to legislation.

Ten statutory rules from the *Gældsinddrivelsesloven* are encoded as Catala scopes:

| GA reference | Rule |
|---|---|
| GA §1.3.4–1.3.5 | Suspension and revocation of claims |
| GA §1.4.2–1.4.5 | Non-collectible claims and cessation |
| GA §1.4.3 | Claim upwriting (*opskrivning*) |
| GA §1.4.4 | Claim downwriting (*nedskrivning*) |
| GA §2.3.2.1 | Priority ordering (*dækningsrækkefølge*) |
| GA §2.3.3–2.3.4 | Set-off and correction pool (*modregning*) |
| GA §2.4 | Limitation (*forældelse*) |
| GA §2.5 | Legal force assessment (*retskraftvurdering*) |
| GA §3.1.1 | Instalment arrangements (*afdragsordninger*) |
| GA §3.1.2 | Wage garnishment percentage (*lønindeholdelse*) |

Each Catala file has a companion test scope that is typechecked and interpreted by the Catala compiler. The `catala-encoder` agent produces these files; the CI pipeline verifies them automatically. This is precisely the "sufficiently restricted domain where decidability can be recovered" that §2.4 identifies as the alternative to undecidable general verification — applied not to toy examples but to real statutory rules that determine how much money is deducted from citizens' wages.

The three-tier classification is instructive: **Tier A** petitions (those with direct statutory rule references) trigger Catala encoding. **Tier B** petitions (workflow logic without direct statutory grounding) skip it. **Tier C** petitions (reference data, configuration) skip it entirely. The pipeline does not attempt to formally verify everything — it identifies the verification-tractable subset and applies formal methods there.

#### 8.6.4 Human Gates as Evaluation Infrastructure (cf. §6.3)

The §6.3 analysis concluded that full pipeline automation "displaces [human judgment] entirely to acceptance testing" and that "the cognitive load on the accepting human increases." The OpenDebt pipeline addresses this with **three mandatory human gates** at structurally distinct points:

| Gate | Placement | What it evaluates | Cognitive load mitigation |
|---|---|---|---|
| **Gate 1** — Scaffold review | After translation, before any code | Outcome contract, Gherkin scenarios, implementation spec | Reviewer evaluates *intent and test design*, not code. Artefacts are documentation-scale, not implementation-scale. |
| **Gate 2** — Code review | After implementation + automated review | Production code, Catala encoding (if Tier A) | AI code-reviewer has already checked GDPR, package structure, coverage. Human focuses on *semantic correctness* and *scope creep*. |
| **Gate 3** — Merge approval | After documentation sync | Complete branch: code + tests + docs + status update | Final checkpoint. All automated validation has passed. Human confirms the branch is ready for main. |

This structure directly responds to the evaluation bottleneck concern: rather than concentrating all human judgment at a single acceptance point, it distributes it across three points with escalating concreteness. Gate 1 catches specification errors before any code is written — the cheapest possible intervention point. Gate 2 catches implementation errors before they propagate to documentation and merge. Gate 3 is a final integrity check.

The pipeline enforces this structurally: formulas define step dependencies, and the Gas City controller will not advance work past a human-assigned step until a human closes it. An agent cannot bypass a gate even if it could technically produce the downstream artefacts.

#### 8.6.5 Professional Accountability as Pipeline Design (cf. §7.2)

The §7.2 resolution argued that accountability is "a property of delivery systems, not individual agents." The OpenDebt pipeline makes this concrete:

```
Citizen/Creditor
  ← [statutory obligation, audit trail, GDPR] ← UFST (tax authority)
  ← [SLA, architecture compliance] ← Delivering team
  ← [pipeline design: human gates, formula constraints, Catala verification] ← AI agents
```

The accountability is structural, not incidental. Specific mechanisms:

- **GDPR isolation**: All personal data (CPR numbers, names, addresses) is confined to the person-registry service. Every other service stores only technical UUIDs. This is enforced in prompt templates, reviewed by the code-reviewer agent (which checks for PII leakage), and validated at Gate 2 by the human reviewer. An agent that stores a CPR number in the debt-service database would be caught at three points before reaching production.
- **Audit trail**: State-changing operations use `audit-trail-commons`, and financial transactions are additionally logged to an immudb append-only ledger. The pipeline does not rely on agents choosing to log — the architecture mandates it.
- **Beads + Dolt versioning**: Every work item, status change, and agent assignment is tracked in a Dolt database — a Git-for-data system that provides full version history and branching. `bd dolt push` synchronises the local database to a remote, creating an immutable audit trail of who (human or agent) did what, when, and why.

The "granularity of accountability" qualification from §7.2 — that firm-level accountability does not automatically replicate "the moment-by-moment epistemic caution that individual professional risk generates" — is addressed by engineering that caution into the pipeline rather than relying on it to emerge from individual agents. An agent that encounters an architectural ambiguity does not resolve it autonomously; it creates a technical backlog item (`TB-*`) and stops. This is not a behavioural property of the LLM — it is a prompt constraint enforced by the formula structure.

#### 8.6.6 Empirical Task-Class Mapping (cf. §3.2)

The §3.2 table rated automation quality by task class. OpenDebt provides empirical data points for several rows:

| Task class | §3.2 rating | OpenDebt observation |
|---|---|---|
| Boilerplate and scaffolding | High | Confirmed. `petition-to-gherkin` and `specs-translator` produce scaffold artefacts routinely. 60 feature files generated. |
| Algorithm implementation (known) | High | Confirmed for statutory rules with Catala reference. 10 formal encodings produced. |
| API integration | Medium | Confirmed. Backend service-to-service integration via WebClient + Resilience4j requires agent guidance but works. Portal service clients (circuit breaker, retry, fallback) require specialised prompt templates. |
| Domain modelling | Low | Confirmed. The *begrebsmodel* (concept model) is human-curated. Agents maintain but do not originate domain concepts. |
| Requirements elicitation | Minimal | Confirmed. 50/140 petitions unstarted — awaiting human domain work, not agent capacity. |
| Architecture decisions | Low | Confirmed. 33 ADRs are human-authored. Agents surface conflicts but do not resolve them. |

The system adds an observation absent from §3.2: **portal UI development** (server-rendered Thymeleaf + HTMX) is automatable at a level comparable to backend API development, provided the agent receives architecture-specific guidance. The `portal-tdd-enforcer` prompt includes controller patterns (full-page vs. HTMX fragment), template structure, accessibility constraints, and design system compliance. Without this specialisation, generic agents produce single-page-application patterns that are architecturally incorrect for the stack.

#### 8.6.7 Limitations as a Worked Example

The example has significant limitations that constrain its evidential weight:

1. **N = 1.** A single system, however detailed, does not constitute empirical evidence for general claims. The example illustrates the thesis structure; it does not validate it.
2. **Greenfield bias.** OpenDebt is a new system replacing legacy infrastructure. The §4 brownfield analysis — particularly the bug-compatibility and unowned-interface-surface objections — is not tested here. The legacy system (EFI/DMI) serves as a domain reference, not as an executable specification in the §4.3 sense.
3. **Regulated domain advantage.** Danish public-sector debt collection is unusually well-specified: statutory rules are explicit, business processes are documented, and the regulatory framework provides structural requirements that reduce ambiguity. Domains with less regulatory scaffolding may exhibit a larger discovery-layer gap.
4. **Pipeline maturity.** The Gas City infrastructure is recent. The 51 implemented petitions passed through earlier, less automated versions of the pipeline. The full 13-service, two-agent-type, three-gate pipeline described here has not yet processed petitions at scale.
5. **Developer expertise baked in.** The prompt templates encode substantial architectural knowledge — package structure conventions, GDPR isolation patterns, Resilience4j configuration, Thymeleaf fragment conventions. This knowledge was extracted from human-authored code by human engineers. The pipeline automates *execution* of these patterns; it does not discover them. This is consistent with the thesis but should be stated explicitly: the execution layer automation presupposes that architectural knowledge has been captured in the pipeline configuration.

Despite these limitations, the example demonstrates that the theoretical structure of this article — the discovery–execution boundary, the evaluation bottleneck, the accountability resolution, the formal verification strategy, and the discovery layer decomposition — can be instantiated in a single coherent system operating in a regulated domain. The fact that such instantiation is architecturally coherent does not prove the thesis, but it does show that the thesis is *implementable* — which is a stronger claim than mere theoretical plausibility.

---

## 9. Conclusion

The Translation Thesis is a productive and partially correct framing that has driven genuine progress in software engineering for sixty years. Its formal structure is invalid (step 6 does not follow), but the practical conjecture it motivates — that the execution layer of software development is increasingly automatable — is well-supported by empirical evidence.

The core insight is not new. Brooks (1986) distinguished "essential" from "accidental" complexity and argued that specification, not coding, is the hard problem. Jackson (2001) formalised the distinction between the "machine" (automatable) and the "problem world" (requiring human understanding). This article arrives at the same destination by a different route, and adds four contemporary elements: the brownfield legacy-as-specification strategy, the discovery layer decomposition, the professional accountability resolution, and the OpenDebt worked example (§8.6) — a concrete multi-agent pipeline operating across 13 services in a regulated public-sector domain that instantiates the article's structural claims.

The strongest surviving objections are practical and social:

1. **Requirement elicitation is generative and socially grounded** — the core of the discovery layer creates specification through Socratic dialogue within relationships of trust, not retrieval from prior knowledge. This is the deepest and most durable limit on automation, though AI-augmented elicitation is a plausible and emerging capability.
2. **The discovery layer is not monolithic** — domain modelling and architecture decisions admit increasing AI assistance once elicitation succeeds; the frontier of automation runs through the discovery layer, not uniformly behind it.
3. **Accountability is a property of delivery systems, not individual agents** — the "skin in the game" objection largely dissolves under professional accountability structures, though the software industry lacks the institutional safeguards that make this work in mature professions.

Software development is substantially automatable, increasingly so, and the automatable fraction is growing rapidly. The claim that it is *completely* automatable elides a qualitative distinction between the execution layer and the discovery layer — and mistakes an increasingly automatable part of the problem for the whole of it. The OpenDebt pipeline demonstrates that this distinction is not merely theoretical: the same system that automates translation, implementation, review, and formal verification across 13 services is blocked on 50 unstarted petitions that await human elicitation. The bottleneck is exactly where the thesis predicts.

The residual human role is not execution. It is judgment, accountability, and the Socratic work of helping organisations discover what they actually want to build.

---

## References

Bass, L., Clements, P., & Kazman, R. (2012). *Software Architecture in Practice* (3rd ed.). Addison-Wesley.

Brooks, F. P. (1986). No silver bullet — essence and accident in software engineering. *Proceedings of the IFIP Tenth World Computing Conference*, 1069–1076.

Chomsky, N. (1957). *Syntactic Structures*. Mouton.

Czarnecki, K., & Helsen, S. (2003). Classification of model transformation approaches. *OOPSLA Workshop on Generative Techniques in the Context of MDA*.

DoltHub. (2024). Dolt — Git for Data. https://www.dolthub.com/

Dreyfus, H. L. (1992). *What Computers Still Can't Do: A Critique of Artificial Reason*. MIT Press.

Floyd, C. (1984). A systematic look at prototyping. In R. Budde et al. (Eds.), *Approaches to Prototyping*. Springer.

Gas Town. (2024). Gas City — Multi-agent orchestration controller. https://github.com/gas-town/gas-city

Goguen, J. A. (1994). Requirements engineering as the reconciliation of social and technical issues. In M. Jirotka & J. Goguen (Eds.), *Requirements Engineering: Social and Technical Issues*. Academic Press.

Grice, H. P. (1975). Logic and conversation. In P. Cole & J. Morgan (Eds.), *Syntax and Semantics, Vol. 3: Speech Acts*. Academic Press.

Gulwani, S., Polozov, O., & Singh, R. (2017). Program synthesis. *Foundations and Trends in Programming Languages*, 4(1–2), 1–119.

Jackson, M. (2001). *Problem Frames: Analysing and Structuring Software Development Problems*. Addison-Wesley.

Jimenez, C. E., et al. (2024). SWE-bench: Can language models resolve real-world GitHub issues? *ICLR 2024*.

Kaplan, D. (1989). Demonstratives. In J. Almog, J. Perry, & H. Wettstein (Eds.), *Themes from Kaplan*. Oxford University Press.

Klein, G., et al. (2009). seL4: Formal verification of an OS kernel. *SOSP 2009*, 207–220.

Leroy, X. (2009). Formal verification of a realistic compiler. *Communications of the ACM*, 52(7), 107–115.

Li, Y., et al. (2022). Competition-level code generation with AlphaCode. *Science*, 378(6624), 1092–1097.

McCarthy, J., & Hayes, P. J. (1969). Some philosophical problems from the standpoint of artificial intelligence. *Machine Intelligence*, 4, 463–502.

Merigoux, D., Chataing, N., & Protzenko, J. (2021). Catala: A programming language for the law. *Proceedings of the ACM on Programming Languages*, 5(ICFP), Article 77.

Newcombe, C., et al. (2015). How Amazon Web Services uses formal methods. *Communications of the ACM*, 58(4), 66–73.

OpenDebt. (2024). OpenDebt — Open-source debt collection for Danish public institutions. https://github.com/opendebt

Parnas, D. L. (1985). Software aspects of strategic defense systems. *Communications of the ACM*, 28(12), 1326–1335.

Peng, S., et al. (2023). The impact of AI on developer productivity: Evidence from GitHub Copilot. *arXiv:2302.06590*.

Polanyi, M. (1966). *The Tacit Dimension*. University of Chicago Press.

Sipser, M. (2012). *Introduction to the Theory of Computation* (3rd ed.). Cengage Learning.

Stahl, T., & Völter, M. (2006). *Model-Driven Software Development: Technology, Engineering, Management*. Wiley.

Wittgenstein, L. (1953). *Philosophical Investigations*. Blackwell.

---

*Keywords: Church–Turing thesis, Rice's theorem, program synthesis, requirements engineering, computational complexity, philosophy of language, tacit knowledge, agentic AI, software automation, legacy modernisation, behavioural equivalence, brownfield systems, professional accountability, epistemic caution, multi-agent pipeline, Catala, formal statutory verification, petition-driven development, Gas City, human gates*
