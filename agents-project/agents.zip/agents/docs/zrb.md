## Zero Repetition Bank Model  {#slide-1}

\[Graphic: other: http://schemas.openxmlformats.org/presentationml/2006/ole\]

October 2024

EY MENA information pack

Auto- IT- compliance and waste 

reduction in tech-driven enterprises

## Banks digitalized and automated their customer journeys --  leading to steep growth of applications and data flows between them... {#slide-2}

\[Graphic: other: http://schemas.openxmlformats.org/presentationml/2006/ole\]

Page  2

## Regulation and more complex IT landscapes compound the compliance effort {#slide-3}

\[Graphic: other: http://schemas.openxmlformats.org/presentationml/2006/ole\]

Documenting and evidencing involves repetitive processes to periodically demonstrate IT compliance.

Maintaining IT compliance requires continuous and repetitive adjustments to operations.

Drift between the paper  and approval board  world of  IT  policies

versus

the actual implementation.

...The increase of regulation requires banks to continuously adapt the IT landscape and provide evidence of  IT  compliance

Page  3

Design        Reality 

![A yellow rectangle with arrows

Description automatically generated](ppt/media/image21.png "Picture 8")

![A yellow line drawing of a paper with check marks

Description automatically generated](ppt/media/image22.png "Picture 10")

![A yellow arrows pointing to the left

Description automatically generated](ppt/media/image23.png "Picture 12")

## The Zero Repetition Bank Framework aims to boost agility and resilience by implementing  a  Continuous Improvement Cycle  for IT Compliance {#slide-4}

- Automation  simplifies tasks and establishes the groundwork for Everything-as-Code, standardizing environments and processes.
- 
- Everything-as-Code  ensures consistency across all IT aspects and generates valuable data. 
- 
- This data facilitates  Datafication , turning operations into insightful information. 
- 
- Artificial Intelligence  uses these insights to optimize processes and predict issues. AI-driven analytics uncover new automation opportunities, creating a continuous improvement cycle. 
- 

By applying and combining these technologies intelligently, banks create a continuous improvement cycle for IT operations, improving efficiency significantly.

Page  4

## Slide 5

Repetition

## Slide 6

\[Graphic: other: http://schemas.openxmlformats.org/presentationml/2006/ole\]

![Arrow circle outline](ppt/media/image25.png "Graphic 4")

Repetition  of efforts, processes and components leads to inefficiencies, fragmented systems, and  makes it harder to scale , stay  secure  and  compliant .

Repetition;  the unnecessary and repeated manual and cognitive efforts required to build, run, and change  systems . 

## Slide 7

\[Graphic: other: http://schemas.openxmlformats.org/presentationml/2006/ole\]

![](ppt/media/image27.jpeg "Picture 1")

That's half of the scarce  talent, time and money  not spend on change and innovation. 

of IT delivery budgets is wasted on repetition \*

50

\%

\* - EY analysis of the IT compliance processes in a large Dutch bank.

## Slide 8

Data Examples:

U ser Agreement

DPIA

## Data sharing agreements -- an inefficiency in current banking operations: paper-based, manual process with limited effect {#slide-9}

- 

Our beliefs

- Any agreements is only as good as it's enforcement. Without regular follow-up, there\'s no guarantee that the data user is adhering to the terms.
- 
- Data Sharing Agreements are, in essence, policies. They outline the conditions under which data can be shared and used.

The data provider and data consumer, draft a detailed agreement, sign it, and file it away.  Based on the agreement, data exchange is made possible

## Currently, banks are faced with inefficiencies and drift in their infrastructure because of manual IT compliance processes...  {#slide-10}

- Datacenter offers a portfolio of services.
- The DevOps team selects the required services from a Service Catalogue.
- The DevOps team makes a Design  and for the  infrastructure.
- These documents are validated in a paper flow by multiple Policy Guardians.
- Often the documents are not approved and returned to the DevOps team.
- A specialist team provisions and configures the infrastructure.

\[Graphic: other: http://schemas.openxmlformats.org/presentationml/2006/ole\]

Policy Guardians on behalf of

Service portfolio

DataCenter

Provisioned & configured

infrastructure

2

3

4

5

Specialist Team

Paper based validation

Design

1

6

1

2

3

4

5

6

DevOps Team

Page  10

## Repetitive Risk Assessments on Data Flows and applications  are a major repetition category {#slide-11}

Assessments like the DPIA require  several iterations  to complete, to align views of the DevOps team, the application owner and second line risk functions.  It requires active knowledge and is heavy on manual tasks.

Detailed Privacy Impact Assessment

Our analysis of a European, with a DevOps organization of 6,000 people, indicates a conservative estimated  annual spend of 30 million  euros on data and application related risk assessments.

![Programmer male outline](ppt/media/image30.png "Graphic 13")

![Office worker male outline](ppt/media/image32.png "Graphic 14")

IT Developer

Privacy Officer

- 

Our belief

Collecting evidence for risk assessments can be fully automated and standardized, as a first step. Automating policy enforcement is second.

## ...banks should leverage the key technology concepts for Auto-Compliance and efficiency gains in infrastructure applying the ZRB Framework {#slide-12}

\[Graphic: other: http://schemas.openxmlformats.org/presentationml/2006/ole\]

- The DevOps team writes the required Infrastructure as Code ( IaC ) to configure the cloud services to the requirements.
- The  IaC  is send to the CI/CD pipeline.
- Policy makers convert Policies-on-Paper ( PoP ) into Policy-as-Code ( PaC ). 
- PaC  is used to validate  IaC  at deployment time.
- IaC  is validated immediately, and  DevOps team is informed.
- The pipeline automatically provisions and configures the cloud infrastructure based on the provided  IaC .
- PaC  is used to validate infrastructure at runtime.

Policy Makers on behalf of

Cloud Service Provider

Provisioned & configured

infrastructure

2

4

Automated validation (CI/CD)

1

Infrastructure-as-Code ( IaC )

Policy-as- Code (PaC)

5

7

6

1

2

3

4

5

6

7

Page  12

DevOps Team

3

## Slide 13

The origin of waste and the vicious circle of repetition

## The increase of number of applications, dataflows and regulation has led to many manual tasks  managing IT compliance  fueling the vicious circle of repetition {#slide-14}

\[Graphic: other: http://schemas.openxmlformats.org/presentationml/2006/ole\]

Page  14

## Slide 15

\[Graphic: other: http://schemas.openxmlformats.org/presentationml/2006/ole\]

...resulting in serious operational challenges and complexities.

Page  15

## Slide 16

The continuous improvement cycle

## Slide 17

Page  17

DEMO

## Slide 18

Conclusion

## EYs vision for a Zero Repetition Bank is ambitious, yet entirely achievable. It\'s a journey that doesn\'t demand a leap, but rather measured, incremental steps.  {#slide-19}

                   EaC  & Automation   Datafication   AI
  ---------------- ------------------- -------------- ------------
  Journey          Next phase          Next phase     Next phase
  Application      Next phase          Next phase     Next phase
  Data             Foundation          Next phase     Next phase
  Infrastructure   Foundation          Next phase     Next phase

The path to a Zero Repetition Bank is one banks can embark on today, starting with a single application, a single process. 

With each success, banks can expand the cycle, gradually integrating it into the broader organization. 

This is not a vision that demands a sweeping overhaul from start. It\'s a vision that grows, and that ultimately leads to a more efficient, innovative, and customer-centric banking environment. 

Page  19

## Slide 20

APPENDICES

## Slide 21

The Zero  Repetition  Bank Framework in action on  Infrastructure  and Data  flows

## These same concepts can be applied as well on data flows! {#slide-22}

\[Graphic: other: http://schemas.openxmlformats.org/presentationml/2006/ole\]

Like  IaC , DCaC automates and defines data flows in code.

Parallel to  PaC , DMaC automates the enforcement of data governance policies.

Data Contract-as-Code (DCaC)

DataManagement -as-Code (DMaC)

Page  22

Data Elements DCaC clearly specifies data details.

Technical Infrastructure Just as  IaC  dictates all infrastructure configurations, DCaC outlines all technology for secure data exchanges. 

DCaC describes:

1

2

Policy Enforcement DMaC automatically applies  DataManagement  policies to all dataflows. 

Compliance Monitoring Continuously and in real-time monitors data flows against latest policies. 

DMaC describes:

1

2

## EY is exploring  DMaC  and  DCaC  to pioneer Auto-Compliance in Data Flows {#slide-23}

\[Graphic: other: http://schemas.openxmlformats.org/presentationml/2006/ole\]

Policy Makers on behalf of

Cloud Service Provider

Provisioned & configured

dataflows

2

4

Automated validation (CI/CD)

CDO

![Male profile](ppt/media/image28.png "Google Shape;1646;p75")

1

DataContract -as-Code (DCaC)

DataManagement -as-Code (DMaC)

5

7

6

3

Page  23

DevOps Team

## Slide 24

![](ppt/media/image36.png "Google Shape;1664;p76")

All data flows are generated automatically.

No data flow between applications can exist without a valid  DataFlow -as-Code.

Each data flow can only exist according to the specifications in the validated  DataFlow -as-Code.

## Slide 25

Management Summary

## Slide 26

\[Graphic: other: http://schemas.openxmlformats.org/presentationml/2006/ole\]

The Framework provides a solution to repetition by holistically applying four cloud technology concepts:

Automation : Using technology to perform tasks without human intervention, saving time and resources.

Everything-as-Code ( EaC ) : Treating all aspects of IT operations as code, ensuring consistency and scalability.

Datafication : Turning all aspects of IT operations into data for better insights and decision-making.

Artificial Intelligence (AI) : Using AI to analyze data and optimize processes without human input.

In recent decades, banks and other financial institutions have significantly transformed their distribution of products and services via digital  channels and customer operations. This shift has led to an increasingly complex landscape of interconnected IT systems and supporting infrastructure.

Much of the work in the CIO domain, however, still largely depends on cumbersome manual processes for managing and enhancing the IT landscape. Tasks such as documenting system configurations, tracking changes, approving architectural modifications, and managing compliance typically involve extensive use of digital forms, checklists and approvals. This requires human actions at each step and introduces repetition. 

The Zero Repetition Bank Framework is designed to help banks and financial institutions become more efficient and agile by reducing repetitive and manual tasks in their IT operations. This framework aims to cut down costs and improve compliance with regulations.

Repetition - The unnecessary and repeated manual and cognitive efforts required to build, run, and change IT systems.

"

Introduction

Key concepts

 	

Integrating the modern technological 

concepts presents a valuable opportunity to achieve:

Operational Efficiency : Streamlining processes to save time and reduce manual work.

Enhanced Compliance : Automatically ensuring IT operations adhere to regulations and policies.

Business Agility : Enabling quicker responses to changes and new opportunities.

Main benefits

Under the General Data Protection Regulation (GDPR), banks are mandated to periodically carry out a Data Privacy Impact Assessment (DPIA) for their processes and supporting IT applications. 

Currently, this task demands significant manual effort and extensive management of documentation. Our research indicates that each DPIA typically requires between 50 to 60 hours. For a bank with

1,000 applications, the annual cost 

attributed to DPIAs can reach 5 to

6 million euros. 

However, by implementing the Zero Repetition Bank Framework, one can automate significant part of the DPIA process. We estimate that a bank can achieve massive reduction in time and resources spent on these assessments.

DPIA example

Source: The Zero Repetition Bank Auto-compliance and waste reduction in tech-driven enterprises, EY Technology Strategy & Transformation, September 2024

Up to 

50%  

of banks\' delivery budgets are wasted on repetitive tasks, such as risk assessments, IT change management, and mandatory tech replacements.

"

Leveraging four key technology concepts  to   realize next level operational efficiency, compliance posture and business agility

Page  26
