---
name: implementation-doc-sync
description: "Use when implementing code changes that require an explicit documentation-impact decision before completion."
workflow_role: worker
workflow_binding: contract_only
primary_outputs:
  - implementation changes
  - documentation impact verdict
  - updated AGENTS.md or architecture/workspace.dsl when required
default_next:
  success: verification or handoff
  blocked: user clarification
  needs_more_evidence: manual docs review
  fail: rerun after docs or output repair
---

# Purpose

Implement requested changes while enforcing an explicit documentation review before you claim completion. This skill owns the **decision and update**. Deterministic hinting about likely docs impact belongs to `scripts/docs_impact_preflight.py`.

## Workflow role

- Role: `worker`
- Goal gate: yes, for any claim that documentation impact was reviewed
- Human approval node: no
- Typical predecessors: `pipeline-conductor`, direct implementation request
- Typical successors: verification, release planning, or user review

## Inputs

### Required

- changed code or configuration scope

### Optional

- `AGENTS.md` or legacy `agents.md`
- `architecture/workspace.dsl`
- `.factory/project.yaml`
- petition context and outcome-contract artifacts

## Preconditions

1. Implementation work is in scope for this run.
2. Documentation review cannot be skipped when code, config, API, or architecture-relevant files changed.
3. This skill may update only:
   - `AGENTS.md` or legacy `agents.md`
   - `architecture/workspace.dsl`
4. `docs/` content is owned by `doc-writer`. Do not edit `docs/` directly here.

## Deterministic docs preflight

1. Build the changed-path list from the files you actually changed in this run. Do **not** use the whole dirty worktree when unrelated changes exist.
2. When git context is helpful, scope it to your touched files, for example:
   `git --no-pager diff --name-only HEAD -- <changed-path>...`
3. Run the advisory preflight with the exact changed paths:
   `python scripts/docs_impact_preflight.py --root <repo> --json <changed-path>...`
4. Interpret the result as follows:
   - `recommended_line` present -> use it as the starting docs-impact verdict
   - `manual_review_required=true` -> inspect `AGENTS.md` and/or `architecture/workspace.dsl` yourself before deciding
   - script error or unusable changed-path input -> `needs_more_evidence`; inspect docs manually instead of skipping review
5. Record the script run as evidence. The preflight is advisory only; it does **not** decide updates by itself.

## Procedure

1. Implement the requested code or configuration change.
2. Before finishing, run the deterministic docs preflight on the actual changed paths from this run.
3. Inspect the flagged collaborative docs:
   - `AGENTS.md` / `agents.md` for project conventions, commands, workflow defaults, or agent-boundary drift
   - `architecture/workspace.dsl` for container, component, datastore, integration, or topology drift
4. Update only the docs that are actually affected.
5. In the final response, always include exactly one `Documentation impact:` line using one of these patterns:
   - `Documentation impact: updated <path>, <path>`
   - `Documentation impact: reviewed; no updates needed because <reason>`
6. After the verdict, read `petitions/program-status.yaml` when present. Do not update petition status here.
7. Write a concise diary entry with the implementation outcome, docs decision, and any deviation worth remembering.

## Output Contract

### Artifacts

- implementation changes
- updated `AGENTS.md` / `agents.md` when required
- updated `architecture/workspace.dsl` when required
- final response containing the required `Documentation impact:` line

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` — implementation completed and documentation impact was explicitly reviewed
- `blocked` — required implementation scope or collaborative docs context is missing
- `needs_more_evidence` — docs impact could not be decided safely without further inspection or clarification
- `fail` — implementation or required docs output could not be completed safely

## Done Criteria

1. Documentation impact was reviewed before completion was claimed.
2. Any required updates to `AGENTS.md` / `agents.md` or `architecture/workspace.dsl` were made.
3. The final response contains exactly one valid `Documentation impact:` line.
4. No direct edits were made to `docs/`.

## Evidence Requirements

- Claim: docs impact was reviewed -> proof: `docs_impact_preflight.py` output and/or manual doc inspection was completed in this run
- Claim: `AGENTS.md` changed -> proof: the file was edited in this run
- Claim: `architecture/workspace.dsl` changed -> proof: the file was edited in this run
- Claim: no docs update was needed -> proof: the flagged docs were inspected in this run and the reason is explicit

## Failure Routing

- changed-path scope is unknown -> `needs_more_evidence`
- docs preflight cannot run and docs were not inspected manually -> `needs_more_evidence`
- required collaborative docs are unwritable -> `fail`
- implementation request is missing core context -> `blocked`

## Never Do

- never skip the docs review step for code or config changes
- never treat the preflight result as automatic permission to skip manual judgement
- never edit `docs/` directly from this skill
- never omit the `Documentation impact:` line
- never claim docs are unaffected without an explicit reason
