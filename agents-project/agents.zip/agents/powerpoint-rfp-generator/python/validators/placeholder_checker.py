from __future__ import annotations

PLACEHOLDER_MARKERS = ("TODO", "TBD", "lorem ipsum", "<placeholder>")


def find_placeholders(text: str) -> list[str]:
    lowered = text.lower()
    return [marker for marker in PLACEHOLDER_MARKERS if marker.lower() in lowered]
