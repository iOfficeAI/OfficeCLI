"""Validation helpers for rendered visuals and slides."""
