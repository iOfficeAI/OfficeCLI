from __future__ import annotations

from models.visual_spec import VisualSpec

SUPPORTED_ARTIFACTS = {
    "architecture_overview",
    "governance",
    "raci_matrix",
    "risk_control_matrix",
    "roadmap",
    "workstream_matrix",
}


def validate_spec(spec: VisualSpec) -> list[str]:
    errors: list[str] = []
    if spec.artifact_type not in SUPPORTED_ARTIFACTS:
        errors.append(f"Unsupported artifact type: {spec.artifact_type}")
    if not spec.slide_title.strip():
        errors.append("Slide title must not be empty")
    if not spec.data:
        errors.append("Visual spec data must not be empty")
    if spec.style.design_profile is not None and not str(spec.style.design_profile).strip():
        errors.append("Design profile reference must not be empty")
    return errors
