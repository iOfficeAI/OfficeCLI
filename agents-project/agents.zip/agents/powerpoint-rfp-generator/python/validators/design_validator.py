from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Mapping

from models.design_profile import DesignProfile
from ppt.deck_fingerprint import fingerprint_presentation
from themes.theme_utils import collect_hex_colors, normalize_hex_color, resolve_chrome, resolve_layout


@dataclass
class DesignValidationResult:
    design_profile: str | None
    warnings: list[str]
    errors: list[str]
    metrics: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def validate_presentation(
    pptx_path: Path,
    slide: Mapping[str, Any],
    theme: Mapping[str, Any],
    design_profile: DesignProfile | None,
) -> DesignValidationResult:
    if design_profile is None:
        return DesignValidationResult(
            design_profile=None,
            warnings=["No design profile supplied; post-render style validation skipped."],
            errors=[],
            metrics={"validated": False},
        )

    fingerprint = fingerprint_presentation(pptx_path)
    warnings: list[str] = []
    errors: list[str] = []
    layout = resolve_layout(theme)

    _validate_slot(
        "title",
        str(slide.get("title", "")),
        fingerprint,
        layout,
        theme,
        design_profile,
        errors,
    )
    _validate_slot(
        "purpose",
        str(slide.get("purpose", "")),
        fingerprint,
        layout,
        theme,
        design_profile,
        errors,
    )
    unexpected_colors = _validate_palette(fingerprint, theme, warnings)
    _validate_artifact_density(
        str(slide.get("artifact_type", "")),
        fingerprint,
        design_profile,
        errors,
    )

    metrics = {
        "validated": True,
        "shape_types": fingerprint["shape_types"],
        "auto_shape_types": fingerprint["auto_shape_types"],
        "coverage_ratio": fingerprint["coverage_ratio"],
        "text_character_count": fingerprint["text_character_count"],
        "text_paragraph_count": fingerprint["text_paragraph_count"],
        "table_metrics": fingerprint["table_metrics"],
        "unexpected_colors": unexpected_colors,
        "source_refs": list(design_profile.source_refs),
    }
    return DesignValidationResult(
        design_profile=design_profile.id,
        warnings=warnings,
        errors=errors,
        metrics=metrics,
    )


def _validate_slot(
    slot: str,
    expected_text: str,
    fingerprint: Mapping[str, Any],
    layout: Mapping[str, Mapping[str, float]],
    theme: Mapping[str, Any],
    design_profile: DesignProfile,
    errors: list[str],
) -> None:
    if not expected_text.strip():
        return

    text_boxes = fingerprint.get("text_boxes", [])
    match = next(
        (box for box in text_boxes if str(box.get("text", "")).strip() == expected_text.strip()),
        None,
    )
    if match is None:
        errors.append(f"Design validation could not locate the {slot} block in the rendered deck")
        return

    expected_box = layout.get(slot, {})
    rules = design_profile.slot_validation(slot)
    tolerance = _coerce_float(rules.get("tolerance"), 0.16)
    max_lines = _coerce_int(rules.get("max_lines"))
    chrome = resolve_chrome(theme, slot)
    expected_font_size = _coerce_float(chrome.get("font_size"), None)
    expected_color = normalize_hex_color(str(chrome.get("color"))) if chrome.get("color") else None
    expected_bold = chrome.get("bold") if isinstance(chrome.get("bold"), bool) else None

    for key in ("left", "top", "width", "height"):
        actual = _coerce_float(match.get(key), None)
        if actual is None:
            continue
        expected = _coerce_float(expected_box.get(key), None)
        if expected is None:
            continue
        if abs(actual - expected) > tolerance:
            errors.append(
                f"{slot.title()} block {key} drifted from the approved layout "
                f"(expected {expected:.2f}in, actual {actual:.2f}in, tolerance {tolerance:.2f}in)"
            )

    actual_font_size = _coerce_float(match.get("max_font_size"), None)
    if expected_font_size is not None and actual_font_size is not None:
        if abs(actual_font_size - expected_font_size) > 1.5:
            errors.append(
                f"{slot.title()} font size drifted from the approved profile "
                f"(expected {expected_font_size:.1f}pt, actual {actual_font_size:.1f}pt)"
            )

    if max_lines is not None and int(match.get("paragraph_count", 0)) > max_lines:
        errors.append(
            f"{slot.title()} block exceeds the approved line count "
            f"({match.get('paragraph_count', 0)} > {max_lines})"
        )

    colors = {normalize_hex_color(str(value)) for value in match.get("colors", [])}
    if expected_color and expected_color not in colors:
        errors.append(
            f"{slot.title()} text color drifted from the approved profile "
            f"(expected {expected_color}, actual {sorted(color for color in colors if color)})"
        )

    if expected_bold is not None and bool(match.get("bold")) != expected_bold:
        errors.append(f"{slot.title()} block bold styling drifted from the approved profile")


def _validate_palette(
    fingerprint: Mapping[str, Any],
    theme: Mapping[str, Any],
    warnings: list[str],
) -> list[str]:
    allowed_colors = collect_hex_colors(theme)
    observed_colors = {
        *(_normalize_color_list(fingerprint.get("fill_colors", []))),
        *(_normalize_color_list(fingerprint.get("line_colors", []))),
        *(_normalize_color_list(fingerprint.get("text_colors", []))),
    }
    unexpected = sorted(color for color in observed_colors if color and color not in allowed_colors)
    if unexpected:
        warnings.append(
            "Rendered deck uses colors outside the approved design palette: "
            + ", ".join(unexpected)
        )
    return unexpected


def _validate_artifact_density(
    artifact_type: str,
    fingerprint: Mapping[str, Any],
    design_profile: DesignProfile,
    errors: list[str],
) -> None:
    rules = design_profile.artifact_validation(artifact_type)
    if not rules:
        return

    total_shapes = sum(int(value) for value in fingerprint.get("shape_types", {}).values())
    max_shapes = _coerce_int(rules.get("max_shapes"))
    if max_shapes is not None and total_shapes > max_shapes:
        errors.append(
            f"Rendered slide exceeds the approved shape budget ({total_shapes} > {max_shapes})"
        )

    max_total_paragraphs = _coerce_int(rules.get("max_total_paragraphs"))
    if (
        max_total_paragraphs is not None
        and int(fingerprint.get("text_paragraph_count", 0)) > max_total_paragraphs
    ):
        errors.append(
            "Rendered slide exceeds the approved paragraph budget "
            f"({fingerprint.get('text_paragraph_count', 0)} > {max_total_paragraphs})"
        )

    max_total_characters = _coerce_int(rules.get("max_total_characters"))
    if (
        max_total_characters is not None
        and int(fingerprint.get("text_character_count", 0)) > max_total_characters
    ):
        errors.append(
            "Rendered slide exceeds the approved text budget "
            f"({fingerprint.get('text_character_count', 0)} > {max_total_characters})"
        )

    max_paragraphs_per_text_box = _coerce_int(rules.get("max_paragraphs_per_text_box"))
    if max_paragraphs_per_text_box is not None:
        for text_box in fingerprint.get("text_boxes", []):
            if int(text_box.get("paragraph_count", 0)) > max_paragraphs_per_text_box:
                errors.append(
                    "Rendered text block exceeds the approved density budget "
                    f"({text_box.get('paragraph_count', 0)} > {max_paragraphs_per_text_box})"
                )
                break

    max_coverage_ratio = _coerce_float(rules.get("max_coverage_ratio"), None)
    if (
        max_coverage_ratio is not None
        and float(fingerprint.get("coverage_ratio", 0.0)) > max_coverage_ratio
    ):
        errors.append(
            "Rendered slide exceeds the approved occupied-area ratio "
            f"({fingerprint.get('coverage_ratio', 0.0):.3f} > {max_coverage_ratio:.3f})"
        )

    max_table_rows = _coerce_int(rules.get("max_table_rows"))
    max_table_cols = _coerce_int(rules.get("max_table_cols"))
    for table in fingerprint.get("table_metrics", []):
        if max_table_rows is not None and int(table.get("rows", 0)) > max_table_rows:
            errors.append(
                f"Rendered table exceeds the approved row limit ({table.get('rows', 0)} > {max_table_rows})"
            )
        if max_table_cols is not None and int(table.get("cols", 0)) > max_table_cols:
            errors.append(
                f"Rendered table exceeds the approved column limit ({table.get('cols', 0)} > {max_table_cols})"
            )

    required_shape_types = rules.get("required_shape_types", [])
    if isinstance(required_shape_types, list):
        for requested_type in required_shape_types:
            if not _has_shape_type(fingerprint, str(requested_type)):
                errors.append(
                    f"Rendered slide is missing the approved shape type '{requested_type}'"
                )


def _has_shape_type(fingerprint: Mapping[str, Any], requested_type: str) -> bool:
    token = requested_type.replace("-", "_").upper()
    shape_types = {
        str(key).upper(): int(value)
        for key, value in fingerprint.get("shape_types", {}).items()
    }
    auto_shape_types = {
        str(key).upper(): int(value)
        for key, value in fingerprint.get("auto_shape_types", {}).items()
    }
    return shape_types.get(token, 0) > 0 or auto_shape_types.get(token, 0) > 0


def _normalize_color_list(values: Any) -> set[str]:
    if not isinstance(values, list):
        return set()
    normalized: set[str] = set()
    for value in values:
        color = normalize_hex_color(str(value))
        if color:
            normalized.add(color)
    return normalized


def _coerce_float(value: Any, default: float | None) -> float | None:
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _coerce_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None
