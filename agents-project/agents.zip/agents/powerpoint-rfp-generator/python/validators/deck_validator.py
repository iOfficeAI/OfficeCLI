from __future__ import annotations

from typing import Any, Mapping

from validators.placeholder_checker import find_placeholders


def validate_slide(slide: Mapping[str, Any]) -> list[str]:
    errors: list[str] = []
    title = str(slide.get("title", ""))
    if not title.strip():
        errors.append("Slide title is missing")
    errors.extend(
        f"Placeholder marker found: {marker}" for marker in find_placeholders(title)
    )
    content = slide.get("content", {})
    elements = content.get("elements", []) if isinstance(content, dict) else []
    if not elements:
        errors.append("Rendered slide contains no elements")
    return errors
