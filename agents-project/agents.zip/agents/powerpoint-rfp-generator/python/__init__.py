"""Deterministic render scaffolding for RFP PowerPoint visual artifacts."""

__all__ = ["cli"]
