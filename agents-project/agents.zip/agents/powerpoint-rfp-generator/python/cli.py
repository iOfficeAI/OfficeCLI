from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Mapping

from models.design_profile import DesignProfile, resolve_design_profile
from models.render_report import RenderReport
from models.visual_spec import VisualSpec, load_mapping
from ppt.presentation_writer import write_presentation
from ppt.slide_writer import build_slide
from renderers import get_renderer
from themes.default_theme import DEFAULT_THEME
from themes.theme_utils import merge_theme
from validators.design_validator import validate_presentation
from validators.deck_validator import validate_slide
from validators.visual_validator import validate_spec


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Render a typed PowerPoint visual spec into slide instructions."
    )
    parser.add_argument("spec", type=Path, help="Path to a YAML or JSON visual spec.")
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
        help="Output path for the rendered JSON payload.",
    )
    parser.add_argument(
        "--pptx-output",
        type=Path,
        help="Optional output path for a rendered .pptx file.",
    )
    parser.add_argument(
        "--template",
        type=Path,
        help="Optional PowerPoint template to use when creating the .pptx file.",
    )
    parser.add_argument(
        "--design-profile",
        type=str,
        help="Optional design profile path or built-in profile ID for render guidance and post-render validation.",
    )
    parser.add_argument(
        "--report-output",
        type=Path,
        help="Optional explicit output path for the JSON render report. Defaults to <output>.report.json.",
    )
    parser.add_argument(
        "--style-validation-output",
        type=Path,
        help="Optional explicit output path for the JSON style-validation report. Defaults to <output>.style-validation.json.",
    )
    return parser.parse_args()


def render_visual(
    spec_data: Mapping[str, Any], explicit_design_profile: DesignProfile | None = None
) -> tuple[dict[str, Any], RenderReport, DesignProfile | None]:
    spec = VisualSpec.from_mapping(spec_data)
    validation_errors = validate_spec(spec)
    if validation_errors:
        raise ValueError("Invalid visual spec: " + "; ".join(validation_errors))

    design_profile = explicit_design_profile or resolve_design_profile(
        spec_ref=spec.style.design_profile
    )
    theme = merge_theme(
        DEFAULT_THEME,
        design_profile.theme_overrides if design_profile is not None else None,
    )
    renderer = get_renderer(spec.artifact_type)
    rendered_visual = renderer.render(spec, theme)
    slide = build_slide(spec, rendered_visual, theme)

    slide_errors = validate_slide(slide)
    report = RenderReport(
        artifact_id=spec.id,
        artifact_type=spec.artifact_type,
        slide_title=spec.slide_title,
        warnings=[],
        errors=slide_errors,
        output_path=None,
        design_profile=design_profile.id if design_profile is not None else None,
    )
    return slide, report, design_profile


def main() -> int:
    args = parse_args()
    spec_data = load_mapping(args.spec)
    explicit_design_profile = resolve_design_profile(explicit_ref=args.design_profile)
    slide, report, design_profile = render_visual(spec_data, explicit_design_profile)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(slide, indent=2), encoding="utf-8")

    if args.pptx_output is not None:
        write_presentation(slide, args.pptx_output, args.template)
        report.output_path = str(args.pptx_output)
        validation_result = validate_presentation(
            args.pptx_output,
            slide,
            slide.get("theme", {}) if isinstance(slide.get("theme"), Mapping) else {},
            design_profile,
        )
        report.validation = validation_result.to_dict()
        report.warnings.extend(validation_result.warnings)
        report.errors.extend(validation_result.errors)
        validation_path = args.style_validation_output or args.output.with_suffix(
            ".style-validation.json"
        )
        validation_path.parent.mkdir(parents=True, exist_ok=True)
        validation_path.write_text(
            json.dumps(validation_result.to_dict(), indent=2),
            encoding="utf-8",
        )
    else:
        report.output_path = str(args.output)
        if design_profile is not None:
            report.warnings.append(
                "Design profile loaded, but post-render style validation was skipped because no PowerPoint file was written."
            )
    report_path = args.report_output or args.output.with_suffix(".report.json")
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report.to_dict(), indent=2), encoding="utf-8")
    return 0 if not report.errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
