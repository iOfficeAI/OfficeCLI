from __future__ import annotations

from collections.abc import Mapping, Sequence
from copy import deepcopy
from typing import Any

EMU_PER_INCH = 914400

DEFAULT_LAYOUT = {
    "title": {"left": 0.5, "top": 0.2, "width": 12.3, "height": 0.45},
    "purpose": {"left": 0.5, "top": 0.72, "width": 12.3, "height": 0.34},
    "content": {"left": 0.45, "top": 1.2, "width": 12.35, "height": 5.95},
}

DEFAULT_CHROME = {
    "title": {"font_size": 22.0, "color": "#1F1F1F", "bold": True},
    "purpose": {"font_size": 10.0, "color": "#475569", "bold": False},
}


def merge_theme(
    base: Mapping[str, Any], overrides: Mapping[str, Any] | None = None
) -> dict[str, Any]:
    merged = deepcopy(dict(base))
    if overrides:
        _deep_update(merged, overrides)
    return merged


def resolve_layout(theme: Mapping[str, Any]) -> dict[str, dict[str, float]]:
    raw_layout = theme.get("layout", {})
    layout = raw_layout if isinstance(raw_layout, Mapping) else {}
    return {
        "title": _resolve_box(layout.get("title"), DEFAULT_LAYOUT["title"]),
        "purpose": _resolve_box(layout.get("purpose"), DEFAULT_LAYOUT["purpose"]),
        "content": _resolve_box(layout.get("content"), DEFAULT_LAYOUT["content"]),
    }


def resolve_chrome(theme: Mapping[str, Any], slot: str) -> dict[str, Any]:
    proposal = theme.get("proposal", {})
    chrome = proposal.get("chrome", {}) if isinstance(proposal, Mapping) else {}
    slot_values = chrome.get(slot, {}) if isinstance(chrome, Mapping) else {}
    merged = dict(DEFAULT_CHROME.get(slot, {}))
    if isinstance(slot_values, Mapping):
        for key, value in slot_values.items():
            merged[key] = value
    return merged


def inches_to_emu(value: float) -> int:
    return int(float(value) * EMU_PER_INCH)


def emu_to_inches(value: int | float) -> float:
    return float(value) / EMU_PER_INCH


def normalize_hex_color(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip().lstrip("#")
    if len(normalized) != 6:
        return None
    try:
        int(normalized, 16)
    except ValueError:
        return None
    return f"#{normalized.upper()}"


def collect_hex_colors(data: Any) -> set[str]:
    colors: set[str] = set()
    if isinstance(data, str):
        normalized = normalize_hex_color(data)
        if normalized:
            colors.add(normalized)
        return colors
    if isinstance(data, Mapping):
        for value in data.values():
            colors.update(collect_hex_colors(value))
        return colors
    if isinstance(data, Sequence) and not isinstance(data, (str, bytes, bytearray)):
        for item in data:
            colors.update(collect_hex_colors(item))
    return colors


def _deep_update(target: dict[str, Any], updates: Mapping[str, Any]) -> None:
    for key, value in updates.items():
        existing = target.get(key)
        if isinstance(existing, Mapping) and isinstance(value, Mapping):
            nested = deepcopy(dict(existing))
            _deep_update(nested, value)
            target[key] = nested
            continue
        target[key] = deepcopy(value)


def _resolve_box(
    value: Any, defaults: Mapping[str, float]
) -> dict[str, float]:
    resolved = dict(defaults)
    if not isinstance(value, Mapping):
        return resolved
    for key in ("left", "top", "width", "height"):
        if key in value:
            resolved[key] = _coerce_float(value[key], defaults[key])
    return resolved


def _coerce_float(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default
