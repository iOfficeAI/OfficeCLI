"""Theme definitions for PowerPoint visual artifact rendering."""
