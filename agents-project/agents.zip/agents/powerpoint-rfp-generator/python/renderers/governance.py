from __future__ import annotations

from typing import Any, Mapping

from models.visual_spec import VisualSpec
from ppt.native_shapes import connector, swimlane
from renderers.base import BaseRenderer


class GovernanceRenderer(BaseRenderer):
    artifact_type = "governance"

    def render(
        self, spec: VisualSpec, theme: Mapping[str, Any] | None = None
    ) -> dict[str, Any]:
        layers = spec.data.get("layers", [])
        elements = [
            swimlane(
                index=index,
                title=layer.get("name", ""),
                items=(layer.get("forums", []) + layer.get("responsibilities", [])),
                forums=layer.get("forums", []),
                responsibilities=layer.get("responsibilities", []),
            )
            for index, layer in enumerate(layers, start=1)
        ]
        path = spec.data.get("escalation_path", [])
        if len(path) > 1:
            elements.append(connector(path=path, label="Escalation"))
        return self.payload(spec, elements)
