from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from models.visual_spec import VisualSpec
from ppt.native_shapes import boundary, connector, node
from renderers.base import BaseRenderer


LAYER_C4_TYPES = {
    "user": "person",
    "users": "person",
    "person": "person",
    "people": "person",
    "actor": "person",
    "actors": "person",
    "external": "software_system",
    "external systems": "software_system",
    "system": "software_system",
    "systems": "software_system",
    "application": "container",
    "applications": "container",
    "container": "container",
    "containers": "container",
    "service": "container",
    "services": "container",
    "platform": "container",
    "data": "database",
    "database": "database",
    "databases": "database",
}


class ArchitectureOverviewRenderer(BaseRenderer):
    artifact_type = "architecture_overview"

    def render(
        self, spec: VisualSpec, theme: Mapping[str, Any] | None = None
    ) -> dict[str, Any]:
        elements: list[dict[str, Any]] = []
        for layer in spec.data.get("layers", []):
            for layer_node in layer.get("nodes", []):
                normalized_node = self._normalize_node(layer.get("name", ""), layer_node)
                elements.append(
                    node(
                        label=normalized_node["label"],
                        layer=normalized_node["layer"],
                        c4_type=normalized_node.get("c4_type"),
                        description=normalized_node.get("description"),
                        technology=normalized_node.get("technology"),
                        boundary=normalized_node.get("boundary"),
                        tags=normalized_node.get("tags"),
                        style=self._node_style(theme, normalized_node.get("c4_type")),
                    )
                )
        for edge in spec.data.get("connections", []):
            elements.append(
                connector(
                    path=[edge.get("from", ""), edge.get("to", "")],
                    label=edge.get("label"),
                    technology=edge.get("technology"),
                    protocol=edge.get("protocol"),
                    relationship=edge.get("relationship"),
                    style=self._relationship_style(theme),
                )
            )
        elements.extend(self._render_boundaries(spec.data.get("trust_boundaries", []), theme))
        payload = self.payload(spec, elements)
        payload["notation"] = "c4"
        payload["c4_level"] = self._infer_c4_level(spec)
        return payload

    def _normalize_node(
        self, layer_name: str, raw_node: str | Mapping[str, Any]
    ) -> dict[str, Any]:
        if isinstance(raw_node, str):
            return {
                "label": raw_node,
                "layer": layer_name,
                "c4_type": self._infer_c4_type(layer_name, raw_node),
            }

        label = str(raw_node.get("name") or raw_node.get("label") or "")
        return {
            "label": label,
            "layer": str(raw_node.get("layer") or layer_name),
            "c4_type": str(raw_node.get("c4_type") or self._infer_c4_type(layer_name, label)),
            "description": self._optional_text(raw_node, "description"),
            "technology": self._optional_text(raw_node, "technology"),
            "boundary": self._optional_text(raw_node, "boundary"),
            "tags": self._normalize_tags(raw_node.get("tags")),
        }

    def _render_boundaries(
        self,
        boundaries: list[str] | list[Mapping[str, Any]],
        theme: Mapping[str, Any] | None,
    ) -> list[dict[str, Any]]:
        rendered: list[dict[str, Any]] = []
        for item in boundaries:
            if isinstance(item, str):
                rendered.append(
                    boundary(
                        name=item,
                        includes=[],
                        style=self._boundary_style(theme, None),
                    )
                )
                continue
            boundary_type = self._optional_text(item, "boundary_type")
            rendered.append(
                boundary(
                    name=str(item.get("name", "")),
                    includes=[str(entry) for entry in item.get("includes", [])],
                    boundary_type=boundary_type,
                    style=self._boundary_style(theme, boundary_type),
                )
            )
        return rendered

    def _infer_c4_level(self, spec: VisualSpec) -> str:
        preferred_layout = (spec.layout.preferred or "").strip().lower()
        if preferred_layout in {"c4-context", "context"}:
            return "context"
        return "container"

    def _infer_c4_type(self, layer_name: str, label: str) -> str:
        layer_key = layer_name.strip().lower()
        if layer_key in LAYER_C4_TYPES:
            return LAYER_C4_TYPES[layer_key]
        label_key = label.strip().lower()
        if any(token in label_key for token in {"database", "store", "warehouse", "db"}):
            return "database"
        return "container"

    def _normalize_tags(self, tags: Any) -> list[str] | None:
        if not isinstance(tags, list):
            return None
        normalized = [str(tag) for tag in tags if str(tag).strip()]
        return normalized or None

    def _optional_text(self, data: Mapping[str, Any], key: str) -> str | None:
        value = data.get(key)
        if value is None:
            return None
        text = str(value).strip()
        return text or None

    def _node_style(
        self, theme: Mapping[str, Any] | None, c4_type: str | None
    ) -> dict[str, Any] | None:
        if theme is None:
            return None
        c4_theme = theme.get("c4")
        if not isinstance(c4_theme, Mapping):
            return None
        node_styles = c4_theme.get("node_styles")
        if not isinstance(node_styles, Mapping):
            return None
        if c4_type and c4_type in node_styles and isinstance(node_styles[c4_type], Mapping):
            return dict(node_styles[c4_type])
        default_style = node_styles.get("default")
        if isinstance(default_style, Mapping):
            return dict(default_style)
        return None

    def _relationship_style(
        self, theme: Mapping[str, Any] | None
    ) -> dict[str, Any] | None:
        if theme is None:
            return None
        c4_theme = theme.get("c4")
        if not isinstance(c4_theme, Mapping):
            return None
        style = c4_theme.get("relationship_style")
        if isinstance(style, Mapping):
            return dict(style)
        return None

    def _boundary_style(
        self, theme: Mapping[str, Any] | None, boundary_type: str | None
    ) -> dict[str, Any] | None:
        if theme is None:
            return None
        c4_theme = theme.get("c4")
        if not isinstance(c4_theme, Mapping):
            return None
        boundary_styles = c4_theme.get("boundary_styles")
        if not isinstance(boundary_styles, Mapping):
            return None
        if boundary_type and boundary_type in boundary_styles:
            style = boundary_styles[boundary_type]
            if isinstance(style, Mapping):
                return dict(style)
        default_style = boundary_styles.get("default")
        if isinstance(default_style, Mapping):
            return dict(default_style)
        return None
