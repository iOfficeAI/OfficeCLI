from __future__ import annotations

from typing import Any, Mapping

from models.visual_spec import VisualSpec
from ppt.native_shapes import matrix_table
from renderers.base import BaseRenderer


class RiskControlMatrixRenderer(BaseRenderer):
    artifact_type = "risk_control_matrix"

    def render(
        self, spec: VisualSpec, theme: Mapping[str, Any] | None = None
    ) -> dict[str, Any]:
        risks = spec.data.get("risks", [])
        assignments = [
            {
                "activity": item.get("risk", ""),
                "role": "Owner",
                "code": item.get("owner", ""),
                "control": item.get("control", ""),
                "evidence": item.get("evidence", ""),
            }
            for item in risks
        ]
        elements = [
            matrix_table(
                columns=["Owner", "Control", "Evidence"],
                rows=[item.get("risk", "") for item in risks],
                assignments=assignments,
            )
        ]
        return self.payload(spec, elements)
