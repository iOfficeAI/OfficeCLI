from __future__ import annotations

from renderers.architecture_overview import ArchitectureOverviewRenderer
from renderers.governance import GovernanceRenderer
from renderers.raci_matrix import RaciMatrixRenderer
from renderers.risk_control_matrix import RiskControlMatrixRenderer
from renderers.roadmap import RoadmapRenderer
from renderers.workstream_matrix import WorkstreamMatrixRenderer

RENDERERS = {
    "architecture_overview": ArchitectureOverviewRenderer(),
    "governance": GovernanceRenderer(),
    "raci_matrix": RaciMatrixRenderer(),
    "risk_control_matrix": RiskControlMatrixRenderer(),
    "roadmap": RoadmapRenderer(),
    "workstream_matrix": WorkstreamMatrixRenderer(),
}


def get_renderer(artifact_type: str):
    try:
        return RENDERERS[artifact_type]
    except KeyError as exc:
        raise ValueError(f"Unsupported artifact type: {artifact_type}") from exc
