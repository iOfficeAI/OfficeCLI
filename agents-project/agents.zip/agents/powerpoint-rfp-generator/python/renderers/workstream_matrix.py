from __future__ import annotations

from typing import Any, Mapping

from models.visual_spec import VisualSpec
from ppt.native_shapes import card
from renderers.base import BaseRenderer


class WorkstreamMatrixRenderer(BaseRenderer):
    artifact_type = "workstream_matrix"

    def render(
        self, spec: VisualSpec, theme: Mapping[str, Any] | None = None
    ) -> dict[str, Any]:
        workstreams = spec.data.get("workstreams", [])
        elements = [
            card(
                title=workstream.get("name", ""),
                body=[
                    f"Owner: {workstream.get('owner', '')}",
                    "Outputs: " + ", ".join(workstream.get("outputs", [])),
                    "Dependencies: "
                    + ", ".join(workstream.get("dependencies", [])),
                ],
            )
            for workstream in workstreams
        ]
        return self.payload(spec, elements)
