from __future__ import annotations

from typing import Any, Mapping

from models.visual_spec import VisualSpec
from ppt.native_shapes import matrix_table
from renderers.base import BaseRenderer


class RaciMatrixRenderer(BaseRenderer):
    artifact_type = "raci_matrix"

    def render(
        self, spec: VisualSpec, theme: Mapping[str, Any] | None = None
    ) -> dict[str, Any]:
        elements = [
            matrix_table(
                columns=list(spec.data.get("roles", [])),
                rows=list(spec.data.get("activities", [])),
                assignments=list(spec.data.get("assignments", [])),
            )
        ]
        return self.payload(spec, elements)
