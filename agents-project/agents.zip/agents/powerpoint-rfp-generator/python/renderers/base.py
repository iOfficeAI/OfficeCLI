from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Mapping

from models.visual_spec import VisualSpec


class BaseRenderer(ABC):
    artifact_type: str

    @abstractmethod
    def render(
        self, spec: VisualSpec, theme: Mapping[str, Any] | None = None
    ) -> dict[str, Any]:
        raise NotImplementedError

    def payload(self, spec: VisualSpec, elements: list[dict[str, Any]]) -> dict[str, Any]:
        return {
            "artifact_id": spec.id,
            "artifact_type": spec.artifact_type,
            "layout": spec.layout.preferred,
            "elements": elements,
        }
