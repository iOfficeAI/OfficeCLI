from __future__ import annotations

from typing import Any, Mapping

from models.visual_spec import VisualSpec
from ppt.native_shapes import chevron_phase
from renderers.base import BaseRenderer


class RoadmapRenderer(BaseRenderer):
    artifact_type = "roadmap"

    def render(
        self, spec: VisualSpec, theme: Mapping[str, Any] | None = None
    ) -> dict[str, Any]:
        phases = spec.data.get("phases", [])
        elements = [
            chevron_phase(
                index=index,
                title=phase.get("name", ""),
                subtitle=phase.get("duration"),
                bullets=phase.get("outcomes", []),
            )
            for index, phase in enumerate(phases, start=1)
        ]
        return self.payload(spec, elements)
