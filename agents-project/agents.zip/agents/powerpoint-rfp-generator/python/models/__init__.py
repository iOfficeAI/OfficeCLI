"""Data models for PowerPoint RFP rendering."""
