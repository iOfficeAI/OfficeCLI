from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class SlideMapEntry:
    slide_number: int
    title: str
    section_ref: str
    artifact_ids: tuple[str, ...] = field(default_factory=tuple)
