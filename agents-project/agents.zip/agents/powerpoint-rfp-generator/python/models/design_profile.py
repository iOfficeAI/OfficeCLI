from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

from models.visual_spec import load_mapping

PROFILE_ROOT = Path(__file__).resolve().parents[2] / "artifacts" / "design_profiles"


@dataclass(frozen=True)
class DesignProfile:
    id: str
    label: str
    description: str | None = None
    source_refs: tuple[str, ...] = ()
    theme_overrides: Mapping[str, Any] = field(default_factory=dict)
    validation: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any]) -> "DesignProfile":
        theme_overrides = data.get("theme_overrides", {}) or {}
        validation = data.get("validation", {}) or {}
        if not isinstance(theme_overrides, Mapping):
            raise ValueError("Design profile theme_overrides must be a mapping")
        if not isinstance(validation, Mapping):
            raise ValueError("Design profile validation must be a mapping")
        return cls(
            id=str(data["id"]),
            label=str(data.get("label") or data["id"]),
            description=_optional_text(data, "description"),
            source_refs=tuple(str(item) for item in data.get("source_refs", [])),
            theme_overrides=dict(theme_overrides),
            validation=dict(validation),
        )

    def artifact_validation(self, artifact_type: str) -> Mapping[str, Any]:
        artifacts = self.validation.get("artifacts", {})
        if not isinstance(artifacts, Mapping):
            return {}
        artifact_rules = artifacts.get(artifact_type, {})
        if isinstance(artifact_rules, Mapping):
            return artifact_rules
        return {}

    def slot_validation(self, slot: str) -> Mapping[str, Any]:
        slot_rules = self.validation.get(slot, {})
        if isinstance(slot_rules, Mapping):
            return slot_rules
        return {}


def load_design_profile(profile_ref: str | Path) -> DesignProfile:
    profile_path = _resolve_profile_path(profile_ref)
    mapping = load_mapping(profile_path)
    profile = DesignProfile.from_mapping(mapping)
    if not profile.id.strip():
        raise ValueError(f"Design profile ID must not be empty: {profile_path}")
    return profile


def resolve_design_profile(
    explicit_ref: str | None = None, spec_ref: str | None = None
) -> DesignProfile | None:
    selected = explicit_ref or spec_ref
    if not selected:
        return None
    return load_design_profile(selected)


def _resolve_profile_path(profile_ref: str | Path) -> Path:
    candidate = Path(profile_ref)
    search_paths: list[Path] = []
    if candidate.suffix.lower() in {".yaml", ".yml", ".json"} or candidate.is_absolute():
        search_paths.append(candidate)
        if not candidate.is_absolute():
            search_paths.append(PROFILE_ROOT / candidate)
    else:
        search_paths.extend(
            PROFILE_ROOT / f"{candidate}.{suffix}"
            for suffix in ("yaml", "yml", "json")
        )

    for path in search_paths:
        if path.exists():
            return path
    rendered_paths = ", ".join(str(path) for path in search_paths)
    raise FileNotFoundError(
        f"Could not resolve design profile '{profile_ref}'. Searched: {rendered_paths}"
    )


def _optional_text(data: Mapping[str, Any], key: str) -> str | None:
    value = data.get(key)
    if value is None:
        return None
    text = str(value).strip()
    return text or None
