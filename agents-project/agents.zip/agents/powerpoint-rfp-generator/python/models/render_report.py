from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass
class RenderReport:
    artifact_id: str
    artifact_type: str
    slide_title: str
    warnings: list[str]
    errors: list[str]
    output_path: str | None
    design_profile: str | None = None
    validation: dict[str, object] | None = None

    def to_dict(self) -> dict[str, object]:
        return asdict(self)
