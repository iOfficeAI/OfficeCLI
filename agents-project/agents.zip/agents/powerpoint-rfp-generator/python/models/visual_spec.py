from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

try:
    import yaml
except ImportError:  # pragma: no cover - optional dependency
    yaml = None


def load_mapping(path: Path) -> Mapping[str, Any]:
    raw = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".json":
        return json.loads(raw)
    if yaml is None:
        raise RuntimeError(
            "PyYAML is required to load YAML visual specs. Install pyyaml or use JSON input."
        )
    loaded = yaml.safe_load(raw)
    if not isinstance(loaded, dict):
        raise ValueError(f"Expected mapping in {path}")
    return loaded


@dataclass(frozen=True)
class VisualLayout:
    preferred: str | None = None
    max_items: int | None = None


@dataclass(frozen=True)
class VisualStyle:
    color_scheme: str | None = None
    complexity: str | None = None
    design_profile: str | None = None


@dataclass(frozen=True)
class VisualSpec:
    id: str
    artifact_type: str
    slide_title: str
    purpose: str
    source_refs: tuple[str, ...] = ()
    layout: VisualLayout = field(default_factory=VisualLayout)
    style: VisualStyle = field(default_factory=VisualStyle)
    data: Mapping[str, Any] = field(default_factory=dict)
    acceptance_checks: tuple[str, ...] = ()

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any]) -> "VisualSpec":
        layout = data.get("layout", {}) or {}
        style = data.get("style", {}) or {}
        return cls(
            id=str(data["id"]),
            artifact_type=str(data["artifact_type"]),
            slide_title=str(data["slide_title"]),
            purpose=str(data["purpose"]),
            source_refs=tuple(str(item) for item in data.get("source_refs", [])),
            layout=VisualLayout(
                preferred=layout.get("preferred"),
                max_items=layout.get("max_items"),
            ),
            style=VisualStyle(
                color_scheme=style.get("color_scheme"),
                complexity=style.get("complexity"),
                design_profile=style.get("design_profile"),
            ),
            data=data.get("data", {}) or {},
            acceptance_checks=tuple(
                str(item) for item in data.get("acceptance_checks", [])
            ),
        )
