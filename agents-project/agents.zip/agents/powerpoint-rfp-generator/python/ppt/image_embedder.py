from __future__ import annotations

from pathlib import Path


def embed_image(image_path: Path, alt_text: str | None = None) -> dict[str, str | None]:
    return {
        "shape": "image",
        "path": str(image_path),
        "alt_text": alt_text,
    }
