from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Any, Mapping

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE, MSO_CONNECTOR_TYPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt
from themes.theme_utils import inches_to_emu, resolve_chrome, resolve_layout


SLIDE_WIDTH = Inches(13.333)
SLIDE_HEIGHT = Inches(7.5)
BOUNDARY_PADDING_X = Inches(0.18)
BOUNDARY_PADDING_Y = Inches(0.12)

NODE_SHAPES = {
    "c4-person": MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
    "c4-container": MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
    "c4-software-system": MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
    "c4-component": MSO_AUTO_SHAPE_TYPE.RECTANGLE,
    "c4-database": MSO_AUTO_SHAPE_TYPE.CAN,
}

BOUNDARY_DASH = {
    "dashed": MSO_LINE_DASH_STYLE.DASH,
    "dotted": MSO_LINE_DASH_STYLE.ROUND_DOT,
    "dash-dot": MSO_LINE_DASH_STYLE.DASH_DOT,
}


def write_presentation(
    slide_data: Mapping[str, Any],
    output_path: Path,
    template_path: Path | None = None,
) -> None:
    presentation = Presentation(str(template_path)) if template_path else Presentation()
    presentation.slide_width = SLIDE_WIDTH
    presentation.slide_height = SLIDE_HEIGHT

    theme = slide_data.get("theme", {}) if isinstance(slide_data.get("theme"), Mapping) else {}
    layout = resolve_layout(theme)
    slide = presentation.slides.add_slide(presentation.slide_layouts[6])
    _add_title(slide, str(slide_data.get("title", "")), theme, layout["title"])
    _add_purpose(slide, str(slide_data.get("purpose", "")), theme, layout["purpose"])

    content = slide_data.get("content", {})
    elements = content.get("elements", []) if isinstance(content, Mapping) else []
    _draw_elements(slide, elements, theme, layout["content"])

    output_path.parent.mkdir(parents=True, exist_ok=True)
    presentation.save(str(output_path))


def _add_title(
    slide: Any, title: str, theme: Mapping[str, Any], title_box: Mapping[str, float]
) -> None:
    chrome = resolve_chrome(theme, "title")
    textbox = slide.shapes.add_textbox(
        _box_metric(title_box, "left"),
        _box_metric(title_box, "top"),
        _box_metric(title_box, "width"),
        _box_metric(title_box, "height"),
    )
    frame = textbox.text_frame
    frame.clear()
    frame.word_wrap = True
    paragraph = frame.paragraphs[0]
    paragraph.text = title
    paragraph.font.size = Pt(float(chrome.get("font_size", 22)))
    paragraph.font.bold = bool(chrome.get("bold", True))
    paragraph.font.color.rgb = _rgb(str(chrome.get("color", "#1F1F1F")))


def _add_purpose(
    slide: Any, purpose: str, theme: Mapping[str, Any], purpose_box: Mapping[str, float]
) -> None:
    chrome = resolve_chrome(theme, "purpose")
    textbox = slide.shapes.add_textbox(
        _box_metric(purpose_box, "left"),
        _box_metric(purpose_box, "top"),
        _box_metric(purpose_box, "width"),
        _box_metric(purpose_box, "height"),
    )
    frame = textbox.text_frame
    frame.clear()
    frame.word_wrap = True
    paragraph = frame.paragraphs[0]
    paragraph.text = purpose
    paragraph.font.size = Pt(float(chrome.get("font_size", 10)))
    paragraph.font.bold = bool(chrome.get("bold", False))
    paragraph.font.color.rgb = _rgb(str(chrome.get("color", "#475569")))


def _draw_elements(
    slide: Any,
    elements: list[dict[str, Any]],
    theme: Mapping[str, Any],
    content_box: Mapping[str, float],
) -> None:
    if any(item.get("shape") == "chevron-phase" for item in elements):
        _draw_roadmap(slide, elements, theme, content_box)
        return

    if any(item.get("shape") == "swimlane" for item in elements):
        _draw_governance(slide, elements, theme, content_box)
        return

    if any(item.get("shape") == "matrix-table" for item in elements):
        _draw_matrix_artifact(slide, elements, theme, content_box)
        return

    if any(item.get("shape") == "card" for item in elements):
        _draw_card_artifact(slide, elements, theme, content_box)
        return

    node_elements = [item for item in elements if item.get("base_shape") == "node"]
    connector_elements = [item for item in elements if item.get("base_shape") == "connector"]
    boundary_elements = [item for item in elements if item.get("base_shape") == "boundary"]

    layout = _layout_nodes(node_elements, content_box)
    for key, box in layout.items():
        if key.startswith("__layer__::"):
            _draw_layer_label(slide, key.removeprefix("__layer__::"), box, theme)
    for element in node_elements:
        _draw_node(slide, element, layout[element["label"]], theme)

    for element in boundary_elements:
        _draw_boundary(slide, element, layout, theme)

    for element in connector_elements:
        _draw_connector(slide, element, layout, theme)


def _draw_roadmap(
    slide: Any,
    elements: list[dict[str, Any]],
    theme: Mapping[str, Any],
    content_box: Mapping[str, float],
) -> None:
    phases = sorted(
        [item for item in elements if item.get("shape") == "chevron-phase"],
        key=lambda item: int(item.get("index", 0)),
    )
    styles = _proposal_theme(theme, "roadmap")
    content_left = _box_metric(content_box, "left")
    content_top = _box_metric(content_box, "top")
    content_width = _box_metric(content_box, "width")
    phase_count = max(len(phases), 1)
    gap = int(Inches(0.08))
    total_gap = gap * max(phase_count - 1, 0)
    phase_width = (content_width - total_gap) // phase_count
    phase_height = int(Inches(2.25))
    top = content_top + int(Inches(0.42))

    panel = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        content_left,
        top - int(Inches(0.18)),
        content_width,
        phase_height + int(Inches(0.38)),
    )
    panel.fill.solid()
    panel.fill.fore_color.rgb = _rgb(str(styles.get("panel_fill", "#F8FAFC")))
    panel.line.color.rgb = _rgb(str(styles.get("panel_border", "#D7DFEA")))

    baseline = slide.shapes.add_connector(
        MSO_CONNECTOR_TYPE.STRAIGHT,
        content_left,
        top + phase_height + int(Inches(0.16)),
        content_left + content_width,
        top + phase_height + int(Inches(0.16)),
    )
    baseline.line.color.rgb = _rgb(str(styles.get("baseline", "#CBD5E1")))
    baseline.line.width = Pt(1.25)

    stage_fills = styles.get("stage_fills", [])
    if not isinstance(stage_fills, list) or not stage_fills:
        stage_fills = [str(_theme_color(theme, "accent", "#2F5D9F"))]

    for position, phase in enumerate(phases):
        left = content_left + position * (phase_width + gap)
        shape = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.CHEVRON,
            left,
            top,
            phase_width,
            phase_height,
        )
        fill = str(stage_fills[position % len(stage_fills)])
        shape.fill.solid()
        shape.fill.fore_color.rgb = _rgb(fill)
        shape.line.color.rgb = _rgb("#FFFFFF")
        shape.line.width = Pt(1.25)

        subtitle_text = str(phase.get("subtitle") or "")
        if subtitle_text:
            chip_width = _badge_width(subtitle_text, minimum=Inches(0.88), maximum=Inches(1.35))
            _draw_badge(
                slide,
                subtitle_text,
                left + int(Inches(0.18)),
                top + int(Inches(0.16)),
                chip_width,
                int(Inches(0.26)),
                fill=str(styles.get("subtitle_fill", "#FFFFFF")),
                text_color=str(styles.get("subtitle_text", "#23406E")),
                font_size=8.5,
                bold=True,
            )

        title_box = slide.shapes.add_textbox(
            left + int(Inches(0.18)),
            top + int(Inches(0.42)),
            phase_width - int(Inches(0.34)),
            int(Inches(0.36)),
        )
        title_frame = title_box.text_frame
        title_frame.clear()
        title_frame.word_wrap = True
        title = title_frame.paragraphs[0]
        title.text = str(phase.get("title", ""))
        title.alignment = PP_ALIGN.LEFT
        title.font.size = Pt(14)
        title.font.bold = True
        title.font.color.rgb = _rgb(str(styles.get("title_text", "#FFFFFF")))

        bullet_box = slide.shapes.add_textbox(
            left + int(Inches(0.18)),
            top + int(Inches(0.82)),
            phase_width - int(Inches(0.36)),
            phase_height - int(Inches(0.92)),
        )
        bullet_frame = bullet_box.text_frame
        bullet_frame.clear()
        bullet_frame.word_wrap = True
        for bullet_text in phase.get("bullets", [])[:3]:
            bullet = bullet_frame.paragraphs[0] if bullet_frame.paragraphs[0].text == "" else bullet_frame.add_paragraph()
            bullet.text = str(bullet_text)
            bullet.alignment = PP_ALIGN.LEFT
            bullet.level = 0
            bullet.font.size = Pt(8.5)
            bullet.font.color.rgb = _rgb(str(styles.get("bullet_text", "#F8FAFC")))
            bullet.bullet = True


def _draw_governance(
    slide: Any,
    elements: list[dict[str, Any]],
    theme: Mapping[str, Any],
    content_box: Mapping[str, float],
) -> None:
    lanes = sorted(
        [item for item in elements if item.get("shape") == "swimlane"],
        key=lambda item: int(item.get("index", 0)),
    )
    connectors = [item for item in elements if item.get("shape") == "connector"]
    styles = _proposal_theme(theme, "governance")
    content_left = _box_metric(content_box, "left")
    content_top = _box_metric(content_box, "top")
    content_width = _box_metric(content_box, "width")
    content_height = _box_metric(content_box, "height")
    lane_count = max(len(lanes), 1)
    gap = int(Inches(0.12))
    total_gap = gap * max(lane_count - 1, 0)
    lane_height = (content_height - int(Inches(0.18)) - total_gap) // lane_count
    header_width = int(Inches(1.78))
    lane_boxes: dict[str, dict[str, int]] = {}

    panel = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        content_left,
        content_top,
        content_width,
        content_height,
    )
    panel.fill.solid()
    panel.fill.fore_color.rgb = _rgb(str(styles.get("panel_fill", "#F8FAFC")))
    panel.line.color.rgb = _rgb(str(styles.get("panel_border", "#D7DFEA")))

    for position, lane in enumerate(lanes):
        top = content_top + position * (lane_height + gap)
        left = content_left
        width = content_width
        outer = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
            left,
            top,
            width,
            lane_height,
        )
        outer.fill.solid()
        outer.fill.fore_color.rgb = _rgb(str(styles.get("lane_fill", "#FBFCFE")))
        outer.line.color.rgb = _rgb(str(styles.get("lane_border", "#CAD6E4")))

        header = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
            left,
            top,
            header_width,
            lane_height,
        )
        header.fill.solid()
        header.fill.fore_color.rgb = _rgb(str(styles.get("header_fill", _theme_color(theme, "accent", "#2F5D9F"))))
        header.line.color.rgb = _rgb(str(styles.get("header_fill", _theme_color(theme, "accent", "#2F5D9F"))))
        header_frame = header.text_frame
        header_frame.clear()
        header_frame.vertical_anchor = MSO_ANCHOR.MIDDLE
        header_text = header_frame.paragraphs[0]
        header_text.text = str(lane.get("title", ""))
        header_text.alignment = PP_ALIGN.CENTER
        header_text.font.size = Pt(13)
        header_text.font.bold = True
        header_text.font.color.rgb = _rgb(str(styles.get("header_text", "#FFFFFF")))

        _draw_governance_lane_body(slide, lane, styles, left, top, width, header_width, lane_height)

        lane_boxes[str(lane.get("title", ""))] = {
            "left": left,
            "top": top,
            "width": width,
            "height": lane_height,
        }

    for connector in connectors:
        _draw_labeled_path(slide, connector, lane_boxes, theme)


def _draw_matrix_artifact(
    slide: Any,
    elements: list[dict[str, Any]],
    theme: Mapping[str, Any],
    content_box: Mapping[str, float],
) -> None:
    table_spec = next((item for item in elements if item.get("shape") == "matrix-table"), None)
    if table_spec is None:
        return

    columns = [str(item) for item in table_spec.get("columns", [])]
    rows = [str(item) for item in table_spec.get("rows", [])]
    styles = _proposal_theme(theme, "table")
    content_left = _box_metric(content_box, "left")
    content_top = _box_metric(content_box, "top")
    content_width = _box_metric(content_box, "width")
    content_height = _box_metric(content_box, "height")
    row_count = len(rows) + 1
    col_count = len(columns) + 1
    graphic_frame = slide.shapes.add_table(
        row_count,
        col_count,
        content_left,
        content_top,
        content_width,
        content_height - int(Inches(0.2)),
    )
    table = graphic_frame.table
    _set_matrix_column_widths(table, len(columns), content_width)

    table.cell(0, 0).text = "Activity"
    _style_table_cell(
        table.cell(0, 0),
        fill=str(styles.get("header_fill", "#23406E")),
        text=str(styles.get("header_text", "#FFFFFF")),
        bold=True,
        align=PP_ALIGN.LEFT,
    )
    for column_index, column_name in enumerate(columns, start=1):
        table.cell(0, column_index).text = column_name
        _style_table_cell(
            table.cell(0, column_index),
            fill=str(styles.get("header_fill", "#23406E")),
            text=str(styles.get("header_text", "#FFFFFF")),
            bold=True,
            align=PP_ALIGN.CENTER,
        )

    value_map = _matrix_values(table_spec.get("assignments", []), columns)
    for row_index, row_name in enumerate(rows, start=1):
        table.cell(row_index, 0).text = row_name
        row_fill = _banded_fill(styles, row_index)
        _style_table_cell(
            table.cell(row_index, 0),
            fill=str(styles.get("row_header_fill", "#E3ECF8")),
            text=str(styles.get("row_header_text", "#173155")),
            bold=True,
            align=PP_ALIGN.LEFT,
        )
        for column_index, column_name in enumerate(columns, start=1):
            value = value_map.get((row_name, column_name), "")
            table.cell(row_index, column_index).text = value
            cell_fill = row_fill
            cell_text = str(styles.get("body_text", "#1F2937"))
            is_code_cell = value in {"R", "A", "C", "I"}
            if is_code_cell:
                highlight = _proposal_highlight(styles, value)
                cell_fill = str(highlight.get("fill", cell_fill))
                cell_text = str(highlight.get("text", cell_text))
            _style_table_cell(
                table.cell(row_index, column_index),
                fill=cell_fill,
                text=cell_text,
                bold=is_code_cell,
                align=PP_ALIGN.CENTER if is_code_cell else PP_ALIGN.LEFT,
            )


def _draw_card_artifact(
    slide: Any,
    elements: list[dict[str, Any]],
    theme: Mapping[str, Any],
    content_box: Mapping[str, float],
) -> None:
    cards = [item for item in elements if item.get("shape") == "card"]
    card_count = max(len(cards), 1)
    columns = 2 if card_count > 1 else 1
    rows = (card_count + columns - 1) // columns
    gap_x = int(Inches(0.25))
    gap_y = int(Inches(0.22))
    content_left = _box_metric(content_box, "left")
    content_top = _box_metric(content_box, "top")
    content_width = _box_metric(content_box, "width")
    content_height = _box_metric(content_box, "height")
    card_width = (content_width - gap_x * max(columns - 1, 0)) // columns
    card_height = (content_height - gap_y * max(rows - 1, 0)) // rows
    styles = _proposal_theme(theme, "card")

    for index, card in enumerate(cards):
        row = index // columns
        column = index % columns
        left = content_left + column * (card_width + gap_x)
        top = content_top + row * (card_height + gap_y)
        shape = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
            left,
            top,
            card_width,
            card_height,
        )
        shape.fill.solid()
        shape.fill.fore_color.rgb = _rgb(str(styles.get("fill", "#FBFCFE")))
        shape.line.color.rgb = _rgb(str(styles.get("border", "#CAD6E4")))
        shape.line.width = Pt(1.2)
        shape.shadow.inherit = False

        accent_height = int(Inches(0.18))
        accent = slide.shapes.add_shape(
            MSO_AUTO_SHAPE_TYPE.RECTANGLE,
            left,
            top,
            card_width,
            accent_height,
        )
        accent.fill.solid()
        accent.fill.fore_color.rgb = _rgb(str(styles.get("accent_fill", _theme_color(theme, "accent", "#2F5D9F"))))
        accent.line.fill.background()

        title_box = slide.shapes.add_textbox(
            left + int(Inches(0.2)),
            top + accent_height + int(Inches(0.12)),
            card_width - int(Inches(0.4)),
            int(Inches(0.42)),
        )
        title_frame = title_box.text_frame
        title_frame.clear()
        title_frame.word_wrap = True
        title = title_frame.paragraphs[0]
        title.text = str(card.get("title", ""))
        title.font.size = Pt(15)
        title.font.bold = True
        title.font.color.rgb = _rgb(str(styles.get("title_text", "#173155")))

        body_lines = [str(line) for line in card.get("body", [])]
        meta_lines = [line for line in body_lines if line.lower().startswith("owner:")]
        detail_lines = [line for line in body_lines if line not in meta_lines]

        meta_top = top + accent_height + int(Inches(0.58))
        if meta_lines:
            meta_text = meta_lines[0].split(":", maxsplit=1)[1].strip() if ":" in meta_lines[0] else meta_lines[0]
            pill = slide.shapes.add_shape(
                MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
                left + int(Inches(0.2)),
                meta_top,
                int(Inches(1.55)),
                int(Inches(0.34)),
            )
            pill.fill.solid()
            pill.fill.fore_color.rgb = _rgb(str(styles.get("meta_fill", "#EAF1FB")))
            pill.line.fill.background()
            pill_frame = pill.text_frame
            pill_frame.clear()
            pill_paragraph = pill_frame.paragraphs[0]
            pill_paragraph.text = f"Owner  {meta_text}"
            pill_paragraph.font.size = Pt(9)
            pill_paragraph.font.bold = True
            pill_paragraph.font.color.rgb = _rgb(str(styles.get("meta_text", "#23406E")))
            pill_paragraph.alignment = PP_ALIGN.CENTER
            details_top = meta_top + int(Inches(0.46))
        else:
            details_top = meta_top

        body_box = slide.shapes.add_textbox(
            left + int(Inches(0.2)),
            details_top,
            card_width - int(Inches(0.4)),
            card_height - (details_top - top) - int(Inches(0.18)),
        )
        body_frame = body_box.text_frame
        body_frame.clear()
        body_frame.word_wrap = True
        for index, body_line in enumerate(detail_lines):
            paragraph = body_frame.paragraphs[0] if index == 0 else body_frame.add_paragraph()
            _set_card_paragraph(paragraph, body_line, styles)


def _layout_nodes(
    elements: list[dict[str, Any]], content_box: Mapping[str, float]
) -> dict[str, dict[str, int]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    layer_order: list[str] = []
    for element in elements:
        layer = str(element.get("layer", "Unspecified"))
        if layer not in grouped:
            layer_order.append(layer)
        grouped[layer].append(element)

    layer_count = max(len(layer_order), 1)
    content_left = _box_metric(content_box, "left")
    content_top = _box_metric(content_box, "top")
    content_width = _box_metric(content_box, "width")
    content_height = _box_metric(content_box, "height")
    layer_gap = content_height // layer_count
    layout: dict[str, dict[str, int]] = {}

    for layer_index, layer in enumerate(layer_order):
        layer_elements = grouped[layer]
        node_count = max(len(layer_elements), 1)
        label_top = content_top + (layer_index * layer_gap)
        label_box = {
            "left": content_left,
            "top": label_top,
            "width": int(Inches(1.65)),
            "height": int(Inches(0.23)),
            "is_layer_label": 1,
        }
        layout[f"__layer__::{layer}"] = label_box

        node_top = label_top + int(Inches(0.28))
        usable_width = content_width - int(Inches(1.95))
        node_width = min(int(Inches(2.15)), usable_width // node_count - int(Inches(0.12)))
        total_width = node_width * node_count
        if node_count > 1:
            gap = (usable_width - total_width) // (node_count - 1)
        else:
            gap = 0
        start_left = content_left + int(Inches(1.82))
        node_height = int(Inches(1.02))

        for node_index, element in enumerate(layer_elements):
            left = start_left + node_index * (node_width + gap)
            layout[str(element.get("label", ""))] = {
                "left": left,
                "top": node_top,
                "width": node_width,
                "height": node_height,
            }

    return layout


def _draw_node(
    slide: Any, element: Mapping[str, Any], box: Mapping[str, int], theme: Mapping[str, Any]
) -> None:
    shape_type = NODE_SHAPES.get(str(element.get("shape")), MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE)
    proposal_c4 = _proposal_theme(theme, "c4")
    shape = slide.shapes.add_shape(
        shape_type,
        box["left"],
        box["top"],
        box["width"],
        box["height"],
    )
    style = element.get("style", {}) if isinstance(element.get("style"), Mapping) else {}
    fill = str(style.get("fill", theme.get("background", "#FFFFFF")))
    stroke = str(style.get("stroke", theme.get("accent", "#2F5D9F")))
    text_color = str(style.get("text", theme.get("text", "#1F1F1F")))
    shape.fill.solid()
    shape.fill.fore_color.rgb = _rgb(fill)
    shape.line.color.rgb = _rgb(stroke)
    shape.line.width = Pt(1.4)

    band = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.RECTANGLE,
        box["left"],
        box["top"],
        box["width"],
        int(Inches(0.13)),
    )
    band.fill.solid()
    band.fill.fore_color.rgb = _rgb(stroke)
    band.line.fill.background()

    c4_type = str(element.get("c4_type", "")).replace("_", " ").upper()
    if c4_type:
        badge_width = _badge_width(c4_type, minimum=Inches(0.72), maximum=Inches(1.15))
        _draw_badge(
            slide,
            c4_type,
            box["left"] + box["width"] - badge_width - int(Inches(0.1)),
            box["top"] + int(Inches(0.05)),
            badge_width,
            int(Inches(0.2)),
            fill=str(proposal_c4.get("badge_fill", "#FFFFFF")),
            text_color=stroke,
            font_size=7.3,
            bold=True,
        )

    title_box = slide.shapes.add_textbox(
        box["left"] + int(Inches(0.12)),
        box["top"] + int(Inches(0.16)),
        box["width"] - int(Inches(0.24)),
        int(Inches(0.28)),
    )
    title_frame = title_box.text_frame
    title_frame.clear()
    title_frame.word_wrap = True
    name_paragraph = title_frame.paragraphs[0]
    name_paragraph.text = str(element.get("label", ""))
    name_paragraph.alignment = PP_ALIGN.LEFT
    name_paragraph.font.bold = True
    name_paragraph.font.size = Pt(10.2)
    name_paragraph.font.color.rgb = _rgb(text_color)

    detail_box = slide.shapes.add_textbox(
        box["left"] + int(Inches(0.12)),
        box["top"] + int(Inches(0.46)),
        box["width"] - int(Inches(0.24)),
        box["height"] - int(Inches(0.52)),
    )
    detail_frame = detail_box.text_frame
    detail_frame.clear()
    detail_frame.word_wrap = True
    if element.get("technology"):
        technology = detail_frame.paragraphs[0]
        technology.text = str(element.get("technology"))
        technology.alignment = PP_ALIGN.LEFT
        technology.font.bold = True
        technology.font.size = Pt(7.5)
        technology.font.color.rgb = _rgb(stroke)
    if element.get("description"):
        detail = detail_frame.add_paragraph() if element.get("technology") else detail_frame.paragraphs[0]
        detail.text = str(element.get("description"))
        detail.alignment = PP_ALIGN.LEFT
        detail.font.size = Pt(7.2)
        detail.font.color.rgb = _rgb(text_color)


def _draw_layer_label(
    slide: Any, layer_name: str, box: Mapping[str, int], theme: Mapping[str, Any]
) -> None:
    proposal_c4 = _proposal_theme(theme, "c4")
    _draw_badge(
        slide,
        layer_name,
        box["left"],
        box["top"],
        _badge_width(layer_name, minimum=Inches(1.4), maximum=Inches(2.05)),
        box["height"],
        fill=str(proposal_c4.get("layer_fill", "#EAF1FB")),
        text_color=str(proposal_c4.get("layer_text", "#23406E")),
        font_size=9.2,
        bold=True,
        line_color=str(proposal_c4.get("layer_border", "#D7DFEA")),
    )


def _draw_boundary(
    slide: Any,
    element: Mapping[str, Any],
    layout: Mapping[str, Mapping[str, int]],
    theme: Mapping[str, Any],
) -> None:
    included = [layout[name] for name in element.get("includes", []) if name in layout]
    if not included:
        return
    left = min(item["left"] for item in included) - int(BOUNDARY_PADDING_X)
    top = min(item["top"] for item in included) - int(BOUNDARY_PADDING_Y)
    right = max(item["left"] + item["width"] for item in included) + int(BOUNDARY_PADDING_X)
    bottom = max(item["top"] + item["height"] for item in included) + int(BOUNDARY_PADDING_Y)
    shape = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.RECTANGLE,
        left,
        top,
        right - left,
        bottom - top,
    )
    shape.fill.solid()
    style = element.get("style", {}) if isinstance(element.get("style"), Mapping) else {}
    proposal_c4 = _proposal_theme(theme, "c4")
    shape.fill.fore_color.rgb = _rgb(str(proposal_c4.get("boundary_fill", "#FBFCFE")))
    shape.line.color.rgb = _rgb(str(style.get("stroke", "#94A3B8")))
    shape.line.width = Pt(1.2)
    dash = BOUNDARY_DASH.get(str(style.get("line", "dashed")))
    if dash is not None:
        shape.line.dash_style = dash
    _draw_badge(
        slide,
        str(element.get("name", "")),
        left + int(Inches(0.14)),
        top - int(Inches(0.12)),
        _badge_width(str(element.get("name", "")), minimum=Inches(1.35), maximum=Inches(2.35)),
        int(Inches(0.24)),
        fill=str(proposal_c4.get("boundary_label_fill", "#23406E")),
        text_color=str(proposal_c4.get("boundary_label_text", "#FFFFFF")),
        font_size=8.5,
        bold=True,
    )


def _draw_connector(
    slide: Any,
    element: Mapping[str, Any],
    layout: Mapping[str, Mapping[str, int]],
    theme: Mapping[str, Any],
) -> None:
    path = element.get("path", [])
    if not isinstance(path, list) or len(path) < 2:
        return
    source = layout.get(str(path[0]))
    target = layout.get(str(path[1]))
    if source is None or target is None:
        return
    begin_x = source["left"] + source["width"]
    begin_y = source["top"] + source["height"] // 2
    end_x = target["left"]
    end_y = target["top"] + target["height"] // 2
    connector = slide.shapes.add_connector(
        MSO_CONNECTOR_TYPE.STRAIGHT,
        begin_x,
        begin_y,
        end_x,
        end_y,
    )
    style = element.get("style", {}) if isinstance(element.get("style"), Mapping) else {}
    proposal_c4 = _proposal_theme(theme, "c4")
    connector.line.color.rgb = _rgb(str(style.get("stroke", theme.get("muted", "#6B7280"))))
    connector.line.width = Pt(1.5)
    label = str(element.get("label") or element.get("relationship") or "")
    if element.get("technology"):
        label = f"{label} · {element.get('technology')}" if label else str(element.get("technology"))
    if label:
        chip_width = _badge_width(label, minimum=Inches(1.1), maximum=Inches(2.05))
        _draw_badge(
            slide,
            label,
            min(begin_x, end_x) + abs(end_x - begin_x) // 2 - chip_width // 2,
            min(begin_y, end_y) - int(Inches(0.18)),
            chip_width,
            int(Inches(0.26)),
            fill=str(proposal_c4.get("connector_fill", "#F8FAFC")),
            text_color=str(proposal_c4.get("connector_text", style.get("text", theme.get("muted", "#6B7280")))),
            font_size=8,
            bold=True,
            line_color=str(proposal_c4.get("connector_border", "#CBD5E1")),
        )


def _draw_labeled_path(
    slide: Any,
    element: Mapping[str, Any],
    layout: Mapping[str, Mapping[str, int]],
    theme: Mapping[str, Any],
) -> None:
    path = element.get("path", [])
    if not isinstance(path, list) or len(path) < 2:
        return
    for index in range(len(path) - 1):
        source = layout.get(str(path[index]))
        target = layout.get(str(path[index + 1]))
        if source is None or target is None:
            continue
        begin_x = source["left"] + source["width"] - int(Inches(0.1))
        begin_y = source["top"] + source["height"] // 2
        end_x = target["left"] + target["width"] - int(Inches(0.1))
        end_y = target["top"] + target["height"] // 2
        connector = slide.shapes.add_connector(
            MSO_CONNECTOR_TYPE.STRAIGHT,
            begin_x,
            begin_y,
            end_x,
            end_y,
        )
        styles = _proposal_theme(theme, "governance")
        connector.line.color.rgb = _rgb(str(styles.get("header_fill", _theme_color(theme, "muted", "#6B7280"))))
        connector.line.width = Pt(1.8)
        if index == 0 and element.get("label"):
            text = str(element.get("label", ""))
            chip_width = _badge_width(text, minimum=Inches(1.05), maximum=Inches(1.7))
            _draw_badge(
                slide,
                text,
                min(begin_x, end_x) + abs(end_x - begin_x) // 2 - chip_width // 2,
                min(begin_y, end_y) - int(Inches(0.16)),
                chip_width,
                int(Inches(0.28)),
                fill=str(styles.get("connector_fill", "#23406E")),
                text_color=str(styles.get("connector_text", "#FFFFFF")),
                font_size=8.5,
                bold=True,
            )


def _matrix_values(
    assignments: list[dict[str, Any]], columns: list[str]
) -> dict[tuple[str, str], str]:
    values: dict[tuple[str, str], str] = {}
    for assignment in assignments:
        row_name = str(assignment.get("activity", ""))
        for column_name in columns:
            if column_name == assignment.get("role"):
                values[(row_name, column_name)] = str(assignment.get("code", ""))
                continue
            key = column_name.lower()
            if key in assignment:
                values[(row_name, column_name)] = str(assignment.get(key, ""))
    return values


def _style_table_cell(
    cell: Any, *, fill: str, text: str, bold: bool, align: PP_ALIGN
) -> None:
    cell.fill.solid()
    cell.fill.fore_color.rgb = _rgb(fill)
    frame = cell.text_frame
    frame.word_wrap = True
    for paragraph in frame.paragraphs:
        paragraph.font.size = Pt(10)
        paragraph.font.bold = bold
        paragraph.font.color.rgb = _rgb(text)
        paragraph.alignment = align
    frame.vertical_anchor = MSO_ANCHOR.MIDDLE


def _theme_color(theme: Mapping[str, Any], key: str, fallback: str) -> str:
    value = theme.get(key, fallback)
    return str(value)


def _proposal_theme(theme: Mapping[str, Any], section: str) -> Mapping[str, Any]:
    proposal = theme.get("proposal", {})
    if not isinstance(proposal, Mapping):
        return {}
    section_theme = proposal.get(section, {})
    if not isinstance(section_theme, Mapping):
        return {}
    return section_theme


def _proposal_highlight(styles: Mapping[str, Any], code: str) -> Mapping[str, Any]:
    highlight = styles.get("highlight", {})
    if not isinstance(highlight, Mapping):
        return {}
    code_style = highlight.get(code, {})
    if not isinstance(code_style, Mapping):
        return {}
    return code_style


def _banded_fill(styles: Mapping[str, Any], row_index: int) -> str:
    if row_index % 2 == 0:
        return str(styles.get("band_fill", "#F6F8FC"))
    return str(styles.get("body_fill", "#FFFFFF"))


def _set_matrix_column_widths(table: Any, column_count: int, content_width: int) -> None:
    first_col_width = Inches(2.9)
    remaining_width = content_width - int(first_col_width)
    each_width = remaining_width // max(column_count, 1)
    table.columns[0].width = first_col_width
    for index in range(1, column_count + 1):
        table.columns[index].width = each_width


def _set_card_paragraph(paragraph: Any, body_line: str, styles: Mapping[str, Any]) -> None:
    paragraph.font.size = Pt(10)
    paragraph.font.color.rgb = _rgb(str(styles.get("body_text", "#334155")))
    if ":" in body_line:
        label, value = body_line.split(":", maxsplit=1)
        paragraph.text = ""
        label_run = paragraph.add_run()
        label_run.text = f"{label.strip()}: "
        label_run.font.size = Pt(10)
        label_run.font.bold = True
        label_run.font.color.rgb = _rgb(str(styles.get("label_text", "#23406E")))
        value_run = paragraph.add_run()
        value_run.text = value.strip()
        value_run.font.size = Pt(10)
        value_run.font.color.rgb = _rgb(str(styles.get("body_text", "#334155")))
        return
    paragraph.text = body_line


def _draw_governance_lane_body(
    slide: Any,
    lane: Mapping[str, Any],
    styles: Mapping[str, Any],
    left: int,
    top: int,
    width: int,
    header_width: int,
    lane_height: int,
) -> None:
    body_left = left + header_width + int(Inches(0.18))
    body_width = width - header_width - int(Inches(0.3))
    forums = lane.get("forums", []) if isinstance(lane.get("forums"), list) else []
    responsibilities = (
        lane.get("responsibilities", [])
        if isinstance(lane.get("responsibilities"), list)
        else lane.get("items", [])
    )

    if forums:
        x_cursor = body_left
        y_cursor = top + int(Inches(0.12))
        for forum in forums:
            badge_width = _badge_width(str(forum), minimum=Inches(1.15), maximum=Inches(2.05))
            _draw_badge(
                slide,
                str(forum),
                x_cursor,
                y_cursor,
                badge_width,
                int(Inches(0.25)),
                fill=str(styles.get("forum_fill", "#EAF1FB")),
                text_color=str(styles.get("forum_text", "#23406E")),
                font_size=8.2,
                bold=True,
            )
            x_cursor += badge_width + int(Inches(0.08))

    body = slide.shapes.add_textbox(
        body_left,
        top + int(Inches(0.46)),
        body_width,
        lane_height - int(Inches(0.56)),
    )
    body_frame = body.text_frame
    body_frame.clear()
    body_frame.word_wrap = True
    for index, item_text in enumerate(responsibilities):
        paragraph = body_frame.paragraphs[0] if index == 0 else body_frame.add_paragraph()
        paragraph.text = str(item_text)
        paragraph.font.size = Pt(9.4)
        paragraph.font.color.rgb = _rgb(str(styles.get("responsibility_text", "#334155")))
        paragraph.bullet = True


def _draw_badge(
    slide: Any,
    label: str,
    left: int,
    top: int,
    width: int,
    height: int,
    *,
    fill: str,
    text_color: str,
    font_size: float,
    bold: bool,
    line_color: str | None = None,
) -> None:
    shape = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE,
        left,
        top,
        width,
        height,
    )
    shape.fill.solid()
    shape.fill.fore_color.rgb = _rgb(fill)
    if line_color:
        shape.line.color.rgb = _rgb(line_color)
    else:
        shape.line.fill.background()
    frame = shape.text_frame
    frame.clear()
    frame.vertical_anchor = MSO_ANCHOR.MIDDLE
    paragraph = frame.paragraphs[0]
    paragraph.text = label
    paragraph.alignment = PP_ALIGN.CENTER
    paragraph.font.size = Pt(font_size)
    paragraph.font.bold = bold
    paragraph.font.color.rgb = _rgb(text_color)


def _badge_width(label: str, *, minimum: int, maximum: int) -> int:
    estimated = int(Inches(0.16)) + len(label) * int(Inches(0.055))
    return max(minimum, min(estimated, maximum))


def _rgb(value: str) -> RGBColor:
    normalized = value.strip().lstrip("#")
    if len(normalized) != 6:
        normalized = "1F1F1F"
    return RGBColor.from_string(normalized.upper())


def _box_metric(box: Mapping[str, float], key: str) -> int:
    return inches_to_emu(float(box.get(key, 0.0)))
