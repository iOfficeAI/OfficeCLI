from __future__ import annotations

from pathlib import Path


def read_template_metadata(template_path: Path) -> dict[str, object]:
    return {
        "template_path": str(template_path),
        "exists": template_path.exists(),
        "note": "Template inspection is a placeholder until PPTX integration is added.",
    }
