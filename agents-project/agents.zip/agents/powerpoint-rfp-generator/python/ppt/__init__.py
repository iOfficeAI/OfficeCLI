"""PowerPoint output helpers."""
