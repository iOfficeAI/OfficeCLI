from __future__ import annotations

from typing import Any, Mapping

from models.visual_spec import VisualSpec


def build_slide(
    spec: VisualSpec, rendered_visual: Mapping[str, Any], theme: Mapping[str, Any]
) -> dict[str, Any]:
    return {
        "title": spec.slide_title,
        "purpose": spec.purpose,
        "artifact_id": spec.id,
        "artifact_type": spec.artifact_type,
        "theme": dict(theme),
        "content": rendered_visual,
    }
