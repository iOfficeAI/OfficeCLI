from __future__ import annotations

from typing import Any, Sequence


def _copy_style(style: dict[str, Any] | None) -> dict[str, Any] | None:
    if style is None:
        return None
    return dict(style)


def chevron_phase(
    index: int, title: str, subtitle: str | None, bullets: Sequence[str]
) -> dict[str, Any]:
    return {
        "shape": "chevron-phase",
        "index": index,
        "title": title,
        "subtitle": subtitle,
        "bullets": list(bullets),
    }


def swimlane(
    index: int,
    title: str,
    items: Sequence[str],
    *,
    forums: Sequence[str] | None = None,
    responsibilities: Sequence[str] | None = None,
) -> dict[str, Any]:
    return {
        "shape": "swimlane",
        "index": index,
        "title": title,
        "items": list(items),
        "forums": list(forums) if forums is not None else [],
        "responsibilities": list(responsibilities) if responsibilities is not None else [],
    }


def matrix_table(
    columns: Sequence[str], rows: Sequence[str], assignments: Sequence[dict[str, Any]]
) -> dict[str, Any]:
    return {
        "shape": "matrix-table",
        "columns": list(columns),
        "rows": list(rows),
        "assignments": list(assignments),
    }


def card(title: str, body: Sequence[str]) -> dict[str, Any]:
    return {"shape": "card", "title": title, "body": list(body)}


def node(
    label: str,
    layer: str,
    *,
    c4_type: str | None = None,
    description: str | None = None,
    technology: str | None = None,
    boundary: str | None = None,
    tags: Sequence[str] | None = None,
    style: dict[str, Any] | None = None,
) -> dict[str, Any]:
    shape_name = "node"
    if c4_type:
        shape_name = f"c4-{c4_type.replace('_', '-')}"
    element = {
        "shape": shape_name,
        "base_shape": "node",
        "label": label,
        "layer": layer,
    }
    if c4_type:
        element["c4_type"] = c4_type
    if description:
        element["description"] = description
    if technology:
        element["technology"] = technology
    if boundary:
        element["boundary"] = boundary
    if tags:
        element["tags"] = list(tags)
    copied_style = _copy_style(style)
    if copied_style:
        element["style"] = copied_style
    return element


def connector(
    path: Sequence[str],
    label: str | None = None,
    *,
    technology: str | None = None,
    protocol: str | None = None,
    relationship: str | None = None,
    style: dict[str, Any] | None = None,
) -> dict[str, Any]:
    shape_name = "connector"
    if relationship or technology or protocol:
        shape_name = "c4-relationship"
    element = {
        "shape": shape_name,
        "base_shape": "connector",
        "path": list(path),
        "label": label,
    }
    if technology:
        element["technology"] = technology
    if protocol:
        element["protocol"] = protocol
    if relationship:
        element["relationship"] = relationship
    copied_style = _copy_style(style)
    if copied_style:
        element["style"] = copied_style
    return element


def boundary(
    name: str,
    includes: Sequence[str],
    *,
    boundary_type: str | None = None,
    style: dict[str, Any] | None = None,
) -> dict[str, Any]:
    shape_name = "boundary"
    if boundary_type:
        shape_name = f"c4-{boundary_type}-boundary"
    element = {
        "shape": shape_name,
        "base_shape": "boundary",
        "name": name,
        "includes": list(includes),
    }
    if boundary_type:
        element["boundary_type"] = boundary_type
    copied_style = _copy_style(style)
    if copied_style:
        element["style"] = copied_style
    return element
