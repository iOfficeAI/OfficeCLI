from __future__ import annotations

from pathlib import Path
from typing import Any

from pptx import Presentation

from themes.theme_utils import emu_to_inches, normalize_hex_color


def fingerprint_presentation(pptx_path: Path) -> dict[str, Any]:
    presentation = Presentation(str(pptx_path))
    if not presentation.slides:
        raise ValueError(f"No slides found in {pptx_path}")

    slide = presentation.slides[-1]
    shape_types: dict[str, int] = {}
    auto_shape_types: dict[str, int] = {}
    text_boxes: list[dict[str, Any]] = []
    table_metrics: list[dict[str, int]] = []
    fill_colors: set[str] = set()
    line_colors: set[str] = set()
    text_colors: set[str] = set()
    total_characters = 0
    total_paragraphs = 0
    occupied_area = 0.0

    for shape in slide.shapes:
        shape_type = getattr(shape.shape_type, "name", str(shape.shape_type))
        shape_types[shape_type] = shape_types.get(shape_type, 0) + 1
        occupied_area += emu_to_inches(shape.width) * emu_to_inches(shape.height)

        auto_shape_name = _auto_shape_name(shape)
        if auto_shape_name is not None:
            auto_shape_types[auto_shape_name] = auto_shape_types.get(auto_shape_name, 0) + 1

        fill_color = _shape_fill_color(shape)
        if fill_color:
            fill_colors.add(fill_color)
        line_color = _line_color(shape)
        if line_color:
            line_colors.add(line_color)

        if getattr(shape, "has_text_frame", False):
            info = _text_frame_info(shape.text_frame)
            if info["text"]:
                info.update(
                    {
                        "left": emu_to_inches(shape.left),
                        "top": emu_to_inches(shape.top),
                        "width": emu_to_inches(shape.width),
                        "height": emu_to_inches(shape.height),
                    }
                )
                text_boxes.append(info)
                total_characters += int(info["character_count"])
                total_paragraphs += int(info["paragraph_count"])
                text_colors.update(info["colors"])

        if getattr(shape, "has_table", False):
            table = shape.table
            table_metrics.append({"rows": len(table.rows), "cols": len(table.columns)})
            for row in table.rows:
                for cell in row.cells:
                    info = _text_frame_info(cell.text_frame)
                    total_characters += int(info["character_count"])
                    total_paragraphs += int(info["paragraph_count"])
                    text_colors.update(info["colors"])

    slide_area = emu_to_inches(presentation.slide_width) * emu_to_inches(
        presentation.slide_height
    )
    coverage_ratio = occupied_area / slide_area if slide_area else 0.0
    return {
        "slide_width": round(emu_to_inches(presentation.slide_width), 3),
        "slide_height": round(emu_to_inches(presentation.slide_height), 3),
        "shape_types": shape_types,
        "auto_shape_types": auto_shape_types,
        "text_boxes": text_boxes,
        "table_metrics": table_metrics,
        "text_character_count": total_characters,
        "text_paragraph_count": total_paragraphs,
        "coverage_ratio": round(coverage_ratio, 3),
        "fill_colors": sorted(fill_colors),
        "line_colors": sorted(line_colors),
        "text_colors": sorted(text_colors),
    }


def _text_frame_info(text_frame: Any) -> dict[str, Any]:
    paragraphs = [paragraph for paragraph in text_frame.paragraphs if paragraph.text.strip()]
    colors: set[str] = set()
    font_sizes: list[float] = []
    bold_values: list[bool] = []

    for paragraph in paragraphs:
        paragraph_size = _font_size(paragraph.font)
        paragraph_color = _font_color(paragraph.font)
        if paragraph_size is not None:
            font_sizes.append(paragraph_size)
        if paragraph_color:
            colors.add(paragraph_color)
        if paragraph.font.bold is not None:
            bold_values.append(bool(paragraph.font.bold))
        for run in paragraph.runs:
            run_size = _font_size(run.font)
            run_color = _font_color(run.font)
            if run_size is not None:
                font_sizes.append(run_size)
            if run_color:
                colors.add(run_color)
            if run.font.bold is not None:
                bold_values.append(bool(run.font.bold))

    text = "\n".join(paragraph.text.strip() for paragraph in paragraphs)
    return {
        "text": text,
        "paragraph_count": len(paragraphs),
        "character_count": len(text.replace("\n", "")),
        "max_font_size": max(font_sizes) if font_sizes else None,
        "min_font_size": min(font_sizes) if font_sizes else None,
        "bold": True if bold_values and all(bold_values) else False,
        "colors": sorted(colors),
    }


def _shape_fill_color(shape: Any) -> str | None:
    try:
        return _rgb_string(shape.fill.fore_color)
    except (AttributeError, TypeError, ValueError):
        return None


def _line_color(shape: Any) -> str | None:
    line = getattr(shape, "line", None)
    if line is None:
        return None
    try:
        return _rgb_string(line.color)
    except (AttributeError, TypeError, ValueError):
        return None


def _font_size(font: Any) -> float | None:
    size = getattr(font, "size", None)
    if size is None:
        return None
    return float(size.pt)


def _font_color(font: Any) -> str | None:
    color = getattr(font, "color", None)
    if color is None:
        return None
    return _rgb_string(color)


def _rgb_string(color_format: Any) -> str | None:
    try:
        rgb = getattr(color_format, "rgb", None)
    except (AttributeError, TypeError, ValueError):
        return None
    if rgb is None:
        return None
    return normalize_hex_color(str(rgb))


def _auto_shape_name(shape: Any) -> str | None:
    try:
        auto_shape_type = shape.auto_shape_type
    except (AttributeError, TypeError, ValueError):
        return None
    return getattr(auto_shape_type, "name", str(auto_shape_type))
