---
name: powerpoint-rfp-generator
description: "Use when you need to render a typed RFP visual spec into deterministic slide JSON and an optional single-slide PowerPoint artifact, then validate the rendered result against the approved design profile."
workflow_role: worker
workflow_binding: contract_only
primary_outputs:
  - rendered PowerPoint visual artifact
  - render report
default_next:
  success: rfp-submission-packager
  blocked: template or asset repair
  needs_more_evidence: missing visual spec detail or formatting rule
  fail: rerun after render-path repair
---

# Purpose

Generate one deterministic PowerPoint-ready visual artifact from an approved typed spec. This node turns a single visual specification into rendered JSON, can materialize that visual as a single-slide `.pptx`, validates the rendered result against the approved design profile when possible, and reports what was produced. It does not assemble a full submission deck from multiple specs or decide whether PowerPoint is the right submission format.

## Workflow role

- Role: `worker`
- Binding: `contract_only`
- Goal gate: no
- Human approval node: no
- Typical predecessors: `rfp-submission-packager`
- Typical successors: `rfp-submission-packager`

## Inputs

### Required

- `rfp/<RFP-ID>/visuals/specs/<NN>-<artifact-id>.yaml`

### Optional

- approved response draft
- visual / exhibit brief
- `rfp/<RFP-ID>/visuals/visual-manifest.yaml`
- `rfp/<RFP-ID>/visuals/design-profile.yaml`
- PowerPoint template
- approved design exemplar deck or approved design snapshots
- claims register
- approved images and diagrams
- output filename rule
- explicit render-report or style-validation output paths

## Preconditions

1. Typed visual spec exists and is readable.
2. The typed visual spec uses an artifact type supported by `powerpoint-rfp-generator/artifacts/catalog.yaml`.
3. Template file exists and is readable when a `.pptx` output is requested.
4. Response content is already approved for packaging before rendering is claimed as final.

## Procedure

1. Verify the typed visual spec and any explicit output paths exist or can be created.
2. Load `powerpoint-rfp-generator/artifacts/catalog.yaml` and validate the typed visual spec against the supported artifact type and schema.
3. Resolve the approved design profile from the explicit input or from `style.design_profile` in the spec.
4. Use the deterministic Python renderer layer under `powerpoint-rfp-generator/python/` to build a single rendered slide payload that preserves the approved artifact structure.
5. Write the rendered JSON payload under `rfp/<RFP-ID>/visuals/rendered/` or another caller-specified path.
6. If a `.pptx` output was requested, materialize the rendered visual as a single-slide PowerPoint artifact using the provided template when available.
7. If a `.pptx` file was written and a design profile exists, run post-render validation and write the style-validation JSON artifact.
8. Write the JSON render report and surface any warnings or validation failures explicitly.
9. Do not claim that a full submission deck, package-level PowerPoint deliverable, or PDF exists unless another step assembled or exported it in this run.

## Output Contract

### Artifacts

- `rfp/<RFP-ID>/visuals/rendered/<NN>-<artifact-id>.json`
- optional `rfp/<RFP-ID>/visuals/rendered/<NN>-<artifact-id>.pptx`
- `rfp/<RFP-ID>/visuals/rendered/<NN>-<artifact-id>.report.json` or caller-routed JSON report path
- optional `rfp/<RFP-ID>/visuals/rendered/<NN>-<artifact-id>.style-validation.json` or caller-routed JSON validation path

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` - the typed visual artifact was rendered successfully and any requested validation completed
- `blocked` - a required template, asset, or packaging rule is missing
- `needs_more_evidence` - the visual spec or formatting expectations are too incomplete to render safely
- `fail` - rendering failed or validation failed after output generation

## Done Criteria

1. Rendered JSON payload exists.
2. Render report exists.
3. If a `.pptx` output was requested, the PowerPoint visual artifact exists.
4. The rendered artifact preserved the typed structure rather than collapsing into generic bullets.
5. When a design profile exists and a `.pptx` file was written, post-render drift was checked explicitly.
6. Package-level deck or PDF claims are made only when another step actually produced them in this run.

## Evidence Requirements

- Claim: the typed visual artifact was rendered -> proof: rendered JSON payload and render report were produced in this run
- Claim: the PowerPoint visual artifact exists -> proof: output `.pptx` file was produced in this run when requested
- Claim: approved visual intent was carried through -> proof: typed visual spec, design profile, and produced artifact were checked in this run
- Claim: a typed artifact was rendered deterministically -> proof: visual spec and rendered payload were produced in this run
- Claim: the rendered slide still looks like the approved design -> proof: post-render design-profile comparison was executed in this run

## Failure Routing

- missing template or approved content -> `blocked`
- incomplete visual spec or formatting brief -> `needs_more_evidence`
- missing design profile for a style-critical visual -> `needs_more_evidence`
- unsupported artifact type or invalid visual spec -> `fail`
- render produced an invalid visual artifact -> `fail`

## Escalation Rules

1. Escalate when the template lacks the layout or geometry needed for the requested visual artifact.
2. Escalate when the typed visual spec is too underspecified to render the required structure faithfully.
3. Escalate when graphical assets are requested but not supplied or approved.
4. Escalate when a requested visual cannot be expressed with the supported artifact catalog without material information loss.

## Never Do

- never hardcode branding that should come from the template
- never guess visual structure when the typed spec is incomplete
- never silently downgrade a required typed visual to generic bullets
- never flatten an explicit visual brief into bullet-only slides without warning
- never claim a full submission deck or PDF when only a per-visual artifact was rendered
