#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Callable

from sdlc_common import (
    build_report,
    emit_report,
    ensure_string_list,
    exit_code_for,
    is_iso_timestamp,
    load_yaml,
)


Validator = Callable[[dict[str, Any], Path], tuple[list[str], list[str]]]

STANDARD_BLOCKING_REVIEWERS = {
    "code-reviewer-strict",
    "code-minimality-reviewer",
    "unit-test-minimality-reviewer",
    "specs-minimality-reviewer",
    "gherkin-minimality-reviewer",
    "petition-translator-reviewer",
}
STANDARD_NON_BLOCKING_REVIEWERS = {
    "specs-reviewer",
    "bdd-test-coverage-auditor",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Validate machine-readable review artifacts."
    )
    parser.add_argument("--json", action="store_true", help="Emit JSON output.")
    parser.add_argument("--root", default=".", help="Project root.")
    parser.add_argument(
        "--strict-warnings", action="store_true", help="Treat warnings as failures."
    )
    return parser.parse_args()


def validate_findings_list(
    payload: dict[str, Any],
    path: Path,
    required_fields: tuple[str, ...],
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    findings = payload.get("findings")
    if not isinstance(findings, list):
        errors.append(f"{path}: `findings` must be a list.")
        return errors, warnings
    for index, item in enumerate(findings):
        if not isinstance(item, dict):
            errors.append(f"{path}: findings[{index}] must be a mapping.")
            continue
        for field in required_fields:
            if field not in item or not str(item[field]).strip():
                errors.append(f"{path}: findings[{index}].{field} is required.")
    return errors, warnings


def validate_standard_review(
    payload: dict[str, Any],
    path: Path,
    *,
    allowed_verdicts: set[str],
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    for key in ("petition_id", "agent", "verdict", "timestamp"):
        if key not in payload or not str(payload[key]).strip():
            errors.append(f"{path}: `{key}` is required.")
    if payload.get("verdict") not in allowed_verdicts:
        errors.append(
            f"{path}: `verdict` must be one of {', '.join(sorted(allowed_verdicts))}."
        )
    if not is_iso_timestamp(payload.get("timestamp")):
        errors.append(f"{path}: `timestamp` must be ISO 8601.")
    for key in ("keep_count", "discard_count", "escalate_count"):
        if not isinstance(payload.get(key), int):
            errors.append(f"{path}: `{key}` must be an integer.")

    finding_errors, finding_warnings = validate_findings_list(
        payload, path, ("id", "decision", "justification")
    )
    errors.extend(finding_errors)
    warnings.extend(finding_warnings)
    findings = payload.get("findings", [])
    for index, item in enumerate(findings if isinstance(findings, list) else []):
        decision = item.get("decision")
        if decision not in {"KEEP", "DISCARD", "ESCALATE"}:
            errors.append(
                f"{path}: findings[{index}].decision must be KEEP, DISCARD, or ESCALATE."
            )

    if payload.get("agent") == "code-reviewer-strict" and not isinstance(
        payload.get("quality_score"), int
    ):
        errors.append(
            f"{path}: `quality_score` must be an integer for code-reviewer-strict."
        )
    if payload.get("agent") == "code-reviewer-strict":
        hotspot_errors, hotspot_warnings = validate_hotspot_review(payload, path)
        errors.extend(hotspot_errors)
        warnings.extend(hotspot_warnings)
    return errors, warnings


def validate_hotspot_review(
    payload: dict[str, Any], path: Path
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    hotspots = payload.get("hotspots")
    if hotspots is None:
        return errors, warnings
    if not isinstance(hotspots, list):
        errors.append(f"{path}: `hotspots` must be a list when present.")
        return errors, warnings
    summary = payload.get("hotspot_summary")
    if not isinstance(summary, dict):
        errors.append(f"{path}: `hotspot_summary` must be a mapping when hotspots are present.")
    else:
        for key in ("policy_version", "baseline_ref"):
            if key not in summary or not str(summary[key]).strip():
                errors.append(f"{path}: hotspot_summary.{key} is required.")
        for key in ("blocking_count", "warning_count", "context_count"):
            if not isinstance(summary.get(key), int):
                errors.append(f"{path}: hotspot_summary.{key} must be an integer.")

    for index, item in enumerate(hotspots):
        if not isinstance(item, dict):
            errors.append(f"{path}: hotspots[{index}] must be a mapping.")
            continue
        for key in ("finding_id", "file", "severity", "verdict"):
            if key not in item or not str(item[key]).strip():
                errors.append(f"{path}: hotspots[{index}].{key} is required.")
        if item.get("severity") not in {"blocking", "warning", "context"}:
            errors.append(
                f"{path}: hotspots[{index}].severity must be blocking, warning, or context."
            )
        if item.get("verdict") not in {"BLOCK", "WARN", "INFO"}:
            errors.append(f"{path}: hotspots[{index}].verdict must be BLOCK, WARN, or INFO.")
        reason_codes = item.get("reason_codes")
        if not isinstance(reason_codes, list) or not reason_codes or not all(
            isinstance(code, str) and code.strip() for code in reason_codes
        ):
            errors.append(f"{path}: hotspots[{index}].reason_codes must be a non-empty list.")
        metrics = item.get("metrics")
        if not isinstance(metrics, dict):
            errors.append(f"{path}: hotspots[{index}].metrics must be a mapping.")
        baseline_metrics = item.get("baseline_metrics")
        if baseline_metrics is not None and not isinstance(baseline_metrics, dict):
            errors.append(f"{path}: hotspots[{index}].baseline_metrics must be a mapping or null.")
        if not isinstance(item.get("tb_required"), bool):
            errors.append(f"{path}: hotspots[{index}].tb_required must be boolean.")
        if item.get("confidence") not in {"high", "medium", "low"}:
            errors.append(f"{path}: hotspots[{index}].confidence must be high, medium, or low.")
        if not isinstance(item.get("baseline_available"), bool):
            errors.append(f"{path}: hotspots[{index}].baseline_available must be boolean.")
        worsened_metrics = item.get("worsened_metrics")
        if not isinstance(worsened_metrics, list) or not all(
            isinstance(metric, str) and metric.strip() for metric in worsened_metrics
        ):
            errors.append(
                f"{path}: hotspots[{index}].worsened_metrics must be a list of non-empty strings."
            )
    return errors, warnings


def validate_bdd_test_coverage(
    payload: dict[str, Any], path: Path
) -> tuple[list[str], list[str]]:
    errors, warnings = validate_standard_review(
        payload,
        path,
        allowed_verdicts={"APPROVED", "REJECTED"},
    )

    gaps = payload.get("gaps")
    if not isinstance(gaps, list):
        errors.append(f"{path}: `gaps` must be a list.")
    else:
        for index, item in enumerate(gaps):
            if not isinstance(item, dict):
                errors.append(f"{path}: gaps[{index}] must be a mapping.")
                continue
            if not str(item.get("requirement", "")).strip():
                errors.append(f"{path}: gaps[{index}].requirement is required.")
            if item.get("severity") not in {"critical", "major", "minor"}:
                errors.append(
                    f"{path}: gaps[{index}].severity must be critical, major, or minor."
                )

    overreach = payload.get("overreach")
    if not isinstance(overreach, list):
        errors.append(f"{path}: `overreach` must be a list.")
    else:
        for index, item in enumerate(overreach):
            if not isinstance(item, dict):
                errors.append(f"{path}: overreach[{index}] must be a mapping.")
                continue
            if not str(item.get("test", "")).strip():
                errors.append(f"{path}: overreach[{index}].test is required.")
            if not str(item.get("justification", "")).strip():
                errors.append(
                    f"{path}: overreach[{index}].justification is required."
                )
    return errors, warnings


def validate_contract_or_runtime(
    payload: dict[str, Any], path: Path, *, runtime: bool
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    for key in ("scope", "agent", "mode", "verdict"):
        if key not in payload or not str(payload[key]).strip():
            errors.append(f"{path}: `{key}` is required.")
    if payload.get("mode") not in {"detect", "enforce"}:
        errors.append(f"{path}: `mode` must be detect or enforce.")
    if payload.get("verdict") not in {"PASS", "PASS-WITH-WARNINGS", "FAIL"}:
        errors.append(f"{path}: `verdict` must be PASS, PASS-WITH-WARNINGS, or FAIL.")
    list_field = "surfaces_checked" if runtime else "layers_checked"
    if not ensure_string_list(payload.get(list_field)):
        errors.append(f"{path}: `{list_field}` must be a non-empty list.")
    if runtime:
        if not str(payload.get("startup_path", "")).strip():
            errors.append(f"{path}: `startup_path` is required.")
        if not ensure_string_list(payload.get("services_expected")):
            errors.append(f"{path}: `services_expected` must be a non-empty list.")
        finding_fields = (
            "severity",
            "drift_class",
            "source_surface",
            "target_surface",
            "symbol",
            "description",
            "remediation_target",
        )
    else:
        if not str(payload.get("canonical_source", "")).strip():
            errors.append(f"{path}: `canonical_source` is required.")
        finding_fields = (
            "severity",
            "drift_class",
            "source_layer",
            "target_layer",
            "symbol",
            "description",
            "remediation_target",
        )
    finding_errors, finding_warnings = validate_findings_list(
        payload, path, finding_fields
    )
    errors.extend(finding_errors)
    warnings.extend(finding_warnings)
    return errors, warnings


def validate_c4(payload: dict[str, Any], path: Path) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    for key in ("petition_id", "agent", "mode", "verdict", "timestamp"):
        if key not in payload or not str(payload[key]).strip():
            errors.append(f"{path}: `{key}` is required.")
    if payload.get("mode") not in {"pr", "drift-detection"}:
        errors.append(f"{path}: `mode` must be pr or drift-detection.")
    if payload.get("verdict") not in {
        "PASS",
        "PASS-WITH-WARNINGS",
        "FAIL",
        "NO-DRIFT",
        "DRIFT-DETECTED",
    }:
        errors.append(f"{path}: invalid `verdict` value.")
    if not is_iso_timestamp(payload.get("timestamp")):
        errors.append(f"{path}: `timestamp` must be ISO 8601.")
    for key in ("blocking_count", "warning_count"):
        if not isinstance(payload.get(key), int):
            errors.append(f"{path}: `{key}` must be an integer.")
    finding_errors, finding_warnings = validate_findings_list(
        payload,
        path,
        ("severity", "element", "policy_id", "file", "description", "fix"),
    )
    errors.extend(finding_errors)
    warnings.extend(finding_warnings)
    return errors, warnings


def validate_path_convention(payload: dict[str, Any], path: Path) -> list[str]:
    warnings: list[str] = []
    filename = path.name.lower()
    agent = str(payload.get("agent", "")).lower()
    petition_id = str(payload.get("petition_id", "")).lower()
    if petition_id and petition_id not in filename:
        warnings.append(
            f"{path}: filename does not contain petition_id `{payload['petition_id']}`."
        )
    if agent and agent not in filename and path.parent.name == "reviews":
        warnings.append(
            f"{path}: filename does not contain agent name `{payload['agent']}`."
        )
    return warnings


VALIDATORS: dict[str, Validator] = {
    "code-reviewer-strict": lambda payload, path: validate_standard_review(
        payload, path, allowed_verdicts={"APPROVED", "REJECTED", "BLOCKED"}
    ),
    "code-minimality-reviewer": lambda payload, path: validate_standard_review(
        payload, path, allowed_verdicts={"APPROVED", "REJECTED", "BLOCKED"}
    ),
    "unit-test-minimality-reviewer": lambda payload, path: validate_standard_review(
        payload, path, allowed_verdicts={"APPROVED", "REJECTED", "BLOCKED"}
    ),
    "specs-minimality-reviewer": lambda payload, path: validate_standard_review(
        payload, path, allowed_verdicts={"APPROVED", "REJECTED", "BLOCKED"}
    ),
    "gherkin-minimality-reviewer": lambda payload, path: validate_standard_review(
        payload, path, allowed_verdicts={"APPROVED", "REJECTED", "BLOCKED"}
    ),
    "petition-translator-reviewer": lambda payload, path: validate_standard_review(
        payload, path, allowed_verdicts={"APPROVED", "REJECTED", "BLOCKED"}
    ),
    "specs-reviewer": lambda payload, path: validate_standard_review(
        payload, path, allowed_verdicts={"APPROVED", "REJECTED"}
    ),
    "bdd-test-coverage-auditor": validate_bdd_test_coverage,
    "contract-drift-auditor": lambda payload, path: validate_contract_or_runtime(
        payload, path, runtime=False
    ),
    "runtime-integration-conductor": lambda payload, path: validate_contract_or_runtime(
        payload, path, runtime=True
    ),
    "c4-architecture-governor": validate_c4,
}


def main() -> int:
    args = parse_args()
    root = Path(args.root).resolve()
    files = sorted((root / "petitions" / "reviews").glob("*.yaml"))
    files.extend(sorted((root / "architecture" / "reviews").glob("*.yaml")))

    errors: list[str] = []
    warnings: list[str] = []
    checked: list[str] = []

    if not files:
        report = build_report(
            f"Review artifact lint for {root}",
            warnings=["No review artifacts found."],
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    for path in files:
        checked.append(str(path))
        payload = load_yaml(path)
        if not isinstance(payload, dict):
            errors.append(f"{path}: artifact must parse as a mapping.")
            continue
        agent = payload.get("agent")
        if not isinstance(agent, str) or not agent.strip():
            errors.append(f"{path}: `agent` is required.")
            continue
        validator = VALIDATORS.get(agent)
        if validator is None:
            warnings.append(
                f"{path}: unknown agent `{agent}`; validated only common envelope."
            )
            continue
        artifact_errors, artifact_warnings = validator(payload, path)
        errors.extend(artifact_errors)
        warnings.extend(artifact_warnings)
        warnings.extend(validate_path_convention(payload, path))

    report = build_report(
        f"Review artifact lint for {root}",
        errors=errors,
        warnings=warnings,
        checked=checked,
    )
    emit_report(report, args.json)
    return exit_code_for(report, args.strict_warnings)


if __name__ == "__main__":
    raise SystemExit(main())
