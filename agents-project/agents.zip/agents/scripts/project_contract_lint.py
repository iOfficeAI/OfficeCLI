#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

from sdlc_common import (
    build_report,
    emit_report,
    ensure_string_list,
    exit_code_for,
    find_files,
    load_yaml,
    resolve_relative,
)


LANGUAGE_SIGNALS = {
    "python": ["pyproject.toml", "requirements.txt", "setup.py"],
    "javascript": ["package.json"],
    "typescript": ["package.json"],
    "node": ["package.json"],
    "java": ["pom.xml", "build.gradle", "build.gradle.kts"],
    "dotnet": ["*.csproj", "*.sln"],
    "c#": ["*.csproj", "*.sln"],
    "go": ["go.mod"],
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Lint `.factory/project.yaml` and harness declarations against repo signals."
    )
    parser.add_argument("--json", action="store_true", help="Emit JSON output.")
    parser.add_argument("--root", default=".", help="Project root.")
    parser.add_argument(
        "--strict-warnings", action="store_true", help="Treat warnings as failures."
    )
    return parser.parse_args()


def require_mapping(value: Any, label: str, errors: list[str]) -> dict[str, Any]:
    if not isinstance(value, dict):
        errors.append(f"`{label}` must be a mapping.")
        return {}
    return value


def require_string(value: Any, label: str, errors: list[str]) -> str:
    if not isinstance(value, str) or not value.strip():
        errors.append(f"`{label}` must be a non-empty string.")
        return ""
    return value.strip()


def validate_paths(
    root: Path, values: list[str], label: str, errors: list[str], warnings: list[str]
) -> None:
    if not values:
        errors.append(f"`{label}` must contain at least one path.")
        return
    for value in values:
        path = resolve_relative(root, value)
        if not path.exists():
            errors.append(f"`{label}` path does not exist: {value}")
        elif not path.is_dir():
            warnings.append(f"`{label}` entry is not a directory: {value}")


def has_manifest(root: Path, patterns: list[str]) -> bool:
    return bool(find_files(root, patterns))


def is_browser_ui(stack: dict[str, Any]) -> bool:
    frameworks = require_mapping(stack.get("frameworks"), "stack.frameworks", [])
    ui = [item.lower() for item in ensure_string_list(frameworks.get("ui"))]
    if any(item not in {"none", "api-only"} for item in ui):
        return True
    rendering = require_mapping(stack.get("rendering"), "stack.rendering", [])
    return str(rendering.get("mode", "")).strip().lower() in {
        "spa",
        "server-rendered",
        "hybrid",
    }


def main() -> int:
    args = parse_args()
    root = Path(args.root).resolve()
    project_path = resolve_relative(root, ".factory/project.yaml")
    errors: list[str] = []
    warnings: list[str] = []

    if not project_path.is_file():
        report = build_report(
            f"Project contract lint for {root}",
            errors=["Missing `.factory/project.yaml`."],
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    data = load_yaml(project_path)
    if not isinstance(data, dict):
        report = build_report(
            f"Project contract lint for {root}",
            errors=["`.factory/project.yaml` must parse as a mapping."],
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    project = require_mapping(data.get("project"), "project", errors)
    stack = require_mapping(data.get("stack"), "stack", errors)
    build = require_mapping(project.get("build"), "project.build", errors)
    docs = require_mapping(project.get("docs"), "project.docs", errors)
    frameworks = require_mapping(stack.get("frameworks"), "stack.frameworks", errors)
    rendering = require_mapping(stack.get("rendering"), "stack.rendering", errors)

    language = require_string(project.get("language"), "project.language", errors).lower()
    runtime = require_string(project.get("runtime"), "project.runtime", errors)
    _ = runtime
    require_string(project.get("name"), "project.name", errors)
    require_string(project.get("test_framework"), "project.test_framework", errors)
    for key in ("compile", "test", "lint"):
        require_string(build.get(key), f"project.build.{key}", errors)

    source_dirs = ensure_string_list(project.get("source_directories"))
    test_dirs = ensure_string_list(project.get("test_directories"))
    validate_paths(root, source_dirs, "project.source_directories", errors, warnings)
    validate_paths(root, test_dirs, "project.test_directories", errors, warnings)

    stack_languages = [item.lower() for item in ensure_string_list(stack.get("languages"))]
    if language and language not in stack_languages:
        errors.append("`project.language` must also appear in `stack.languages`.")

    if not ensure_string_list(stack.get("runtimes")):
        errors.append("`stack.runtimes` must contain at least one runtime.")

    if language in LANGUAGE_SIGNALS and not has_manifest(root, LANGUAGE_SIGNALS[language]):
        errors.append(
            f"Repo signals do not match declared language `{language}`: missing expected manifest."
        )

    browser_ui = is_browser_ui(stack)
    if browser_ui:
        e2e = require_mapping(project.get("e2e"), "project.e2e", errors)
        for key in (
            "framework",
            "project_root",
            "test_dir",
            "config",
            "install_command",
            "type_check_command",
            "test_list_command",
            "runner",
            "report_dir",
        ):
            require_string(e2e.get(key), f"project.e2e.{key}", errors)
        if e2e:
            e2e_root = resolve_relative(root, e2e["project_root"])
            if not e2e_root.exists():
                errors.append(f"`project.e2e.project_root` does not exist: {e2e['project_root']}")
            config_path = resolve_relative(root, e2e["config"])
            if not config_path.exists():
                errors.append(f"`project.e2e.config` does not exist: {e2e['config']}")
            test_dir = e2e_root / Path(e2e["test_dir"])
            if not test_dir.exists():
                errors.append(f"`project.e2e.test_dir` does not exist under project root: {e2e['test_dir']}")
            if str(e2e.get("framework", "")).strip().lower() == "playwright" and not config_path.exists():
                errors.append("Playwright projects must declare an existing config file.")
    elif "e2e" in project and not isinstance(project["e2e"], dict):
        errors.append("`project.e2e` must be a mapping when declared.")

    for key in ("engine", "config", "docs_dir", "site_dir", "build_command", "serve_command"):
        require_string(docs.get(key), f"project.docs.{key}", errors)
    plugins = ensure_string_list(docs.get("plugins"))
    if not plugins:
        warnings.append("`project.docs.plugins` is empty.")

    agent_workflow = data.get("agent_workflow")
    if agent_workflow is not None:
        workflow = require_mapping(agent_workflow, "agent_workflow", errors)
        if workflow:
            review_scope = workflow.get("review_scope")
            if review_scope not in {"full", "targeted"}:
                errors.append("`agent_workflow.review_scope` must be `full` or `targeted`.")
            testing_scope = workflow.get("testing_scope")
            if testing_scope not in {"full", "targeted"}:
                errors.append("`agent_workflow.testing_scope` must be `full` or `targeted`.")
            if not isinstance(workflow.get("goal_verification"), bool):
                errors.append("`agent_workflow.goal_verification` must be boolean.")

    harness = data.get("harness")
    if harness is not None:
        harness_map = require_mapping(harness, "harness", errors)
        for key in ("local_fast", "ci_required", "architecture", "runtime"):
            value = harness_map.get(key)
            if value is None:
                continue
            if not isinstance(value, list) or not all(isinstance(item, str) and item.strip() for item in value):
                errors.append(f"`harness.{key}` must be a list of non-empty strings.")
        coverage = harness_map.get("coverage")
        if coverage is not None:
            coverage_map = require_mapping(coverage, "harness.coverage", errors)
            for key in ("tool", "command"):
                require_string(coverage_map.get(key), f"harness.coverage.{key}", errors)
            target = require_mapping(coverage_map.get("target"), "harness.coverage.target", errors)
            for key in ("lines", "branches"):
                if key not in target or not isinstance(target[key], int):
                    errors.append(f"`harness.coverage.target.{key}` must be an integer.")
            reports = require_mapping(coverage_map.get("reports"), "harness.coverage.reports", errors)
            for key in ("console", "xml", "html_dir"):
                require_string(reports.get(key), f"harness.coverage.reports.{key}", errors)

    report = build_report(
        f"Project contract lint for {root}",
        errors=errors,
        warnings=warnings,
        project_path=str(project_path),
        browser_ui=browser_ui,
        repo_signal_summary={
            "package_json": bool(find_files(root, ["package.json"])),
            "pyproject": bool(find_files(root, ["pyproject.toml"])),
            "pom": bool(find_files(root, ["pom.xml"])),
            "dotnet": bool(find_files(root, ["*.csproj", "*.sln"])),
            "go_mod": bool(find_files(root, ["go.mod"])),
        },
    )
    emit_report(report, args.json)
    return exit_code_for(report, args.strict_warnings)


if __name__ == "__main__":
    raise SystemExit(main())
