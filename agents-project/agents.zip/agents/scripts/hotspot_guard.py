#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import tempfile
from dataclasses import dataclass
from datetime import date, timedelta
from pathlib import Path
from typing import Any

from sdlc_common import (
    EXCLUDED_DIRS,
    build_report,
    emit_report,
    ensure_string_list,
    exit_code_for,
    normalized_relpath,
)

POLICY_VERSION = "structural_hotspot_v1"
SUPPORTED_COMPLEXITY_SUFFIXES = {
    ".ts",
    ".tsx",
    ".mts",
    ".cts",
    ".js",
    ".jsx",
    ".mjs",
    ".cjs",
    ".py",
    ".java",
}
STRUCTURAL_THRESHOLDS = {
    "file_loc": {"warn": 500, "block": 800},
    "max_complexity": {"warn": 10, "block": 15},
    "max_nesting": {"warn": 4, "block": 5},
    "public_methods": {"warn": 15, "block": 25},
    "constructor_params": {"warn": 6, "block": 8},
    "import_fanout": {"warn": 12, "block": 20},
}
CHURN_THRESHOLDS = {"warn": 6, "block": 10}
METRIC_REASON_CODES = {
    "file_loc": "HOTSPOT_FILE_LOC",
    "max_complexity": "HOTSPOT_MAX_COMPLEXITY",
    "max_nesting": "HOTSPOT_MAX_NESTING",
    "public_methods": "HOTSPOT_PUBLIC_METHOD_COUNT",
    "constructor_params": "HOTSPOT_CONSTRUCTOR_PARAM_COUNT",
    "import_fanout": "HOTSPOT_IMPORT_FANOUT",
}
LANGUAGE_NAMES = {
    ".py": "python",
    ".java": "java",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".mts": "typescript",
    ".cts": "typescript",
    ".js": "typescript",
    ".jsx": "typescript",
    ".mjs": "typescript",
    ".cjs": "typescript",
}


@dataclass
class HotspotFinding:
    file: str
    language: str
    analyzer_supported: bool
    metrics_available: list[str]
    severity: str
    verdict: str
    reason_codes: list[str]
    worsened_metrics: list[str]
    metrics: dict[str, Any]
    baseline_metrics: dict[str, Any] | None
    finding_id: str
    tb_required: bool
    confidence: str
    baseline_available: bool
    baseline_ref: str | None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Detect deterministic structural hotspots for touched files."
    )
    parser.add_argument("--json", action="store_true", help="Emit JSON output.")
    parser.add_argument("--root", default=".", help="Project root.")
    parser.add_argument(
        "--baseline-ref",
        help="Git ref used for baseline comparison. Defaults to HEAD~1 when available.",
    )
    parser.add_argument(
        "--churn-days",
        type=int,
        default=90,
        help="Git churn window in days. Default: 90.",
    )
    parser.add_argument(
        "--strict-warnings", action="store_true", help="Treat warnings as failures."
    )
    parser.add_argument(
        "targets",
        nargs="+",
        help="Touched file or directory paths relative to repo root.",
    )
    return parser.parse_args()


def run_git(root: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", "-C", str(root), *args],
        capture_output=True,
        text=True,
        check=False,
    )


def resolve_baseline_ref(root: Path, explicit_ref: str | None) -> str | None:
    if explicit_ref:
        return explicit_ref
    result = run_git(root, "rev-parse", "--verify", "HEAD~1")
    return "HEAD~1" if result.returncode == 0 else None


def expand_targets(root: Path, targets: list[str]) -> list[Path]:
    files: set[Path] = set()
    for raw_target in targets:
        path = (root / Path(normalized_relpath(raw_target))).resolve()
        if not path.exists():
            continue
        if path.is_file():
            files.add(path)
            continue
        for candidate in path.rglob("*"):
            if not candidate.is_file():
                continue
            if any(part in EXCLUDED_DIRS for part in candidate.parts):
                continue
            files.add(candidate.resolve())
    return sorted(files)


def run_maintainability_snapshot(root: Path, targets: list[str]) -> tuple[dict[str, Any], list[str]]:
    if not targets:
        return {}, []
    helper = Path(__file__).with_name("maintainability_snapshot.mjs")
    command = ["node", str(helper), "--cwd", str(root)]
    for target in targets:
        command.extend(["--target", target])
    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip() or "maintainability snapshot failed"
        return {}, [detail]
    payload = json.loads(result.stdout)
    return {
        item["path"]: item
        for item in payload.get("files", [])
        if isinstance(item, dict) and isinstance(item.get("path"), str)
    }, ensure_string_list(payload.get("warnings"))


def run_maintainability_for_text(
    suffix: str, logical_path: str, source_text: str
) -> dict[str, Any] | None:
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_root = Path(temp_dir)
        temp_file = temp_root / f"snapshot{suffix}"
        temp_file.write_text(source_text, encoding="utf-8")
        helper = Path(__file__).with_name("maintainability_snapshot.mjs")
        result = subprocess.run(
            ["node", str(helper), "--cwd", str(temp_root), "--target", temp_file.name],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            return None
        payload = json.loads(result.stdout)
        files = payload.get("files", [])
        if not isinstance(files, list) or not files:
            return None
        file_result = files[0]
        if isinstance(file_result, dict):
            file_result["path"] = logical_path
            return file_result
        return None


def derive_language(path: Path) -> str:
    return LANGUAGE_NAMES.get(path.suffix.lower(), "unsupported")


def extract_analysis_metrics(file_result: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(file_result, dict):
        return {"max_complexity": None, "max_nesting": None}
    functions = file_result.get("functions", [])
    if not isinstance(functions, list) or not functions:
        return {"max_complexity": 0, "max_nesting": 0}
    return {
        "max_complexity": max(int(item.get("cyclomatic", 0) or 0) for item in functions if isinstance(item, dict)),
        "max_nesting": max(int(item.get("nesting_depth", 0) or 0) for item in functions if isinstance(item, dict)),
    }


def count_import_fanout(text: str, suffix: str) -> int:
    unique_imports: set[str] = set()
    for line in text.splitlines():
        stripped = line.strip()
        if suffix in {".py"}:
            if stripped.startswith("import ") or stripped.startswith("from "):
                unique_imports.add(stripped)
        elif suffix == ".java":
            if stripped.startswith("import "):
                unique_imports.add(stripped)
        elif suffix in {".ts", ".tsx", ".mts", ".cts", ".js", ".jsx", ".mjs", ".cjs"}:
            if stripped.startswith("import ") or stripped.startswith("export ") and " from " in stripped:
                unique_imports.add(stripped)
            if "require(" in stripped:
                unique_imports.add(stripped)
    return len(unique_imports)


def count_python_public_methods(text: str) -> int:
    count = 0
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("def "):
            name = stripped[4:].split("(", 1)[0].strip()
            if name and not name.startswith("_"):
                count += 1
    return count


def count_python_constructor_params(text: str) -> int:
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("def __init__("):
            params = stripped.split("(", 1)[1].rsplit(")", 1)[0]
            values = [value.strip() for value in params.split(",") if value.strip()]
            return max(len([value for value in values if value not in {"self", "cls"}]), 0)
    return 0


def count_java_public_methods(text: str, class_name: str) -> tuple[int, int]:
    public_methods = 0
    constructor_params = 0
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped.startswith("public "):
            continue
        if "(" not in stripped or ")" not in stripped:
            continue
        before_params, after_params = stripped.split("(", 1)
        params = after_params.split(")", 1)[0]
        name = before_params.split()[-1]
        param_count = len([value for value in params.split(",") if value.strip()])
        if name == class_name:
            constructor_params = max(constructor_params, param_count)
        else:
            public_methods += 1
    return public_methods, constructor_params


def count_ts_public_methods_and_constructors(text: str) -> tuple[int, int]:
    public_methods = 0
    constructor_params = 0
    skip_names = {"if", "for", "while", "switch", "catch", "function"}
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or "(" not in stripped or ")" not in stripped:
            continue
        if stripped.startswith("//") or stripped.startswith("*"):
            continue
        if stripped.startswith("constructor("):
            params = stripped.split("(", 1)[1].split(")", 1)[0]
            constructor_params = max(
                constructor_params,
                len([value for value in params.split(",") if value.strip()]),
            )
            continue
        candidate = stripped.removeprefix("public ").removeprefix("private ").removeprefix("protected ")
        name = candidate.split("(", 1)[0].split()[-1]
        if name in skip_names or name.startswith("#"):
            continue
        if stripped.startswith("export function ") or stripped.startswith("function "):
            public_methods += 1
            continue
        if stripped.endswith("{") and name.isidentifier():
            public_methods += 1
    return public_methods, constructor_params


def extract_signature_metrics(path: Path, text: str) -> dict[str, int]:
    suffix = path.suffix.lower()
    if suffix == ".py":
        return {
            "public_methods": count_python_public_methods(text),
            "constructor_params": count_python_constructor_params(text),
        }
    if suffix == ".java":
        public_methods, constructor_params = count_java_public_methods(text, path.stem)
        return {
            "public_methods": public_methods,
            "constructor_params": constructor_params,
        }
    if suffix in {".ts", ".tsx", ".mts", ".cts", ".js", ".jsx", ".mjs", ".cjs"}:
        public_methods, constructor_params = count_ts_public_methods_and_constructors(text)
        return {
            "public_methods": public_methods,
            "constructor_params": constructor_params,
        }
    return {
        "public_methods": 0,
        "constructor_params": 0,
    }


def compute_file_metrics(
    path: Path,
    logical_path: str,
    text: str,
    analysis: dict[str, Any] | None,
    churn: int | None,
) -> dict[str, Any]:
    signature_metrics = extract_signature_metrics(path, text)
    complexity_metrics = extract_analysis_metrics(analysis)
    return {
        "file_loc": len(text.splitlines()),
        "max_complexity": complexity_metrics["max_complexity"],
        "max_nesting": complexity_metrics["max_nesting"],
        "public_methods": signature_metrics["public_methods"],
        "constructor_params": signature_metrics["constructor_params"],
        "import_fanout": count_import_fanout(text, path.suffix.lower()),
        "churn_90d": churn,
        "path": logical_path,
    }


def read_file_at_ref(root: Path, baseline_ref: str, logical_path: str) -> str | None:
    result = run_git(root, "show", f"{baseline_ref}:{logical_path}")
    if result.returncode != 0:
        return None
    return result.stdout


def compute_churn(root: Path, logical_path: str, churn_days: int) -> tuple[int | None, str | None]:
    since = (date.today() - timedelta(days=churn_days)).isoformat()
    result = run_git(root, "log", "--follow", f"--since={since}", "--format=%H", "--", logical_path)
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip() or "git log failed"
        return None, detail
    commits = {line.strip() for line in result.stdout.splitlines() if line.strip()}
    return len(commits), None


def metric_band(metric_name: str, value: int | None) -> str:
    if value is None:
        return "none"
    if metric_name == "churn_90d":
        thresholds = CHURN_THRESHOLDS
    else:
        thresholds = STRUCTURAL_THRESHOLDS[metric_name]
    if value >= thresholds["block"]:
        return "block"
    if value >= thresholds["warn"]:
        return "warn"
    return "none"


def confidence_for(metrics_available: list[str], analyzer_supported: bool, churn: int | None) -> str:
    if analyzer_supported and churn is not None:
        return "high"
    if analyzer_supported or churn is not None:
        return "medium"
    return "low"


def build_finding(
    logical_path: str,
    language: str,
    analyzer_supported: bool,
    metrics: dict[str, Any],
    baseline_metrics: dict[str, Any] | None,
    baseline_ref: str | None,
) -> HotspotFinding | None:
    reason_codes: set[str] = set()
    warn_metrics: list[str] = []
    block_metrics: list[str] = []
    worsened_metrics: list[str] = []

    for metric_name in (
        "file_loc",
        "max_complexity",
        "max_nesting",
        "public_methods",
        "constructor_params",
        "import_fanout",
    ):
        band = metric_band(metric_name, metrics.get(metric_name))
        if band == "none":
            continue
        reason_codes.add(METRIC_REASON_CODES[metric_name])
        warn_metrics.append(metric_name)
        if band == "block":
            block_metrics.append(metric_name)
        baseline_value = None if baseline_metrics is None else baseline_metrics.get(metric_name)
        current_value = metrics.get(metric_name)
        if isinstance(current_value, int) and isinstance(baseline_value, int) and current_value > baseline_value:
            worsened_metrics.append(metric_name)

    churn = metrics.get("churn_90d")
    if isinstance(churn, int) and metric_band("churn_90d", churn) != "none":
        reason_codes.add("HOTSPOT_HIGH_CHURN")

    if baseline_metrics is None and warn_metrics:
        reason_codes.add("HOTSPOT_NEW_FILE_ABOVE_THRESHOLD")

    if not warn_metrics:
        return None

    if block_metrics and (baseline_metrics is None or worsened_metrics):
        severity = "blocking"
        verdict = "BLOCK"
    else:
        severity = "warning"
        verdict = "WARN"

    confidence = confidence_for(
        [key for key, value in metrics.items() if value is not None and key != "path"],
        analyzer_supported,
        churn if isinstance(churn, int) else None,
    )
    signature = "|".join([logical_path, severity, *sorted(reason_codes)])
    finding_id = f"HS-{hashlib.sha1(signature.encode('utf-8')).hexdigest()[:12]}"
    return HotspotFinding(
        file=logical_path,
        language=language,
        analyzer_supported=analyzer_supported,
        metrics_available=[key for key, value in metrics.items() if key != "path" and value is not None],
        severity=severity,
        verdict=verdict,
        reason_codes=sorted(reason_codes),
        worsened_metrics=sorted(set(worsened_metrics)),
        metrics={key: value for key, value in metrics.items() if key != "path"},
        baseline_metrics=(
            {key: value for key, value in baseline_metrics.items() if key != "path"}
            if baseline_metrics is not None
            else None
        ),
        finding_id=finding_id,
        tb_required=True,
        confidence=confidence,
        baseline_available=baseline_metrics is not None,
        baseline_ref=baseline_ref,
    )


def main() -> int:
    args = parse_args()
    root = Path(args.root).resolve()
    baseline_ref = resolve_baseline_ref(root, args.baseline_ref)
    files = expand_targets(root, args.targets)
    errors: list[str] = []
    warnings: list[str] = []
    checked_files: list[str] = []

    if not files:
        report = build_report(
            f"Structural hotspot guard for {root}",
            errors=["No matching files were found for the provided targets."],
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    relative_files = [normalized_relpath(str(path.relative_to(root))) for path in files]
    complexity_targets = [
        path for path in relative_files if Path(path).suffix.lower() in SUPPORTED_COMPLEXITY_SUFFIXES
    ]
    current_analysis, analysis_warnings = run_maintainability_snapshot(root, complexity_targets)
    warnings.extend(analysis_warnings)

    hotspots: list[dict[str, Any]] = []
    for path, logical_path in zip(files, relative_files):
        checked_files.append(logical_path)
        text = path.read_text(encoding="utf-8")
        churn, churn_warning = compute_churn(root, logical_path, args.churn_days)
        if churn_warning:
            warnings.append(f"{logical_path}: {churn_warning}")
        language = derive_language(path)
        analyzer_supported = path.suffix.lower() in SUPPORTED_COMPLEXITY_SUFFIXES
        metrics = compute_file_metrics(
            path,
            logical_path,
            text,
            current_analysis.get(logical_path),
            churn,
        )

        baseline_metrics: dict[str, Any] | None = None
        if baseline_ref:
            baseline_text = read_file_at_ref(root, baseline_ref, logical_path)
            if baseline_text is not None:
                baseline_analysis = (
                    run_maintainability_for_text(path.suffix.lower(), logical_path, baseline_text)
                    if analyzer_supported
                    else None
                )
                baseline_metrics = compute_file_metrics(
                    path,
                    logical_path,
                    baseline_text,
                    baseline_analysis,
                    churn,
                )

        finding = build_finding(
            logical_path,
            language,
            analyzer_supported,
            metrics,
            baseline_metrics,
            baseline_ref,
        )
        if finding is None:
            continue
        hotspots.append(
            {
                "finding_id": finding.finding_id,
                "file": finding.file,
                "language": finding.language,
                "analyzer_supported": finding.analyzer_supported,
                "metrics_available": finding.metrics_available,
                "severity": finding.severity,
                "verdict": finding.verdict,
                "reason_codes": finding.reason_codes,
                "worsened_metrics": finding.worsened_metrics,
                "metrics": finding.metrics,
                "baseline_metrics": finding.baseline_metrics,
                "tb_required": finding.tb_required,
                "confidence": finding.confidence,
                "baseline_available": finding.baseline_available,
            }
        )
        if finding.severity == "blocking":
            errors.append(
                f"Blocking structural hotspot in {finding.file}: {', '.join(finding.reason_codes)}."
            )
        else:
            warnings.append(
                f"Structural hotspot debt in {finding.file}: {', '.join(finding.reason_codes)}."
            )

    hotspot_counts = {
        "blocking": sum(1 for item in hotspots if item["severity"] == "blocking"),
        "warning": sum(1 for item in hotspots if item["severity"] == "warning"),
        "context": 0,
    }
    report = build_report(
        f"Structural hotspot guard for {root}",
        errors=errors,
        warnings=warnings,
        policy_version=POLICY_VERSION,
        baseline_ref=baseline_ref,
        churn_window_days=args.churn_days,
        checked_files=checked_files,
        hotspot_counts=hotspot_counts,
        hotspots=hotspots,
    )
    emit_report(report, args.json)
    return exit_code_for(report, args.strict_warnings)


if __name__ == "__main__":
    raise SystemExit(main())
