#!/usr/bin/env node
import { analyzeTargets } from "../.github/extensions/ts-maintainability/analyzer.mjs";

function parseArgs(argv) {
    const args = {
        cwd: process.cwd(),
        targets: [],
        maxFiles: 100,
        maxHotspots: 100,
    };

    for (let index = 0; index < argv.length; index += 1) {
        const token = argv[index];
        if (token === "--cwd") {
            args.cwd = argv[index + 1];
            index += 1;
            continue;
        }
        if (token === "--target") {
            args.targets.push(argv[index + 1]);
            index += 1;
            continue;
        }
        if (token === "--max-files") {
            args.maxFiles = Number.parseInt(argv[index + 1], 10);
            index += 1;
            continue;
        }
        if (token === "--max-hotspots") {
            args.maxHotspots = Number.parseInt(argv[index + 1], 10);
            index += 1;
        }
    }

    if (args.targets.length === 0) {
        args.targets = ["."];
    }
    return args;
}

const args = parseArgs(process.argv.slice(2));
const result = await analyzeTargets({
    cwd: args.cwd,
    targets: args.targets,
    maxFiles: Number.isFinite(args.maxFiles) ? args.maxFiles : 100,
    maxHotspots: Number.isFinite(args.maxHotspots) ? args.maxHotspots : 100,
});

process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
