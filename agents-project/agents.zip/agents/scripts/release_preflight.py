#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path
from typing import Any

from sdlc_common import (
    build_report,
    emit_report,
    exit_code_for,
    find_files,
    is_semver_tag,
    load_yaml,
    resolve_relative,
)


ALLOWED_RELEASE_STATUSES = {"implemented", "validated"}
TRIAGED_HOTSPOT_STATUSES = {"accepted", "planned", "deferred", "waived"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Deterministic preflight checks for release-manager inputs."
    )
    parser.add_argument("--json", action="store_true", help="Emit JSON output.")
    parser.add_argument("--root", default=".", help="Project root.")
    parser.add_argument("--version", required=True, help="Release tag, e.g. v1.2.3.")
    parser.add_argument(
        "--scope",
        nargs="*",
        default=[],
        help="Petition IDs to include. Defaults to all implemented/validated petitions.",
    )
    parser.add_argument(
        "--release-notes",
        help="Explicit release notes path. Defaults to releases/*-v<version>.md search.",
    )
    parser.add_argument(
        "--strict-warnings", action="store_true", help="Treat warnings as failures."
    )
    return parser.parse_args()


def find_release_notes(root: Path, version: str, explicit_path: str | None) -> Path | None:
    if explicit_path:
        path = resolve_relative(root, explicit_path)
        return path if path.is_file() else None
    candidates = sorted((root / "releases").glob(f"*-{version}.md"))
    return candidates[0] if candidates else None


def git_is_clean(root: Path) -> tuple[bool, str]:
    try:
        result = subprocess.run(
            ["git", "-C", str(root), "status", "--porcelain"],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError as exc:
        return False, f"git invocation failed: {exc}"
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip() or "unknown git error"
        return False, detail
    return not result.stdout.strip(), result.stdout.strip()


def main() -> int:
    args = parse_args()
    root = Path(args.root).resolve()
    errors: list[str] = []
    warnings: list[str] = []

    if not is_semver_tag(args.version):
        errors.append("`--version` must match `v<major>.<minor>.<patch>`.")

    notes_path = find_release_notes(root, args.version, args.release_notes)
    if notes_path is None:
        errors.append("Release notes file was not found.")

    clean, git_detail = git_is_clean(root)
    if not clean:
        errors.append("Git working tree is not clean.")

    status_path = resolve_relative(root, "petitions/program-status.yaml")
    if not status_path.is_file():
        errors.append("Missing `petitions/program-status.yaml`.")
        report = build_report(
            f"Release preflight for {root}",
            errors=errors,
            warnings=warnings,
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    data = load_yaml(status_path)
    if not isinstance(data, dict):
        errors.append("`petitions/program-status.yaml` must parse as a mapping.")
        report = build_report(
            f"Release preflight for {root}",
            errors=errors,
            warnings=warnings,
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    petitions = data.get("petitions")
    if not isinstance(petitions, list):
        errors.append("`petitions` must be a list in program-status.")
        petitions = []

    petition_index: dict[str, dict[str, Any]] = {}
    for entry in petitions:
        if isinstance(entry, dict) and isinstance(entry.get("id"), str):
            petition_index[entry["id"]] = entry

    selected = list(args.scope)
    if not selected:
        selected = [
            petition_id
            for petition_id, entry in petition_index.items()
            if entry.get("status") in ALLOWED_RELEASE_STATUSES
        ]
        if not selected:
            errors.append("No release candidates found with status implemented or validated.")

    for petition_id in selected:
        entry = petition_index.get(petition_id)
        if entry is None:
            errors.append(f"Requested petition `{petition_id}` not found in program-status.")
            continue
        status = entry.get("status")
        if status not in ALLOWED_RELEASE_STATUSES:
            errors.append(
                f"Petition `{petition_id}` must be implemented or validated before release; found `{status}`."
            )
        if entry.get("released_in"):
            warnings.append(f"Petition `{petition_id}` already declares `released_in={entry['released_in']}`.")

    escalations = data.get("escalations", [])
    if escalations is None:
        escalations = []
    if not isinstance(escalations, list):
        errors.append("`escalations` must be a list when present.")
        escalations = []

    selected_set = set(selected)
    for escalation in escalations:
        if not isinstance(escalation, dict):
            continue
        if escalation.get("status") != "open":
            continue
        target = escalation.get("petition")
        if target in selected_set or target in {None, "~", ""}:
            errors.append(
                f"Open escalation blocks release: {escalation.get('id', '<missing-id>')}."
            )

    technical_backlog = data.get("technical_backlog", [])
    if technical_backlog is None:
        technical_backlog = []
    if not isinstance(technical_backlog, list):
        errors.append("`technical_backlog` must be a list when present.")
        technical_backlog = []

    hotspot_debt: list[dict[str, Any]] = []
    for item in technical_backlog:
        if not isinstance(item, dict) or item.get("category") != "structural-hotspot":
            continue
        if item.get("status") == "done":
            continue
        petition_ref = item.get("petition")
        if petition_ref not in selected_set:
            continue
        if item.get("severity") != "blocking":
            hotspot_debt.append(
                {
                    "id": item.get("id"),
                    "petition": petition_ref,
                    "severity": item.get("severity"),
                    "triage_status": item.get("triage_status"),
                }
            )
            continue
        triage_status = item.get("triage_status")
        hotspot_debt.append(
            {
                "id": item.get("id"),
                "petition": petition_ref,
                "severity": item.get("severity"),
                "triage_status": triage_status,
            }
        )
        if triage_status not in TRIAGED_HOTSPOT_STATUSES:
            errors.append(
                f"Blocking structural hotspot debt for `{petition_ref}` is untriaged: {item.get('id', '<missing-id>')}."
            )

    project_path = resolve_relative(root, ".factory/project.yaml")
    if project_path.is_file():
        project_data = load_yaml(project_path)
        if not isinstance(project_data, dict):
            errors.append("`.factory/project.yaml` must parse as a mapping.")
        else:
            project = project_data.get("project")
            if not isinstance(project, dict):
                errors.append("`.factory/project.yaml` missing `project` mapping.")
            else:
                build = project.get("build")
                if not isinstance(build, dict):
                    errors.append("`.factory/project.yaml` missing `project.build` mapping.")
                else:
                    for key in ("compile", "test", "lint"):
                        if not str(build.get(key, "")).strip():
                            errors.append(f"`.factory/project.yaml` missing `project.build.{key}`.")
    else:
        warnings.append("`.factory/project.yaml` is missing; preflight could not confirm build/test declarations.")

    report = build_report(
        f"Release preflight for {root}",
        errors=errors,
        warnings=warnings,
        version=args.version,
        selected_scope=selected,
        release_notes=str(notes_path) if notes_path else None,
        git_clean=clean,
        git_detail=git_detail,
        hotspot_debt=hotspot_debt,
        detected_manifests={
            "package_json": bool(find_files(root, ["package.json"])),
            "pyproject": bool(find_files(root, ["pyproject.toml"])),
            "pom": bool(find_files(root, ["pom.xml"])),
            "dotnet": bool(find_files(root, ["*.csproj", "*.sln"])),
        },
    )
    emit_report(report, args.json)
    return exit_code_for(report, args.strict_warnings)


if __name__ == "__main__":
    raise SystemExit(main())
