#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

from sdlc_common import build_report, emit_report, exit_code_for, file_exists, resolve_relative


CHECKS: dict[str, dict[str, Any]] = {
    "petitions/program-status.yaml": {"group": "planning", "baseline": True},
    "architecture/workspace.dsl": {"group": "architecture", "baseline": False},
    "architecture/policies.yaml": {"group": "architecture", "baseline": False},
    "AGENTS.md / agents.md": {"group": "docs", "baseline": False},
    "architecture/adr/": {"group": "docs", "baseline": False},
    "domain/concept-model.yaml": {"group": "concept_model", "baseline": False},
}
GROUP_LABELS = {
    "planning": "Planning scaffold",
    "architecture": "Architecture scaffold",
    "docs": "Documentation scaffold",
    "concept_model": "Concept model",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Deterministic readiness checker for delivery-orchestrator scaffolds."
    )
    parser.add_argument("--json", action="store_true", help="Emit JSON output.")
    parser.add_argument("--root", default=".", help="Project root.")
    parser.add_argument(
        "--require",
        action="append",
        choices=sorted(GROUP_LABELS),
        default=[],
        help="Mark a scaffold group as required for the current path.",
    )
    parser.add_argument(
        "--strict-warnings", action="store_true", help="Treat warnings as failures."
    )
    return parser.parse_args()


def check_presence(root: Path) -> dict[str, str]:
    presence: dict[str, str] = {}
    presence["petitions/program-status.yaml"] = (
        "found" if file_exists(root, "petitions/program-status.yaml") else "MISSING"
    )
    presence["architecture/workspace.dsl"] = (
        "found" if file_exists(root, "architecture/workspace.dsl") else "MISSING"
    )
    presence["architecture/policies.yaml"] = (
        "found" if file_exists(root, "architecture/policies.yaml") else "MISSING"
    )
    agents_found = file_exists(root, "AGENTS.md") or file_exists(root, "agents.md")
    presence["AGENTS.md / agents.md"] = "found" if agents_found else "MISSING"
    adr_dir = resolve_relative(root, "architecture/adr")
    presence["architecture/adr/"] = (
        "found" if adr_dir.is_dir() and any(adr_dir.glob("*.md")) else "MISSING"
    )
    presence["domain/concept-model.yaml"] = (
        "found" if file_exists(root, "domain/concept-model.yaml") else "MISSING"
    )
    return presence


def main() -> int:
    args = parse_args()
    root = Path(args.root).resolve()
    presence = check_presence(root)

    errors: list[str] = []
    warnings: list[str] = []
    required_groups = set(args.require)

    for key, state in presence.items():
        group = CHECKS[key]["group"]
        if state == "found":
            continue
        if CHECKS[key]["baseline"] or group in required_groups:
            errors.append(f"{key} is missing for {GROUP_LABELS[group].lower()}.")
        else:
            warnings.append(f"{key} is missing but optional for this path.")

    report = build_report(
        f"Project readiness summary for {root}",
        errors=errors,
        warnings=warnings,
        required_groups=sorted(required_groups),
        items=presence,
    )
    emit_report(report, args.json)
    return exit_code_for(report, args.strict_warnings)


if __name__ == "__main__":
    raise SystemExit(main())
