#!/usr/bin/env python3
from __future__ import annotations

import argparse
from collections import Counter
from pathlib import Path
from typing import Any

from delivery_state_lint import collect_review_refs, collect_telemetry_refs
from sdlc_common import build_report, emit_report, exit_code_for, load_yaml
from telemetry_tool import compute_telemetry_rollup


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compile a deterministic retro snapshot from planning, review, and telemetry artifacts."
    )
    parser.add_argument("--json", action="store_true", help="Emit JSON output.")
    parser.add_argument("--root", default=".", help="Project root.")
    parser.add_argument(
        "--petition-id",
        action="append",
        default=[],
        help="Restrict the snapshot to one or more petition IDs.",
    )
    parser.add_argument(
        "--strict-warnings", action="store_true", help="Treat warnings as failures."
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.root).resolve()
    status_path = root / "petitions" / "program-status.yaml"
    if not status_path.is_file():
        report = build_report(
            f"Retro snapshot for {root}",
            errors=["Missing `petitions/program-status.yaml`."],
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    data = load_yaml(status_path)
    if not isinstance(data, dict):
        report = build_report(
            f"Retro snapshot for {root}",
            errors=["`petitions/program-status.yaml` must parse as a mapping."],
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    requested = set(args.petition_id)
    petitions = [
        item
        for item in data.get("petitions", [])
        if isinstance(item, dict)
        and isinstance(item.get("id"), str)
        and (not requested or item["id"] in requested)
    ]
    petition_ids = {item["id"] for item in petitions}

    review_refs = collect_review_refs(root)
    telemetry_refs = collect_telemetry_refs(root)

    status_counts = Counter(str(item.get("status")) for item in petitions)
    phase_counts = Counter(str(item.get("phase")) for item in petitions if item.get("phase") is not None)
    open_escalations = [
        item
        for item in data.get("escalations", [])
        if isinstance(item, dict)
        and item.get("status") == "open"
        and (not petition_ids or item.get("petition") in petition_ids or item.get("petition") in {None, "", "~"})
    ]
    open_tb = [
        item
        for item in data.get("technical_backlog", [])
        if isinstance(item, dict)
        and item.get("status") != "done"
        and (not petition_ids or item.get("petition") in petition_ids or item.get("petition") in {None, "", "~"})
    ]

    review_artifacts_inspected = 0
    discard_total = 0
    escalate_total = 0
    non_approved: list[dict[str, Any]] = []
    knowledge_gaps: list[str] = []
    hotfix_review_failures: list[str] = []

    for petition_id, paths in review_refs.items():
        if petition_ids and petition_id not in petition_ids:
            continue
        for path in paths:
            review_artifacts_inspected += 1
            payload = load_yaml(path)
            if not isinstance(payload, dict):
                knowledge_gaps.append(f"Unreadable review artifact: {path}")
                continue
            verdict = str(payload.get("verdict", ""))
            discard_total += int(payload.get("discard_count", 0) or 0)
            escalate_total += int(payload.get("escalate_count", 0) or 0)
            if verdict not in {"APPROVED", "PASS", "PASS-WITH-WARNINGS", "NO-DRIFT"}:
                non_approved.append(
                    {
                        "petition_id": petition_id,
                        "agent": payload.get("agent"),
                        "verdict": verdict,
                        "path": str(path),
                    }
                )
            if path.name.startswith("hotfix-") and verdict not in {"APPROVED", "PASS"}:
                hotfix_review_failures.append(str(path))

    blockers: list[dict[str, Any]] = []
    for petition in petitions:
        if petition.get("status") == "blocked":
            blockers.append(
                {
                    "petition_id": petition["id"],
                    "reason": petition.get("notes") or "blocked with no explicit notes",
                }
            )
        petition_doc = root / "petitions" / f"{petition['id']}.md"
        if not petition_doc.is_file():
            knowledge_gaps.append(f"Missing petition artifact: {petition_doc}")

    telemetry_by_petition: dict[str, Any] = {}
    telemetry_totals = {
        "input_tokens": 0,
        "output_tokens": 0,
        "cached_input_tokens": 0,
        "total_tokens": 0,
        "estimated_cost_usd": 0.0,
        "tool_calls": 0,
        "measured_runs": 0,
        "total_runs": 0,
    }
    coverage_states: list[str] = []
    for petition_id, paths in telemetry_refs.items():
        if petition_ids and petition_id not in petition_ids:
            continue
        path = paths[0]
        payload = load_yaml(path)
        if not isinstance(payload, dict):
            knowledge_gaps.append(f"Unreadable telemetry artifact: {path}")
            continue
        derived = compute_telemetry_rollup(payload)
        telemetry_by_petition[petition_id] = derived
        coverage_states.append(derived["coverage"])
        for key in telemetry_totals:
            telemetry_totals[key] += derived["rollups"].get(key, 0)

    telemetry_coverage = (
        "absent"
        if not coverage_states or set(coverage_states) == {"absent"}
        else "measured"
        if set(coverage_states) == {"measured"}
        else "partial"
    )
    if telemetry_coverage != "measured":
        knowledge_gaps.append(
            "Telemetry coverage is not fully measured; headline token/cost claims are limited."
        )

    report = build_report(
        f"Retro snapshot for {root}",
        warnings=sorted(set(knowledge_gaps)),
        retro_basis="current snapshot only",
        snapshot_metrics={
            "petition_status_counts": dict(status_counts),
            "phase_counts": dict(phase_counts),
            "open_escalations": len(open_escalations),
            "open_technical_backlog": len(open_tb),
        },
        review_failures={
            "artifacts_inspected": review_artifacts_inspected,
            "discard_total": discard_total,
            "escalate_total": escalate_total,
            "non_approved": non_approved,
            "hotfix_review_failures": hotfix_review_failures,
        },
        blockers=blockers,
        knowledge_gaps=sorted(set(knowledge_gaps)),
        telemetry_coverage=telemetry_coverage,
        telemetry_signal={
            "measured_totals": telemetry_totals,
            "petitions": telemetry_by_petition,
        },
        activity_signal="Not derived in snapshot-only mode.",
    )
    emit_report(report, args.json)
    return exit_code_for(report, args.strict_warnings)


if __name__ == "__main__":
    raise SystemExit(main())
