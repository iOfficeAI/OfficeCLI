#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
RUNNER="${SCRIPT_DIR}/janitor.py"

if command -v python3 >/dev/null 2>&1; then
  exec python3 "$RUNNER" "$@"
elif command -v python >/dev/null 2>&1; then
  exec python "$RUNNER" "$@"
elif command -v uv >/dev/null 2>&1; then
  exec uv run python "$RUNNER" "$@"
else
  echo "janitor.sh requires python3, python, or uv on PATH." >&2
  exit 1
fi
