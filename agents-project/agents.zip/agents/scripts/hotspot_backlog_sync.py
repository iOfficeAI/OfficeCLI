#!/usr/bin/env python3
from __future__ import annotations

import argparse
from datetime import date
from pathlib import Path
from typing import Any

from sdlc_common import build_report, emit_report, exit_code_for, load_yaml, write_yaml

TRIAGE_STATUSES = {"untriaged", "accepted", "planned", "deferred", "waived"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Sync structural hotspot review findings into technical_backlog."
    )
    parser.add_argument("--json", action="store_true", help="Emit JSON output.")
    parser.add_argument("--root", default=".", help="Project root.")
    parser.add_argument(
        "--petition-id",
        action="append",
        default=[],
        help="Restrict sync to one or more petition IDs.",
    )
    parser.add_argument(
        "--strict-warnings", action="store_true", help="Treat warnings as failures."
    )
    return parser.parse_args()


def next_tb_id(items: list[dict[str, Any]]) -> str:
    seen = []
    for item in items:
        if not isinstance(item, dict):
            continue
        value = str(item.get("id", ""))
        if value.startswith("TB-") and value[3:].isdigit():
            seen.append(int(value[3:]))
    return f"TB-{max(seen, default=0) + 1:03d}"


def load_program_status(path: Path) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    payload = load_yaml(path)
    return payload if isinstance(payload, dict) else None


def main() -> int:
    args = parse_args()
    root = Path(args.root).resolve()
    program_status_path = root / "petitions" / "program-status.yaml"
    review_dir = root / "petitions" / "reviews"
    errors: list[str] = []
    warnings: list[str] = []

    data = load_program_status(program_status_path)
    if data is None:
        report = build_report(
            f"Hotspot backlog sync for {root}",
            errors=["Missing or unreadable `petitions/program-status.yaml`."],
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    technical_backlog = data.get("technical_backlog", [])
    if not isinstance(technical_backlog, list):
        errors.append("`technical_backlog` must be a list in program-status.")
        technical_backlog = []
    data["technical_backlog"] = technical_backlog

    existing_by_finding_id = {
        str(item.get("finding_id")): item
        for item in technical_backlog
        if isinstance(item, dict) and str(item.get("finding_id", "")).strip()
    }
    petition_filter = set(args.petition_id)
    created: list[str] = []
    updated: list[str] = []

    for path in sorted(review_dir.glob("*.yaml")):
        payload = load_yaml(path)
        if not isinstance(payload, dict):
            warnings.append(f"{path}: review artifact could not be parsed.")
            continue
        if payload.get("agent") != "code-reviewer-strict":
            continue
        petition_id = str(payload.get("petition_id", "")).strip()
        if petition_filter and petition_id not in petition_filter:
            continue
        hotspots = payload.get("hotspots", [])
        if not isinstance(hotspots, list):
            warnings.append(f"{path}: `hotspots` must be a list when present.")
            continue
        for hotspot in hotspots:
            if not isinstance(hotspot, dict) or not hotspot.get("tb_required"):
                continue
            finding_id = str(hotspot.get("finding_id", "")).strip()
            hotspot_file = str(hotspot.get("file", "")).strip()
            severity = str(hotspot.get("severity", "")).strip() or "warning"
            if not finding_id or not hotspot_file:
                warnings.append(f"{path}: hotspot finding is missing finding_id or file.")
                continue
            item = existing_by_finding_id.get(finding_id)
            if item is None:
                item = {
                    "id": next_tb_id(technical_backlog),
                    "title": f"Refactor structural hotspot: {Path(hotspot_file).name}",
                    "status": "pending",
                    "source": f"{hotspot_file} structural-hotspot {finding_id}",
                    "source_agent": "code-reviewer-strict",
                    "petition": petition_id or None,
                    "category": "structural-hotspot",
                    "remediation_target": hotspot_file,
                    "evidence_artifact": str(path.relative_to(root)).replace("\\", "/"),
                    "finding_id": finding_id,
                    "severity": severity,
                    "triage_status": "untriaged",
                    "policy_version": payload.get("hotspot_summary", {}).get(
                        "policy_version", "structural_hotspot_v1"
                    ),
                    "first_seen": date.today().isoformat(),
                    "notes": ", ".join(hotspot.get("reason_codes", [])),
                }
                technical_backlog.append(item)
                existing_by_finding_id[finding_id] = item
                created.append(item["id"])
                continue

            item["petition"] = item.get("petition") or petition_id or None
            item["severity"] = severity
            item["remediation_target"] = hotspot_file
            item["evidence_artifact"] = str(path.relative_to(root)).replace("\\", "/")
            item["policy_version"] = payload.get("hotspot_summary", {}).get(
                "policy_version", item.get("policy_version", "structural_hotspot_v1")
            )
            if str(item.get("triage_status", "")).strip() not in TRIAGE_STATUSES:
                item["triage_status"] = "untriaged"
            reason_codes = hotspot.get("reason_codes", [])
            if isinstance(reason_codes, list) and reason_codes:
                item["notes"] = ", ".join(str(code) for code in reason_codes)
            updated.append(str(item.get("id")))

    if not errors:
        write_yaml(program_status_path, data)

    report = build_report(
        f"Hotspot backlog sync for {root}",
        errors=errors,
        warnings=warnings,
        created=created,
        updated=updated,
        technical_backlog_count=len(technical_backlog),
    )
    emit_report(report, args.json)
    return exit_code_for(report, args.strict_warnings)


if __name__ == "__main__":
    raise SystemExit(main())
