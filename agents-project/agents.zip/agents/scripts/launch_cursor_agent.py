#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Launch Cursor Agent with prompt file and optional agent definition."
    )
    parser.add_argument("--workspace", required=True, help="Workspace path for Cursor Agent.")
    parser.add_argument("--prompt-file", required=True, help="Path to the task prompt file.")
    parser.add_argument(
        "--result-file",
        help="Optional machine-readable result file path that the agent must write before finishing.",
    )
    parser.add_argument(
        "--agent",
        help="Optional agent name. Loads ~/.claude/agents/<agent>.agent.md and prepends its body.",
    )
    parser.add_argument(
        "--model",
        default=os.environ.get("JANITOR_AGENT_MODEL", "gpt-5.4-high"),
        help="Cursor Agent model slug. Defaults to JANITOR_AGENT_MODEL or gpt-5.4-high.",
    )
    return parser.parse_args()


def strip_frontmatter(text: str) -> str:
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return text

    for idx in range(1, len(lines)):
        if lines[idx].strip() == "---":
            body = "\n".join(lines[idx + 1 :]).lstrip()
            return body
    return text


def build_prompt(prompt_path: Path, agent_name: str | None, result_file: str | None) -> str:
    prompt = prompt_path.read_text(encoding="utf-8")
    contract = ""
    if result_file:
        contract = (
            "Headless automation contract:\n"
            "- This is not an interactive chat.\n"
            "- Complete the requested repo work first.\n"
            f"- Before finishing, write the required machine-readable result JSON to:\n  {result_file}\n"
            "- If no safe edit is possible, still write a `blocked` or `skipped` result JSON.\n"
            "- Do not end with 'If Markus wants...' or any similar follow-up prompt.\n"
            "- Your final state must include the result file.\n\n"
        )
    if not agent_name:
        return (
            "Treat the task below as authoritative. Complete all required side effects "
            "before you return any narrative summary.\n\n"
            f"{contract}"
            f"{prompt}"
        )

    agent_path = Path.home() / ".claude" / "agents" / f"{agent_name}.agent.md"
    agent_md = agent_path.read_text(encoding="utf-8")
    agent_body = strip_frontmatter(agent_md).strip()
    return (
        f"Follow these agent instructions for `{agent_name}`.\n"
        "The task prompt below is authoritative for this run.\n"
        "You must complete required side effects before you return a narrative summary.\n"
        f"{contract}"
        f"Agent instructions:\n\n"
        f"{agent_body}\n\n"
        f"Task for this run:\n\n"
        f"{prompt}"
    )


def main() -> int:
    args = parse_args()
    agent_bin = shutil.which("agent") or shutil.which("cursor-agent")
    if not agent_bin:
        raise SystemExit("Could not find agent or cursor-agent on PATH")

    full_prompt = build_prompt(Path(args.prompt_file), args.agent, args.result_file)
    result = subprocess.run(
        [
            agent_bin,
            "--print",
            "--model",
            args.model,
            "--force",
            "--trust",
            "--workspace",
            args.workspace,
            full_prompt,
        ]
    )
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
