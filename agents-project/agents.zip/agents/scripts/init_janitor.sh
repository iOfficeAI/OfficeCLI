#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
RUNNER="${SCRIPT_DIR}/init_janitor.py"

runner_for_windows_python() {
  if command -v cygpath >/dev/null 2>&1; then
    cygpath -w "$RUNNER"
  elif [[ "$RUNNER" =~ ^/mnt/([a-zA-Z])/(.*)$ ]]; then
    local drive="${BASH_REMATCH[1]}"
    local rest="${BASH_REMATCH[2]//\//\\}"
    printf '%s\n' "${drive^^}:\\${rest}"
  else
    printf '%s\n' "$RUNNER"
  fi
}

if command -v python3 >/dev/null 2>&1; then
  exec python3 "$RUNNER" "$@"
elif command -v py.exe >/dev/null 2>&1; then
  exec py.exe -3 "$(runner_for_windows_python)" "$@"
elif command -v py >/dev/null 2>&1; then
  exec py -3 "$RUNNER" "$@"
elif command -v python.exe >/dev/null 2>&1; then
  exec python.exe "$(runner_for_windows_python)" "$@"
elif command -v python >/dev/null 2>&1; then
  exec python "$RUNNER" "$@"
elif command -v uv >/dev/null 2>&1; then
  exec uv run python "$RUNNER" "$@"
else
  echo "init_janitor.sh requires python3, py.exe, py, python.exe, python, or uv on PATH." >&2
  exit 1
fi
