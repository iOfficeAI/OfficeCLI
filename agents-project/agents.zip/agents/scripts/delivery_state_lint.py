#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Any

from sdlc_common import build_report, emit_report, exit_code_for, is_iso_date, load_yaml


PETITION_STATUS_VALUES = {
    "pending",
    "planned",
    "in-progress",
    "done",
    "blocked",
    "implemented",
    "validated",
    "released",
}
TB_STATUS_VALUES = {"pending", "in-progress", "done"}
ESC_STATUS_VALUES = {"open", "resolved", "closed"}
HOTSPOT_TRIAGE_STATUSES = {"untriaged", "accepted", "planned", "deferred", "waived"}
HOTSPOT_SEVERITIES = {"blocking", "warning", "context"}
ESC_ID_RE = re.compile(r"^ESC-\d+$")
TB_ID_RE = re.compile(r"^TB-\d+$")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Lint program-status.yaml and delivery-state referential integrity."
    )
    parser.add_argument("--json", action="store_true", help="Emit JSON output.")
    parser.add_argument("--root", default=".", help="Project root.")
    parser.add_argument(
        "--petition-id",
        action="append",
        default=[],
        help="Restrict supporting artifact checks to one or more petition IDs.",
    )
    parser.add_argument(
        "--strict-warnings", action="store_true", help="Treat warnings as failures."
    )
    return parser.parse_args()


def canonical_petition_files(root: Path, petition_id: str) -> dict[str, bool]:
    return {
        "petition_doc": (root / "petitions" / f"{petition_id}.md").is_file(),
        "outcome_contract": (
            root / "petitions" / f"{petition_id}-outcome-contract.md"
        ).is_file(),
        "feature_file": (root / "petitions" / f"{petition_id}.feature").is_file(),
        "specs_doc": (
            root / "petitions" / "specs" / f"{petition_id}-specs.yaml"
        ).is_file(),
        "validation_contract": (
            root / "petitions" / "validation" / petition_id / "validation-contract.md"
        ).is_file(),
    }


def collect_review_refs(root: Path) -> dict[str, list[Path]]:
    refs: dict[str, list[Path]] = {}
    for path in sorted((root / "petitions" / "reviews").glob("*.yaml")):
        payload = load_yaml(path)
        if isinstance(payload, dict) and isinstance(payload.get("petition_id"), str):
            refs.setdefault(payload["petition_id"], []).append(path)
    return refs


def collect_telemetry_refs(root: Path) -> dict[str, list[Path]]:
    refs: dict[str, list[Path]] = {}
    for path in sorted((root / "petitions" / "telemetry").glob("*-telemetry.yaml")):
        payload = load_yaml(path)
        if isinstance(payload, dict) and isinstance(payload.get("subject_id"), str):
            refs.setdefault(payload["subject_id"], []).append(path)
    return refs


def main() -> int:
    args = parse_args()
    root = Path(args.root).resolve()
    status_path = root / "petitions" / "program-status.yaml"
    errors: list[str] = []
    warnings: list[str] = []

    if not status_path.is_file():
        report = build_report(
            f"Delivery state lint for {root}",
            errors=["Missing `petitions/program-status.yaml`."],
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    data = load_yaml(status_path)
    if not isinstance(data, dict):
        report = build_report(
            f"Delivery state lint for {root}",
            errors=["`petitions/program-status.yaml` must parse as a mapping."],
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    if not isinstance(data.get("program"), str) or not data["program"].strip():
        errors.append("`program` must be a non-empty string.")
    if not is_iso_date(data.get("last_updated")):
        errors.append("`last_updated` must be YYYY-MM-DD.")

    petitions = data.get("petitions")
    if not isinstance(petitions, list):
        errors.append("`petitions` must be a list.")
        petitions = []
    technical_backlog = data.get("technical_backlog", [])
    if not isinstance(technical_backlog, list):
        errors.append("`technical_backlog` must be a list.")
        technical_backlog = []
    escalations = data.get("escalations", [])
    if not isinstance(escalations, list):
        errors.append("`escalations` must be a list.")
        escalations = []

    petition_ids: set[str] = set()
    filtered_petitions = set(args.petition_id) if args.petition_id else None

    for index, petition in enumerate(petitions):
        if not isinstance(petition, dict):
            errors.append(f"petitions[{index}] must be a mapping.")
            continue
        petition_id = petition.get("id")
        if not isinstance(petition_id, str) or not petition_id.strip():
            errors.append(f"petitions[{index}].id must be a non-empty string.")
            continue
        if petition_id in petition_ids:
            errors.append(f"Duplicate petition id `{petition_id}`.")
            continue
        petition_ids.add(petition_id)
        if filtered_petitions and petition_id not in filtered_petitions:
            continue

        if not isinstance(petition.get("title"), str) or not petition["title"].strip():
            errors.append(f"petition `{petition_id}` must have non-empty title.")
        status = petition.get("status")
        if status not in PETITION_STATUS_VALUES:
            warnings.append(f"petition `{petition_id}` uses unexpected status `{status}`.")
        phase = petition.get("phase")
        if phase is not None and not isinstance(phase, int):
            warnings.append(f"petition `{petition_id}` phase should usually be an integer.")
        depends_on = petition.get("depends_on", [])
        if not isinstance(depends_on, list):
            errors.append(f"petition `{petition_id}` depends_on must be a list.")
            depends_on = []
        for dependency in depends_on:
            if dependency not in petition_ids and dependency not in {
                item.get("id") for item in petitions if isinstance(item, dict)
            }:
                errors.append(
                    f"petition `{petition_id}` depends_on references unknown petition `{dependency}`."
                )
        if status == "released":
            if not isinstance(petition.get("released_in"), str) or not petition["released_in"].strip():
                errors.append(f"released petition `{petition_id}` must declare `released_in`.")
            if not is_iso_date(petition.get("released_date")):
                errors.append(f"released petition `{petition_id}` must declare `released_date`.")
        elif petition.get("released_in") or petition.get("released_date"):
            warnings.append(
                f"petition `{petition_id}` has release metadata but status is `{status}`."
            )
        if status == "blocked" and not str(petition.get("notes", "")).strip():
            warnings.append(f"blocked petition `{petition_id}` should record blocker details in notes.")

    esc_ids: set[str] = set()
    for index, escalation in enumerate(escalations):
        if not isinstance(escalation, dict):
            errors.append(f"escalations[{index}] must be a mapping.")
            continue
        esc_id = escalation.get("id")
        if not isinstance(esc_id, str) or not ESC_ID_RE.fullmatch(esc_id):
            errors.append(f"escalations[{index}].id must match ESC-<number>.")
        elif esc_id in esc_ids:
            errors.append(f"Duplicate escalation id `{esc_id}`.")
        else:
            esc_ids.add(esc_id)
        petition_ref = escalation.get("petition")
        if petition_ref not in {None, "", "~"} and petition_ref not in petition_ids:
            errors.append(
                f"escalation `{esc_id}` references unknown petition `{petition_ref}`."
            )
        status = escalation.get("status")
        if status not in ESC_STATUS_VALUES:
            warnings.append(f"escalation `{esc_id}` uses unexpected status `{status}`.")
        if status in {"resolved", "closed"} and not is_iso_date(escalation.get("resolved_date")):
            errors.append(
                f"resolved escalation `{esc_id}` must declare `resolved_date`."
            )
        if not isinstance(escalation.get("reason"), str) or not escalation["reason"].strip():
            errors.append(f"escalation `{esc_id}` must include a reason.")

    tb_ids: set[str] = set()
    hotspot_finding_ids: set[str] = set()
    for index, item in enumerate(technical_backlog):
        if not isinstance(item, dict):
            errors.append(f"technical_backlog[{index}] must be a mapping.")
            continue
        tb_id = item.get("id")
        if not isinstance(tb_id, str) or not TB_ID_RE.fullmatch(tb_id):
            errors.append(f"technical_backlog[{index}].id must match TB-<number>.")
        elif tb_id in tb_ids:
            errors.append(f"Duplicate technical backlog id `{tb_id}`.")
        else:
            tb_ids.add(tb_id)
        if item.get("status") not in TB_STATUS_VALUES:
            warnings.append(f"technical backlog `{tb_id}` uses unexpected status `{item.get('status')}`.")
        petition_ref = item.get("petition")
        if petition_ref not in {None, "", "~"} and petition_ref not in petition_ids:
            errors.append(
                f"technical backlog `{tb_id}` references unknown petition `{petition_ref}`."
            )
        if item.get("category") == "contract-drift" and not item.get("source_agent"):
            warnings.append(
                f"technical backlog `{tb_id}` is contract-drift but missing source_agent."
            )
        if item.get("category") == "structural-hotspot":
            finding_id = item.get("finding_id")
            if not isinstance(finding_id, str) or not finding_id.strip():
                errors.append(f"technical backlog `{tb_id}` structural-hotspot entries require finding_id.")
            elif finding_id in hotspot_finding_ids:
                errors.append(f"Duplicate structural-hotspot finding_id `{finding_id}` in technical_backlog.")
            else:
                hotspot_finding_ids.add(finding_id)
            severity = item.get("severity")
            if severity not in HOTSPOT_SEVERITIES:
                errors.append(
                    f"technical backlog `{tb_id}` structural-hotspot severity must be blocking, warning, or context."
                )
            triage_status = item.get("triage_status")
            if triage_status not in HOTSPOT_TRIAGE_STATUSES:
                warnings.append(
                    f"technical backlog `{tb_id}` structural-hotspot triage_status should be one of {', '.join(sorted(HOTSPOT_TRIAGE_STATUSES))}."
                )
            evidence_artifact = item.get("evidence_artifact")
            if not isinstance(evidence_artifact, str) or not evidence_artifact.strip():
                warnings.append(
                    f"technical backlog `{tb_id}` structural-hotspot should record evidence_artifact."
                )
            else:
                artifact_path = root / evidence_artifact
                if not artifact_path.is_file():
                    warnings.append(
                        f"technical backlog `{tb_id}` evidence_artifact does not exist: {evidence_artifact}."
                    )

    review_refs = collect_review_refs(root)
    telemetry_refs = collect_telemetry_refs(root)
    scoped_petitions = filtered_petitions or petition_ids

    for petition_id in scoped_petitions:
        if petition_id not in petition_ids:
            errors.append(f"Requested petition `{petition_id}` is not present in program-status.")
            continue
        artifacts = canonical_petition_files(root, petition_id)
        if not artifacts["petition_doc"]:
            warnings.append(f"petition `{petition_id}` is missing canonical petition document.")

    for petition_id, paths in review_refs.items():
        if petition_id not in petition_ids:
            errors.append(
                f"review artifacts reference unknown petition `{petition_id}`: {', '.join(str(path) for path in paths)}."
            )

    for petition_id, paths in telemetry_refs.items():
        if petition_id not in petition_ids:
            errors.append(
                f"telemetry artifacts reference unknown petition `{petition_id}`: {', '.join(str(path) for path in paths)}."
            )
        for path in paths:
            if petition_id not in path.name:
                warnings.append(
                    f"{path}: filename does not contain subject_id `{petition_id}`."
                )

    report = build_report(
        f"Delivery state lint for {root}",
        errors=errors,
        warnings=warnings,
        petition_count=len(petition_ids),
        review_refs={key: [str(path) for path in value] for key, value in review_refs.items()},
        telemetry_refs={key: [str(path) for path in value] for key, value in telemetry_refs.items()},
    )
    emit_report(report, args.json)
    return exit_code_for(report, args.strict_warnings)


if __name__ == "__main__":
    raise SystemExit(main())
