#!/usr/bin/env python3
from __future__ import annotations

import argparse
from datetime import date
from pathlib import Path
from typing import Any

from sdlc_common import (
    build_report,
    deep_merge,
    dir_exists,
    dump_yaml,
    emit_report,
    ensure_string_list,
    exit_code_for,
    file_exists,
    load_data_file,
    normalized_relpath,
    parse_frontmatter_markdown,
    resolve_relative,
    write_text,
    write_yaml,
)


MODULES: dict[str, dict[str, Any]] = {
    "mise_toolchain": {
        "label": "Mise Toolchain",
        "required": True,
        "checks": [{"kind": "file", "path": ".mise.toml"}],
    },
    "project_configuration": {
        "label": "Project Configuration",
        "required": True,
        "checks": [
            {"kind": "file", "path": ".factory/project.yaml"},
            {"kind": "file", "path": ".factory/context/PROJECT_CONTEXT.md"},
            {"kind": "file", "path": ".factory/context/stack.md"},
            {"kind": "file", "path": ".factory/context/testing.md"},
        ],
    },
    "c4_architecture_governance": {
        "label": "C4 Architecture Governance",
        "required": False,
        "checks": [
            {"kind": "file", "path": "architecture/workspace.dsl"},
            {"kind": "file", "path": "architecture/policies.yaml"},
        ],
    },
    "sdlc_planning_infrastructure": {
        "label": "SDLC Planning Infrastructure",
        "required": True,
        "checks": [
            {"kind": "dir", "path": "petitions"},
            {"kind": "file", "path": "petitions/program-status.yaml"},
        ],
    },
    "documentation_scaffold": {
        "label": "Documentation Scaffold",
        "required": False,
        "checks": [
            {"kind": "either_file", "paths": ["AGENTS.md", "agents.md"]},
            {"kind": "dir_with_files", "path": "architecture/adr", "pattern": "*.md"},
            {"kind": "file", "path": "architecture/overview.md"},
        ],
    },
    "compliance_registry": {
        "label": "Compliance Registry",
        "required": False,
        "checks": [
            {"kind": "file", "path": "compliance/nfr-register.yaml"},
            {"kind": "file", "path": "compliance/gdpr-register.csv"},
            {"kind": "file", "path": "compliance/rigsarkivet-assessment.csv"},
        ],
    },
}

OPTIONAL_MODULES = {
    "c4_architecture_governance",
    "documentation_scaffold",
    "compliance_registry",
}
ALLOWED_MODULES = set(MODULES)
DOCS_DEFAULTS = {
    "engine": "mkdocs-material",
    "config": "mkdocs.yml",
    "docs_dir": "docs",
    "site_dir": "site",
    "build_command": "mkdocs build --strict",
    "serve_command": "mkdocs serve",
    "plugins": ["search", "tags", "mermaid2"],
    "site_language": "en",
    "sections": {
        "user": {"language": "en", "label": "User Guide", "enabled": True},
        "developer": {
            "language": "en",
            "label": "Developer Guide",
            "enabled": True,
        },
        "operations": {"language": "en", "label": "Operations", "enabled": True},
        "compliance": {"language": "en", "label": "Compliance", "enabled": False},
    },
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Deterministic bootstrap validation, readiness, and scaffold generation."
    )
    parser.add_argument("--json", action="store_true", help="Emit JSON output.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    validate = subparsers.add_parser(
        "validate-blueprint", help="Validate a project blueprint Markdown file."
    )
    validate.add_argument("--blueprint", required=True, help="Path to blueprint Markdown.")
    validate.add_argument(
        "--strict-warnings", action="store_true", help="Treat warnings as failures."
    )

    readiness = subparsers.add_parser(
        "readiness", help="Scan bootstrap readiness across required modules."
    )
    readiness.add_argument("--root", default=".", help="Project root.")
    readiness.add_argument(
        "--strict-warnings", action="store_true", help="Treat warnings as failures."
    )

    generate = subparsers.add_parser(
        "generate", help="Generate deterministic bootstrap scaffolds from a config file."
    )
    generate.add_argument("--root", default=".", help="Project root.")
    generate.add_argument(
        "--config",
        required=True,
        help="YAML or JSON config with bootstrap values and selected modules.",
    )
    generate.add_argument(
        "--blueprint",
        help="Optional blueprint Markdown file whose frontmatter is merged into the config.",
    )
    generate.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite existing target files instead of skipping them.",
    )
    generate.add_argument(
        "--strict-warnings", action="store_true", help="Treat warnings as failures."
    )
    return parser.parse_args()


def check_module(root: Path, definition: dict[str, Any]) -> tuple[str, list[str]]:
    present = 0
    details: list[str] = []
    checks = definition["checks"]
    for check in checks:
        kind = check["kind"]
        if kind == "file":
            ok = file_exists(root, check["path"])
            details.append(f"{check['path']}: {'found' if ok else 'missing'}")
        elif kind == "dir":
            ok = dir_exists(root, check["path"])
            details.append(f"{check['path']}/: {'found' if ok else 'missing'}")
        elif kind == "either_file":
            ok = any(file_exists(root, path) for path in check["paths"])
            details.append(
                f"{' or '.join(check['paths'])}: {'found' if ok else 'missing'}"
            )
        elif kind == "dir_with_files":
            directory = resolve_relative(root, check["path"])
            ok = directory.is_dir() and any(directory.glob(check["pattern"]))
            details.append(f"{check['path']}/: {'ready' if ok else 'missing'}")
        else:
            raise ValueError(f"Unsupported readiness check kind: {kind}")

        if ok:
            present += 1

    if present == len(checks):
        return "ready", details
    if present == 0:
        return "missing", details
    return "partial", details


def scan_readiness(root: Path) -> dict[str, Any]:
    modules: dict[str, Any] = {}
    for module_id, definition in MODULES.items():
        status, details = check_module(root, definition)
        modules[module_id] = {
            "label": definition["label"],
            "required": definition["required"],
            "status": status,
            "details": details,
        }
    return modules


def validate_blueprint_data(data: dict[str, Any]) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    if not isinstance(data.get("name"), str) or not data["name"].strip():
        errors.append("Blueprint frontmatter must include non-empty `name`.")
    if not isinstance(data.get("description"), str) or not data["description"].strip():
        errors.append("Blueprint frontmatter must include non-empty `description`.")

    mise = data.get("mise")
    if not isinstance(mise, dict):
        errors.append("Blueprint must include `mise` mapping.")
        mise = {}
    tools = mise.get("tools")
    if not isinstance(tools, dict) or not tools:
        errors.append("Blueprint `mise.tools` must be a non-empty mapping.")

    project = data.get("project")
    if project is not None and not isinstance(project, dict):
        errors.append("Blueprint `project` must be a mapping when present.")
        project = {}
    project = project or {}

    frameworks = data.get("frameworks")
    if frameworks is not None and not isinstance(frameworks, dict):
        errors.append("Blueprint `frameworks` must be a mapping when present.")
        frameworks = {}
    frameworks = frameworks or {}

    build = project.get("build")
    if build is not None:
        if not isinstance(build, dict):
            errors.append("Blueprint `project.build` must be a mapping.")
        else:
            for key in ("compile", "test", "lint"):
                if key not in build or not str(build[key]).strip():
                    errors.append(f"Blueprint `project.build.{key}` is required when build is declared.")

    rendering_mode = frameworks.get("rendering_model")
    browser_ui = has_browser_ui(frameworks, rendering_mode)
    if browser_ui and not isinstance(project.get("e2e"), dict):
        errors.append("Blueprint with browser UI must define `project.e2e`.")
    if isinstance(project.get("e2e"), dict):
        for key in (
            "framework",
            "project_root",
            "test_dir",
            "config",
            "install_command",
            "type_check_command",
            "test_list_command",
            "runner",
            "report_dir",
        ):
            if key not in project["e2e"] or not str(project["e2e"][key]).strip():
                errors.append(f"Blueprint `project.e2e.{key}` is required when `project.e2e` is declared.")

    compliance = data.get("compliance") or {}
    if compliance and not isinstance(compliance, dict):
        errors.append("Blueprint `compliance` must be a mapping when present.")
    else:
        for key in ("gdpr", "rigsarkivet"):
            value = compliance.get(key)
            if value is None:
                continue
            if not isinstance(value, bool) and value != "unknown":
                errors.append(
                    f"Blueprint `compliance.{key}` must be true, false, or 'unknown'."
                )

    for key in ("containers", "external_systems", "adr_principles"):
        value = data.get(key)
        if value is not None and not isinstance(value, list):
            errors.append(f"Blueprint `{key}` must be a list when present.")

    if not project:
        warnings.append("Blueprint does not define `project` defaults, so generator input must supply them.")

    return errors, warnings


def has_browser_ui(frameworks: dict[str, Any], rendering_mode: Any) -> bool:
    ui_items = [item.lower() for item in ensure_string_list(frameworks.get("ui"))]
    if any(item not in {"none", "api-only"} for item in ui_items):
        return True
    return str(rendering_mode or "").strip().lower() in {"spa", "server-rendered", "hybrid"}


def load_generation_config(config_path: Path, blueprint_path: Path | None) -> dict[str, Any]:
    config_data = load_data_file(config_path) or {}
    if not isinstance(config_data, dict):
        raise ValueError(f"{config_path}: config must be a mapping")

    if blueprint_path is None:
        return config_data

    blueprint_data, _ = parse_frontmatter_markdown(blueprint_path)
    return deep_merge(blueprint_data, config_data)


def validate_generation_config(config: dict[str, Any]) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    selected_modules = set(ensure_string_list(config.get("selected_modules")))
    unknown_modules = sorted(selected_modules - OPTIONAL_MODULES)
    if unknown_modules:
        errors.append(f"Unknown optional modules: {', '.join(unknown_modules)}")

    system_name = str(config.get("system_name") or config.get("name") or "").strip()
    if not system_name:
        errors.append("Generation config must include `system_name` or `name`.")

    mise = config.get("mise")
    if not isinstance(mise, dict) or not isinstance(mise.get("tools"), dict) or not mise["tools"]:
        errors.append("Generation config must include non-empty `mise.tools`.")

    project = config.get("project")
    if not isinstance(project, dict):
        errors.append("Generation config must include `project` mapping.")
        project = {}

    for key in ("language", "runtime", "test_framework"):
        if not str(project.get(key, "")).strip():
            errors.append(f"Generation config must include `project.{key}`.")

    for key in ("source_directories", "test_directories"):
        values = ensure_string_list(project.get(key))
        if not values:
            errors.append(f"Generation config must include non-empty `project.{key}`.")

    build = project.get("build")
    if not isinstance(build, dict):
        errors.append("Generation config must include `project.build` mapping.")
    else:
        for key in ("compile", "test", "lint"):
            if not str(build.get(key, "")).strip():
                errors.append(f"Generation config must include `project.build.{key}`.")

    frameworks = config.get("frameworks")
    if frameworks is not None and not isinstance(frameworks, dict):
        errors.append("Generation config `frameworks` must be a mapping when present.")
        frameworks = {}
    frameworks = frameworks or {}

    rendering_mode = frameworks.get("rendering_model") or frameworks.get("rendering", {}).get("mode")
    if has_browser_ui(frameworks, rendering_mode):
        e2e = project.get("e2e")
        if not isinstance(e2e, dict):
            errors.append("Browser UI config requires `project.e2e`.")
        else:
            for key in (
                "framework",
                "project_root",
                "test_dir",
                "config",
                "install_command",
                "type_check_command",
                "test_list_command",
                "runner",
                "report_dir",
            ):
                if not str(e2e.get(key, "")).strip():
                    errors.append(f"Browser UI config requires `project.e2e.{key}`.")

    if not config.get("description"):
        warnings.append("Generation config omits `description`; generated docs will use a stub summary.")

    return errors, warnings


def toml_value(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    return f'"{value}"'


def render_mise_toml(config: dict[str, Any]) -> str:
    mise = config["mise"]
    lines = ["[tools]"]
    for key, value in mise["tools"].items():
        lines.append(f"{key} = {toml_value(value)}")
    env = mise.get("env") or {}
    if env:
        lines.append("")
        lines.append("[env]")
        for key, value in env.items():
            lines.append(f"{key} = {toml_value(value)}")
    return "\n".join(lines) + "\n"


def build_project_yaml(config: dict[str, Any]) -> dict[str, Any]:
    system_name = str(config.get("system_name") or config.get("name")).strip()
    project = dict(config["project"])
    frameworks = dict(config.get("frameworks") or {})
    docs = deep_merge(DOCS_DEFAULTS, project.get("docs") or {})
    project["name"] = system_name
    project["source_directories"] = [
        normalized_relpath(value) for value in ensure_string_list(project.get("source_directories"))
    ]
    project["test_directories"] = [
        normalized_relpath(value) for value in ensure_string_list(project.get("test_directories"))
    ]
    project["docs"] = docs

    if project.get("bdd", {}).get("framework") in {"", "none", None}:
        project.pop("bdd", None)

    if not project.get("e2e") and not has_browser_ui(
        frameworks, frameworks.get("rendering_model")
    ):
        project.pop("e2e", None)

    rendering_mode = str(frameworks.get("rendering_model") or "unknown")
    stack = {
        "languages": ensure_string_list(config.get("stack", {}).get("languages"))
        or [str(project["language"])],
        "runtimes": ensure_string_list(config.get("stack", {}).get("runtimes"))
        or [str(project["runtime"])],
        "frameworks": {
            "backend": ensure_string_list(frameworks.get("backend")) or ["none"],
            "ui": ensure_string_list(frameworks.get("ui")) or ["none"],
            "data": ensure_string_list(frameworks.get("data")) or ["none"],
            "integration": ensure_string_list(frameworks.get("integration")) or ["none"],
            "testing": ensure_string_list(frameworks.get("testing"))
            or [str(project["test_framework"])],
        },
        "rendering": {
            "mode": rendering_mode,
            "dynamic_interaction": str(
                frameworks.get("dynamic_interaction") or "unknown"
            ),
        },
        "notes": ensure_string_list(config.get("stack", {}).get("notes")),
    }

    data: dict[str, Any] = {
        "project": project,
        "stack": stack,
    }

    if isinstance(config.get("agent_workflow"), dict):
        data["agent_workflow"] = config["agent_workflow"]
    if isinstance(config.get("harness"), dict):
        data["harness"] = config["harness"]
    if isinstance(config.get("compliance"), dict):
        data["compliance"] = config["compliance"]
    return data


def render_project_context(project_data: dict[str, Any]) -> str:
    project = project_data["project"]
    stack = project_data["stack"]
    return "\n".join(
        [
            f"# Project Context — {project['name']}",
            "<!-- Managed by: bootstrap_tool.py -->",
            "<!-- Derived from: `.factory/project.yaml` -->",
            "",
            "## Canonical Config",
            "- `.factory/project.yaml` is the source of truth for build, test, and stack metadata.",
            "",
            "## Snapshot",
            f"- Primary language: {project['language']}",
            f"- Runtime: {project['runtime']}",
            f"- Source dirs: {', '.join(project['source_directories'])}",
            f"- Test dirs: {', '.join(project['test_directories'])}",
            f"- Test framework: {project['test_framework']}",
            f"- Rendering mode: {stack['rendering']['mode']}",
            "",
        ]
    )


def render_stack_context(project_data: dict[str, Any]) -> str:
    stack = project_data["stack"]
    return "\n".join(
        [
            "# Stack Context",
            "<!-- Managed by: bootstrap_tool.py -->",
            "<!-- Derived from: `.factory/project.yaml` -->",
            "",
            f"- Languages: {', '.join(stack['languages'])}",
            f"- Runtimes: {', '.join(stack['runtimes'])}",
            f"- Backend: {', '.join(stack['frameworks']['backend'])}",
            f"- UI: {', '.join(stack['frameworks']['ui'])}",
            f"- Data: {', '.join(stack['frameworks']['data'])}",
            f"- Integration: {', '.join(stack['frameworks']['integration'])}",
            f"- Testing: {', '.join(stack['frameworks']['testing'])}",
            "",
        ]
    )


def render_testing_context(project_data: dict[str, Any]) -> str:
    project = project_data["project"]
    lines = [
        "# Testing Context",
        "<!-- Managed by: bootstrap_tool.py -->",
        "<!-- Derived from: `.factory/project.yaml` -->",
        "",
        f"- Test framework: {project['test_framework']}",
        f"- Test command: {project['build']['test']}",
        f"- Lint command: {project['build']['lint']}",
    ]
    if "bdd" in project:
        lines.extend(
            [
                f"- BDD framework: {project['bdd']['framework']}",
                f"- BDD runner: {project['bdd']['runner']}",
            ]
        )
    if "e2e" in project:
        lines.extend(
            [
                f"- E2E framework: {project['e2e']['framework']}",
                f"- E2E runner: {project['e2e']['runner']}",
            ]
        )
    lines.append("")
    return "\n".join(lines)


def render_program_status(system_name: str) -> dict[str, Any]:
    return {
        "program": system_name,
        "last_updated": str(date.today()),
        "petitions": [],
        "technical_backlog": [],
        "escalations": [],
    }


def render_workspace_dsl(config: dict[str, Any]) -> str:
    system_name = str(config.get("system_name") or config.get("name")).strip()
    description = str(config.get("description") or "[STUB — update with real content]")
    containers = config.get("containers") or [
        {
            "id": "app",
            "name": "Application",
            "description": "[STUB — update with real content]",
            "technology": "[STUB — update with real content]",
        }
    ]
    externals = config.get("external_systems") or []

    lines = [
        f'workspace "{system_name}" "Bootstrap scaffold" {{',
        "  model {",
        f'    system = softwareSystem "{system_name}" "{description}"',
    ]
    for item in externals:
        lines.append(
            f'    {item.get("name", "external").replace(" ", "")} = softwareSystem "{item.get("name", "External System")}" "{item.get("description", "[STUB — update with real content]")}"'
        )
    for container in containers:
        lines.append(
            f'    {container.get("id", "container")} = container system "{container.get("name", "Container")}" "{container.get("description", "[STUB — update with real content]")}" "{container.get("technology", "[STUB — update with real content]")}"'
        )
    lines.extend(
        [
            "  }",
            "  views {",
            '    systemContext system "system-context" {',
            "      include *",
            "      autolayout lr",
            "    }",
            '    container system "container-overview" {',
            "      include *",
            "      autolayout lr",
            "    }",
            "  }",
            "}",
            "",
        ]
    )
    return "\n".join(lines)


def render_policies_yaml() -> dict[str, Any]:
    return {
        "policies": [
            {
                "id": "ARCH-001",
                "title": "Declare runtime topology in workspace.dsl",
                "description": "[STUB — update with real content]",
                "severity": "blocking",
            }
        ]
    }


def render_agents_md(system_name: str) -> str:
    return "\n".join(
        [
            f"# Agents — {system_name}",
            "",
            "This file captures project-specific agent conventions for this repository.",
            "",
            "## Local Rules",
            "- `.factory/project.yaml` is the canonical delivery configuration.",
            "- `architecture/workspace.dsl` is the canonical topology source.",
            "- `implementation-doc-sync` owns updates to this file when repository-specific guidance changes.",
            "",
        ]
    )


def render_architecture_overview(system_name: str) -> str:
    return "\n".join(
        [
            f"# Architecture Overview — {system_name}",
            "",
            "[STUB — update with real content]",
            "",
            "## Canonical Sources",
            "- `architecture/workspace.dsl`",
            "- `architecture/adr/0001-architecture-principles.md`",
            "",
        ]
    )


def render_adr(system_name: str, principles: list[str]) -> str:
    principle_lines = principles or ["[STUB — update with real content]"]
    rendered_principles = "\n".join(f"- {line}" for line in principle_lines)
    return "\n".join(
        [
            f"# ADR-0001: {system_name} Architecture Principles",
            "",
            "## Status",
            "Accepted",
            "",
            "## Context",
            "[STUB — update with real content]",
            "",
            "## Decision",
            rendered_principles,
            "",
            "## Consequences",
            "- `architecture/workspace.dsl` must stay aligned with the implemented topology.",
            "",
        ]
    )


def render_nfr_register(system_name: str) -> dict[str, Any]:
    return {
        "program": system_name,
        "nfrs": [
            {
                "id": "NFR-001",
                "title": "Availability",
                "scope": "all",
                "status": "draft",
                "notes": "[STUB — update with real content]",
            }
        ],
    }


def render_csv(headers: list[str], row: list[str]) -> str:
    return ",".join(headers) + "\n" + ",".join(row) + "\n"


def write_if_allowed(
    target: Path,
    content: str,
    *,
    overwrite: bool,
    written: list[str],
    skipped: list[str],
) -> None:
    if target.exists() and not overwrite:
        skipped.append(str(target))
        return
    write_text(target, content)
    written.append(str(target))


def write_yaml_if_allowed(
    target: Path,
    data: Any,
    *,
    overwrite: bool,
    written: list[str],
    skipped: list[str],
) -> None:
    if target.exists() and not overwrite:
        skipped.append(str(target))
        return
    write_yaml(target, data)
    written.append(str(target))


def generate_scaffolds(root: Path, config: dict[str, Any], overwrite: bool) -> tuple[list[str], list[str]]:
    written: list[str] = []
    skipped: list[str] = []
    selected_modules = set(ensure_string_list(config.get("selected_modules")))
    system_name = str(config.get("system_name") or config.get("name")).strip()

    project_yaml = build_project_yaml(config)
    required_files = {
        ".mise.toml": render_mise_toml(config),
        ".factory/context/PROJECT_CONTEXT.md": render_project_context(project_yaml),
        ".factory/context/stack.md": render_stack_context(project_yaml),
        ".factory/context/testing.md": render_testing_context(project_yaml),
    }

    for relative_path, content in required_files.items():
        write_if_allowed(
            resolve_relative(root, relative_path),
            content,
            overwrite=overwrite,
            written=written,
            skipped=skipped,
        )

    write_yaml_if_allowed(
        resolve_relative(root, ".factory/project.yaml"),
        project_yaml,
        overwrite=overwrite,
        written=written,
        skipped=skipped,
    )
    write_yaml_if_allowed(
        resolve_relative(root, "petitions/program-status.yaml"),
        render_program_status(system_name),
        overwrite=overwrite,
        written=written,
        skipped=skipped,
    )
    resolve_relative(root, "petitions").mkdir(parents=True, exist_ok=True)

    if "c4_architecture_governance" in selected_modules:
        write_if_allowed(
            resolve_relative(root, "architecture/workspace.dsl"),
            render_workspace_dsl(config),
            overwrite=overwrite,
            written=written,
            skipped=skipped,
        )
        write_yaml_if_allowed(
            resolve_relative(root, "architecture/policies.yaml"),
            render_policies_yaml(),
            overwrite=overwrite,
            written=written,
            skipped=skipped,
        )

    if "documentation_scaffold" in selected_modules:
        agents_path = resolve_relative(root, "AGENTS.md")
        if not agents_path.exists() and resolve_relative(root, "agents.md").exists():
            agents_path = resolve_relative(root, "agents.md")
        write_if_allowed(
            agents_path,
            render_agents_md(system_name),
            overwrite=overwrite,
            written=written,
            skipped=skipped,
        )
        write_if_allowed(
            resolve_relative(root, "architecture/overview.md"),
            render_architecture_overview(system_name),
            overwrite=overwrite,
            written=written,
            skipped=skipped,
        )
        write_if_allowed(
            resolve_relative(root, "architecture/adr/0001-architecture-principles.md"),
            render_adr(system_name, ensure_string_list(config.get("adr_principles"))),
            overwrite=overwrite,
            written=written,
            skipped=skipped,
        )

    if "compliance_registry" in selected_modules:
        compliance = config.get("compliance") or {}
        gdpr_value = str(compliance.get("gdpr", "unknown"))
        rigsarkivet_value = str(compliance.get("rigsarkivet", "unknown"))
        write_yaml_if_allowed(
            resolve_relative(root, "compliance/nfr-register.yaml"),
            render_nfr_register(system_name),
            overwrite=overwrite,
            written=written,
            skipped=skipped,
        )
        write_if_allowed(
            resolve_relative(root, "compliance/gdpr-register.csv"),
            render_csv(
                ["system", "applicability", "notes"],
                [system_name, gdpr_value, "[STUB — update with real content]"],
            ),
            overwrite=overwrite,
            written=written,
            skipped=skipped,
        )
        write_if_allowed(
            resolve_relative(root, "compliance/rigsarkivet-assessment.csv"),
            render_csv(
                ["system", "applicability", "notes"],
                [system_name, rigsarkivet_value, "[STUB — update with real content]"],
            ),
            overwrite=overwrite,
            written=written,
            skipped=skipped,
        )

    return written, skipped


def handle_validate_blueprint(args: argparse.Namespace) -> int:
    blueprint_path = Path(args.blueprint).resolve()
    data, _ = parse_frontmatter_markdown(blueprint_path)
    errors, warnings = validate_blueprint_data(data)
    report = build_report(
        f"Blueprint validation for {blueprint_path.name}",
        errors=errors,
        warnings=warnings,
        blueprint=str(blueprint_path),
    )
    emit_report(report, args.json)
    return exit_code_for(report, args.strict_warnings)


def handle_readiness(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    modules = scan_readiness(root)
    warnings = [
        f"{details['label']} is {details['status']}"
        for details in modules.values()
        if details["status"] != "ready" and not details["required"]
    ]
    errors = [
        f"{details['label']} is {details['status']}"
        for details in modules.values()
        if details["status"] != "ready" and details["required"]
    ]
    report = build_report(
        f"Bootstrap readiness scan for {root}",
        errors=errors,
        warnings=warnings,
        modules=modules,
    )
    emit_report(report, args.json)
    return exit_code_for(report, args.strict_warnings)


def handle_generate(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    config = load_generation_config(
        Path(args.config).resolve(),
        Path(args.blueprint).resolve() if args.blueprint else None,
    )
    errors, warnings = validate_generation_config(config)
    if errors:
        report = build_report(
            f"Bootstrap generation blocked for {root}",
            errors=errors,
            warnings=warnings,
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    written, skipped = generate_scaffolds(root, config, args.overwrite)
    report = build_report(
        f"Bootstrap scaffolds generated for {root}",
        warnings=warnings,
        written=written,
        skipped=skipped,
    )
    emit_report(report, args.json)
    return exit_code_for(report, args.strict_warnings)


def main() -> int:
    args = parse_args()
    if args.command == "validate-blueprint":
        return handle_validate_blueprint(args)
    if args.command == "readiness":
        return handle_readiness(args)
    if args.command == "generate":
        return handle_generate(args)
    raise ValueError(f"Unsupported command: {args.command}")


if __name__ == "__main__":
    raise SystemExit(main())
