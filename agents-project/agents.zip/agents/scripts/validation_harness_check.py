#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

from sdlc_common import (
    build_report,
    emit_report,
    exit_code_for,
    first_existing,
    is_browser_ui,
    load_project_config,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Check browser UI validation harness requirements deterministically."
    )
    parser.add_argument("--json", action="store_true", help="Emit JSON output.")
    parser.add_argument("--root", default=".", help="Project root.")
    parser.add_argument("--petition-id", help="Optional petition ID for canonical validation-contract lookup.")
    parser.add_argument(
        "--strict-warnings", action="store_true", help="Treat warnings as failures."
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.root).resolve()
    errors: list[str] = []
    warnings: list[str] = []

    try:
        config = load_project_config(root)
    except ValueError as exc:
        report = build_report(f"Validation harness check for {root}", errors=[str(exc)])
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    if config is None:
        report = build_report(
            f"Validation harness check for {root}",
            errors=["Missing `.factory/project.yaml`."],
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    stack = config.get("stack")
    if not isinstance(stack, dict):
        report = build_report(
            f"Validation harness check for {root}",
            errors=["`.factory/project.yaml` missing `stack` mapping."],
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    frameworks = stack.get("frameworks")
    rendering = stack.get("rendering")
    if not isinstance(frameworks, dict) or not isinstance(rendering, dict):
        report = build_report(
            f"Validation harness check for {root}",
            errors=["`.factory/project.yaml` missing `stack.frameworks` or `stack.rendering`."],
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    browser_ui = is_browser_ui(frameworks, str(rendering.get("mode") or ""))
    if not browser_ui:
        report = build_report(
            f"Validation harness check for {root}",
            browser_ui=False,
            validation_required=False,
            summary="Project is API-only or otherwise non-browser UI; validation harness is not required.",
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    user_testing_doc = first_existing(
        root,
        [
            ".factory/library/user-testing.md",
            "docs/user-testing.md",
            "user-testing.md",
        ],
    )
    contract_candidates: list[Path] = []
    if args.petition_id:
        candidate = root / "petitions" / "validation" / args.petition_id / "validation-contract.md"
        if candidate.is_file():
            contract_candidates.append(candidate)
    contract_candidates.extend(sorted((root / "petitions" / "validation").glob("*/validation-contract.md")))
    contract_candidates.extend(sorted((root / ".factory" / "validation").glob("*/validation-contract.md")))
    seen_contracts: list[Path] = []
    seen_paths: set[Path] = set()
    for path in contract_candidates:
        resolved = path.resolve()
        if resolved not in seen_paths:
            seen_paths.add(resolved)
            seen_contracts.append(path)

    if user_testing_doc is None:
        errors.append("Browser UI project is missing `.factory/library/user-testing.md` or equivalent.")
    if not seen_contracts:
        errors.append("Browser UI project is missing a validation contract.")

    service_config = first_existing(root, [".factory/services.yaml"])
    if service_config is None:
        warnings.append("`.factory/services.yaml` is missing; app URL resolution may need manual input.")

    report = build_report(
        f"Validation harness check for {root}",
        errors=errors,
        warnings=warnings,
        browser_ui=True,
        validation_required=True,
        user_testing_doc=str(user_testing_doc) if user_testing_doc else None,
        validation_contracts=[str(path) for path in seen_contracts],
        service_config=str(service_config) if service_config else None,
    )
    emit_report(report, args.json)
    return exit_code_for(report, args.strict_warnings)


if __name__ == "__main__":
    raise SystemExit(main())
