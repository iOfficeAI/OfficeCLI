#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import fnmatch
import json
import shutil
import subprocess
import sys
import textwrap
from dataclasses import dataclass
from pathlib import Path
from typing import Any

try:
    import yaml  # type: ignore
except ImportError as exc:  # pragma: no cover - import guard
    raise SystemExit(
        "PyYAML is required for scripts/janitor.py. Install with "
        "`pip install pyyaml` or `uv add --dev pyyaml`."
    ) from exc


class JanitorError(RuntimeError):
    pass


@dataclass
class RepoRunConfig:
    path: Path
    base_branch: str | None = None
    agent_command_template: str | None = None
    open_pr_command_template: str | None = None


@dataclass
class ExecutionContext:
    anchor_repo: Path
    repo: Path
    created_worktree: bool = False
    cleanup_worktree: bool = False


JANITOR_RESULT_STATUSES = {"success", "skipped", "blocked"}
PLAN_STEP_STATUSES = {"planned", "completed", "skipped", "blocked"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run janitor automation for one or more repos."
    )
    parser.add_argument("--repo", help="Path to a single repo to janitor.")
    parser.add_argument(
        "--config",
        help="Path to runner config YAML. Supports repo list and command templates.",
    )
    parser.add_argument(
        "--agent-command-template",
        help=(
            "Command template used to launch the janitor agent. "
            "Placeholders: {repo} {prompt} {result} {branch} "
            "{scan_head} {previous_base} {base_branch} {agent}"
        ),
    )
    parser.add_argument(
        "--open-pr-command-template",
        help=(
            "Optional command template used after push in PR mode. "
            "Placeholders: {repo} {branch} {base_branch} {title} {body_file}"
        ),
    )
    parser.add_argument(
        "--allow-direct-push",
        action="store_true",
        help="Allow direct push when repo policy sets mode=direct.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print planned actions without launching agent, committing, or pushing.",
    )
    parser.add_argument(
        "--cleanup-stale-janitor-worktrees",
        action="store_true",
        help=(
            "Maintenance mode: prune clean janitor-owned worktrees and their branches "
            "without running the janitor agent."
        ),
    )
    return parser.parse_args()


def git(
    repo: Path, *args: str, check: bool = True, capture_output: bool = True
) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        ["git", *args],
        cwd=repo,
        text=True,
        capture_output=capture_output,
    )
    if check and result.returncode != 0:
        stderr = (result.stderr or "").strip()
        stdout = (result.stdout or "").strip()
        detail = stderr or stdout or f"git {' '.join(args)} failed"
        raise JanitorError(detail)
    return result


def git_output(repo: Path, *args: str) -> str:
    return git(repo, *args).stdout.strip()


def git_dir(repo: Path) -> Path:
    raw = git_output(repo, "rev-parse", "--git-dir")
    path = Path(raw)
    if not path.is_absolute():
        path = (repo / path).resolve()
    return path


def auto_trust_mise(repo: Path, dry_run: bool) -> None:
    if shutil.which("mise") is None:
        return

    has_mise_config = any(
        (repo / name).exists()
        for name in (".mise.toml", "mise.toml", "mise.local.toml", "mise.prod.toml")
    )
    if not has_mise_config:
        return

    print(f"[mise] trust config in {repo}")
    if dry_run:
        return

    result = subprocess.run(
        ["mise", "trust", "-y", "--all"],
        cwd=repo,
        text=True,
        capture_output=True,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip() or "mise trust failed"
        raise JanitorError(f"Failed to trust mise config in {repo}: {detail}")


def run_shell(
    command: str,
    cwd: Path,
    label: str,
    dry_run: bool = False,
    stdout_path: Path | None = None,
    stderr_path: Path | None = None,
) -> None:
    print(f"[{label}] {command}")
    if dry_run:
        return
    capture_output = stdout_path is not None or stderr_path is not None
    result = subprocess.run(
        command,
        cwd=cwd,
        shell=True,
        text=True,
        capture_output=capture_output,
    )
    if capture_output:
        stdout_text = result.stdout or ""
        stderr_text = result.stderr or ""
        if stdout_path is not None:
            stdout_path.write_text(stdout_text, encoding="utf-8")
        if stderr_path is not None:
            stderr_path.write_text(stderr_text, encoding="utf-8")
        if stdout_text:
            print(stdout_text, end="" if stdout_text.endswith("\n") else "\n")
        if stderr_text:
            print(stderr_text, file=sys.stderr, end="" if stderr_text.endswith("\n") else "\n")
    if result.returncode != 0:
        raise JanitorError(f"{label} failed: {command}")


def load_yaml(path: Path) -> dict[str, Any]:
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except FileNotFoundError as exc:
        raise JanitorError(f"Missing file: {path}") from exc
    if not isinstance(data, dict):
        raise JanitorError(f"Expected mapping in {path}")
    return data


def save_yaml(path: Path, data: dict[str, Any]) -> None:
    path.write_text(
        yaml.safe_dump(data, sort_keys=False, allow_unicode=False),
        encoding="utf-8",
    )


def load_runner_repos(args: argparse.Namespace) -> list[RepoRunConfig]:
    repos: list[RepoRunConfig] = []

    if args.config:
        config = load_yaml(Path(args.config).resolve())
        default_agent = config.get("agent_command_template")
        default_pr = config.get("open_pr_command_template")
        for item in config.get("repos", []):
            if not isinstance(item, dict) or "path" not in item:
                raise JanitorError("Each repo entry in runner config needs a path.")
            repos.append(
                RepoRunConfig(
                    path=Path(str(item["path"])).resolve(),
                    base_branch=item.get("base_branch"),
                    agent_command_template=item.get(
                        "agent_command_template", default_agent
                    ),
                    open_pr_command_template=item.get(
                        "open_pr_command_template", default_pr
                    ),
                )
            )

    if args.repo:
        repos.append(
            RepoRunConfig(
                path=Path(args.repo).resolve(),
                agent_command_template=args.agent_command_template,
                open_pr_command_template=args.open_pr_command_template,
            )
        )

    if not repos:
        raise JanitorError("Provide --repo or --config.")

    return repos


def resolve_default_branch(repo: Path, configured: str | None) -> str:
    if configured:
        return configured
    try:
        ref = git_output(repo, "symbolic-ref", "refs/remotes/origin/HEAD")
        return ref.rsplit("/", 1)[-1]
    except JanitorError:
        for candidate in ("main", "master"):
            if git(repo, "show-ref", "--verify", f"refs/heads/{candidate}", check=False).returncode == 0:
                return candidate
        return "main"


def ensure_clean_worktree(repo: Path) -> None:
    status = git_output(repo, "status", "--porcelain")
    if status:
        raise JanitorError("Working tree is dirty; janitor requires a clean repo.")


def ensure_valid_policy(repo: Path) -> dict[str, Any]:
    policy_path = repo / ".janitor.yml"
    if not policy_path.exists():
        raise JanitorError(f"{repo}: missing .janitor.yml")
    policy = load_yaml(policy_path)
    if not policy.get("enabled", False):
        raise JanitorError(f"{repo}: janitor disabled in .janitor.yml")
    return policy


def validate_base(repo: Path, base: str, head: str) -> None:
    if not base:
        raise JanitorError("last_janitor_base missing from .janitor.yml")
    exists = git(repo, "rev-parse", "--verify", base, check=False)
    if exists.returncode != 0:
        raise JanitorError(f"last_janitor_base is invalid: {base}")
    reachable = git(repo, "merge-base", "--is-ancestor", base, head, check=False)
    if reachable.returncode != 0:
        raise JanitorError(f"last_janitor_base is not an ancestor of HEAD: {base}")


def count_new_commits(repo: Path, previous_base: str, head: str) -> int:
    raw = git_output(repo, "rev-list", "--count", f"{previous_base}..{head}")
    return int(raw or "0")


def build_branch_name(prefix: str, head: str, sequence: int = 1) -> str:
    if not prefix:
        prefix = "janitor/"
    if prefix.endswith("/"):
        base = f"{prefix}{head[:7]}"
    else:
        base = f"{prefix}-{head[:7]}"
    if sequence <= 1:
        return base
    return f"{base}-{sequence}"


def branch_exists(repo: Path, branch: str) -> bool:
    exists = git(repo, "show-ref", "--verify", f"refs/heads/{branch}", check=False)
    return exists.returncode == 0


def ensure_branch_missing(repo: Path, branch: str) -> None:
    if branch_exists(repo, branch):
        raise JanitorError(
            f"Branch already exists locally: {branch}. Clean it up or choose new prefix."
        )


def resolve_worktree_root(repo: Path, execution: dict[str, Any]) -> Path:
    configured_root = str(execution.get("worktree_root", "")).strip()
    if configured_root:
        return Path(configured_root).expanduser().resolve()
    return (repo.parent / f".{repo.name}-janitor-worktrees").resolve()


def parse_worktree_branches(repo: Path) -> dict[str, Path]:
    raw = git_output(repo, "worktree", "list", "--porcelain")
    if not raw:
        return {}

    branch_to_path: dict[str, Path] = {}
    current_path: Path | None = None
    for line in raw.splitlines():
        if not line:
            current_path = None
            continue
        if line.startswith("worktree "):
            current_path = Path(line.removeprefix("worktree ")).resolve()
            continue
        if line.startswith("branch ") and current_path is not None:
            ref = line.removeprefix("branch ").strip()
            branch = ref.removeprefix("refs/heads/")
            branch_to_path[branch] = current_path
    return branch_to_path


def path_is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def cleanup_stale_janitor_branch(
    repo: Path,
    branch: str,
    branch_prefix: str,
    worktree_root: Path,
    dry_run: bool,
) -> bool:
    worktree_path = parse_worktree_branches(repo).get(branch)
    if worktree_path is None:
        return False
    if branch_prefix and not branch.startswith(branch_prefix):
        return False
    if not path_is_within(worktree_path, worktree_root):
        return False

    dirty = False
    if worktree_path.exists():
        dirty = bool(git_output(worktree_path, "status", "--porcelain"))
    if dirty:
        print(f"[git] keep stale janitor worktree {worktree_path} (dirty)")
        return False

    print(f"[git] remove stale janitor worktree {worktree_path}")
    if not dry_run:
        git(
            repo,
            "worktree",
            "remove",
            "--force",
            str(worktree_path),
            capture_output=False,
        )

    if branch_exists(repo, branch):
        print(f"[git] delete stale janitor branch {branch}")
        if not dry_run:
            git(repo, "branch", "-D", branch, capture_output=False)
    return True


def cleanup_stale_janitor_worktrees(
    repo: Path, policy: dict[str, Any], dry_run: bool
) -> tuple[int, int]:
    execution = policy.get("execution", {}) or {}
    worktree_root = resolve_worktree_root(repo, execution)
    branch_prefix = str(policy.get("branch_prefix", "janitor/"))

    print(f"[git] prune stale worktree metadata in {repo}")
    if not dry_run:
        git(repo, "worktree", "prune", capture_output=False)

    removed = 0
    kept = 0
    for branch, worktree_path in sorted(parse_worktree_branches(repo).items()):
        if branch_prefix and not branch.startswith(branch_prefix):
            continue
        if not path_is_within(worktree_path, worktree_root):
            continue

        dirty = False
        if worktree_path.exists():
            dirty = bool(git_output(worktree_path, "status", "--porcelain"))
        if dirty:
            print(f"[git] keep janitor worktree {worktree_path} (dirty)")
            kept += 1
            continue

        print(f"[git] remove janitor worktree {worktree_path}")
        if not dry_run:
            git(
                repo,
                "worktree",
                "remove",
                "--force",
                str(worktree_path),
                capture_output=False,
            )

        if branch_exists(repo, branch):
            print(f"[git] delete janitor branch {branch}")
            if not dry_run:
                git(repo, "branch", "-D", branch, capture_output=False)
        removed += 1

    if removed == 0 and kept == 0:
        print(f"[done] no janitor worktrees found under {worktree_root}")
    else:
        print(f"[done] janitor worktrees removed={removed} kept={kept}")
    return removed, kept


def resolve_branch_name(repo: Path, policy: dict[str, Any], head: str, dry_run: bool) -> str:
    prefix = str(policy.get("branch_prefix", "janitor/"))
    execution = policy.get("execution", {}) or {}
    use_worktree = bool(execution.get("use_worktree", False))
    worktree_root = resolve_worktree_root(repo, execution) if use_worktree else None

    sequence = 1
    while True:
        branch = build_branch_name(prefix, head, sequence=sequence)
        if not branch_exists(repo, branch):
            return branch
        if (
            sequence == 1
            and use_worktree
            and worktree_root is not None
            and cleanup_stale_janitor_branch(
                repo, branch, prefix, worktree_root, dry_run
            )
        ):
            if not branch_exists(repo, branch):
                return branch
        sequence += 1


def checkout_branch(repo: Path, branch: str, dry_run: bool) -> None:
    current = git_output(repo, "rev-parse", "--abbrev-ref", "HEAD")
    if current == branch:
        return
    ensure_branch_missing(repo, branch)
    print(f"[git] create branch {branch}")
    if dry_run:
        return
    git(repo, "checkout", "-b", branch, capture_output=False)


def runner_dir(repo: Path) -> Path:
    path = git_dir(repo) / "janitor-run"
    path.mkdir(parents=True, exist_ok=True)
    return path


def sanitize_for_dir(name: str) -> str:
    return name.replace("/", "__").replace("\\", "__")


def create_worktree_context(
    repo: Path, policy: dict[str, Any], branch: str, dry_run: bool
) -> ExecutionContext:
    execution = policy.get("execution", {}) or {}
    use_worktree = bool(execution.get("use_worktree", False))
    if not use_worktree:
        checkout_branch(repo, branch, dry_run)
        return ExecutionContext(anchor_repo=repo, repo=repo)

    ensure_branch_missing(repo, branch)
    root = resolve_worktree_root(repo, execution)
    worktree_path = (root / sanitize_for_dir(branch)).resolve()
    keep_worktree = bool(execution.get("keep_worktree", False))

    print(f"[git] create worktree {worktree_path}")
    if dry_run:
        return ExecutionContext(anchor_repo=repo, repo=repo)

    worktree_path.parent.mkdir(parents=True, exist_ok=True)
    git(
        repo,
        "worktree",
        "add",
        "-b",
        branch,
        str(worktree_path),
        "HEAD",
        capture_output=False,
    )
    return ExecutionContext(
        anchor_repo=repo,
        repo=worktree_path,
        created_worktree=True,
        cleanup_worktree=not keep_worktree,
    )


def cleanup_execution_context(context: ExecutionContext, dry_run: bool) -> None:
    if not context.created_worktree or not context.cleanup_worktree:
        return
    print(f"[git] remove worktree {context.repo}")
    if dry_run:
        return
    git(
        context.anchor_repo,
        "worktree",
        "remove",
        "--force",
        str(context.repo),
        capture_output=False,
    )


def write_prompt(
    repo: Path,
    policy: dict[str, Any],
    prompt_path: Path,
    result_path: Path,
    previous_base: str,
    scan_head: str,
) -> None:
    policy_summary = {
        "paths": policy.get("paths", {}),
        "limits": policy.get("limits", {}),
        "checks": policy.get("checks", {}),
    }
    prompt = textwrap.dedent(
        f"""
        Run the `janitor` agent in this repository.

        Repo root:
        {repo}

        Goal:
        Perform low-risk cleanup only. Do not invent feature work.

        Runner-owned policy summary:
        {json.dumps(policy_summary, indent=2)}

        Commit window under review:
        {previous_base}..{scan_head}

        Hard constraints:
        - Do not create or switch git branches.
        - Do not commit, push, or open PRs.
        - Do not update `.janitor.yml`.
        - Write machine-readable result JSON to:
          {result_path}

        Result JSON minimum schema:
        {{
          "status": "success|skipped|blocked",
          "summary": "<short summary>",
          "safe_to_commit": true,
          "cleanup_buckets": ["docs", "formatting"],
          "cleanup_plan": {{
            "version": 1,
            "steps": [
              {{
                "id": "docs-nav",
                "step": 1,
                "bucket": "docs",
                "action": "repair broken MkDocs nav references",
                "reason": "broken nav targets after docs move",
                "status": "completed|skipped|planned|blocked",
                "depends_on": [],
                "paths": ["mkdocs.yml", "docs/**"]
              }}
            ]
          }},
          "notes": []
        }}

        Cleanup plan rules:
        - Build the structured `cleanup_plan` before editing.
        - Execute steps in listed order.
        - Step `depends_on` entries must reference earlier step ids only.
        - Every changed file must be covered by at least one completed step path.
        - If no safe cleanup is needed, return `status: "skipped"` with an empty or skipped-only plan.
        """
    ).strip()
    prompt_path.write_text(prompt + "\n", encoding="utf-8")


def invoke_agent(
    repo_cfg: RepoRunConfig,
    repo: Path,
    prompt_path: Path,
    result_path: Path,
    branch: str,
    scan_head: str,
    previous_base: str,
    base_branch: str,
    dry_run: bool,
) -> None:
    template = repo_cfg.agent_command_template
    if not template:
        raise JanitorError("No agent command template configured.")
    stdout_log = result_path.parent / "agent.stdout.log"
    stderr_log = result_path.parent / "agent.stderr.log"
    command = template.format(
        repo=str(repo),
        prompt=str(prompt_path),
        result=str(result_path),
        branch=branch,
        scan_head=scan_head,
        previous_base=previous_base,
        base_branch=base_branch,
        agent="janitor",
    )
    run_shell(
        command,
        repo,
        "agent",
        dry_run=dry_run,
        stdout_path=stdout_log,
        stderr_path=stderr_log,
    )


def load_result(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise JanitorError(
            "Agent did not produce result file: "
            f"{path}. Check {path.parent / 'agent.stdout.log'} and "
            f"{path.parent / 'agent.stderr.log'}."
        )
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise JanitorError(f"Invalid janitor result JSON: {path}") from exc
    if not isinstance(data, dict):
        raise JanitorError("Janitor result must be a JSON object.")
    return validate_result(data)


def require_non_empty_string(value: Any, field_name: str) -> str:
    if not isinstance(value, str):
        raise JanitorError(f"Janitor result field '{field_name}' must be a string.")
    text = value.strip()
    if not text:
        raise JanitorError(f"Janitor result field '{field_name}' cannot be empty.")
    return text


def normalize_string_list(
    value: Any, field_name: str, *, allow_empty: bool = True
) -> list[str]:
    if value is None:
        items: list[Any] = []
    elif isinstance(value, list):
        items = value
    else:
        raise JanitorError(f"Janitor result field '{field_name}' must be a list.")

    normalized: list[str] = []
    for index, item in enumerate(items, start=1):
        if not isinstance(item, str):
            raise JanitorError(
                f"Janitor result field '{field_name}[{index}]' must be a string."
            )
        text = item.strip()
        if not text:
            raise JanitorError(
                f"Janitor result field '{field_name}[{index}]' cannot be empty."
            )
        normalized.append(text)

    if not allow_empty and not normalized:
        raise JanitorError(f"Janitor result field '{field_name}' cannot be empty.")
    return normalized


def normalize_repo_pattern(path_or_pattern: str) -> str:
    normalized = path_or_pattern.replace("\\", "/").strip()
    while normalized.startswith("./"):
        normalized = normalized[2:]
    if normalized in {"*", "**", "**/*"}:
        return normalized
    return normalized.rstrip("/")


def validate_cleanup_plan(
    result: dict[str, Any], status: str, cleanup_buckets: list[str]
) -> dict[str, Any]:
    raw_plan = result.get("cleanup_plan")
    if not isinstance(raw_plan, dict):
        raise JanitorError("Janitor result missing required 'cleanup_plan' object.")

    version = raw_plan.get("version")
    if version != 1:
        raise JanitorError("Janitor cleanup_plan.version must be 1.")

    raw_steps = raw_plan.get("steps")
    if not isinstance(raw_steps, list):
        raise JanitorError("Janitor cleanup_plan.steps must be a list.")

    normalized_steps: list[dict[str, Any]] = []
    seen_step_ids: set[str] = set()
    seen_step_numbers: set[int] = set()

    for index, raw_step in enumerate(raw_steps, start=1):
        if not isinstance(raw_step, dict):
            raise JanitorError(f"Janitor cleanup_plan.steps[{index}] must be an object.")

        step_id = require_non_empty_string(
            raw_step.get("id"), f"cleanup_plan.steps[{index}].id"
        )
        if step_id in seen_step_ids:
            raise JanitorError(f"Duplicate janitor cleanup_plan step id: {step_id}")
        seen_step_ids.add(step_id)

        step_number = raw_step.get("step")
        if not isinstance(step_number, int) or step_number < 1:
            raise JanitorError(
                f"Janitor cleanup_plan.steps[{index}].step must be a positive integer."
            )
        if step_number in seen_step_numbers:
            raise JanitorError(
                f"Duplicate janitor cleanup_plan step number: {step_number}"
            )
        seen_step_numbers.add(step_number)

        bucket = require_non_empty_string(
            raw_step.get("bucket"), f"cleanup_plan.steps[{index}].bucket"
        )
        action = require_non_empty_string(
            raw_step.get("action"), f"cleanup_plan.steps[{index}].action"
        )
        reason = require_non_empty_string(
            raw_step.get("reason"), f"cleanup_plan.steps[{index}].reason"
        )
        step_status = require_non_empty_string(
            raw_step.get("status"), f"cleanup_plan.steps[{index}].status"
        ).lower()
        if step_status not in PLAN_STEP_STATUSES:
            raise JanitorError(
                "Janitor cleanup_plan step status must be one of: "
                + ", ".join(sorted(PLAN_STEP_STATUSES))
            )

        paths = [
            normalize_repo_pattern(item)
            for item in normalize_string_list(
                raw_step.get("paths"), f"cleanup_plan.steps[{index}].paths"
            )
        ]
        if step_status in {"planned", "completed"} and not paths:
            raise JanitorError(
                f"Janitor cleanup_plan.steps[{index}].paths cannot be empty "
                f"when status={step_status!r}."
            )

        depends_on = normalize_string_list(
            raw_step.get("depends_on", []),
            f"cleanup_plan.steps[{index}].depends_on",
        )
        normalized_steps.append(
            {
                "id": step_id,
                "step": step_number,
                "bucket": bucket,
                "action": action,
                "reason": reason,
                "status": step_status,
                "paths": paths,
                "depends_on": depends_on,
            }
        )

    expected_steps = list(range(1, len(normalized_steps) + 1))
    actual_steps = sorted(seen_step_numbers)
    if actual_steps != expected_steps:
        raise JanitorError(
            "Janitor cleanup_plan.steps must use contiguous step numbers starting at 1."
        )

    steps_by_id = {step["id"]: step for step in normalized_steps}
    for step in normalized_steps:
        for dependency in step["depends_on"]:
            if dependency not in steps_by_id:
                raise JanitorError(
                    f"Janitor cleanup_plan step '{step['id']}' depends on unknown "
                    f"step '{dependency}'."
                )
            if steps_by_id[dependency]["step"] >= step["step"]:
                raise JanitorError(
                    f"Janitor cleanup_plan step '{step['id']}' depends on '{dependency}' "
                    "but the dependency does not come earlier in execution order."
                )

    plan_buckets = sorted({step["bucket"] for step in normalized_steps})
    if sorted(cleanup_buckets) != plan_buckets:
        raise JanitorError(
            "Janitor cleanup_buckets must exactly match cleanup_plan step buckets."
        )

    completed_steps = [step for step in normalized_steps if step["status"] == "completed"]
    if status == "success":
        if not normalized_steps:
            raise JanitorError("Janitor result status='success' requires cleanup_plan steps.")
        if not completed_steps:
            raise JanitorError(
                "Janitor result status='success' requires at least one completed cleanup step."
            )
        invalid_statuses = [
            step["status"]
            for step in normalized_steps
            if step["status"] not in {"completed", "skipped"}
        ]
        if invalid_statuses:
            raise JanitorError(
                "Janitor result status='success' cannot include planned or blocked steps."
            )

    if status == "skipped" and completed_steps:
        raise JanitorError(
            "Janitor result status='skipped' cannot include completed cleanup steps."
        )

    return {"version": 1, "steps": sorted(normalized_steps, key=lambda item: item["step"])}


def validate_result(result: dict[str, Any]) -> dict[str, Any]:
    status = require_non_empty_string(result.get("status"), "status").lower()
    if status not in JANITOR_RESULT_STATUSES:
        raise JanitorError(
            "Janitor result status must be one of: "
            + ", ".join(sorted(JANITOR_RESULT_STATUSES))
        )

    summary = require_non_empty_string(result.get("summary"), "summary")
    safe_to_commit = result.get("safe_to_commit")
    if not isinstance(safe_to_commit, bool):
        raise JanitorError("Janitor result field 'safe_to_commit' must be a boolean.")

    if status in {"success", "skipped"} and not safe_to_commit:
        raise JanitorError(
            f"Janitor result status={status!r} requires safe_to_commit=true."
        )
    if status == "blocked" and safe_to_commit:
        raise JanitorError("Janitor result status='blocked' requires safe_to_commit=false.")

    cleanup_buckets = normalize_string_list(
        result.get("cleanup_buckets"), "cleanup_buckets"
    )
    notes = normalize_string_list(result.get("notes", []), "notes")
    cleanup_plan = validate_cleanup_plan(result, status, cleanup_buckets)

    return {
        **result,
        "status": status,
        "summary": summary,
        "safe_to_commit": safe_to_commit,
        "cleanup_buckets": cleanup_buckets,
        "cleanup_plan": cleanup_plan,
        "notes": notes,
    }


def changed_files_since_head(repo: Path) -> list[str]:
    status = git_output(repo, "status", "--porcelain")
    if not status:
        return []

    changed: list[str] = []
    for line in status.splitlines():
        if len(line) < 4:
            continue
        path_text = line[3:].strip()
        if " -> " in path_text:
            path_text = path_text.split(" -> ", 1)[1].strip()
        changed.append(normalize_repo_pattern(path_text))
    return changed


def path_matches_plan(rel_path: str, pattern: str) -> bool:
    rel_path = normalize_repo_pattern(rel_path)
    pattern = normalize_repo_pattern(pattern)
    if not pattern:
        return False
    if any(char in pattern for char in "*?[]"):
        return fnmatch.fnmatch(rel_path, pattern)
    return rel_path == pattern or rel_path.startswith(pattern + "/")


def validate_changed_files_against_plan(repo: Path, result: dict[str, Any]) -> None:
    changed_files = changed_files_since_head(repo)
    status = str(result["status"])
    steps = result["cleanup_plan"]["steps"]

    if status == "skipped":
        if changed_files:
            raise JanitorError(
                "Janitor reported status='skipped' but changed files were found: "
                + ", ".join(changed_files)
            )
        return

    if status == "success" and not changed_files:
        raise JanitorError(
            "Janitor reported status='success' but no repository changes were found."
        )

    allowed_patterns = [
        pattern
        for step in steps
        if step["status"] == "completed"
        for pattern in step["paths"]
    ]
    uncovered = [
        path
        for path in changed_files
        if path != ".janitor.yml"
        and not any(path_matches_plan(path, pattern) for pattern in allowed_patterns)
    ]
    if uncovered:
        raise JanitorError(
            "Janitor changed files not covered by cleanup_plan paths: "
            + ", ".join(uncovered)
        )


def run_checks(repo: Path, commands: list[str], label: str, dry_run: bool) -> None:
    for command in commands:
        run_shell(command, repo, label, dry_run=dry_run)


def update_policy_baseline(policy_path: Path, policy: dict[str, Any], scan_head: str) -> None:
    policy["last_janitor_base"] = scan_head
    if "last_run_at" in policy:
        policy["last_run_at"] = dt.date.today().isoformat()
    save_yaml(policy_path, policy)


def stage_all(repo: Path, dry_run: bool) -> None:
    print("[git] stage changes")
    if dry_run:
        return
    git(repo, "add", "-A", capture_output=False)


def diff_limits(repo: Path, policy: dict[str, Any]) -> tuple[int, int]:
    limits = policy.get("limits", {}) or {}
    max_files = int(limits.get("max_files_changed", 25))
    max_lines = int(limits.get("max_lines_changed", 400))

    numstat = git_output(repo, "diff", "--cached", "--numstat", "HEAD")
    files_changed = 0
    lines_changed = 0
    if numstat:
        for line in numstat.splitlines():
            added_raw, removed_raw, _path = line.split("\t", 2)
            files_changed += 1
            added = 0 if added_raw == "-" else int(added_raw)
            removed = 0 if removed_raw == "-" else int(removed_raw)
            lines_changed += added + removed

    if files_changed > max_files:
        raise JanitorError(
            f"Changed file limit exceeded: {files_changed} > {max_files}"
        )
    if lines_changed > max_lines:
        raise JanitorError(
            f"Changed line limit exceeded: {lines_changed} > {max_lines}"
        )
    return files_changed, lines_changed


def commit_changes(repo: Path, message: str, dry_run: bool) -> bool:
    has_changes = git(repo, "diff", "--cached", "--quiet", check=False).returncode != 0
    if not has_changes:
        print("[git] nothing to commit")
        return False
    print(f"[git] commit: {message}")
    if dry_run:
        return True
    git(repo, "commit", "-m", message, capture_output=False)
    return True


def push_and_pr(
    repo_cfg: RepoRunConfig,
    repo: Path,
    mode: str,
    branch: str,
    base_branch: str,
    title: str,
    body_file: Path,
    allow_direct_push: bool,
    dry_run: bool,
) -> None:
    if mode == "direct":
        if not allow_direct_push:
            raise JanitorError(
                "Repo policy requested mode=direct but --allow-direct-push was not set."
            )
        command = f'git push origin HEAD:{base_branch}'
        run_shell(command, repo, "push", dry_run=dry_run)
        return

    run_shell(f'git push -u origin "{branch}"', repo, "push", dry_run=dry_run)

    template = repo_cfg.open_pr_command_template
    if template:
        command = template.format(
            repo=str(repo),
            branch=branch,
            base_branch=base_branch,
            title=title,
            body_file=str(body_file),
        )
        run_shell(command, repo, "open-pr", dry_run=dry_run)
    else:
        print("[pr] no PR command template configured; branch pushed only")


def write_pr_body(path: Path, result: dict[str, Any], files_changed: int, lines_changed: int) -> None:
    notes = result.get("notes") or []
    if not isinstance(notes, list):
        notes = [str(notes)]
    cleanup_steps = result.get("cleanup_plan", {}).get("steps", [])
    body = textwrap.dedent(
        f"""
        ## Summary
        - {result.get("summary", "Janitor cleanup pass")}
        - Safe-to-commit: {result.get("safe_to_commit", False)}
        - Diff size: {files_changed} files, {lines_changed} lines

        ## Cleanup Buckets
        {chr(10).join(f"- {bucket}" for bucket in result.get("cleanup_buckets", [])) or "- none"}

        ## Cleanup Plan
        {chr(10).join(
            f"- [{step['status']}] Step {step['step']} `{step['bucket']}`: {step['action']}"
            for step in cleanup_steps
        ) or "- none"}

        ## Notes
        {chr(10).join(f"- {note}" for note in notes) or "- none"}
        """
    ).strip()
    path.write_text(body + "\n", encoding="utf-8")


def run_repo(repo_cfg: RepoRunConfig, args: argparse.Namespace) -> None:
    repo = repo_cfg.path
    print(f"\n=== janitor: {repo} ===")

    if not repo.exists():
        raise JanitorError(f"Repo path does not exist: {repo}")

    policy_path = repo / ".janitor.yml"
    policy = ensure_valid_policy(repo)
    ensure_clean_worktree(repo)

    scan_head = git_output(repo, "rev-parse", "HEAD")
    previous_base = str(policy.get("last_janitor_base", "")).strip()
    validate_base(repo, previous_base, scan_head)

    min_new_commits = int((policy.get("triggers") or {}).get("min_new_commits", 1))
    new_commit_count = count_new_commits(repo, previous_base, scan_head)
    if new_commit_count < min_new_commits:
        print(
            f"[skip] only {new_commit_count} new commit(s) since {previous_base}; "
            f"threshold is {min_new_commits}"
        )
        return

    pre_checks = list((policy.get("checks") or {}).get("pre", []))
    post_checks = list((policy.get("checks") or {}).get("post", []))

    base_branch = resolve_default_branch(repo, repo_cfg.base_branch)
    branch = resolve_branch_name(repo, policy, scan_head, args.dry_run)
    context = create_worktree_context(repo, policy, branch, args.dry_run)

    try:
        execution_repo = context.repo
        auto_trust_mise(execution_repo, args.dry_run)
        run_checks(execution_repo, pre_checks, "pre-check", args.dry_run)

        scratch = runner_dir(execution_repo)
        prompt_path = scratch / "prompt.md"
        result_path = scratch / "result.json"
        pr_body_path = scratch / "pr-body.md"

        write_prompt(
            execution_repo, policy, prompt_path, result_path, previous_base, scan_head
        )
        invoke_agent(
            repo_cfg,
            execution_repo,
            prompt_path,
            result_path,
            branch,
            scan_head,
            previous_base,
            base_branch,
            args.dry_run,
        )

        if args.dry_run:
            return

        result = load_result(result_path)
        status = str(result.get("status", "")).strip().lower()
        safe_to_commit = bool(result.get("safe_to_commit", False))
        if status not in {"success", "skipped"} or not safe_to_commit:
            raise JanitorError(
                f"Agent blocked janitor run: status={status!r}, safe_to_commit={safe_to_commit}"
            )

        validate_changed_files_against_plan(execution_repo, result)
        run_checks(execution_repo, post_checks, "post-check", args.dry_run)

        update_policy_baseline(execution_repo / ".janitor.yml", policy, scan_head)
        stage_all(execution_repo, args.dry_run)
        files_changed, lines_changed = diff_limits(execution_repo, policy)

        commit_message = str(
            ((policy.get("commit") or {}).get("message"))
            or "chore(janitor): refresh repo hygiene"
        )
        committed = commit_changes(execution_repo, commit_message, args.dry_run)
        if not committed:
            print("[done] no commit created")
            return

        write_pr_body(pr_body_path, result, files_changed, lines_changed)
        mode = str(policy.get("mode", "pr") or "pr").strip().lower()
        push_and_pr(
            repo_cfg,
            execution_repo,
            mode,
            branch,
            base_branch,
            commit_message,
            pr_body_path,
            args.allow_direct_push,
            args.dry_run,
        )
    finally:
        cleanup_execution_context(context, args.dry_run)


def run_repo_worktree_cleanup(repo_cfg: RepoRunConfig, args: argparse.Namespace) -> None:
    repo = repo_cfg.path
    print(f"\n=== janitor cleanup: {repo} ===")

    if not repo.exists():
        raise JanitorError(f"Repo path does not exist: {repo}")

    policy = ensure_valid_policy(repo)
    cleanup_stale_janitor_worktrees(repo, policy, args.dry_run)


def main() -> int:
    args = parse_args()
    try:
        repos = load_runner_repos(args)
        for repo_cfg in repos:
            if args.cleanup_stale_janitor_worktrees:
                run_repo_worktree_cleanup(repo_cfg, args)
            else:
                run_repo(repo_cfg, args)
    except JanitorError as exc:
        print(f"[janitor] {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
