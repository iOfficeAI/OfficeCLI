#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from sdlc_common import build_report, emit_report, exit_code_for, normalized_relpath


DIRECT_DOC_PATHS = {"AGENTS.md", "agents.md", "architecture/workspace.dsl"}
WORKSPACE_SIGNAL_FRAGMENTS = (
    "architecture/",
    "docker-compose",
    "compose.",
    "helm/",
    "k8s/",
    "terraform/",
    "infra/",
    "deploy/",
    "migration",
    "schema",
    "dto",
    "controller",
    "handler",
    "client",
    "entity",
    "model",
    "api",
)
AGENTS_SIGNAL_FRAGMENTS = (
    ".factory/project.yaml",
    ".factory/services.yaml",
    "Makefile",
    "scripts/",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Advisory docs-impact preflight for implementation-doc-sync."
    )
    parser.add_argument("--json", action="store_true", help="Emit JSON output.")
    parser.add_argument("--root", default=".", help="Project root.")
    parser.add_argument("changed_paths", nargs="+", help="Changed paths relative to repo root.")
    parser.add_argument(
        "--strict-warnings", action="store_true", help="Treat warnings as failures."
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    _root = Path(args.root).resolve()
    changed_paths = [normalized_relpath(path) for path in args.changed_paths]
    touched = set(changed_paths)
    warnings: list[str] = []

    updated_paths: list[str] = []
    if "architecture/workspace.dsl" in touched:
        updated_paths.append("architecture/workspace.dsl")
    if "AGENTS.md" in touched:
        updated_paths.append("AGENTS.md")
    elif "agents.md" in touched:
        updated_paths.append("agents.md")

    review_workspace = any(
        any(fragment in path for fragment in WORKSPACE_SIGNAL_FRAGMENTS)
        for path in changed_paths
    )
    review_agents = any(
        any(fragment in path for fragment in AGENTS_SIGNAL_FRAGMENTS)
        for path in changed_paths
    )

    manual_review_required = False
    recommended_line: str | None
    if updated_paths:
        recommended_line = "Documentation impact: updated " + ", ".join(updated_paths)
    elif not review_workspace and not review_agents:
        recommended_line = (
            "Documentation impact: reviewed; no updates needed because touched files do not signal project-convention or architecture drift."
        )
    else:
        manual_review_required = True
        recommended_line = None
        if review_workspace:
            warnings.append(
                "architecture/workspace.dsl should be reviewed because changed paths suggest topology, integration, or runtime drift."
            )
        if review_agents:
            warnings.append(
                "AGENTS.md should be reviewed because changed paths suggest project-convention drift."
            )

    report = build_report(
        f"Docs impact preflight for {args.root}",
        warnings=warnings,
        changed_paths=changed_paths,
        review_workspace_dsl=review_workspace or "architecture/workspace.dsl" in touched,
        review_agents_md=review_agents or "AGENTS.md" in touched or "agents.md" in touched,
        touched_docs_paths=updated_paths,
        manual_review_required=manual_review_required,
        recommended_line=recommended_line,
    )
    emit_report(report, args.json)
    return exit_code_for(report, args.strict_warnings)


if __name__ == "__main__":
    raise SystemExit(main())
