#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

from sdlc_common import (
    build_report,
    emit_report,
    ensure_string_list,
    exit_code_for,
    is_iso_timestamp,
    load_yaml,
)


ALLOWED_ARTIFACT_STATUSES = {"draft", "active", "closed"}
ALLOWED_WRITER_MODES = {"harness_append_only", "provider_export", "mixed"}
ALLOWED_COVERAGE = {"absent", "partial", "measured"}
ALLOWED_SOURCES = {"harness_measured", "provider_export", "self_reported", "unmeasured"}
ALLOWED_OUTCOMES = {"success", "retry", "blocked", "escalated"}
TOP_LEVEL_KEYS = {
    "subject_type",
    "subject_id",
    "title",
    "schema_version",
    "status",
    "measurement_window",
    "writer",
    "coverage",
    "rollups",
    "runs",
    "rework_events",
}
RUN_KEYS = {
    "run_id",
    "phase",
    "phase_name",
    "agent",
    "agent_version",
    "model",
    "model_version",
    "started_at",
    "ended_at",
    "input_tokens",
    "output_tokens",
    "cached_input_tokens",
    "total_tokens",
    "tool_calls",
    "estimated_cost_usd",
    "outcome",
    "source",
    "measurement_uri",
    "notes",
    "subject_type",
    "subject_id",
    "retry_of_run_id",
    "rework_cause",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Lint and roll up petition telemetry artifacts."
    )
    parser.add_argument("--json", action="store_true", help="Emit JSON output.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    for command in ("lint", "rollup"):
        sub = subparsers.add_parser(command)
        sub.add_argument("--root", default=".", help="Project root.")
        sub.add_argument("--petition-id", help="Limit to one petition telemetry artifact.")
        sub.add_argument(
            "--strict-warnings", action="store_true", help="Treat warnings as failures."
        )
    return parser.parse_args()


def iter_telemetry_paths(root: Path, petition_id: str | None = None) -> list[Path]:
    telemetry_dir = root / "petitions" / "telemetry"
    if not telemetry_dir.is_dir():
        return []
    if petition_id:
        candidate = telemetry_dir / f"{petition_id}-telemetry.yaml"
        return [candidate] if candidate.is_file() else []
    return sorted(telemetry_dir.glob("*-telemetry.yaml"))


def as_number(value: Any, *, integer: bool = False) -> int | float | None:
    if isinstance(value, bool):
        return None
    if integer and isinstance(value, int):
        return value
    if not integer and isinstance(value, (int, float)):
        return value
    return None


def compute_telemetry_rollup(payload: dict[str, Any]) -> dict[str, Any]:
    runs = payload.get("runs", [])
    total_runs = len(runs) if isinstance(runs, list) else 0
    measured_runs = 0
    rollup = {
        "total_runs": total_runs,
        "measured_runs": 0,
        "input_tokens": 0,
        "output_tokens": 0,
        "cached_input_tokens": 0,
        "total_tokens": 0,
        "estimated_cost_usd": 0.0,
        "tool_calls": 0,
        "retry_runs": 0,
        "escalated_runs": 0,
    }
    trust_breakdown = {source: 0 for source in ALLOWED_SOURCES}
    timestamps: list[str] = []

    for run in runs if isinstance(runs, list) else []:
        if not isinstance(run, dict):
            continue
        source = str(run.get("source", ""))
        if source in trust_breakdown:
            trust_breakdown[source] += 1
        if source in {"harness_measured", "provider_export"}:
            measured_runs += 1
            rollup["input_tokens"] += int(run.get("input_tokens", 0) or 0)
            rollup["output_tokens"] += int(run.get("output_tokens", 0) or 0)
            rollup["cached_input_tokens"] += int(run.get("cached_input_tokens", 0) or 0)
            rollup["total_tokens"] += int(run.get("total_tokens", 0) or 0)
            rollup["estimated_cost_usd"] += float(run.get("estimated_cost_usd", 0.0) or 0.0)
            rollup["tool_calls"] += int(run.get("tool_calls", 0) or 0)
        if run.get("outcome") == "retry":
            rollup["retry_runs"] += 1
        if run.get("outcome") == "escalated":
            rollup["escalated_runs"] += 1
        for key in ("started_at", "ended_at"):
            value = run.get(key)
            if isinstance(value, str) and value.strip():
                timestamps.append(value)

    rollup["measured_runs"] = measured_runs
    coverage = (
        "absent"
        if total_runs == 0 or measured_runs == 0
        else "measured"
        if measured_runs == total_runs
        else "partial"
    )
    measurement_window = {
        "started_at": min(timestamps) if timestamps else None,
        "ended_at": max(timestamps) if timestamps else None,
    }
    return {
        "coverage": coverage,
        "rollups": rollup,
        "trust_breakdown": trust_breakdown,
        "measurement_window": measurement_window,
    }


def validate_run(run: dict[str, Any], path: Path, index: int) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []
    required = (
        "run_id",
        "phase",
        "phase_name",
        "agent",
        "model",
        "started_at",
        "ended_at",
        "input_tokens",
        "output_tokens",
        "cached_input_tokens",
        "total_tokens",
        "tool_calls",
        "estimated_cost_usd",
        "outcome",
        "source",
    )
    for key in required:
        if key not in run:
            errors.append(f"{path}: runs[{index}].{key} is required.")

    for key in ("started_at", "ended_at"):
        value = run.get(key)
        if value is not None and not is_iso_timestamp(value):
            errors.append(f"{path}: runs[{index}].{key} must be ISO 8601.")

    source = run.get("source")
    if source not in ALLOWED_SOURCES:
        errors.append(f"{path}: runs[{index}].source is invalid.")
    outcome = run.get("outcome")
    if outcome not in ALLOWED_OUTCOMES:
        errors.append(f"{path}: runs[{index}].outcome is invalid.")

    for key in ("input_tokens", "output_tokens", "cached_input_tokens", "total_tokens", "tool_calls"):
        value = as_number(run.get(key), integer=True)
        if value is None or value < 0:
            errors.append(f"{path}: runs[{index}].{key} must be a non-negative integer.")
    value = as_number(run.get("estimated_cost_usd"), integer=False)
    if value is None or value < 0:
        errors.append(f"{path}: runs[{index}].estimated_cost_usd must be a non-negative number.")

    measurement_uri = run.get("measurement_uri")
    if source in {"harness_measured", "provider_export"}:
        if not isinstance(measurement_uri, str) or not measurement_uri.strip():
            errors.append(
                f"{path}: runs[{index}].measurement_uri is required for measured sources."
            )
    elif measurement_uri not in {None, ""} and not str(measurement_uri).strip():
        warnings.append(f"{path}: runs[{index}].measurement_uri is blank.")

    if any(key not in RUN_KEYS for key in run):
        unknown_keys = sorted(key for key in run if key not in RUN_KEYS)
        warnings.append(f"{path}: runs[{index}] has unknown keys: {', '.join(unknown_keys)}.")

    notes = run.get("notes")
    if isinstance(notes, str) and len(notes) > 500:
        warnings.append(f"{path}: runs[{index}].notes is unusually long; keep telemetry metadata compact.")

    total_tokens = as_number(run.get("total_tokens"), integer=True)
    input_tokens = as_number(run.get("input_tokens"), integer=True)
    output_tokens = as_number(run.get("output_tokens"), integer=True)
    if None not in {total_tokens, input_tokens, output_tokens} and total_tokens != input_tokens + output_tokens:
        warnings.append(
            f"{path}: runs[{index}].total_tokens does not equal input_tokens + output_tokens."
        )
    return errors, warnings


def validate_telemetry_artifact(path: Path, payload: dict[str, Any]) -> tuple[list[str], list[str], dict[str, Any]]:
    errors: list[str] = []
    warnings: list[str] = []

    for key in (
        "subject_type",
        "subject_id",
        "title",
        "schema_version",
        "status",
        "measurement_window",
        "writer",
        "coverage",
        "rollups",
        "runs",
    ):
        if key not in payload:
            errors.append(f"{path}: `{key}` is required.")

    if payload.get("status") not in ALLOWED_ARTIFACT_STATUSES:
        errors.append(f"{path}: `status` must be draft, active, or closed.")

    writer = payload.get("writer")
    if not isinstance(writer, dict):
        errors.append(f"{path}: `writer` must be a mapping.")
    elif writer.get("mode") not in ALLOWED_WRITER_MODES:
        errors.append(f"{path}: `writer.mode` must be harness_append_only, provider_export, or mixed.")

    coverage = payload.get("coverage")
    if not isinstance(coverage, dict):
        errors.append(f"{path}: `coverage` must be a mapping.")
    elif coverage.get("status") not in ALLOWED_COVERAGE:
        errors.append(f"{path}: `coverage.status` must be absent, partial, or measured.")

    window = payload.get("measurement_window")
    if not isinstance(window, dict):
        errors.append(f"{path}: `measurement_window` must be a mapping.")
    else:
        for key in ("started_at", "ended_at"):
            value = window.get(key)
            if value is not None and value != "" and not is_iso_timestamp(value):
                errors.append(f"{path}: `measurement_window.{key}` must be ISO 8601 or null.")

    rollups = payload.get("rollups")
    if not isinstance(rollups, dict):
        errors.append(f"{path}: `rollups` must be a mapping.")

    if any(key not in TOP_LEVEL_KEYS for key in payload):
        unknown_keys = sorted(key for key in payload if key not in TOP_LEVEL_KEYS)
        warnings.append(f"{path}: unknown top-level keys present: {', '.join(unknown_keys)}.")

    runs = payload.get("runs")
    if not isinstance(runs, list):
        errors.append(f"{path}: `runs` must be a list.")
        runs = []

    for index, run in enumerate(runs):
        if not isinstance(run, dict):
            errors.append(f"{path}: runs[{index}] must be a mapping.")
            continue
        run_errors, run_warnings = validate_run(run, path, index)
        errors.extend(run_errors)
        warnings.extend(run_warnings)

    derived = compute_telemetry_rollup(payload)
    if isinstance(coverage, dict) and coverage.get("status") != derived["coverage"]:
        warnings.append(
            f"{path}: coverage.status={coverage.get('status')} differs from derived coverage {derived['coverage']}."
        )
    if isinstance(rollups, dict):
        for key, value in derived["rollups"].items():
            current = rollups.get(key)
            if key == "estimated_cost_usd":
                if current is None or abs(float(current) - float(value)) > 1e-9:
                    warnings.append(f"{path}: rollups.{key} differs from derived value {value}.")
            elif current != value:
                warnings.append(f"{path}: rollups.{key} differs from derived value {value}.")
    return errors, warnings, derived


def handle_lint(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    files = iter_telemetry_paths(root, args.petition_id)
    if not files:
        report = build_report(
            f"Telemetry lint for {root}",
            warnings=["No telemetry artifacts found."],
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    errors: list[str] = []
    warnings: list[str] = []
    derived_by_file: dict[str, Any] = {}
    for path in files:
        payload = load_yaml(path)
        if not isinstance(payload, dict):
            errors.append(f"{path}: telemetry artifact must parse as a mapping.")
            continue
        item_errors, item_warnings, derived = validate_telemetry_artifact(path, payload)
        errors.extend(item_errors)
        warnings.extend(item_warnings)
        derived_by_file[str(path)] = derived

    report = build_report(
        f"Telemetry lint for {root}",
        errors=errors,
        warnings=warnings,
        checked=[str(path) for path in files],
        derived=derived_by_file,
    )
    emit_report(report, args.json)
    return exit_code_for(report, args.strict_warnings)


def handle_rollup(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    files = iter_telemetry_paths(root, args.petition_id)
    if not files:
        report = build_report(
            f"Telemetry rollup for {root}",
            warnings=["No telemetry artifacts found."],
        )
        emit_report(report, args.json)
        return exit_code_for(report, args.strict_warnings)

    petition_rollups: dict[str, Any] = {}
    warnings: list[str] = []
    aggregate = {
        "petitions": 0,
        "total_runs": 0,
        "measured_runs": 0,
        "input_tokens": 0,
        "output_tokens": 0,
        "cached_input_tokens": 0,
        "total_tokens": 0,
        "estimated_cost_usd": 0.0,
        "tool_calls": 0,
    }

    for path in files:
        payload = load_yaml(path)
        if not isinstance(payload, dict):
            warnings.append(f"{path}: skipped because artifact is not a mapping.")
            continue
        derived = compute_telemetry_rollup(payload)
        petition_id = str(payload.get("subject_id") or path.stem.replace("-telemetry", ""))
        petition_rollups[petition_id] = derived
        aggregate["petitions"] += 1
        for key in (
            "total_runs",
            "measured_runs",
            "input_tokens",
            "output_tokens",
            "cached_input_tokens",
            "total_tokens",
            "tool_calls",
        ):
            aggregate[key] += derived["rollups"][key]
        aggregate["estimated_cost_usd"] += derived["rollups"]["estimated_cost_usd"]

    coverage_states = {item["coverage"] for item in petition_rollups.values()}
    aggregate_coverage = (
        "absent"
        if not petition_rollups or coverage_states == {"absent"}
        else "measured"
        if coverage_states == {"measured"}
        else "partial"
    )

    report = build_report(
        f"Telemetry rollup for {root}",
        warnings=warnings,
        telemetry_coverage=aggregate_coverage,
        petitions=petition_rollups,
        aggregate=aggregate,
    )
    emit_report(report, args.json)
    return exit_code_for(report, args.strict_warnings)


def main() -> int:
    args = parse_args()
    if args.command == "lint":
        return handle_lint(args)
    if args.command == "rollup":
        return handle_rollup(args)
    raise ValueError(f"Unsupported command: {args.command}")


if __name__ == "__main__":
    raise SystemExit(main())
