#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path


WORKFLOW_ROLES = {
    "orchestrator",
    "worker",
    "reviewer",
    "validator",
    "gate",
    "reporter",
}

REQUIRED_CONTRACT_SECTIONS = [
    "# Purpose",
    "## Workflow role",
    "## Inputs",
    "## Preconditions",
    "## Procedure",
    "## Output Contract",
    "## Status Vocabulary",
    "## Done Criteria",
    "## Evidence Requirements",
    "## Failure Routing",
    "## Escalation Rules",
    "## Never Do",
]

REQUIRED_OUTPUT_SUBHEADS = [
    "### Artifacts",
    "### Report Fields",
    "### Evidence Entry Fields",
]

REQUIRED_REPORT_FIELDS = [
    "`status`",
    "`summary`",
    "`artifacts`",
    "`evidence_checked`",
    "`warnings`",
    "`escalations`",
    "`next_action`",
    "`handoff_target`",
]

REQUIRED_EVIDENCE_FIELDS = [
    "`claim`",
    "`proof`",
    "`freshness`",
    "`result`",
]

REQUIRED_STATUS_TOKENS = [
    "`success`",
    "`blocked`",
    "`needs_more_evidence`",
]


# ── A2: SKILL.md frontmatter schema ──────────────────────────────────────────
KNOWN_FRONTMATTER_FIELDS: dict[str, type | tuple[type, ...]] = {
    "name": str,
    "description": str,
    "workflow_role": str,
    "workflow_binding": str,
    "graph_node_ids": list,
    "upstream_dependencies": (str, list),
    "primary_outputs": (str, list),
    "default_next": (str, dict),
    "spec_version": str,
    "tool_permissions": (str, dict, list),
    "triggers": (str, list),
    "invocable": str,
    "argument-hint": str,
    "allowed-tools": (str, list),
}

REQUIRED_FRONTMATTER_FIELDS = {"name", "description"}


def _spec_display_name(spec: "AgentSpec") -> str:
    """User-friendly display name for a SKILL.md spec."""
    return f"{spec.path.parent.name}/SKILL.md"


def lint_frontmatter(
    spec: "AgentSpec", frontmatter: dict[str, object]
) -> tuple[list[str], list[str]]:
    """Validate SKILL.md frontmatter against known schema."""
    errors: list[str] = []
    warnings: list[str] = []
    display = _spec_display_name(spec)

    for req in REQUIRED_FRONTMATTER_FIELDS:
        if req not in frontmatter or not frontmatter[req]:
            errors.append(
                f"{display}: frontmatter missing required field '{req}'"
            )

    for key, value in frontmatter.items():
        if key not in KNOWN_FRONTMATTER_FIELDS:
            warnings.append(
                f"{display}: unknown frontmatter field '{key}'"
            )
            continue
        expected = KNOWN_FRONTMATTER_FIELDS[key]
        if isinstance(expected, tuple):
            if not isinstance(value, expected):
                errors.append(
                    f"{display}: frontmatter field '{key}' has wrong type "
                    f"(expected {' | '.join(t.__name__ for t in expected)}, got {type(value).__name__})"
                )
        elif not isinstance(value, expected):
            errors.append(
                f"{display}: frontmatter field '{key}' has wrong type "
                f"(expected {expected.__name__}, got {type(value).__name__})"
            )

    # ── B3: tool_permissions schema validation ──────────────────────────────────
    tp = frontmatter.get("tool_permissions")
    if tp is not None:
        tp_errors = lint_tool_permissions(display, tp)
        errors.extend(tp_errors)

    if "workflow_role" in frontmatter and "workflow_binding" not in frontmatter:
        errors.append(
            f"{display}: frontmatter field 'workflow_binding' is required when 'workflow_role' is declared"
        )

    if (
        frontmatter.get("workflow_binding") == "contract_only"
        and isinstance(frontmatter.get("graph_node_ids"), list)
        and frontmatter.get("graph_node_ids")
    ):
        warnings.append(
            f"{display}: contract_only agent declares graph_node_ids that will not be graph-validated"
        )

    return errors, warnings


# ── B3: Tool-permission profile validation ───────────────────────────────────
VALID_PERMISSION_KEYS = {"read_only", "allowed_tools", "deny"}


def lint_tool_permissions(display: str, tp: object) -> list[str]:
    """Validate the tool_permissions frontmatter field (B3)."""
    errors: list[str] = []
    if isinstance(tp, str):
        return errors  # simple preset name like "read_only"
    if isinstance(tp, list):
        for i, item in enumerate(tp):
            if not isinstance(item, str):
                errors.append(f"{display}: tool_permissions[{i}] must be string, got {type(item).__name__}")
        return errors
    if isinstance(tp, dict):
        for key in tp:
            if key not in VALID_PERMISSION_KEYS:
                errors.append(f"{display}: tool_permissions has unknown key '{key}'")
        if "read_only" in tp and not isinstance(tp["read_only"], bool):
            errors.append(f"{display}: tool_permissions.read_only must be bool")
        if "allowed_tools" in tp:
            if not isinstance(tp["allowed_tools"], list):
                errors.append(f"{display}: tool_permissions.allowed_tools must be list")
            elif not all(isinstance(t, str) for t in tp["allowed_tools"]):
                errors.append(f"{display}: tool_permissions.allowed_tools entries must be strings")
        if "deny" in tp:
            if not isinstance(tp["deny"], list):
                errors.append(f"{display}: tool_permissions.deny must be list")
            elif not all(isinstance(t, str) for t in tp["deny"]):
                errors.append(f"{display}: tool_permissions.deny entries must be strings")
        return errors
    errors.append(f"{display}: tool_permissions must be string, list, or mapping, got {type(tp).__name__}")
    return errors


@dataclass
class AgentSpec:
    path: Path
    name: str
    workflow_role: str | None
    workflow_binding: str | None
    text: str
    graph_node_ids: list[str] = field(default_factory=list)


@dataclass
class WorkflowEdge:
    src: str
    dst: str
    attrs: str = ""


@dataclass
class WorkflowGraph:
    path: Path
    graph_name: str
    nodes: dict[str, str]
    edges: list[WorkflowEdge]
    start_nodes: list[str]
    exit_nodes: list[str]
    goal_gate_nodes: list[str]


def node_shape(attrs: str) -> str:
    match = re.search(r"\bshape\s*=\s*([A-Za-z]+)", attrs)
    return match.group(1) if match else "box"


def has_human_gate(attrs: str) -> bool:
    return node_shape(attrs) == "hexagon"


def build_adjacency(
    nodes: dict[str, str], edges: list[WorkflowEdge]
) -> tuple[dict[str, set[str]], dict[str, set[str]]]:
    outgoing = {node_id: set() for node_id in nodes}
    incoming = {node_id: set() for node_id in nodes}

    for edge in edges:
        if edge.src in outgoing and edge.dst in incoming:
            outgoing[edge.src].add(edge.dst)
            incoming[edge.dst].add(edge.src)

    return outgoing, incoming


def walk_reachable(outgoing: dict[str, set[str]], start: str) -> set[str]:
    seen: set[str] = set()
    stack = [start]

    while stack:
        node_id = stack.pop()
        if node_id in seen:
            continue
        seen.add(node_id)
        stack.extend(sorted(outgoing[node_id] - seen))

    return seen


def walk_reverse_reachable(incoming: dict[str, set[str]], target: str) -> set[str]:
    seen: set[str] = set()
    stack = [target]

    while stack:
        node_id = stack.pop()
        if node_id in seen:
            continue
        seen.add(node_id)
        stack.extend(sorted(incoming[node_id] - seen))

    return seen


def uncontrolled_exit_path(
    graph: WorkflowGraph, outgoing: dict[str, set[str]], start: str, exit_node: str
) -> list[str] | None:
    start_control = bool(
        graph.nodes[start].find("goal_gate=true") >= 0 or has_human_gate(graph.nodes[start])
    )
    stack: list[tuple[str, bool, list[str]]] = [(start, start_control, [start])]
    seen: set[tuple[str, bool]] = set()

    while stack:
        node_id, seen_control, path = stack.pop()
        state = (node_id, seen_control)
        if state in seen:
            continue
        seen.add(state)

        if node_id == exit_node and not seen_control:
            return path

        for next_node in sorted(outgoing[node_id], reverse=True):
            next_attrs = graph.nodes[next_node]
            next_seen_control = (
                seen_control
                or "goal_gate=true" in next_attrs
                or has_human_gate(next_attrs)
            )
            stack.append((next_node, next_seen_control, [*path, next_node]))

    return None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Lightweight linter for workflow DOT files and graph-aligned agent specs."
    )
    parser.add_argument(
        "--root",
        default=".",
        help="Repository root. Defaults to current directory.",
    )
    parser.add_argument(
        "--strict-warnings",
        action="store_true",
        help="Treat warnings as failures.",
    )
    return parser.parse_args()


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def parse_frontmatter(text: str) -> dict[str, object]:
    if not text.startswith("---\n"):
        return {}

    end = text.find("\n---", 4)
    if end == -1:
        return {}

    block = text[4:end].splitlines()
    data: dict[str, object] = {}
    current_list_key: str | None = None

    for raw_line in block:
        if not raw_line.strip():
            continue

        if current_list_key and raw_line.startswith("  - "):
            data.setdefault(current_list_key, [])
            assert isinstance(data[current_list_key], list)
            data[current_list_key].append(raw_line[4:].strip())
            continue

        current_list_key = None

        if raw_line.startswith(" "):
            continue

        if ":" not in raw_line:
            continue

        key, value = raw_line.split(":", 1)
        key = key.strip()
        value = value.strip()

        if not value:
            if key == "graph_node_ids":
                data[key] = []
                current_list_key = key
            else:
                data[key] = ""
            continue

        if value.startswith('"') and value.endswith('"'):
            value = value[1:-1]

        data[key] = value

    return data


def load_agent_specs(root: Path) -> tuple[list[AgentSpec], list[str], list[str]]:
    """Load SKILL.md specs and run frontmatter schema validation (A1 + A2)."""
    specs: list[AgentSpec] = []
    fm_errors: list[str] = []
    fm_warnings: list[str] = []
    for path in sorted(root.glob("*/SKILL.md")):
        text = read_text(path)
        frontmatter = parse_frontmatter(text)
        spec = AgentSpec(
            path=path,
            name=str(frontmatter.get("name", path.parent.name)),
            workflow_role=(
                str(frontmatter["workflow_role"])
                if "workflow_role" in frontmatter
                else None
            ),
            workflow_binding=(
                str(frontmatter["workflow_binding"])
                if "workflow_binding" in frontmatter
                else None
            ),
            text=text,
            graph_node_ids=list(frontmatter.get("graph_node_ids", [])),
        )
        specs.append(spec)
        errs, warns = lint_frontmatter(spec, frontmatter)
        fm_errors.extend(errs)
        fm_warnings.extend(warns)
    return specs, fm_errors, fm_warnings


def extract_markdown_section(text: str, heading: str) -> str | None:
    lines = text.splitlines()
    start_idx: int | None = None

    for idx, line in enumerate(lines):
        if line.strip() == heading:
            start_idx = idx
            break

    if start_idx is None:
        return None

    collected: list[str] = []
    for idx in range(start_idx, len(lines)):
        line = lines[idx]
        if idx > start_idx and line.startswith("## "):
            break
        collected.append(line)

    return "\n".join(collected)


def extract_status_tokens(text: str) -> set[str]:
    section = extract_markdown_section(text, "## Status Vocabulary")
    if section is None:
        return set()
    return set(re.findall(r"`([a-z_]+)`", section))


def strip_dot_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = re.sub(r"//.*$", "", text, flags=re.M)
    return text


def load_workflow_graph(path: Path) -> WorkflowGraph:
    text = strip_dot_comments(read_text(path))
    graph_match = re.search(r"digraph\s+([A-Za-z_][A-Za-z0-9_]*)\s*\{", text)
    if not graph_match:
        raise ValueError(f"{path}: missing digraph declaration")

    graph_name = graph_match.group(1)
    nodes: dict[str, str] = {}
    reserved_ids = {"graph", "node", "edge"}

    lines = text.splitlines()
    idx = 0
    while idx < len(lines):
        line = lines[idx]
        stripped = line.strip()
        node_start = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)\s*\[(.*)$", stripped)
        if not node_start or "->" in stripped:
            idx += 1
            continue

        node_id = node_start.group(1)
        if node_id in reserved_ids:
            idx += 1
            continue

        attr_parts = [node_start.group(2)]
        while "]" not in attr_parts[-1] and idx + 1 < len(lines):
            idx += 1
            attr_parts.append(lines[idx].strip())

        attrs = "\n".join(attr_parts)
        attrs = attrs.split("]", 1)[0]

        if node_id in nodes:
            raise ValueError(f"{path}: duplicate node definition for {node_id}")
        nodes[node_id] = attrs
        idx += 1

    edges: list[WorkflowEdge] = []
    for line in lines:
        if "->" not in line:
            continue
        attrs_match = re.search(r"\[(.*)\]", line)
        attrs = attrs_match.group(1) if attrs_match else ""
        normalized = re.sub(r"\[.*$", "", line).strip()
        ids = re.findall(r"[A-Za-z_][A-Za-z0-9_]*", normalized)
        if len(ids) < 2:
            continue
        for src, dst in zip(ids, ids[1:]):
            edges.append(WorkflowEdge(src=src, dst=dst, attrs=attrs))

    start_nodes = [
        node_id for node_id, attrs in nodes.items() if "shape=Mdiamond" in attrs
    ]
    exit_nodes = [
        node_id for node_id, attrs in nodes.items() if "shape=Msquare" in attrs
    ]
    goal_gate_nodes = [
        node_id for node_id, attrs in nodes.items() if "goal_gate=true" in attrs
    ]

    return WorkflowGraph(
        path=path,
        graph_name=graph_name,
        nodes=nodes,
        edges=edges,
        start_nodes=start_nodes,
        exit_nodes=exit_nodes,
        goal_gate_nodes=goal_gate_nodes,
    )


def load_workflow_graphs(root: Path) -> dict[str, WorkflowGraph]:
    graphs: dict[str, WorkflowGraph] = {}
    workflows_dir = root / "workflows"
    for path in sorted(workflows_dir.glob("*.dot")):
        graphs[path.stem] = load_workflow_graph(path)
    return graphs


def lint_graphs(graphs: dict[str, WorkflowGraph]) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    for _name, graph in graphs.items():
        if len(graph.start_nodes) != 1:
            errors.append(
                f"{graph.path.name}: expected exactly 1 start node, found {len(graph.start_nodes)}"
            )
        if len(graph.exit_nodes) != 1:
            errors.append(
                f"{graph.path.name}: expected exactly 1 exit node, found {len(graph.exit_nodes)}"
            )
        if not graph.goal_gate_nodes:
            warnings.append(
                f"{graph.path.name}: no goal_gate=true nodes found"
            )

        for edge in graph.edges:
            if edge.src not in graph.nodes:
                errors.append(
                    f"{graph.path.name}: edge source '{edge.src}' has no node definition"
                )
            if edge.dst not in graph.nodes:
                errors.append(
                    f"{graph.path.name}: edge target '{edge.dst}' has no node definition"
                )

        escalation_present = any(
            "Escalation" in attrs or "escalation" in node_id
            for node_id, attrs in graph.nodes.items()
        )
        if not escalation_present:
            warnings.append(
                f"{graph.path.name}: no obvious escalation node found"
            )

        if len(graph.start_nodes) != 1 or len(graph.exit_nodes) != 1:
            continue

        start = graph.start_nodes[0]
        exit_node = graph.exit_nodes[0]
        outgoing, incoming = build_adjacency(graph.nodes, graph.edges)
        reachable_from_start = walk_reachable(outgoing, start)
        can_reach_exit = walk_reverse_reachable(incoming, exit_node)

        for node_id in sorted(graph.nodes):
            attrs = graph.nodes[node_id]
            shape = node_shape(attrs)
            out_degree = len(outgoing[node_id])
            in_degree = len(incoming[node_id])

            if node_id not in reachable_from_start:
                errors.append(
                    f"{graph.path.name}: node '{node_id}' is unreachable from start"
                )
            if node_id not in can_reach_exit:
                errors.append(
                    f"{graph.path.name}: node '{node_id}' cannot reach exit"
                )

            if node_id == start and in_degree != 0:
                errors.append(
                    f"{graph.path.name}: start node '{node_id}' should not have incoming edges"
                )
            if node_id == exit_node and out_degree != 0:
                errors.append(
                    f"{graph.path.name}: exit node '{node_id}' should not have outgoing edges"
                )
            if node_id != exit_node and out_degree == 0:
                errors.append(
                    f"{graph.path.name}: non-exit node '{node_id}' has no outgoing edges"
                )
            if node_id != start and in_degree == 0:
                errors.append(
                    f"{graph.path.name}: non-start node '{node_id}' has no incoming edges"
                )
            if shape == "diamond" and out_degree < 2:
                warnings.append(
                    f"{graph.path.name}: decision node '{node_id}' has fewer than 2 outgoing edges"
                )

        uncontrolled_path = uncontrolled_exit_path(graph, outgoing, start, exit_node)
        if uncontrolled_path:
            warnings.append(
                f"{graph.path.name}: found start-to-exit path with no goal gate or human gate: {' -> '.join(uncontrolled_path)}"
            )

    return errors, warnings


ALLOWED_OUTCOME_TOKENS = {
    "success",
    "partial_success",
    "blocked",
    "needs_more_evidence",
    "retry",
    "fail",
}


def lint_graph_status_conditions(
    specs: list[AgentSpec], graphs: dict[str, WorkflowGraph]
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    for spec in specs:
        if spec.workflow_role is None:
            continue
        if spec.workflow_binding == "contract_only":
            continue

        graph = graphs.get(spec.name)
        if graph is None:
            continue

        status_tokens = extract_status_tokens(spec.text)
        for edge in graph.edges:
            if "condition=" not in edge.attrs:
                continue

            condition_match = re.search(r'condition\s*=\s*"([^"]+)"', edge.attrs)
            if condition_match is None:
                errors.append(
                    f"{graph.path.name}: edge {edge.src} -> {edge.dst} has malformed condition attribute"
                )
                continue

            condition = condition_match.group(1).strip()
            parsed = re.fullmatch(r"outcome(!?=)([a-z_|]+)", condition)
            if parsed is None:
                errors.append(
                    f"{graph.path.name}: edge {edge.src} -> {edge.dst} uses unsupported condition '{condition}'"
                )
                continue

            statuses = parsed.group(2).split("|")
            for status in statuses:
                if status not in ALLOWED_OUTCOME_TOKENS:
                    errors.append(
                        f"{graph.path.name}: edge {edge.src} -> {edge.dst} references unsupported status '{status}'"
                    )
                if status not in status_tokens:
                    errors.append(
                        f"{graph.path.name}: edge {edge.src} -> {edge.dst} references status '{status}' not declared in {_spec_display_name(spec)}"
                    )

            if parsed.group(1) == "!=" and len(statuses) != 1:
                errors.append(
                    f"{graph.path.name}: edge {edge.src} -> {edge.dst} cannot use outcome!= with multiple statuses"
                )

    return errors, warnings


def lint_agent_specs(
    specs: list[AgentSpec], graphs: dict[str, WorkflowGraph]
) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    graph_names = set(graphs.keys())
    spec_names = {spec.name for spec in specs}

    for spec in specs:
        display = _spec_display_name(spec)
        if spec.workflow_role is None:
            continue

        if spec.workflow_role not in WORKFLOW_ROLES:
            errors.append(
                f"{display}: invalid workflow_role '{spec.workflow_role}'"
            )

        if (
            spec.workflow_binding is not None
            and spec.workflow_binding not in {"graph_aligned", "contract_only"}
        ):
            errors.append(
                f"{display}: invalid workflow_binding '{spec.workflow_binding}'"
            )

        if (
            spec.workflow_binding == "graph_aligned"
            and spec.workflow_role in {"orchestrator", "gate"}
            and not spec.graph_node_ids
        ):
            warnings.append(
                f"{display}: workflow_role={spec.workflow_role} but graph_node_ids is empty"
            )

        requires_graph = spec.workflow_binding == "graph_aligned"

        graph = graphs.get(spec.name)
        if requires_graph and graph is None:
            warnings.append(
                f"{display}: graph-aligned agent has no matching workflows/{spec.name}.dot"
            )
            continue

        if graph is not None:
            for node_id in spec.graph_node_ids:
                if node_id not in graph.nodes:
                    errors.append(
                        f"{display}: graph_node_id '{node_id}' not found in {graph.path.name}"
                    )

        for heading in REQUIRED_CONTRACT_SECTIONS:
            if re.search(rf"(?m)^{re.escape(heading)}\s*$", spec.text) is None:
                errors.append(
                    f"{display}: missing required section '{heading}'"
                )

        output_contract = extract_markdown_section(spec.text, "## Output Contract")
        if output_contract is not None:
            for heading in REQUIRED_OUTPUT_SUBHEADS:
                if re.search(rf"(?m)^{re.escape(heading)}\s*$", output_contract) is None:
                    errors.append(
                        f"{display}: output contract missing '{heading}'"
                    )

            for field_name in REQUIRED_REPORT_FIELDS:
                if field_name not in output_contract:
                    errors.append(
                        f"{display}: output contract missing report field {field_name}"
                    )

            for field_name in REQUIRED_EVIDENCE_FIELDS:
                if field_name not in output_contract:
                    errors.append(
                        f"{display}: output contract missing evidence field {field_name}"
                    )

        status_vocab = extract_markdown_section(spec.text, "## Status Vocabulary")
        if status_vocab is not None:
            for token in REQUIRED_STATUS_TOKENS:
                if token not in status_vocab:
                    errors.append(
                        f"{display}: status vocabulary missing {token}"
                    )

    for graph_name in sorted(graph_names - spec_names):
        warnings.append(
            f"workflows/{graph_name}.dot: no matching {graph_name}/SKILL.md found"
        )

    return errors, warnings


# ── A3: Graph ↔ SKILL.md cross-reference ─────────────────────────────────────

def lint_graph_spec_cross_reference(
    specs: list[AgentSpec], graphs: dict[str, WorkflowGraph]
) -> tuple[list[str], list[str]]:
    """Cross-validate graph node IDs against SKILL.md declarations."""
    errors: list[str] = []
    warnings: list[str] = []

    # Build a reverse map within each same-name graph only. Node IDs are local to a
    # workflow file, so `implementation` in pipeline-conductor.dot must not collide
    # with `implementation` in change-request-conductor.dot.
    claimed_nodes: dict[str, dict[str, list[str]]] = {}
    for spec in specs:
        if spec.workflow_binding != "graph_aligned":
            continue
        graph = graphs.get(spec.name)
        if graph is None:
            continue
        for node_id in spec.graph_node_ids:
            if node_id in graph.nodes:
                claimed_nodes.setdefault(spec.name, {}).setdefault(node_id, []).append(spec.name)

    # Check for graph nodes that no spec claims
    for graph_name, graph in graphs.items():
        for node_id, attrs in graph.nodes.items():
            shape = node_shape(attrs)
            if shape in ("Mdiamond", "Msquare"):
                continue  # start/exit nodes don't need spec coverage
            claimed_by = claimed_nodes.get(graph_name, {}).get(node_id, [])
            if not claimed_by:
                warnings.append(
                    f"{graph.path.name}: node '{node_id}' is not claimed by any SKILL.md graph_node_ids"
                )
            elif len(claimed_by) > 1:
                warnings.append(
                    f"{graph.path.name}: node '{node_id}' claimed by multiple specs: {', '.join(claimed_by)}"
                )

    return errors, warnings


# ── F3: Rejected-patterns feedback integration ────────────────────────────────

def lint_rejected_patterns(
    root: Path, specs: list[AgentSpec]
) -> tuple[list[str], list[str]]:
    """Read rejected-patterns.yaml (written by alice) and surface warnings.

    The file contains recurring failure patterns per agent/node that the
    runtime has observed. This lint pass surfaces them as warnings so SKILL.md
    authors can tighten their specs.
    """
    errors: list[str] = []
    warnings: list[str] = []

    rejected_file = root / "docs" / "rejected-patterns.yaml"
    if not rejected_file.exists():
        return errors, warnings

    try:
        data = yaml.safe_load(rejected_file.read_text(encoding="utf-8"))
    except (yaml.YAMLError, OSError):
        warnings.append("docs/rejected-patterns.yaml: could not parse file")
        return errors, warnings

    if not isinstance(data, dict) or "patterns" not in data:
        return errors, warnings

    spec_names = {s.name for s in specs}
    for pattern in data.get("patterns", []):
        if not isinstance(pattern, dict):
            continue
        agent = pattern.get("agent", "")
        code = pattern.get("failure_code", "")
        count = pattern.get("occurrences", 0)
        suggestion = pattern.get("suggestion", "")
        if agent and agent in spec_names:
            warnings.append(
                f"{agent}/SKILL.md: recurring failure '{code}' ({count}x). "
                f"Suggestion: {suggestion}"
            )

    return errors, warnings


def main() -> int:
    args = parse_args()
    root = Path(args.root).resolve()

    specs, frontmatter_errors, frontmatter_warnings = load_agent_specs(root)
    graphs = load_workflow_graphs(root)

    errors: list[str] = []
    warnings: list[str] = []

    graph_errors, graph_warnings = lint_graphs(graphs)
    spec_errors, spec_warnings = lint_agent_specs(specs, graphs)
    condition_errors, condition_warnings = lint_graph_status_conditions(specs, graphs)
    crossref_errors, crossref_warnings = lint_graph_spec_cross_reference(specs, graphs)
    rejected_errors, rejected_warnings = lint_rejected_patterns(root, specs)

    errors.extend(frontmatter_errors)
    errors.extend(graph_errors)
    errors.extend(spec_errors)
    errors.extend(condition_errors)
    errors.extend(crossref_errors)
    errors.extend(rejected_errors)
    warnings.extend(frontmatter_warnings)
    warnings.extend(graph_warnings)
    warnings.extend(spec_warnings)
    warnings.extend(condition_warnings)
    warnings.extend(crossref_warnings)
    warnings.extend(rejected_warnings)

    print("## Workflow Lint")
    print()
    print(f"Graphs checked: {len(graphs)}")
    print(f"Agent specs checked: {len([s for s in specs if s.workflow_role is not None])}")
    print()

    if errors:
        print("Errors:")
        for item in errors:
            print(f"- {item}")
        print()

    if warnings:
        print("Warnings:")
        for item in warnings:
            print(f"- {item}")
        print()

    if not errors and not warnings:
        print("No issues found.")

    if errors:
        return 1
    if warnings and args.strict_warnings:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
