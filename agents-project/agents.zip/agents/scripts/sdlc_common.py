#!/usr/bin/env python3
from __future__ import annotations

import json
import re
from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml


FRONTMATTER_RE = re.compile(r"^---\r?\n(.*?)\r?\n---\r?\n?", re.S)
ISO_TIMESTAMP_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$"
)
SEMVER_TAG_RE = re.compile(r"^v\d+\.\d+\.\d+$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
EXCLUDED_DIRS = {
    ".git",
    ".hg",
    ".svn",
    "node_modules",
    ".venv",
    "venv",
    "__pycache__",
    "dist",
    "build",
    "site",
}


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def load_yaml(path: Path) -> Any:
    return yaml.safe_load(read_text(path))


def dump_yaml(data: Any) -> str:
    text = yaml.safe_dump(data, sort_keys=False, allow_unicode=False)
    return text if text.endswith("\n") else f"{text}\n"


def write_yaml(path: Path, data: Any) -> None:
    write_text(path, dump_yaml(data))


def load_data_file(path: Path) -> Any:
    if path.suffix.lower() == ".json":
        return json.loads(read_text(path))
    return load_yaml(path)


def parse_frontmatter_markdown(path: Path) -> tuple[dict[str, Any], str]:
    text = read_text(path)
    match = FRONTMATTER_RE.match(text)
    if not match:
        return {}, text
    data = yaml.safe_load(match.group(1)) or {}
    if not isinstance(data, dict):
        raise ValueError(f"{path}: frontmatter must be a mapping")
    return data, text[match.end() :]


def deep_merge(base: Any, override: Any) -> Any:
    if not isinstance(base, dict) or not isinstance(override, dict):
        return deepcopy(override)

    merged = deepcopy(base)
    for key, value in override.items():
        if key in merged:
            merged[key] = deep_merge(merged[key], value)
        else:
            merged[key] = deepcopy(value)
    return merged


def ensure_string_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item) for item in value if str(item).strip()]
    if isinstance(value, str) and value.strip():
        return [value]
    return []


def is_non_empty_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def normalized_relpath(value: str) -> str:
    return value.replace("\\", "/").strip()


def resolve_relative(root: Path, value: str) -> Path:
    return root / Path(normalized_relpath(value))


def file_exists(root: Path, relative_path: str) -> bool:
    return resolve_relative(root, relative_path).is_file()


def dir_exists(root: Path, relative_path: str) -> bool:
    return resolve_relative(root, relative_path).is_dir()


def any_matching_file(root: Path, relative_dir: str, pattern: str) -> bool:
    directory = resolve_relative(root, relative_dir)
    return directory.is_dir() and any(directory.glob(pattern))


def find_files(root: Path, patterns: list[str]) -> list[Path]:
    matches: list[Path] = []
    for pattern in patterns:
        for path in root.rglob(pattern):
            if any(part in EXCLUDED_DIRS for part in path.parts):
                continue
            matches.append(path)
    return sorted({path.resolve() for path in matches})


def first_existing(root: Path, candidates: list[str]) -> Path | None:
    for candidate in candidates:
        path = resolve_relative(root, candidate)
        if path.exists():
            return path
    return None


def load_project_config(root: Path) -> dict[str, Any] | None:
    path = resolve_relative(root, ".factory/project.yaml")
    if not path.is_file():
        return None
    data = load_yaml(path)
    if not isinstance(data, dict):
        raise ValueError("`.factory/project.yaml` must parse as a mapping.")
    return data


def is_iso_timestamp(value: Any) -> bool:
    return isinstance(value, str) and ISO_TIMESTAMP_RE.fullmatch(value) is not None


def is_semver_tag(value: Any) -> bool:
    return isinstance(value, str) and SEMVER_TAG_RE.fullmatch(value) is not None


def is_iso_date(value: Any) -> bool:
    return isinstance(value, str) and DATE_RE.fullmatch(value) is not None


def is_browser_ui(frameworks: dict[str, Any], rendering_mode: str | None) -> bool:
    ui_items = [item.lower() for item in ensure_string_list(frameworks.get("ui"))]
    if any(item not in {"none", "api-only"} for item in ui_items):
        return True
    normalized_mode = (rendering_mode or "").strip().lower()
    return normalized_mode in {"spa", "server-rendered", "hybrid"}


def emit_report(report: dict[str, Any], as_json: bool) -> None:
    if as_json:
        print(json.dumps(report, indent=2))
        return

    print(f"Status: {report['status']}")
    print(report["summary"])

    for key in ("errors", "warnings"):
        items = report.get(key, [])
        if not items:
            continue
        print(f"{key.title()}:")
        for item in items:
            print(f"- {item}")

    for key, value in report.items():
        if key in {"status", "summary", "errors", "warnings"}:
            continue
        print(f"{key}: {json.dumps(value, indent=2)}")


def build_report(
    summary: str,
    *,
    errors: list[str] | None = None,
    warnings: list[str] | None = None,
    **extra: Any,
) -> dict[str, Any]:
    errors = errors or []
    warnings = warnings or []
    if errors:
        status = "FAIL"
    elif warnings:
        status = "PASS-WITH-WARNINGS"
    else:
        status = "PASS"

    report: dict[str, Any] = {
        "status": status,
        "summary": summary,
        "errors": errors,
        "warnings": warnings,
    }
    report.update(extra)
    return report


def exit_code_for(report: dict[str, Any], strict_warnings: bool = False) -> int:
    if report.get("errors"):
        return 1
    if strict_warnings and report.get("warnings"):
        return 1
    return 0
