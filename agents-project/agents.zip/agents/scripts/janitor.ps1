[CmdletBinding()]
param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$ForwardArgs
)

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$runner = Join-Path $scriptDir "janitor.py"

if (Get-Command py -ErrorAction SilentlyContinue) {
    & py -3 $runner @ForwardArgs
    exit $LASTEXITCODE
}

if (Get-Command python -ErrorAction SilentlyContinue) {
    & python $runner @ForwardArgs
    exit $LASTEXITCODE
}

if (Get-Command uv -ErrorAction SilentlyContinue) {
    & uv run python $runner @ForwardArgs
    exit $LASTEXITCODE
}

Write-Error "janitor.ps1 requires py, python, or uv on PATH."
exit 1
