---
name: rfp-strategy-shaper
description: "Use when you need to shape a bid strategy from the compliance matrix by defining win themes, discriminators, proof priorities, section depth, and a visual / exhibit brief grounded in standard artifact types."
workflow_role: worker
workflow_binding: contract_only
primary_outputs:
  - response strategy brief
  - response outline
  - response visual brief
default_next:
  success: rfp-response-drafter
  partial_success: human approval boundary
  blocked: user escalation or clarification path
  needs_more_evidence: missing customer or capability context
  fail: rerun after compliance repair
---

# Purpose

Turn a compliance view into a persuasive response strategy. This node decides how the bid should win, what it should emphasize, how deep each major section should go, and where visuals or exhibits should carry evaluator understanding. It does not write the full proposal body.

## Workflow role

- Role: `worker`
- Binding: `contract_only`
- Goal gate: no
- Human approval node: yes, when strategic positioning or differentiators need confirmation
- Typical predecessors: `rfp-compliance-mapper`
- Typical successors: `rfp-response-drafter`

## Inputs

### Required

- `rfp/<RFP-ID>/intake/rfp-intake.md`
- `rfp/<RFP-ID>/compliance/compliance-matrix.yaml`

### Optional

- organization capability library
- approved case studies and references
- customer intelligence
- account strategy notes
- legal or commercial guardrails
- approved design exemplars or brand-approved proposal samples

## Preconditions

1. Compliance matrix exists and mandatory unresolved items are not being ignored.
2. Differentiators must be grounded in real capability, not aspiration.
3. Any unsupported strategic promise must be flagged, not normalized.

## Procedure

1. Read the intake summary and compliance matrix in full.
2. Identify evaluator priorities, decision risks, and high-weight scoring areas.
3. Define:
   - 2-4 win themes
   - core discriminators
   - likely objections or evaluator concerns
   - proof priorities for high-value claims
   - score-moving process, work-product, and delivery details that must not stay generic
4. Build a response outline that maps sections to requirement groups, proof moments, and section depth expectations.
5. Build a visual / exhibit brief that identifies where the response should use tables, timelines, process flows, governance views, architecture views, matrices, or other simple graphics instead of text-only explanation, and record which approved design exemplar or style family each visual should align to when one exists.
6. For each score-moving visual, prefer a supported artifact type from `powerpoint-rfp-generator/artifacts/catalog.yaml` and record:
   - candidate `artifact_type`
   - section or requirement coverage
   - scoring purpose
   - expected data shape or source path
   - whether native PowerPoint rendering should be preferred
   - approved design reference or design-profile seed when available
7. Record any strategic dependency that still needs human confirmation.

## Output Contract

### Artifacts

- `rfp/<RFP-ID>/strategy/response-strategy.md`
- `rfp/<RFP-ID>/strategy/response-outline.yaml`
- `rfp/<RFP-ID>/strategy/response-visual-brief.yaml`

### Report Fields

- `status`
- `summary`
- `artifacts`
- `evidence_checked`
- `warnings`
- `escalations`
- `next_action`
- `handoff_target`

### Evidence Entry Fields

- `claim`
- `proof`
- `freshness`
- `result`

## Status Vocabulary

- `success` - a usable strategy brief and outline were produced
- `partial_success` - the strategy is usable, but one or more strategic choices still need confirmation
- `blocked` - no credible strategic path exists because key tender or capability gaps remain
- `needs_more_evidence` - customer, evaluator, or capability context is too thin to set a strong strategy
- `fail` - strategy shaping failed because upstream inputs were unusable

## Done Criteria

1. Win themes and discriminators are explicit.
2. Outline aligns to tender requirements and scoring logic.
3. Proof priorities are visible.
4. Section-level depth expectations are visible for score-moving sections.
5. Visual / exhibit guidance exists where it would improve evaluator understanding.
6. Preferred artifact types are explicit for score-moving visuals.
7. Unsupported strategic promises are called out.

## Evidence Requirements

- Claim: a discriminator is credible -> proof: supporting capability or reference source was identified in this run
- Claim: a win theme matches evaluator priorities -> proof: tender scoring or requirement signals were checked in this run
- Claim: an objection matters -> proof: compliance matrix, tender language, or source risk signal was checked in this run
- Claim: a richer section or exhibit is needed -> proof: tender scoring logic, complexity, or evaluator risk signal was checked in this run
- Claim: a preferred artifact type fits the need -> proof: visual intent and supported catalog pattern were matched in this run
- Claim: a visual should follow a specific design language -> proof: the approved exemplar or style reference was recorded in this run

## Failure Routing

- unresolved mandatory compliance gap -> `blocked`
- weak or unsupported differentiator set -> `needs_more_evidence`
- no clear high-value path through evaluator priorities -> `needs_more_evidence`
- unusable upstream inputs -> `fail`

## Escalation Rules

1. Escalate when proposed differentiators depend on unapproved commercial or delivery commitments.
2. Escalate when customer priorities appear internally contradictory.
3. Escalate when the best strategic position conflicts with approved organizational positioning.

## Never Do

- never treat a generic capability statement as a discriminator
- never recommend a promise that the evidence base cannot support
- never let the outline drift away from the compliance matrix
- never confuse internal preference with evaluator value
- never stop at title-only outline shells when a scored section needs explicit process, work-product, or exhibit guidance

