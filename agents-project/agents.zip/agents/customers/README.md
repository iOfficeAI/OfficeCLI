# Customer Style Packs

Customer style packs provide reusable tone, structure, and scoring guidance for the CV pipeline.

## Directory layout

```text
customers/
  <CUSTOMER>/
    style-guide.md
    section-targets.yaml
    terminology.yaml
    scoring-hints.yaml
    good-examples/
      <section>-<id>.md
```

## Usage intent

- `style-guide.md`: voice, tone, and phrasing constraints.
- `section-targets.yaml`: target section length and structure.
- `terminology.yaml`: preferred terms and forbidden substitutions.
- `scoring-hints.yaml`: evaluator emphasis and penalty patterns.
- `good-examples/*.md`: approved exemplar snippets with rationale and reuse guardrails.

## Important guardrails

1. Example snippets are framing references, not copy text.
2. Candidate-owned evidence always remains the proof source.
3. Style packs may shape phrasing and depth, never fabricate facts.

