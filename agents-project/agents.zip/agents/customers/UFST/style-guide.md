# UFST Style Guide (CV Responses)

## Voice and tone

- Formal, precise, and public-sector appropriate.
- Confident but non-promissory.
- Evidence-forward before adjectives.
- Method-first framing with explicit "how" and "why it works".

## Preferred writing pattern

1. Direct requirement answer.
2. Candidate relevance in UFST context.
3. Concrete evidence (role, scope, method, outcome).
4. Short link to governance, collaboration, or implementation impact.

## Preferred section macro (when methods/tools are evaluated)

1. Inddragelse og nyttiggoerelse af metoder og vaerktoejer.
2. Relevans for Skatteministeriets Koncern.
3. Effektivitet.
4. Kvalitet.

## Language guidance

- Prefer Danish terminology used in tender material when available.
- Keep sentences compact and specific.
- Avoid sales-heavy wording and generic transformation buzzwords.
- Tie each method/tool to practical execution steps (not only framework names).

## Preferred wording

- "dokumenteret erfaring med"
- "har ansvar for"
- "har gennemført i offentlig kontekst"
- "understøtter styring, koordinering og leverancekvalitet"
- "transparens og sporbarhed"
- "forankring i forretningen"
- "understoetter statens it-projektmodel"
- "skaleres til projektets/programmets karakter"

## Avoid

- "verdensklasse", "unik", "banebrydende"
- unsupported quantification
- vague claims without source anchor
- framework name-dropping without concrete nyttiggoerelse

## Evidence rule

Non-trivial claims must be traceable to candidate-owned evidence paths in the active run.

