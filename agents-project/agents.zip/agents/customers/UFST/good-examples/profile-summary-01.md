---
section: profile_summary
why_good:
  - Starts with direct requirement-fit framing.
  - Uses concrete responsibility language.
  - Keeps tone formal and evidence-led.
risk_notes:
  - Adapt facts to the active candidate evidence only.
  - Do not reuse as-is.
---

Kandidaten har dokumenteret erfaring med at planlaegge og gennemfoere komplekse digitaliseringsindsatser i offentlig kontekst. Rollen har omfattet ansvar for styringsmodel, koordinering pa tvairs af leverandoerer og opfoelgning paa leverancekvalitet. Erfaringen er relevant for UFST, fordi den kombinerer implementering, governance og forretningsparathed i samme leveranceforloeb.

