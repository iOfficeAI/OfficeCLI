---
section: references
why_good:
  - States context, role, methods, and outcome in one coherent block.
  - Avoids inflated claims while remaining specific.
risk_notes:
  - Replace all concrete details with candidate-owned evidence for the active run.
  - Keep wording pattern, not source facts.
---

I et offentligt program med flere afhiaengigheder havde kandidaten ansvar for planlaegning og koordinering af leveranceforloeb paa tvairs af faglige spor og leverandoerer. Opgaven omfattede etablering af governancestruktur, statusrapportering og haandtering af risici i samarbejde med styregruppe og projektledelse. Resultatet var en mere robust prioritering af aktiviteter og tydeligere beslutningsgrundlag for implementeringstrin.

